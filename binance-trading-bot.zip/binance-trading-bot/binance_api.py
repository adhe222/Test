import time
import hmac
import threading
import hashlib
from urllib.parse import urlencode
from typing import Dict, List, Optional, Any
import requests

import config as _cfg
import dns_route
from config import BINANCE_API_URL, BINANCE_API_KEY, BINANCE_API_SECRET
try:
    from config import BINANCE_PROXY_URL
except ImportError:
    BINANCE_PROXY_URL = ""

DEFAULT_ENDPOINTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com"
]

FUTURES_ENDPOINTS = [
    "https://fapi.binance.com",
    "https://fapi1.binance.com",
    "https://fapi2.binance.com",
    "https://fapi3.binance.com",
]


class BinanceClient:
    exchange_name = "binance"
    supports_spot = True
    supports_futures = True

    def __init__(self, base_url: str = BINANCE_API_URL, api_key: str = BINANCE_API_KEY, api_secret: str = BINANCE_API_SECRET):
        primary = base_url.rstrip("/") if base_url else "https://data-api.binance.vision"
        endpoints = [primary]
        for ep in DEFAULT_ENDPOINTS:
            if ep not in endpoints:
                endpoints.append(ep)
        self.endpoints = endpoints
        self.active_base_url = primary
        self.active_futures_url = FUTURES_ENDPOINTS[0]
        self._cache = {}
        self._cache_lock = threading.Lock()
        self._futures_info_cache = {}
        self._futures_info_all = (0.0, {})
        self._futures_health = {}
        self._futures_blocked_until = 0.0
        self._spot_info_all = (0.0, {})
        dns_route.ensure_routing()
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        if BINANCE_PROXY_URL:
            self.session.proxies = {"http": BINANCE_PROXY_URL, "https": BINANCE_PROXY_URL}
        if self.api_key:
            self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    def _sign_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _cache_get(self, key: str) -> Optional[Any]:
        with self._cache_lock:
            entry = self._cache.get(key)
            if entry and entry[0] > time.time():
                return entry[1]
        return None

    def _cache_set(self, key: str, ttl_sec: float, value: Any) -> None:
        with self._cache_lock:
            self._cache[key] = (time.time() + float(ttl_sec), value)

    def clear_cache(self) -> None:
        with self._cache_lock:
            self._cache.clear()

    def _request_with_fallback(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 4.0) -> requests.Response:
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}{path}"
            try:
                resp = self.session.request(method, url, params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_base_url = base
                return resp
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint")

    @staticmethod
    def _normalize_market(market: Optional[str]) -> str:
        return "FUTURES" if str(market or "SPOT").upper() in ("FUTURES", "SWAP", "PERP") else "SPOT"

    def _futures_order(self) -> List[str]:
        now = time.time()
        healthy = [ep for ep in FUTURES_ENDPOINTS if self._futures_health.get(ep, 0.0) <= now]
        ordered: List[str] = []
        if self.active_futures_url in healthy:
            ordered.append(self.active_futures_url)
        ordered.extend(ep for ep in healthy if ep != self.active_futures_url)
        if not ordered:
            self._futures_blocked_until = max(
                self._futures_blocked_until,
                now + float(getattr(_cfg, "FUTURES_FEED_BACKOFF_SEC", 180)),
            )
        return ordered

    def _futures_request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None,
                         timeout: float = 5.0) -> requests.Response:
        now = time.time()
        if now < self._futures_blocked_until:
            raise requests.exceptions.ConnectionError(
                f"Binance Futures feed cooling down for {int(self._futures_blocked_until - now)}s "
                "after repeated connect failures"
            )
        ordered = self._futures_order()
        if not ordered:
            raise requests.exceptions.ConnectionError("No reachable Binance Futures endpoint")
        cooldown = float(getattr(_cfg, "FUTURES_ENDPOINT_COOLDOWN_SEC", 300))
        last_exc = None
        failed = 0
        for base in ordered:
            try:
                resp = self.session.request(method, f"{base}{path}", params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_futures_url = base
                self._futures_health.pop(base, None)
                return resp
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                failed += 1
                self._futures_health[base] = time.time() + cooldown
                continue
        if failed >= len(FUTURES_ENDPOINTS):
            self._futures_blocked_until = time.time() + float(getattr(_cfg, "FUTURES_FEED_BACKOFF_SEC", 180))
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance Futures API endpoint")

    def _ensure_futures_info(self) -> Dict[str, float]:
        expiry, mapping = self._futures_info_all
        if expiry > time.time() and mapping:
            return mapping
        resp = self._futures_request("GET", "/fapi/v1/exchangeInfo", timeout=6.0)
        mapping = {}
        for item in resp.json().get("symbols", []):
            step = 0.001
            for f in item.get("filters", []):
                if f.get("filterType") == "LOT_SIZE":
                    step = float(f.get("stepSize", step))
                    break
            mapping[item.get("symbol")] = step
        self._futures_info_all = (time.time() + 3600.0, mapping)
        return mapping

    def _futures_symbols(self) -> set:
        try:
            return set(self._ensure_futures_info().keys())
        except Exception:
            return set()

    def _futures_step_size(self, symbol: str) -> float:
        entry = self._futures_info_cache.get(symbol)
        if entry and entry[0] > time.time():
            return entry[1]
        step = self._ensure_futures_info().get(symbol, 0.001)
        self._futures_info_cache[symbol] = (time.time() + 3600.0, step)
        return step

    def _spot_filters(self) -> Dict[str, Dict[str, float]]:
        expiry, mapping = self._spot_info_all
        if expiry > time.time() and mapping:
            return mapping
        resp = self._request_with_fallback("GET", "/api/v3/exchangeInfo", timeout=8.0)
        mapping = {}
        for item in resp.json().get("symbols", []):
            step = 0.00000001
            min_qty = 0.0
            min_notional = 0.0
            for f in item.get("filters", []):
                kind = f.get("filterType")
                if kind == "LOT_SIZE":
                    step = float(f.get("stepSize", step) or step)
                    min_qty = float(f.get("minQty", 0.0) or 0.0)
                elif kind in ("NOTIONAL", "MIN_NOTIONAL"):
                    min_notional = float(f.get("minNotional", f.get("notional", 0.0)) or 0.0)
            mapping[item.get("symbol")] = {"step": step, "min_qty": min_qty, "min_notional": min_notional}
        self._spot_info_all = (time.time() + 3600.0, mapping)
        return mapping

    @staticmethod
    def _step_decimals(step: float) -> int:
        text = f"{float(step):.12f}".rstrip("0")
        return len(text.split(".")[1]) if "." in text else 0

    def _format_spot_quantity(self, symbol: str, quantity: float) -> str:
        info = self._spot_filters().get(symbol, {})
        step = float(info.get("step", 0.00000001) or 0.00000001)
        value = self._round_step(float(quantity), step)
        min_qty = float(info.get("min_qty", 0.0) or 0.0)
        if value <= 0:
            raise ValueError(f"Spot quantity {quantity} below step size {step} for {symbol}")
        if min_qty > 0 and value < min_qty:
            raise ValueError(f"Spot quantity {value} below exchange minimum {min_qty} for {symbol}")
        return f"{value:.{min(self._step_decimals(step), 8)}f}"

    @staticmethod
    def _round_step(value: float, step: float) -> float:
        if step <= 0:
            return value
        return int(round(value / step, 8)) * step

    def get_24hr_tickers(self, market: Optional[str] = None) -> List[Dict[str, Any]]:
        market_name = self._normalize_market(market) if market else None
        key = f"tickers:24hr:{market_name or 'ALL'}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        spot_rows: List[Dict[str, Any]] = []
        futures_rows: List[Dict[str, Any]] = []
        futures_symbols = set()
        if market_name in (None, "SPOT"):
            resp = self._request_with_fallback("GET", "/api/v3/ticker/24hr", timeout=6.0)
            spot_rows = resp.json()
        if market_name in (None, "FUTURES"):
            if market_name == "FUTURES":
                resp = self._futures_request("GET", "/fapi/v1/ticker/24hr", timeout=8.0)
                futures_rows = resp.json()
            futures_symbols = self._futures_symbols()
        merged: Dict[str, Dict[str, Any]] = {}
        for row in spot_rows:
            symbol = row.get("symbol")
            if not symbol:
                continue
            item = dict(row)
            item["markets"] = ["SPOT"] + (["FUTURES"] if symbol in futures_symbols else [])
            merged[symbol] = item
        for row in futures_rows:
            symbol = row.get("symbol")
            if not symbol:
                continue
            existing = merged.get(symbol)
            if existing is None:
                item = dict(row)
                item["markets"] = ["FUTURES"]
                merged[symbol] = item
            else:
                existing["markets"] = sorted(set(existing.get("markets") or []) | {"FUTURES"})
        data = list(merged.values())
        self._cache_set(key, getattr(_cfg, "TICKER_CACHE_TTL_SEC", 25), data)
        return data

    def get_price(self, symbol: str, market: Optional[str] = None) -> float:
        market_name = self._normalize_market(market)
        key = f"price:{market_name}:{symbol}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        if market_name == "FUTURES":
            resp = self._futures_request("GET", "/fapi/v1/ticker/price", params={"symbol": symbol}, timeout=4.0)
        else:
            resp = self._request_with_fallback("GET", "/api/v3/ticker/price", params={"symbol": symbol}, timeout=4.0)
        data = resp.json()
        price = float(data["price"])
        self._cache_set(key, getattr(_cfg, "PRICE_CACHE_TTL_SEC", 10), price)
        return price

    _KLINE_INTERVAL_SEC = {
        "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "8h": 28800,
        "12h": 43200, "1d": 86400,
    }

    def _klines_cache_ttl(self, interval: str) -> float:
        cap = float(getattr(_cfg, "KLINES_CACHE_TTL_SEC", 120))
        interval_sec = self._KLINE_INTERVAL_SEC.get(interval, 900)
        return max(15.0, min(cap, interval_sec / 4.0))

    def get_klines(self, symbol: str, interval: str = "15m", limit: int = 100,
                   market: Optional[str] = None) -> List[Dict[str, Any]]:
        market_name = self._normalize_market(market)
        key = f"klines:{market_name}:{symbol}:{interval}:{limit}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        requested_at = time.time()
        if market_name == "FUTURES":
            resp = self._futures_request("GET", "/fapi/v1/klines", params=params, timeout=5.0)
        else:
            resp = self._request_with_fallback("GET", "/api/v3/klines", params=params, timeout=5.0)
        raw_klines = resp.json()

        klines = []
        for k in raw_klines:
            klines.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "quote_volume": float(k[7]),
                "trades": int(k[8]),
                "is_closed": int(k[6]) < requested_at * 1000,
            })
        ttl = self._klines_cache_ttl(interval)
        if klines:
            close_time = klines[-1].get("close_time")
            if close_time and not klines[-1]["is_closed"]:
                seconds_to_close = (float(close_time) + 1.0) / 1000.0 - time.time()
                ttl = min(ttl, max(0.0, seconds_to_close))
        self._cache_set(key, ttl, klines)
        return klines

    def get_orderbook(self, symbol: str, limit: int = 20, use_cache: bool = True,
                      market: Optional[str] = None) -> Dict[str, Any]:
        market_name = self._normalize_market(market)
        key = f"depth:{market_name}:{symbol}:{limit}"
        if use_cache:
            cached = self._cache_get(key)
            if cached is not None:
                return cached
        params = {"symbol": symbol, "limit": limit}
        data = None
        for attempt in range(2):
            try:
                if market_name == "FUTURES":
                    resp = self._futures_request("GET", "/fapi/v1/depth", params=params, timeout=4.0)
                else:
                    resp = self._request_with_fallback("GET", "/api/v3/depth", params=params, timeout=4.0)
                data = resp.json()
                break
            except Exception:
                if attempt:
                    raise
                time.sleep(0.6)
        bids = [[float(p), float(q)] for p, q in data.get("bids", [])]
        asks = [[float(p), float(q)] for p, q in data.get("asks", [])]
        book = {"bids": bids, "asks": asks}
        if use_cache:
            self._cache_set(key, getattr(_cfg, "ORDERBOOK_CACHE_TTL_SEC", 8), book)
        return book

    def get_account_info(self) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for private account endpoints.")
        params = self._sign_params({})
        resp = self._request_with_fallback("GET", "/api/v3/account", params=params, timeout=6.0)
        return resp.json()

    def place_order(self, symbol: str, side: str, order_type: str = "MARKET",
                    quantity: Optional[float] = None, quote_order_qty: Optional[float] = None,
                    market: Optional[str] = None, reduce_only: bool = False,
                    close_full: bool = False) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        market_name = self._normalize_market(market)
        if market_name == "FUTURES":
            if quantity is None:
                if quote_order_qty is None:
                    raise ValueError("Either quantity or quote_order_qty must be provided.")
                price = self.get_price(symbol, market="FUTURES")
                quantity = float(quote_order_qty) / price if price > 0 else 0.0
            step = self._futures_step_size(symbol)
            qty = self._round_step(float(quantity), step)
            if qty <= 0:
                raise ValueError(f"Futures quantity {quantity} below step size {step} for {symbol}")
            params: Dict[str, Any] = {
                "symbol": symbol,
                "side": side.upper(),
                "type": order_type.upper(),
                "quantity": f"{qty:.8f}".rstrip("0").rstrip("."),
            }
            if reduce_only:
                params["reduceOnly"] = "true"
            params = self._sign_params(params)
            ordered = [self.active_futures_url] + [ep for ep in FUTURES_ENDPOINTS if ep != self.active_futures_url]
            last_exc = None
            for base in ordered:
                try:
                    resp = self.session.post(f"{base}/fapi/v1/order", params=params, timeout=6.0)
                    resp.raise_for_status()
                    self.active_futures_url = base
                    return resp.json()
                except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                    last_exc = exc
                    continue
            if last_exc:
                raise last_exc
            raise RuntimeError("No available Binance Futures API endpoint for placing order")
        params = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper()
        }
        filters = self._spot_filters().get(symbol, {})
        if quantity is not None:
            params["quantity"] = self._format_spot_quantity(symbol, quantity)
        elif quote_order_qty is not None:
            notional_floor = float(filters.get("min_notional", 0.0) or 0.0)
            if notional_floor > 0 and float(quote_order_qty) < notional_floor:
                raise ValueError(
                    f"Spot notional {quote_order_qty} below exchange minimum {notional_floor} for {symbol}"
                )
            params["quoteOrderQty"] = f"{float(quote_order_qty):.2f}"
        else:
            raise ValueError("Either quantity or quote_order_qty must be provided.")

        params = self._sign_params(params)
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}/api/v3/order"
            try:
                resp = self.session.post(url, params=params, timeout=6.0)
                resp.raise_for_status()
                self.active_base_url = base
                return resp.json()
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint for placing order")

    def _signed_request(self, method: str, path: str, params: Dict[str, Any], timeout: float = 8.0) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        params = self._sign_params(dict(params))
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}{path}"
            try:
                resp = self.session.request(method, url, params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_base_url = base
                return resp.json()
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError(f"No available Binance API endpoint for {path}")

    def place_oco_order(self, symbol: str, side: str, quantity: float,
                        take_profit_price: float, stop_price: float, stop_limit_price: float,
                        market: Optional[str] = None) -> Dict[str, Any]:
        """Server-side OCO (spot): TP limit + SL stop-limit on one order list.

        Live-mode insurance only: if this process dies, the exchange still
        executes the stop. Paper mode never calls this.
        """
        if self._normalize_market(market) == "FUTURES":
            raise NotImplementedError("Binance Futures has no OCO order list; polling exits remain active.")
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "quantity": f"{quantity:.6f}",
            "price": f"{take_profit_price:.6f}",
            "stopPrice": f"{stop_price:.6f}",
            "stopLimitPrice": f"{stop_limit_price:.6f}",
            "stopLimitTimeInForce": "GTC",
        }
        return self._signed_request("POST", "/api/v3/order/oco", params)

    def cancel_oco_order(self, symbol: str, order_list_id: int,
                         market: Optional[str] = None) -> Dict[str, Any]:
        if self._normalize_market(market) == "FUTURES":
            raise NotImplementedError("Binance Futures has no OCO order list.")
        params: Dict[str, Any] = {"symbol": symbol, "orderListId": int(order_list_id)}
        return self._signed_request("DELETE", "/api/v3/order/oco", params)

    def get_funding_rate(self, symbol: str, market: Optional[str] = None) -> Optional[float]:
        """Futures funding (fraction, e.g. 0.0001 == 0.01%/8h) or None.

        fapi.* is blocked by some ISPs (TrustPositif). Each blocked call costs
        two 3s timeouts per SHORT candidate, so after a full failure we back
        off for FUNDING_FETCH_BACKOFF_SEC instead of paying it every candidate.
        """
        import config as _cfg
        now = time.time()
        if now < getattr(self, "_funding_backoff_until", 0.0):
            return None
        endpoints = [
            f"https://fapi.binance.com/fapi/v1/premiumIndex?symbol={symbol}",
            f"https://fapi1.binance.com/fapi/v1/premiumIndex?symbol={symbol}"
        ]
        reachable = False
        for url in endpoints:
            try:
                resp = self.session.get(url, timeout=3.0)
                reachable = True
                if resp.status_code == 200:
                    data = resp.json()
                    if "lastFundingRate" in data:
                        return float(data["lastFundingRate"])
            except Exception:
                continue
        if not reachable:
            self._funding_backoff_until = now + float(getattr(_cfg, "FUNDING_FETCH_BACKOFF_SEC", 900))
        return None
