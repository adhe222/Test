from typing import Any

import config
from binance_api import BinanceClient
from okx_api import OKXClient

SUPPORTED_EXCHANGES = ("binance", "okx")


def create_exchange_client(exchange: str = None, **kwargs: Any):
    name = (exchange or getattr(config, "EXCHANGE", "binance") or "binance").strip().lower()
    if name == "okx":
        return OKXClient(**kwargs)
    if name in ("binance", "binance_spot"):
        return BinanceClient(**kwargs)
    raise ValueError(f"Unsupported exchange {name!r}; valid: {', '.join(SUPPORTED_EXCHANGES)}")


def exchange_label(client: Any = None) -> str:
    name = getattr(client, "exchange_name", None) or getattr(config, "EXCHANGE", "binance")
    return str(name).upper()
