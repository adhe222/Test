window.AegisOperations = (() => {
  'use strict';
  const U = window.AegisUtil;
  const labels = {
    WAITING_SETUP: 'Menunggu setup valid',
    SELECTIVE: 'Selektif · risiko 50%',
    MACRO_PAUSED: 'Entry ditahan makro',
    WAITING_DATA: 'Menunggu data makro',
    DAILY_PAUSED: 'Batas rugi harian',
    CAPACITY_FULL: 'Slot posisi penuh',
    DISABLED: 'Dinonaktifkan',
    UNSUPPORTED: 'Mode tidak dikenal',
    EXECUTED: 'Dieksekusi pada siklus ini',
    BLOCKED: 'Entry ditolak',
    AWAITING_APPROVAL: 'Menunggu persetujuan'
  };
  let lastRoutes = '';
  let lastAudit = '';

  function rows(value) {
    const result = Array.isArray(value) ? value : value?.items ?? [];
    return Array.isArray(result) ? result.filter((row) => row && typeof row === 'object') : [];
  }

  function stamp(value) {
    if (!value) return 'Belum ada scan lengkap';
    const date = new Date(value);
    return isNaN(date.getTime()) ? 'Waktu scan belum valid' : new Intl.DateTimeFormat('id-ID', {
      dateStyle: 'medium', timeStyle: 'medium'
    }).format(date);
  }

  function badge(text, ready = false) {
    return '<span class="operation-badge ' + (ready ? 'ready' : 'paused') + '">' + U.esc(text) + '</span>';
  }

  function routeHTML(route) {
    const isShort = route.direction === 'SHORT';
    const simulated = route.execution === 'SIMULATION';
    const execution = simulated ? 'Simulasi PAPER' : route.execution === 'SPOT_ORDER_PATH' ? 'Jalur order Spot LIVE' : route.execution === 'FUTURES_ORDER_PATH' ? 'Jalur order Futures LIVE' : 'Routing tidak tersedia';
    return '<section class="market-route" aria-label="' + (isShort ? 'Futures SHORT' : 'Spot LONG') + '">' +
      '<div class="route-identity"><h3 translate="no">' + (isShort ? 'FUTURES SHORT' : 'SPOT LONG') + '</h3><p>' + execution +
      ' · ' + (route.configured ? 'Konfigurasi aktif' : 'Konfigurasi nonaktif') + '</p></div>' +
      '<div class="route-permission">' + badge(labels[route.status] || 'Status belum tersedia', route.entry_eligible === true) +
      '<p>' + U.esc(route.reason) + '</p></div>' +
      '<dl class="route-counts"><div><dt>Kandidat</dt><dd>' + U.safe(route.candidate_count) + '</dd></div>' +
      '<div><dt>Posisi</dt><dd>' + U.safe(route.position_count) + '</dd></div>' +
      '<div><dt>Lolos kualitas</dt><dd>' + U.safe(route.quality_pass_count) + '</dd></div></dl></section>';
  }

  function candidateHTML(row) {
    const reasons = Array.isArray(row.blockers) ? row.blockers : [];
    return '<article class="audit-row"><div class="audit-identity"><strong translate="no">' + U.esc(row.symbol) + '</strong>' +
      '<span class="operation-muted" translate="no">' + U.esc(row.market) + ' · ' + U.esc(row.direction) + '</span>' +
      badge(labels[row.status] || 'Menunggu evaluasi', row.status === 'EXECUTED') + '</div>' +
      '<div class="audit-reasons">' + (reasons.length ? '<ul>' + reasons.map((reason) => '<li>' + U.esc(reason) + '</li>').join('') + '</ul>' :
        '<p>Gate kualitas lolos; verdict eksekutif: ' + U.esc(row.executive_verdict) + '. Lolos kualitas bukan bukti order.</p>') + '</div></article>';
  }

  function render(d) {
    const operations = d.market_operations;
    if (!operations || typeof operations !== 'object') {
      U.setText('executionMode', 'MENUNGGU API BARU');
      U.setText('executionNotice', 'Data pasar belum tersedia dari server. Status Spot/Futures belum dapat dikonfirmasi.');
      stale(true);
      return;
    }
    stale(false);
    const mode = operations.mode || 'UNKNOWN';
    U.setText('executionMode', mode === 'PAPER' ? 'PAPER · SIMULASI' : mode === 'LIVE' ? 'LIVE · ORDER EXCHANGE' : 'MODE TIDAK DIKETAHUI');
    U.setText('executionNotice', operations.execution_notice);
    const mismatch = U.$('#modeMismatch');
    if (mismatch) mismatch.hidden = operations.mode_mismatch !== true;
    const routes = rows(operations.routes);
    const routeSignature = JSON.stringify(routes);
    if (lastRoutes !== routeSignature) {
      U.setHTML('marketRoutes', routes.map(routeHTML).join(''));
      lastRoutes = routeSignature;
    }
    const activity = { SCANNING: 'Memindai & mengevaluasi kandidat', MONITORING: 'Memantau posisi & proteksi risiko', WAITING_SETUP: 'Menunggu setup; belum ada posisi terbuka', WARMING_UP: 'Memulai engine; menunggu scan lengkap' };
    U.setText('botActivity', activity[operations.activity] || 'Status belum tersedia');
    U.setText('botScanSummary', stamp(operations.snapshot_at) + ' · ' + U.safe(operations.evaluated_count) + ' dievaluasi · ' + U.safe(operations.executed_count) + ' entry pada scan terakhir');
    U.setText('marketDataSource', (operations.data_market || 'UNKNOWN') + ' · ' + (operations.data_host || 'UNKNOWN'));
    U.setText('marketTimeframes', Array.isArray(operations.timeframes) ? operations.timeframes.join(' / ') + ' · candle tertutup' : 'Belum tersedia');
    U.setText('marketDataNotice', operations.data_notice);
    U.setText('futuresNotice', operations.futures_notice + ' Leverage konfigurasi ' + U.num(operations.configured_leverage, 1) + 'x; tidak diterapkan ke simulasi.');
    const candidates = rows(operations.candidates);
    U.setText('candidateAuditMeta', candidates.length + ' kandidat · hasil scan terakhir');
    const signature = JSON.stringify(candidates);
    if (lastAudit !== signature) {
      const expanded = U.$('#remainingCandidates')?.open === true;
      const more = candidates.slice(3);
      U.setHTML('candidateAudit', candidates.length ? candidates.slice(0, 3).map(candidateHTML).join('') +
        (more.length ? '<details class="operations-detail" id="remainingCandidates"' + (expanded ? ' open' : '') + '><summary>Lihat ' + more.length + ' kandidat lainnya</summary>' + more.map(candidateHTML).join('') + '</details>' : '') :
        '<p class="operation-muted">Belum ada kandidat pada scan terakhir. Bot tetap memantau pasar.</p>');
      lastAudit = signature;
    }
  }

  function stale(value) {
    const notice = U.$('#operationsFreshness');
    if (notice) notice.hidden = !value;
    const panel = U.$('#marketOperations');
    if (panel) panel.classList.toggle('telemetry-stale', value);
  }

  return { render, stale, rows, stamp };
})();
