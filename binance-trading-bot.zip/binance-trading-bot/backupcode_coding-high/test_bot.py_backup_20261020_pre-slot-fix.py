    def test_risk_management_veto_on_capacity(self):
        risk_agent = RiskManagementAgent()
        open_pos = [{"symbol": "A"}, {"symbol": "B"}, {"symbol": "C"}]
        res = risk_agent.evaluate_risk("D", 100.0, 1.0, 1000.0, open_pos)
        self.assertFalse(res["approved"])
        self.assertIn("Maximum open positions limit", res["reason"])
