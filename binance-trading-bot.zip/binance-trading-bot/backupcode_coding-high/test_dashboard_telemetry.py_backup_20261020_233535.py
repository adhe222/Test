import unittest
from unittest.mock import patch

import config
from dashboard_telemetry import build_market_operations, describe_market_record


class TestMarketOperations(unittest.TestCase):
    def build(self, **kwargs):
        values = {
            "mode": "paper",
            "ledger_mode": "paper",
            "scan": {},
            "positions": [],
            "macro": {},
            "loop": {"is_scanning": False, "cycle_count": 0},
            "data_endpoint": "https://data-api.binance.vision",
        }
        values.update(kwargs)
        with patch.object(config, "ENABLE_SPOT_LONGS", True), patch.object(config, "ENABLE_FUTURES_SHORTS", True):
            return build_market_operations(**values)

    def test_paper_routes_are_simulations_not_exchange_orders(self):
        result = self.build(macro={"safe_to_trade": True, "safe_for_shorts": False})
        self.assertEqual(result["mode"], "PAPER")
        self.assertFalse(result["exchange_orders_enabled"])
        self.assertFalse(result["futures_live_supported"])
        self.assertEqual(result["routes"][0]["execution"], "SIMULATION")
        self.assertEqual(result["routes"][1]["status"], "MACRO_PAUSED")
        self.assertEqual(result["data_market"], "SPOT")

    def test_runtime_mode_takes_precedence_over_ledger_label(self):
        result = self.build(mode="live", ledger_mode="paper")
        self.assertEqual(result["mode"], "LIVE")
        self.assertTrue(result["mode_mismatch"])
        self.assertEqual(result["routes"][1]["status"], "UNSUPPORTED")
        self.assertFalse(result["routes"][1]["entry_eligible"])

    def test_candidate_counts_do_not_confuse_quality_with_approval(self):
        scan = {"candidates_evaluated": [
            {"symbol": "ONEUSDT", "direction": "LONG", "gates_passed": False, "hard_gate_failures": ["EMA bearish"], "execution_note": "QUALITY_GATE_BLOCKED"},
            {"symbol": "TWOUSDT", "direction": "SHORT", "gates_passed": True, "can_execute": True, "executive_verdict": {"final_verdict": "WAIT"}},
        ], "executed_trades": []}
        result = self.build(scan=scan, macro={"safe_to_trade": True, "safe_for_shorts": True})
        self.assertEqual(result["evaluated_count"], 2)
        self.assertEqual(result["routes"][0]["candidate_count"], 1)
        self.assertEqual(result["routes"][1]["quality_pass_count"], 1)
        self.assertEqual(result["executed_count"], 0)
        self.assertNotEqual(result["candidates"][1]["status"], "EXECUTED")
        self.assertIn("EMA bearish", result["candidates"][0]["blockers"])

    def test_ready_candidate_is_not_blocked_by_informational_note(self):
        scan = {"candidates_evaluated": [{"symbol": "READYUSDT", "direction": "LONG", "gates_passed": True, "can_execute": True, "execution_note": "READY_TO_EXECUTE", "executive_verdict": {"final_verdict": "APPROVE"}}]}
        result = self.build(scan=scan, macro={"safe_to_trade": True})
        self.assertEqual(result["candidates"][0]["status"], "AWAITING_APPROVAL")
        self.assertEqual(result["candidates"][0]["blockers"], [])

    def test_macro_fallback_is_not_reported_as_verified_permission(self):
        result = self.build(macro={"regime": "FALLBACK_NORMAL", "safe_to_trade": True, "safe_for_shorts": True})
        self.assertTrue(all(route["status"] == "WAITING_DATA" for route in result["routes"]))
        self.assertTrue(all(route["macro_permission"] == "UNKNOWN" for route in result["routes"]))

    def test_no_macro_data_stays_unknown(self):
        result = self.build()
        self.assertEqual(result["routes"][0]["macro_permission"], "UNKNOWN")
        self.assertEqual(result["routes"][1]["status"], "WAITING_DATA")
        self.assertFalse(result["routes"][0]["entry_eligible"])

    def test_daily_loss_and_capacity_do_not_claim_route_ready(self):
        result = self.build(scan={"daily_loss_limit_hit": True}, macro={"safe_to_trade": True, "safe_for_shorts": True})
        self.assertTrue(all(route["status"] == "DAILY_PAUSED" for route in result["routes"]))
        positions = [{"direction": "LONG"} for _ in range(config.MAX_OPEN_POSITIONS)]
        result = self.build(positions=positions, macro={"safe_to_trade": True, "safe_for_shorts": True})
        self.assertTrue(all(route["status"] == "CAPACITY_FULL" for route in result["routes"]))

    def test_disabled_route_is_visible_but_not_eligible(self):
        with patch.object(config, "ENABLE_SPOT_LONGS", False):
            result = build_market_operations("paper", "paper", {}, [], {"safe_to_trade": True}, {}, "https://data-api.binance.vision")
        self.assertEqual(len(result["routes"]), 2)
        self.assertEqual(result["routes"][0]["status"], "DISABLED")
        self.assertFalse(result["routes"][0]["entry_eligible"])

    def test_unknown_mode_never_claims_live_order_execution(self):
        result = self.build(mode="unexpected")
        self.assertEqual(result["mode"], "UNKNOWN")
        self.assertFalse(result["exchange_orders_enabled"])
        self.assertNotIn("LIVE: jalur", result["execution_notice"])
        self.assertTrue(all(route["status"] == "UNSUPPORTED" for route in result["routes"]))

    def test_endpoint_is_only_a_host_and_never_contains_credentials(self):
        result = self.build(data_endpoint="https://user:example-password@example.com/path?token=example-token")
        self.assertEqual(result["data_host"], "example.com")
        self.assertNotIn("password", str(result))
        self.assertNotIn("token=", str(result))

    def test_enveloped_and_malformed_rows_are_safe(self):
        scan = {"candidates_evaluated": {"items": [{"direction": "SHORT"}, None]}, "executed_trades": {"unexpected": True}}
        result = self.build(scan=scan, positions={"items": []})
        self.assertEqual(result["evaluated_count"], 1)
        self.assertEqual(result["executed_count"], 0)

    def test_scan_activity_and_timestamp_are_reported(self):
        result = self.build(loop={"is_scanning": True, "cycle_count": 3}, scan={"completed_at": "2026-10-19T00:00:00+00:00"})
        self.assertEqual(result["activity"], "SCANNING")
        self.assertEqual(result["snapshot_at"], "2026-10-19T00:00:00+00:00")


class TestMarketRecordDescription(unittest.TestCase):
    def test_ambiguous_legacy_close_is_unknown_not_long(self):
        result = describe_market_record({"symbol": "OLDUSDT", "action": "CLOSED", "side": "SELL"})
        self.assertEqual(result["display_direction"], "UNKNOWN")
        self.assertEqual(result["display_market"], "UNKNOWN")

    def test_explicit_short_can_infer_strategy_but_not_exchange_fill(self):
        result = describe_market_record({"direction": "SHORT"})
        self.assertEqual(result["display_market"], "FUTURES")
        self.assertEqual(result["market_source"], "DIRECTION")
        self.assertNotIn("mode", result)

    def test_explicit_metadata_is_preserved_without_mutation(self):
        record = {"direction": "LONG", "market": "SPOT", "action": "CLOSED"}
        result = describe_market_record(record)
        self.assertEqual(result["market_source"], "RECORDED")
        self.assertNotIn("display_market", record)


if __name__ == "__main__":
    unittest.main()
