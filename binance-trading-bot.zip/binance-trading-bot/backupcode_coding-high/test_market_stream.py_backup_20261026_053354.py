"""Tick-by-tick market stream: parser, staleness, velocity and fallback contract."""
import time
import unittest
from unittest.mock import patch

import market_stream as ms


class StreamParserTests(unittest.TestCase):
    def setUp(self):
        self.stream = ms.MarketStream(exchange="okx")
        self.stream.enabled = True

    def test_okx_inst_mapping(self):
        self.assertEqual(self.stream._okx_inst("BTCUSDT", "SPOT"), "BTC-USDT")
        self.assertEqual(self.stream._okx_inst("BTCUSDT", "FUTURES"), "BTC-USDT-SWAP")
        self.assertEqual(self.stream._okx_inst("ETH-USDT", "SPOT"), "ETH-USDT")

    def test_okx_ticker_stored_and_priced(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        self.stream._handle(
            '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"65000.5","bidPx":"64999","askPx":"65001","ts":"1793000000000","vol24h":"123"}]}',
            "SPOT",
        )
        self.assertAlmostEqual(self.stream.price("BTCUSDT", "SPOT"), 65000.5)
        quote = self.stream.quote("BTCUSDT", "SPOT")
        self.assertEqual(quote["source"], "okx-ws")
        self.assertLess(quote["age_sec"], 1.0)

    def test_stale_quote_is_not_returned(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        self.stream._handle(
            '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"65000"}]}',
            "SPOT",
        )
        with patch("market_stream.time.time", return_value=time.time() + 30):
            self.assertIsNone(self.stream.price("BTCUSDT", "SPOT"))
            self.assertIsNone(self.stream.quote("BTCUSDT", "SPOT"))

    def test_binance_aggtrade_stored(self):
        stream = ms.MarketStream(exchange="binance")
        stream._inst_map["btcusdt@aggTrade"] = ("BTCUSDT", "SPOT")
        stream._handle(
            '{"stream":"btcusdt@aggTrade","data":{"s":"BTCUSDT","p":"65123.4","q":"0.01","T":1793000000000}}',
            "SPOT",
        )
        self.assertAlmostEqual(stream.price("BTCUSDT", "SPOT"), 65123.4)

    def test_velocity_uses_tick_history(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        now = time.time()
        with patch("market_stream.time.time", return_value=now - 30):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"100"}]}',
                "SPOT",
            )
        with patch("market_stream.time.time", return_value=now):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"101"}]}',
                "SPOT",
            )
            self.assertAlmostEqual(self.stream.velocity("BTCUSDT", "SPOT", window_sec=60), 1.0, places=4)

    def test_stats_contract(self):
        stats = self.stream.stats()
        for key in ("enabled", "connected", "healthy", "symbols_streaming", "ticks", "ticks_per_sec", "reconnects"):
            self.assertIn(key, stats)
        self.assertFalse(stats["healthy"])

    def test_pong_and_garbage_are_ignored(self):
        self.stream._handle("pong", "SPOT")
        self.stream._handle("not json", "SPOT")
        self.stream._handle('{"event":"subscribe"}', "SPOT")
        self.assertEqual(self.stream.stats()["ticks"], 0)

    def test_disabled_stream_never_starts(self):
        stream = ms.MarketStream()
        stream.enabled = False
        self.assertFalse(stream.start())


class PortfolioFallbackTests(unittest.TestCase):
    def test_price_for_uses_rest_when_stream_stale(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock

        client = MagicMock()
        client.get_price.return_value = 42.0
        pm = PortfolioManagerAgent(client, mode="paper")
        pm.market_stream = MagicMock()
        pm.market_stream.price.return_value = None
        self.assertEqual(pm._price_for("BTCUSDT", "SPOT"), 42.0)
        client.get_price.assert_called_once()

    def test_price_for_prefers_stream(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock

        client = MagicMock()
        client.get_price.return_value = 42.0
        pm = PortfolioManagerAgent(client, mode="paper")
        pm.market_stream = MagicMock()
        pm.market_stream.price.return_value = 43.5
        self.assertEqual(pm._price_for("BTCUSDT", "SPOT"), 43.5)
        client.get_price.assert_not_called()


if __name__ == "__main__":
    unittest.main()
