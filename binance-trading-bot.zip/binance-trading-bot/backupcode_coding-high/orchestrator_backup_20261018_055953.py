from typing import Dict, Any, List
from datetime import datetime, timezone
from binance_api import BinanceClient
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.momentum import MomentumAnalystAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent
from agents.macro_sentinel import MacroMarketSentinel
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)
import config
from config import MAX_OPEN_POSITIONS


class TradingOrchestrator:
    """
    CEO Orchestrator:
    Coordinates Macro Market Sentinel + 8 Distinct Institutional AI Divisions (32 Agents Total):
    0. Macro Market Sentinel (Bitcoin Beta Circuit Breaker)
    1. Market Flow & Narrative Division (🌐)
    2. Technical Price Action Division (📈)
    3. Momentum & Exhaustion Division (⚡)
    4. Order Book Microstructure Division (🔬)
    5. Volatility & Market Regime Division (📡)
    6. Quantitative Risk & Capital Division - Veto Authority (🛡️)
    7. Profit Extraction & Tactical Exits Division (🎯)
    8. Executive Investment Committee & Judge (👑)
    """

    def __init__(self):
        self.client = BinanceClient()
        self.llm = LLMClient()
        self.macro_sentinel = MacroMarketSentinel(self.client, self.llm)
        self.scanner = ScannerAgent(self.client)
        self.momentum_data_agent = MomentumAnalystAgent(self.client)
        self.orderbook_data_agent = OrderbookAgent(self.client)
        self.risk_data_agent = RiskManagementAgent()
        self.portfolio = PortfolioManagerAgent(self.client)

        # 8 Specialized AI Divisions
        self.narrative_spec = MarketNarrativeSpecialist(self.llm)
        self.price_action_spec = PriceActionSpecialist(self.llm)
        self.exhaustion_spec = MomentumExhaustionSpecialist(self.llm)
        self.microstructure_spec = MicrostructureSpecialist(self.llm)
        self.sentiment_spec = MarketSentimentSpecialist(self.llm)
        self.cro_spec = ChiefRiskOfficerSpecialist(self.llm)
        self.profit_spec = ProfitExtractionSpecialist(self.llm)
        self.executive_spec = ExecutiveStrategistSpecialist(self.llm)

    def _consecutive_losses(self) -> int:
        """Count consecutive completed losing trades from the immutable trade ledger."""
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return 0
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
            streak = 0
            for event in reversed(events):
                if event.get("action") != "CLOSED":
                    continue
                if float(event.get("pnl_usdt", 0.0)) < 0:
                    streak += 1
                else:
                    break
            return streak
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return 0

    def _adaptive_tightening(self) -> Dict[str, int]:
        """Return deterministic gate tightening after a losing streak."""
        streak = self._consecutive_losses()
        if not config.ADAPTIVE_GATES_ENABLED or streak < config.LOSS_STREAK_TIGHTEN_AFTER:
            return {"loss_streak": streak, "steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        steps = min(
            config.MAX_TIGHTEN_STEPS,
            1 + (streak - config.LOSS_STREAK_TIGHTEN_AFTER),
        )
        return {
            "loss_streak": streak,
            "steps": steps,
            "score_bonus": steps * config.LOSS_STREAK_SCORE_BONUS,
            "conviction_bonus": steps * config.LOSS_STREAK_CONVICTION_BONUS,
        }

    def _daily_loss_limit_hit(self) -> bool:
        """Pause only new entries when today's realized loss exceeds the capital guard."""
        perf = self.portfolio.get_periodic_performance().get("today", {})
        net = float(perf.get("net_pnl_usdt", 0.0))
        initial = float(self.portfolio.state.get("initial_capital", config.INITIAL_PAPER_BALANCE_USDT))
        return net < 0 and abs(net) >= initial * (config.DAILY_LOSS_LIMIT_PCT / 100.0)

    def _symbols_in_cooldown(self) -> Dict[str, str]:
        """
        Symbols recently stopped out are blocked for a few bars.

        Re-entering immediately after a loss pays fees twice in the same
        conditions that just failed — classic churn that destroys expectancy.
        """
        blocked: Dict[str, str] = {}
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return blocked
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
        except (OSError, ValueError, TypeError):
            return blocked

        tf_minutes = {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240}
        bar_min = tf_minutes.get(config.KLINES_TIMEFRAME, 15)
        window_min = bar_min * config.SYMBOL_COOLDOWN_BARS
        now = datetime.now(timezone.utc)

        for event in reversed(events[-60:]):
            if event.get("action") != "CLOSED":
                continue
            if float(event.get("pnl_usdt", 0.0)) >= 0:
                continue
            try:
                exited = datetime.fromisoformat(event["exit_time"])
            except (KeyError, ValueError):
                continue
            age_min = (now - exited).total_seconds() / 60.0
            if age_min < window_min:
                remaining = window_min - age_min
                blocked[event["symbol"]] = f"Cooldown after loss ({remaining:.0f}m left)"
        return blocked

    def run_cycle(self) -> Dict[str, Any]:
        adaptive = self._adaptive_tightening()
        results = {
            "ai_status": self.llm.status_summary,
            "macro_health": {},
            "exit_events": [],
            "candidates_scanned": 0,
            "candidates_evaluated": [],
            "executed_trades": [],
            "portfolio_summary": {},
            "adaptive_guard": adaptive,
            "daily_loss_limit_hit": False,
        }

        # Step 1: Manage and protect existing positions (TP1 scaling, Break-even SL, Trailing, Stagnation)
        exit_events = self.portfolio.update_and_monitor_positions()
        results["exit_events"] = exit_events

        open_positions = self.portfolio.get_open_positions()
        current_equity = self.portfolio.get_equity()

        # Step 2: Global Macro Sentinel Evaluation (Bitcoin Beta Circuit Breaker)
        macro_health = self.macro_sentinel.evaluate_macro_health()
        results["macro_health"] = macro_health

        # Step 3: Check capacity
        available_slots = MAX_OPEN_POSITIONS - len(open_positions)
        circuit_breaker_active = not macro_health.get("safe_to_trade", True)
        daily_limit_hit = self._daily_loss_limit_hit()
        results["daily_loss_limit_hit"] = daily_limit_hit
        cooldowns = self._symbols_in_cooldown()
        results["symbols_in_cooldown"] = cooldowns
        # Correlation cap: N simultaneous high-beta altcoin longs is effectively
        # one leveraged bet on BTC direction, not N diversified trades.
        correlation_full = len(open_positions) >= config.MAX_CORRELATED_POSITIONS

        # Step 4: Scan market for trending pairs (Always run to keep surveillance wall active!)
        candidates = self.scanner.scan_trending_pairs(top_limit=8)
        results["candidates_scanned"] = len(candidates)

        for candidate in candidates:
            try:
                symbol = candidate["symbol"]

                # Filter if already held
                if any(pos["symbol"] == symbol for pos in open_positions):
                    continue

                # Gather raw data feeds
                ob_eval = self.orderbook_data_agent.inspect_orderbook(symbol)
                mom_eval = self.momentum_data_agent.analyze_symbol(
                    symbol, extra_score_required=adaptive["score_bonus"]
                )
                risk_eval = self.risk_data_agent.evaluate_risk(
                    symbol=symbol,
                    current_price=mom_eval.get("price", candidate["price"]),
                    atr=mom_eval.get("atr", 0.0),
                    total_equity=current_equity,
                    open_positions=open_positions
                )

                # -------------------------------------------------------------
                # HARD PRE-COMMITTEE GATES (win-rate critical).
                # The committee can only vote on structurally valid setups;
                # it can never override a failed data gate.
                # -------------------------------------------------------------
                hard_gate_failures: List[str] = []

                if symbol in cooldowns:
                    hard_gate_failures.append(cooldowns[symbol])
                if config.REQUIRE_MOMENTUM_PASS and not mom_eval.get("passed", False):
                    hard_gate_failures.extend(
                        mom_eval.get("gate_failures") or [mom_eval.get("reason", "Momentum gate failed")]
                    )
                if config.REQUIRE_ORDERBOOK_PASS and not ob_eval.get("passed", False):
                    hard_gate_failures.append(
                        f"Orderbook gate: {ob_eval.get('reason', 'liquidity check failed')}"
                    )
                if ob_eval.get("passed") and ob_eval.get("imbalance", 0.0) < config.MIN_ORDERBOOK_IMBALANCE:
                    hard_gate_failures.append(
                        f"Orderbook bid support weak (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                    )
                if candidate.get("count_trades", 0) < config.MIN_TRADE_COUNT_24H:
                    hard_gate_failures.append(
                        f"Thin participation ({candidate.get('count_trades', 0):,} trades/24h < {config.MIN_TRADE_COUNT_24H:,})"
                    )
                if not risk_eval.get("approved"):
                    hard_gate_failures.append(f"Risk desk: {risk_eval.get('reason', 'risk plan rejected')}")

                gates_passed = len(hard_gate_failures) == 0

                # Consult the 7 Specialist AI Divisions (each querying their 3 employee sub-agents)
                rep_narrative = self.narrative_spec.analyze(candidate)
                rep_pa = self.price_action_spec.analyze({"momentum_data": mom_eval})
                rep_exhaustion = self.exhaustion_spec.analyze({"momentum_data": mom_eval})
                rep_micro = self.microstructure_spec.analyze({"orderbook_data": ob_eval})
                rep_sentiment = self.sentiment_spec.analyze({"momentum_data": mom_eval, "ticker_data": candidate})
                rep_cro = self.cro_spec.analyze({"risk_plan": risk_eval})
                rep_profit = self.profit_spec.analyze({"risk_plan": risk_eval})

                all_specialist_reports = [
                    rep_narrative,
                    rep_pa,
                    rep_exhaustion,
                    rep_micro,
                    rep_sentiment,
                    rep_cro,
                    rep_profit
                ]

                # Synthesize final consensus through Executive Committee
                executive_verdict = self.executive_spec.synthesize(
                    all_specialist_reports,
                    extra_conviction_required=adaptive["conviction_bonus"]
                )

                can_execute = (
                    available_slots > 0
                    and not circuit_breaker_active
                    and not daily_limit_hit
                    and not correlation_full
                    and gates_passed
                )
                if available_slots <= 0:
                    execution_note = "CAPACITY_FULL_SURVEILLANCE"
                elif circuit_breaker_active:
                    execution_note = "CIRCUIT_BREAKER_ACTIVE"
                elif daily_limit_hit:
                    execution_note = "DAILY_LOSS_LIMIT_PAUSE"
                elif correlation_full:
                    execution_note = f"CORRELATION_CAP_REACHED ({config.MAX_CORRELATED_POSITIONS} correlated longs)"
                elif not gates_passed:
                    execution_note = f"QUALITY_GATE_BLOCKED: {hard_gate_failures[0]}"
                else:
                    execution_note = "READY_TO_EXECUTE"

                eval_record = {
                    "symbol": symbol,
                    "price": candidate["price"],
                    "price_change_24h": candidate["price_change_24h"],
                    "quote_volume_24h": candidate["quote_volume_24h"],
                    "technical_score": mom_eval.get("score", 0),
                    "min_score_required": mom_eval.get("min_score_required"),
                    "hard_gate_failures": hard_gate_failures,
                    "gates_passed": gates_passed,
                    "specialist_reports": all_specialist_reports,
                    "executive_verdict": executive_verdict,
                    "risk_plan": risk_eval,
                    "can_execute": can_execute,
                    "execution_note": execution_note
                }
                results["candidates_evaluated"].append(eval_record)

                # Execute only when gates pass AND committee reaches unanimous approval
                if can_execute and executive_verdict["final_verdict"] == "APPROVE" and risk_eval.get("approved"):
                    success = self.portfolio.execute_buy(risk_eval)
                    if success:
                        results["executed_trades"].append(eval_record)
                        open_positions = self.portfolio.get_open_positions()
                        available_slots = MAX_OPEN_POSITIONS - len(open_positions)
                        correlation_full = len(open_positions) >= config.MAX_CORRELATED_POSITIONS

                # Once we evaluated top candidates during capacity full, break to save API calls
                if available_slots <= 0 and len(results["candidates_evaluated"]) >= 2:
                    break
            except Exception as e:
                print(f"[Orchestrator Warning] Candidate {candidate.get('symbol')} skipped due to network glitch: {e}")
                continue

        if available_slots <= 0:
            status = "Capacity full (3/3) - Watchlist surveillance active"
        elif daily_limit_hit:
            status = f"Daily loss guard active (-{config.DAILY_LOSS_LIMIT_PCT}%) - entries paused, surveillance live"
        elif circuit_breaker_active:
            status = "Macro circuit breaker active - entries paused, surveillance live"
        elif adaptive["steps"] > 0:
            status = f"Active scanning (defensive mode: +{adaptive['score_bonus']} score / +{adaptive['conviction_bonus']}% conviction required)"
        else:
            status = "Active scanning"

        results["portfolio_summary"] = {
            "equity_usdt": round(self.portfolio.get_equity(), 2),
            "cash_usdt": round(self.portfolio.state["cash_usdt"], 2),
            "open_positions": self.portfolio.get_open_positions(),
            "realized_pnl_usdt": round(self.portfolio.state.get("realized_pnl_usdt", 0.0), 4),
            "total_trades": self.portfolio.state.get("total_trades", 0),
            "winning_trades": self.portfolio.state.get("winning_trades", 0),
            "status": status
        }

        return results
