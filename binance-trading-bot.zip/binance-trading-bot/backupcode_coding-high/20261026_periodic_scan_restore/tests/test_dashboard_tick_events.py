"""Integration contract: a websocket tick reaches the position guard without a timer."""
import asyncio
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import config
from agents.portfolio_manager import PortfolioManagerAgent


ROOT = Path(__file__).resolve().parents[1]


def load_dashboard(engine):
    """Load the dashboard with its orchestrator factory isolated from the live bot."""
    name = "_web_dashboard_tick_event_test"
    spec = importlib.util.spec_from_file_location(name, ROOT / "web_dashboard.py")
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {name: module}), patch(
        "orchestrator.TradingOrchestrator", return_value=engine
    ):
        spec.loader.exec_module(module)
    return module


class TickEventIntegrationTests(unittest.TestCase):
    def test_tick_callback_closes_paper_position_without_timer(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "MOMENTUM_FADE_EXIT_ENABLED", False):
                client = MagicMock()
                pm = PortfolioManagerAgent(client, mode="paper")
                pm.market_stream = MagicMock()
                pm.market_stream.price.return_value = 97.0
                pm.market_stream.velocity.return_value = 0.0
                self.assertTrue(pm.execute_buy({
                    "symbol": "AAAUSDT",
                    "entry_price": 100.0,
                    "quantity": 1.0,
                    "position_usdt": 100.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0,
                    "take_profit_2": 106.0,
                    "trailing_trigger_pct": 2.0,
                    "trailing_distance_pct": 1.0,
                }))

                engine = MagicMock()
                engine.portfolio = pm
                engine._candidate_watchlist = {}
                dashboard = load_dashboard(engine)
                dashboard.TICK_GUARD_COALESCE_SEC = 0.0
                dashboard.pending_ticks.clear()
                dashboard.pending_trigger_symbols.clear()
                dashboard.tick_wakeup.clear()
                dashboard.stream_event_stats.update({
                    "ticks_received": 0,
                    "tick_batches": 0,
                    "position_guard_runs": 0,
                    "event_scan_triggers": 0,
                    "last_trigger_symbols": [],
                    "last_tick_at": None,
                })

                async def exercise():
                    with patch.object(dashboard.market_stream, "movers", return_value=[]):
                        task = asyncio.create_task(dashboard.tick_event_consumer())
                        try:
                            dashboard._queue_tick({
                                "symbol": "AAAUSDT",
                                "market": "SPOT",
                                "price": 97.0,
                                "source": "test-ws",
                            })
                            for _ in range(100):
                                if dashboard.stream_event_stats["position_guard_runs"]:
                                    break
                                await asyncio.sleep(0.02)
                            self.assertEqual(dashboard.stream_event_stats["position_guard_runs"], 1)
                        finally:
                            task.cancel()
                            try:
                                await task
                            except asyncio.CancelledError:
                                pass

                asyncio.run(exercise())
                self.assertEqual(pm.get_open_positions(), [])
                close_action = engine.tv_verifier.journal_exit.call_args.args[0]
                self.assertEqual(close_action["symbol"], "AAAUSDT")
                self.assertEqual(close_action["reason"], "STOP_LOSS_HIT")
                self.assertEqual(dashboard.stream_event_stats["ticks_received"], 1)
                self.assertEqual(dashboard.stream_event_stats["tick_batches"], 1)


class ScanLoopContractTests(unittest.TestCase):
    def test_periodic_and_event_scans_publish_separately(self):
        engine = MagicMock()
        engine.run_cycle.side_effect = [
            {"scan_mode": "PERIODIC", "candidates_scanned": 20},
            {"scan_mode": "EVENT", "candidates_scanned": 1},
        ]
        dashboard = load_dashboard(engine)

        async def exercise():
            periodic = await dashboard._run_scan_cycle()
            event = await dashboard._run_scan_cycle(["AAAUSDT"])
            return periodic, event

        periodic, event = asyncio.run(exercise())
        self.assertEqual(periodic["scan_mode"], "PERIODIC")
        self.assertEqual(event["scan_mode"], "EVENT")
        self.assertEqual(engine.run_cycle.call_args_list[0].kwargs["triggered_symbols"], None)
        self.assertEqual(engine.run_cycle.call_args_list[1].kwargs["triggered_symbols"], ["AAAUSDT"])
        self.assertEqual(dashboard.latest_scan_by_mode["PERIODIC"]["candidates_scanned"], 20)
        self.assertEqual(dashboard.latest_scan_by_mode["EVENT"]["candidates_scanned"], 1)
        self.assertEqual(dashboard.latest_scan_data["scan_mode"], "EVENT")
        self.assertEqual(dashboard.cycle_count, 2)
        self.assertFalse(dashboard.is_scanning)

    def test_periodic_loop_calls_untriggered_scan(self):
        engine = MagicMock()
        dashboard = load_dashboard(engine)
        fake_scan = AsyncMock(return_value={})

        async def exercise():
            with patch.object(dashboard, "_run_scan_cycle", fake_scan), patch.object(
                dashboard.asyncio, "sleep", side_effect=[None, asyncio.CancelledError()]
            ):
                with self.assertRaises(asyncio.CancelledError):
                    await dashboard.periodic_scan_loop()

        asyncio.run(exercise())
        fake_scan.assert_awaited_once()


if __name__ == "__main__":
    unittest.main()
