# Periodic universe scan restore (2026-10-26)

Root cause:
- The streaming retrofit left only candidate discovery and tick-triggered event analysis.
- No `run_cycle()` without `triggered_symbols` remained, so the 25-symbol universe was discovered but never fully analyzed.
- Dashboard read `latest_scan`, which was usually the last EVENT scan (1 symbol).

Fix:
- Added `periodic_scan_loop()` calling `_run_scan_cycle()` with no trigger.
- Serialized periodic and event cycles with one `scan_lock`.
- Published `latest_periodic_scan` and `latest_event_scan` separately.
- Dashboard now reads periodic scan for universe pair counts and shows event count separately.
- Cache bumped to hud17 / aegis-shell-v17-periodic-scan.

Verification:
- 414 tests OK.
- Live periodic scan: 25 candidates, 17 gates passed, 2 entries (PUMPUSDT, ADAUSDT); open positions 3.
- Renderer test: `scanMeta = 25 pair universe · event 1`.
