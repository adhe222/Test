(function () {
  'use strict';

  const U = window.AegisUtil;

  const ICONS = {
    wallet: '<path d="M3 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7V5a2 2 0 0 1 2-2h10"/><circle cx="16" cy="13" r="1.4"/>',
    target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
    scale: '<path d="M12 3v18M5 8h14M7 8l-3 7h6zM17 8l-3 7h6z"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 12l6-4"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>'
  };

  const svg = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.radar}</svg>`;

  const get = (d, path, fallback) => {
    const parts = String(path).split('.');
    let cur = d;
    for (let i = 0; i < parts.length; i += 1) {
      if (cur === null || cur === undefined || typeof cur !== 'object') return fallback;
      cur = cur[parts[i]];
    }
    return cur === undefined || cur === null ? fallback : cur;
  };

  const arr = (value) => (Array.isArray(value) ? value : []);

  const universeScan = (data) => {
    const periodic = get(data, 'latest_periodic_scan', {});
    if (periodic && typeof periodic === 'object' && Object.keys(periodic).length) return periodic;
    return get(data, 'latest_scan', {});
  };

  const clamp = (value, min, max) => {
    const n = Number(value);
    return Math.min(max, Math.max(min, Number.isFinite(n) ? n : min));
  };

  const signedPct = (value, digits) => {
    const n = Number(value);
    const safeValue = Number.isFinite(n) ? n : 0;
    return `${safeValue > 0 ? '+' : ''}${safeValue.toFixed(digits === undefined ? 1 : digits)}%`;
  };

  const bubbleGroup = (side, tone, author, title, copy, meta, items) => {
    const toneAttr = tone ? ` data-tone="${U.esc(tone)}"` : '';
    const metaHtml = arr(meta).length
      ? `<div class="bubble-meta">${arr(meta).map((m) => `<span>${U.esc(m)}</span>`).join('')}</div>` : '';
    const itemsHtml = arr(items).length
      ? `<ul class="bubble-list">${arr(items).map((i) => `<li class="${i.ok ? 'ok' : ''}"><i>${i.ok ? '&#10003;' : '&#10005;'}</i><span>${U.esc(i.text)}</span></li>`).join('')}</ul>` : '';
    return `<div class="bubble-group ${side}"><div class="bubble bubble--${side}"${toneAttr}>`
      + `<div class="bubble-author"><span>${U.esc(author)}</span></div>`
      + (title ? `<div class="bubble-title">${U.esc(title)}</div>` : '')
      + (copy ? `<div class="bubble-copy">${copy}</div>` : '')
      + itemsHtml + metaHtml + '</div></div>';
  };

  const statBubble = (label, value, tone, suffix) => {
    const toneAttr = tone ? ` data-tone="${U.esc(tone)}"` : '';
    return `<div class="bubble-stat"${toneAttr}><span>${U.esc(label)}</span>`
      + `<b>${value}${suffix ? `<small>${U.esc(suffix)}</small>` : ''}</b></div>`;
  };

  const header = (d) => {
    const data = d || {};
    const mode = String(get(data, 'mode', 'PAPER')).toUpperCase();
    U.setText('mode', mode);
    U.setText('exchange', String(get(data, 'market_operations.exchange', get(data, 'exchange', '—'))).toUpperCase());
    const route = get(data, 'market_operations.dns_route', '');
    U.setText('dnsRoute', route ? `DNS ${route}` : 'DNS —');
    const scan = universeScan(data);
    const eventScan = get(data, 'latest_event_scan', {});
    const scanned = U.safe(get(scan, 'candidates_scanned', get(scan, 'scanned_count', 0)));
    const eventScanned = U.safe(get(eventScan, 'candidates_scanned', 0));
    U.setText('scanMeta', scanned > 0
      ? `${U.num(scanned, 0)} pair universe${eventScanned > 0 ? ` · event ${U.num(eventScanned, 0)}` : ''}`
      : 'menunggu scan');
    U.setText('updatedAt', U.timeAgo(get(data, 'generated_at', get(data, 'market_operations.snapshot_at'))));
    const positions = arr(get(data, 'open_positions', []));
    const positionCount = positions.length;
    const badgeText = positionCount > 9 ? '9+' : String(positionCount);
    const badgeLabel = positionCount ? `Posisi, ${positionCount} terbuka` : 'Posisi';
    [U.$('tabPositionsCount'), U.$('tabPositionsCountMobile')].forEach((badge) => {
      if (!badge) return;
      badge.textContent = badgeText;
      badge.hidden = positionCount === 0;
      const button = badge.closest ? badge.closest('.tab') : null;
      if (button) button.setAttribute('aria-label', badgeLabel);
    });
    const loop = get(data, 'autonomous_loop', {});
    const running = get(loop, 'active', get(loop, 'running', false));
    const cycles = U.safe(get(loop, 'cycle_count', get(loop, 'cycles_completed', get(data, 'cycles', 0))));
    U.setText('engineState', running ? 'Loop aktif' : 'Loop jeda');
    U.setText('engineCycle', `Siklus ${U.num(cycles, 0)}`);
  };

  const overview = (d) => {
    const data = d || {};
    const loop = get(data, 'autonomous_loop', {});
    const scan = universeScan(data);
    const gates = get(data, 'quality_gates', {});

    const equity = U.safe(get(data, 'equity_usdt', get(data, 'equity', 0)));
    const cash = U.safe(get(data, 'cash_usdt', get(data, 'cash', 0)));
    const allocated = U.safe(get(data, 'allocated_margin_usdt', get(data, 'allocated', 0)));
    const netPnl = U.safe(get(data, 'total_net_pnl_usdt', get(data, 'net_pnl', 0)));
    const realized = U.safe(get(data, 'realized_pnl_usdt', get(data, 'realized_pnl', 0)));
    const unrealized = U.safe(get(data, 'unrealized_pnl_usdt', get(data, 'unrealized_pnl', 0)));
    const fees = U.safe(get(data, 'total_fees_paid_usdt', get(data, 'fees_paid', 0)));

    U.countTo('equity', equity, { format: (v) => U.money(v) });
    U.countTo('netPnl', netPnl, { format: (v) => U.signed(v) });
    U.setText('cash', U.money(cash));
    U.setText('allocated', U.money(allocated));
    U.setText('realized', U.signed(realized));
    U.setText('unrealized', U.signed(unrealized));
    U.setText('feesFoot', `Fees ${U.money(fees)}`);

    const equityEl = U.$('netPnl');
    if (equityEl) equityEl.className = `pnl-line ${U.cls(netPnl)}`;

    const capacityMax = U.safe(get(data, 'capacity_max', 0));
    const capacityUsed = U.safe(get(data, 'capacity_used', 0));
    const unlimited = Boolean(get(data, 'capacity_unlimited', false)) || capacityMax <= 0;
    U.setText('capacity', unlimited ? `${U.num(capacityUsed, 0)} / ∞` : `${U.num(capacityUsed, 0)} / ${U.num(capacityMax, 0)}`);
    U.setText('capacityCaption', unlimited ? 'Tanpa batas searah (mode korelasi terbuka)' : `Slot terpakai dari ${U.num(capacityMax, 0)}`);
    U.setProgress('capacityProgress', unlimited ? Math.min(100, capacityUsed * 12) : (capacityUsed / Math.max(1, capacityMax)) * 100);
    U.setText('capacityFoot', unlimited ? 'Kapasitas dinamis' : `Sisa ${U.num(Math.max(0, capacityMax - capacityUsed), 0)} slot`);

    const cycles = U.safe(get(loop, 'cycle_count', get(loop, 'cycles_completed', get(data, 'cycles', 0))));
    U.setText('cycles', U.num(cycles, 0));
    U.setText('scanCount', U.num(U.safe(get(scan, 'candidates_scanned', 0)), 0));
    U.setText('gatesPassed', U.num(U.safe(get(scan, 'gates_passed_count', get(data, 'gates_passed_count', 0))), 0));
    const duration = U.safe(get(scan, 'timing.total_s', get(loop, 'last_cycle_duration_sec', 0)));
    U.setText('cycleDuration', duration > 0 ? `${duration.toFixed(1)}s` : '—');

    const winRate = U.safe(get(data, 'win_rate', 0));
    const target = U.safe(get(data, 'win_rate_target', 48));
    const trades = U.safe(get(data, 'total_trades', 0));
    U.setText('winRate', U.pct(winRate, 1));
    U.setText('tradeRecord', `${U.num(trades, 0)} trade tertutup`);
    U.setProgress('winProgress', winRate);
    U.setText('winTarget', `Target ${U.pct(target, 0)}`);
    const mark = U.$('breakevenMark');
    if (mark) {
      mark.style.left = `${clamp(target, 0, 100)}%`;
      mark.hidden = false;
    }

    const pf = U.safe(get(data, 'profit_factor', 0));
    const expectancy = U.safe(get(data, 'expectancy_usdt', 0));
    const avgWin = U.safe(get(data, 'avg_win_usdt', 0));
    const avgLoss = U.safe(get(data, 'avg_loss_usdt', 0));
    U.setText('profitFactor', pf > 0 ? pf.toFixed(2) : '—');
    U.setText('expectancy', U.signed(expectancy));
    U.setText('avgWin', U.signed(avgWin));
    U.setText('avgLoss', U.signed(avgLoss));
    U.setText('unrealizedPct', `${signedPct(get(data, 'unrealized_pnl_pct', 0), 2)}`);

    const positions = arr(get(data, 'open_positions', []));
    const statusStream = U.$('statusStream');
    if (statusStream) {
      const running = Boolean(get(loop, 'active', get(loop, 'running', false)));
      const mode = String(get(data, 'mode', 'PAPER')).toUpperCase();
      const parts = [];
      parts.push(bubbleGroup('in', running ? 'ok' : 'busy', 'AEGIS ENGINE',
        running ? 'Mesin berjalan normal' : 'Mesin dalam mode jeda',
        `Mode ${U.esc(mode)} · ${positions.length} posisi terbuka · ${U.num(cycles, 0)} siklus selesai.`,
        [U.stamp(get(data, 'generated_at')), get(data, 'exchange_label', '—')]));

      const routes = arr(get(data, 'market_operations.routes', []));
      const blocked = routes.filter((r) => r && r.entry_eligible === false);
      if (routes.length) {
        parts.push(bubbleGroup('in', blocked.length ? 'warn' : 'scan', 'ROUTING PASAR',
          blocked.length ? `${blocked.length} rute ditahan` : 'Semua rute terbuka',
          '',
          routes.map((r) => `${r.market || '—'} ${r.direction || ''}`.trim()),
          routes.map((r) => ({ ok: r.entry_eligible !== false, text: `${r.market || '—'} ${r.direction || ''} — ${r.reason || r.status || 'aktif'}` }))));
      }

      const funnel = arr(get(data, 'rejection_funnel', []));
      const topReject = funnel.slice().sort((a, b) => U.safe(b.count) - U.safe(a.count))[0];
      if (topReject) {
        parts.push(bubbleGroup('out', 'alert', 'DIAGNOSA',
          `Penolakan terbanyak: ${U.title(topReject.reason || topReject.gate || 'unknown')}`,
          `${U.num(U.safe(topReject.count), 0)} kandidat gugur pada gate ini.`,
          [`${funnel.length} gate aktif`]));
      }

      const macro = get(data, 'macro_health', {});
      if (macro && (macro.regime || macro.safe_to_trade !== undefined)) {
        const blocked = macro.safe_to_trade === false || macro.circuit_breaker === true;
        parts.push(bubbleGroup('out', blocked ? 'alert' : 'ok', 'MAKRO',
          `Rezim ${U.title(macro.regime || 'netral')}`,
          U.esc(macro.rationale || macro.long_block_reason || macro.short_block_reason || 'Kondisi pasar global dipantau tiap siklus.'),
          [blocked ? 'Entry ditahan' : 'Entry diizinkan', `RSI ${U.num(U.safe(macro.rsi), 1)}`]));
      }

      statusStream.innerHTML = parts.join('');
    }

    const kpiBubbles = U.$('kpiBubbles');
    if (kpiBubbles) {
      kpiBubbles.innerHTML = [
        statBubble('Win rate', U.pct(winRate, 1), winRate >= target ? 'ok' : 'alert'),
        statBubble('Profit factor', pf > 0 ? pf.toFixed(2) : '—', pf >= 1.35 ? 'ok' : ''),
        statBubble('Net PnL', U.signed(netPnl), netPnl >= 0 ? 'ok' : 'alert'),
        statBubble('Posisi', U.num(positions.length, 0), '', 'terbuka'),
        statBubble('Scan', U.num(U.safe(get(scan, 'candidates_scanned', 0)), 0), '', 'pair universe'),
        statBubble('Siklus', U.num(cycles, 0), '', 'selesai')
      ].join('');
    }

    const periodic = get(data, 'periodic_performance', {});
    const periodEl = U.$('periodic');
    if (periodEl) {
      const keys = ['today', 'this_week', 'this_month'];
      periodEl.innerHTML = keys.map((k) => {
        const row = periodic[k] || {};
        const pnl = U.safe(row.net_pnl_usdt !== undefined ? row.net_pnl_usdt : row.pnl);
        const tradesIn = U.safe(row.trades);
        const wr = U.safe(row.win_rate !== undefined ? row.win_rate : row.win_rate_pct);
        const label = k === 'today' ? 'Hari ini' : k === 'this_week' ? '7 hari' : '30 hari';
        return `<div class="period-row"><div><div class="period-title">${label}</div>`
          + `<div class="period-foot">${U.num(tradesIn, 0)} trade · WR ${U.pct(wr, 0)}</div></div>`
          + `<div class="period-right"><div class="period-pnl ${U.cls(pnl)}">${U.signed(pnl)}</div>`
          + `<div class="period-foot">${row.sessions ? `${U.num(U.safe(row.sessions), 0)} sesi` : 'akumulasi'}</div></div></div>`;
      }).join('');
    }

    const funnelEl = U.$('rejectionFunnel');
    if (funnelEl) {
      const funnel = arr(get(data, 'rejection_funnel', []));
      U.setText('funnelMeta', funnel.length ? `${funnel.length} gate` : 'belum ada data');
      const max = Math.max(1, ...funnel.map((f) => U.safe(f.count)));
      funnelEl.innerHTML = funnel.length
        ? funnel.map((f) => `<div class="funnel-row"><div class="funnel-label">${U.esc(U.title(f.reason || f.gate || 'unknown'))}</div>`
          + `<div class="funnel-bar"><i style="width:${Math.round((U.safe(f.count) / max) * 100)}%"></i></div>`
          + `<div class="funnel-count">${U.num(U.safe(f.count), 0)}</div></div>`).join('')
        : '<div class="gate-empty">Belum ada penolakan tercatat pada siklus ini.</div>';
    }

    const guard = get(data, 'adaptive_guard', {});
    const guardRow = U.$('guardRow');
    if (guardRow) {
      const items = Object.keys(guard).slice(0, 4).map((k) => {
        const v = guard[k];
        const text = typeof v === 'number' ? U.num(v, 2) : String(v);
        return `<div class="fact"><span>${U.esc(U.title(k))}</span><b>${U.esc(text)}</b></div>`;
      });
      guardRow.innerHTML = items.length ? items.join('') : '<div class="fact"><span>Guard</span><b>standby</b></div>';
    }

    const quotes = arr(get(data, 'accepted_quotes', []));
    const quoteEl = U.$('quotes');
    if (quoteEl) {
      quoteEl.innerHTML = quotes.length
        ? quotes.slice(0, 8).map((q) => `<span class="quote-chip">${U.esc(typeof q === 'string' ? q : q.symbol || q.asset || '—')}</span>`).join('')
        : '<span class="quote-chip">menunggu quote</span>';
    }
  };

  const macro = (d) => {
    const data = d || {};
    const m = get(data, 'macro_health', {}) || {};
    const price = U.safe(get(m, 'price', get(m, 'btc_price', 0)));
    U.setText('macroPrice', price > 0 ? U.money(price, 0) : '—');
    U.setText('regimeName', U.title(m.regime || 'Netral'));
    const badge = U.$('regimeBadge');
    const blocked = m.safe_to_trade === false || m.circuit_breaker === true;
    if (badge) {
      badge.textContent = blocked ? 'circuit breaker' : m.safe_to_trade === true ? 'aman' : 'normal';
      badge.className = `regime-badge${blocked ? ' risk' : ''}`;
    }
    const ema21 = U.safe(get(m, 'ema21', 0));
    const ema50 = U.safe(get(m, 'ema50', 0));
    const trend = ema21 > 0 && ema50 > 0 ? (ema21 >= ema50 ? 'bullish' : 'bearish') : '';
    U.setText('macroRsi', m.rsi !== undefined ? U.num(U.safe(m.rsi), 1) : '—');
    U.setText('macroEma', trend ? U.title(trend) : '—');
    U.setText('macroDrop', m.drop_4h_pct !== undefined ? U.pct(U.safe(m.drop_4h_pct), 2) : '—');
    U.setText('macroRationale', m.rationale || m.long_block_reason || m.short_block_reason || 'Belum ada narasi makro pada siklus ini.');
  };

  const positions = (d) => {
    const data = d || {};
    const rows = arr(get(data, 'open_positions', []));
    const el = U.$('positions');
    U.setText('positionMeta', rows.length ? `${rows.length} posisi aktif` : 'flat');
    if (!el) return;
    if (!rows.length) {
      el.innerHTML = '<div class="empty-state"><div><div class="empty-orbit"></div>'
        + '<div class="empty-title">Belum ada posisi terbuka</div>'
        + '<div class="empty-copy">Mesin menunggu kandidat yang lolos seluruh gate kualitas sebelum mengalokasikan modal.</div></div></div>';
      return;
    }
    const markCache = window.__markPrices || (window.__markPrices = {});
    el.innerHTML = rows.map((p) => {
      const pnl = U.safe(p.unrealized_pnl_usdt !== undefined ? p.unrealized_pnl_usdt : (p.unrealized_pnl !== undefined ? p.unrealized_pnl : p.pnl));
      const pnlPct = U.safe(p.unrealized_pct !== undefined ? p.unrealized_pct : (p.unrealized_pnl_pct !== undefined ? p.unrealized_pnl_pct : p.pnl_pct));
      const openedAt = p.opened_at || p.entry_time || p.timestamp || null;
      const entry = U.safe(p.entry_price);
      const current = U.safe(p.current_price !== undefined ? p.current_price : p.mark_price);
      const sl = U.safe(p.stop_loss_price !== undefined ? p.stop_loss_price : p.stop_loss);
      const tp = U.safe(p.take_profit_1 !== undefined ? p.take_profit_1 : (p.take_profit !== undefined ? p.take_profit : p.take_profit_2));
      const side = String(p.direction || p.side || '').toUpperCase();
      const span = tp > sl && sl > 0 ? tp - sl : 0;
      const progress = span > 0 ? clamp(((current - sl) / span) * 100, 0, 100) : 50;
      const sideClass = side === 'LONG' ? 'long' : side === 'SHORT' ? 'short' : 'unknown';
      const sym = p.symbol || '';
      const prev = markCache[sym];
      let tickClass = '';
      if (prev !== undefined && prev !== current && current > 0) {
        tickClass = current > prev ? ' tick-up' : ' tick-down';
      }
      markCache[sym] = current;
      return `<article class="card position-card">`
        + `<div class="position-head"><div><div class="pair">${U.esc(p.symbol || '—')}`
        + `<span class="side-badge ${sideClass}">${U.esc(side || 'N/A')}</span></div>`
        + `<div class="pair-sub">${U.esc(p.market || 'SPOT')} · qty ${U.num(U.safe(p.quantity || p.qty), 4)}</div></div>`
        + `<div class="pos-pnl ${U.cls(pnl)}">${U.signed(pnl)}<small class="${U.cls(pnlPct)}">${signedPct(pnlPct, 2)}</small></div></div>`
        + `<div class="price-strip">`
        + `<div class="price-cell"><span>Entry</span><strong>${U.price(entry)}</strong></div>`
        + `<div class="price-cell"><span>Mark</span><strong class="${tickClass}">${U.price(current)}</strong></div>`
        + `<div class="price-cell"><span>SL / TP</span><strong>${U.price(sl)} / ${U.price(tp)}</strong></div>`
        + `</div>`
        + `<div class="risk-track"><span class="risk-marker" style="left:${progress.toFixed(1)}%"></span></div>`
        + `<div class="position-foot"><span>${U.esc(openedAt ? U.stamp(openedAt) : '—')}</span>`
        + `<span>${p.leverage ? `${U.num(U.safe(p.leverage), 0)}x` : 'spot'}</span>`
        + `<span>${U.esc(p.strategy || p.source || 'engine')}</span></div></article>`;
    }).join('');
  };

  window.AegisViews = { header, overview, macro, positions };
})();
