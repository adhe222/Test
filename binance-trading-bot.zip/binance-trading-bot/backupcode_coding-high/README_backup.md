# Binance Institutional AI Multi-Agent Quant Trading System

An institutional-grade multi-agent algorithmic trading system designed for Binance Spot markets with an uncompromising mandate: maximize profitability through asymmetric risk-reward, strict capital preservation, and zero emotional bias.

## Corporate Quant Hierarchy: 8 Divisions & 24 Specialized Sub-Agents (32 AI Roles)

To guarantee institutional-grade precision, every division lead is supported by 3 dedicated employee sub-agents who conduct granular quantitative audits before the lead synthesizes the division's verdict:

### Division 1: Market Flow & Narrative (🌐)
Lead: Head of Flow Strategy
- Sub-Agent 1.1: Volume Velocity Analyst (Audits 24h quote volume magnitude vs $5M+ threshold)
- Sub-Agent 1.2: Smart Money Tracker (Evaluates average trade size & whale block order footprint)
- Sub-Agent 1.3: Trend Corridor Sentinel (Ensures 24h price gains remain inside safe corridor +2% to +40%)

### Division 2: Technical Price Action (📈)
Lead: Head Quantitative Chartist
- Sub-Agent 2.1: EMA Trend Alignment Quant (Audits EMA 9/21/50 stack and slope)
- Sub-Agent 2.2: Candle Geometry Analyst (Measures close ratio near candle peak & wick rejection)
- Sub-Agent 2.3: Volume Surge Auditor (Validates volume surge multiplier vs 20-period SMA volume)

### Division 3: Momentum & Exhaustion (⚡)
Lead: Head Momentum Auditor
- Sub-Agent 3.1: RSI Velocity Auditor (Audits prime acceleration zone 50-70)
- Sub-Agent 3.2: Overbought Divergence Guard (Enforces absolute VETO if RSI > 75 to prevent buying tops)
- Sub-Agent 3.3: Mean Reversion Quant (Audits price distance from EMA21 to prevent rubber-band snap)

### Division 4: Order Book Microstructure (🔬)
Lead: Head Market Maker & Liquidity Quant
- Sub-Agent 4.1: Spread & Slippage Guard (Enforces strict spread <= 0.20% to eliminate friction)
- Sub-Agent 4.2: Depth Imbalance Quant (Measures top 20 bid depth vs ask depth wall absorption)
- Sub-Agent 4.3: Order Book Wall Scanner (Detects heavy sell walls that could cap immediate upside)

### Division 5: Volatility & Market Regime (📡)
Lead: Head Volatility & Regime Analyst
- Sub-Agent 5.1: ATR Volatility Engineer (Measures ATR volatility expansion vs dead chop)
- Sub-Agent 5.2: Trade Velocity Scout (Audits 24h count of trades for active participation)
- Sub-Agent 5.3: Market Noise Filter (Detects low-participation spoofing and wash trading)

### Division 6: Quantitative Risk & Capital (🛡️) - VETO AUTHORITY
Lead: Chief Risk Officer (Holds Absolute Veto)
- Sub-Agent 6.1: Position Sizing Auditor (Enforces 2% max portfolio risk per trade, max 25% single-asset cap)
- Sub-Agent 6.2: Stop Loss Engineer (Calculates ATR 1.5x volatility stop price)
- Sub-Agent 6.3: Risk-to-Reward Calculator (Enforces minimum 1:2.5 R:R mathematical positive expectancy)

### Division 7: Profit Extraction & Tactical Exits (🎯)
Lead: Head Profit Extraction Strategist
- Sub-Agent 7.1: Take Profit Architect (Designs 2-stage harvest: TP1 at 1.5R and TP2 at 2.5R)
- Sub-Agent 7.2: Trailing Stop Specialist (Arms dynamic trailing: triggers at +2.5%, trails 1.2% from peak)
- Sub-Agent 7.3: Fee & Friction Auditor (Guarantees net profitability accounting for Binance 0.10% fee)

### Division 8: Executive Investment Committee (👑)
Lead: Managing Director & Executive Judge
- Sub-Agent 8.1: Department Consensus Auditor (Tallies votes, detects any department veto)
- Sub-Agent 8.2: Conviction Weight Synthesizer (Aggregates division scores into firm-wide conviction >= 70%)
- Sub-Agent 8.3: Order Execution Commander (Formulates trade thesis and authorizes execution ticket)

## LLM Compatibility: OpenAI & Custom Endpoints

Works with standard OpenAI or ANY custom OpenAI-compatible endpoint (Ollama, LM Studio, OpenRouter, vLLM, DeepSeek):

```bash
# Example with OpenAI:
export OPENAI_API_KEY="sk-..."
export OPENAI_MODEL="gpt-4o-mini"

# Example with Local Ollama / Custom Server:
export OPENAI_BASE_URL="http://localhost:11434/v1"
export OPENAI_MODEL="llama3"

# Example with DeepSeek:
export OPENAI_BASE_URL="https://api.deepseek.com/v1"
export OPENAI_API_KEY="sk-..."
export OPENAI_MODEL="deepseek-chat"
```

*Note:* If no LLM endpoint is provided, the system operates on its high-speed embedded Heuristic AI Engine.

## Visualization Interfaces

### 1. Visual Terminal CLI (Rich Tree)
Displays real-time pipeline steppers, the 8-division verdict matrix, an organizational Tree showing all 32 agents' individual signals and scores for the top candidate, executed position details, and real-time PnL tables.

```bash
# Run single scan & 32-agent deliberation:
python3 /home/lollipop/binance-trading-bot/main.py --scan

# Run continuous 60s loop:
python3 /home/lollipop/binance-trading-bot/main.py --run --interval 60

# Inspect portfolio & live unrealized PnL:
python3 /home/lollipop/binance-trading-bot/main.py --portfolio
```

### 2. Interactive Web Dashboard (FastAPI)
Cyberpunk/Institutional dark terminal with live deliberation feed, KPI meters, 8 division cards each with 3 sub-agent employee cards, conviction bars, and live position tracking.

```bash
python3 /home/lollipop/binance-trading-bot/main.py --web --port 8080
# Open http://localhost:8080 in your browser
```

## Automated Test Suite
```bash
PYTHONPATH=/home/lollipop/binance-trading-bot python3 /home/lollipop/binance-trading-bot/tests/test_bot.py
```
