import json
import os
import time
import threading
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path
import config

from config import (
    INITIAL_PAPER_BALANCE_USDT,
    ESTIMATED_FEE_PCT,
    EFFECTIVE_FEE_PCT,
    TRADING_MODE,
    FASTER_TP1_RATIO as PARTIAL_TP1_RATIO,
    EARLY_BREAK_EVEN_PCT,
    MAX_HOLD_HOURS_STAGNANT,
    BREAK_EVEN_BUFFER_PCT,
    TRAILING_STOP_TRIGGER_PCT,
    TRAILING_STOP_DISTANCE_PCT
)


class PortfolioManagerAgent:
    """
    Portfolio & Execution Agent:
    Tracks wallet balance, open positions, exact transaction fee accounting (Binance Spot),
    partial profit-taking (TP1 scaling), proactive break-even stop adjustments,
    dynamic volatility-adjusted trailing stops, simulated or live execution, and trade ledger history.
    """

    def __init__(self, binance_client: BinanceClient, mode: str = TRADING_MODE):
        self.client = binance_client
        self.mode = mode
        self._last_loaded_mtime = 0.0
        self.state = self._load_portfolio()

    def _sync_state_if_file_newer(self):
        target = config.PORTFOLIO_FILE
        if target.exists():
            try:
                mtime = target.stat().st_mtime
                if mtime > getattr(self, "_last_loaded_mtime", 0.0):
                    self.state = self._load_portfolio()
            except Exception:
                pass

    def _load_portfolio(self) -> Dict[str, Any]:
        # Resolve via the config module (not a stale import binding) so tests and
        # isolated runs honouring BOT_DATA_DIR / config overrides never write to
        # the live production state file.
        portfolio_file = config.PORTFOLIO_FILE
        if portfolio_file.exists():
            try:
                self._last_loaded_mtime = portfolio_file.stat().st_mtime
                with open(portfolio_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if "equity_history" not in data:
                        data["equity_history"] = []
                    if "total_fees_paid_usdt" not in data:
                        data["total_fees_paid_usdt"] = 0.0
                    if "gross_realized_pnl_usdt" not in data:
                        data["gross_realized_pnl_usdt"] = 0.0
                    return data
            except Exception:
                pass
        # Default fresh state
        default_state = {
            "mode": self.mode,
            "cash_usdt": INITIAL_PAPER_BALANCE_USDT,
            "initial_capital": INITIAL_PAPER_BALANCE_USDT,
            "open_positions": [],
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "total_fees_paid_usdt": 0.0,
            "gross_realized_pnl_usdt": 0.0,
            "realized_pnl_usdt": 0.0,
            "equity_history": [
                {
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "equity": INITIAL_PAPER_BALANCE_USDT,
                    "cash": INITIAL_PAPER_BALANCE_USDT
                }
            ],
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        self._save_portfolio(default_state)
        return default_state

    def _save_portfolio(self, state: Dict[str, Any]):
        state["updated_at"] = datetime.now(timezone.utc).isoformat()
        target = config.PORTFOLIO_FILE
        tmp = target.with_name(f"{target.name}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, target)
            try:
                self._last_loaded_mtime = target.stat().st_mtime
            except Exception:
                pass
        except Exception:
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            raise

    def record_equity_snapshot(self):
        current_eq = round(self.get_equity(), 2)
        history = self.state.get("equity_history", [])
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

        if not history or history[-1]["time"] != now_str:
            history.append({
                "time": now_str,
                "equity": current_eq,
                "cash": round(self.state.get("cash_usdt", 0.0), 2)
            })
            if len(history) > 150:
                history = history[-150:]
            self.state["equity_history"] = history
            self._save_portfolio(self.state)

    def _log_trade(self, trade_data: Dict[str, Any]):
        trade_file = config.TRADE_LOG_FILE
        trades = []
        if trade_file.exists():
            try:
                with open(trade_file, "r", encoding="utf-8") as f:
                    trades = json.load(f)
            except Exception:
                trades = []
        is_dup = False
        t_sym = trade_data.get("symbol")
        t_exit = trade_data.get("exit_time")
        if t_sym and t_exit:
            for existing in trades:
                if existing.get("symbol") == t_sym and existing.get("exit_time") == t_exit:
                    is_dup = True
                    break
        if not is_dup:
            trades.append(trade_data)
        tmp = trade_file.with_name(f"{trade_file.name}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(trades, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, trade_file)
        except Exception:
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            raise

    def get_equity(self) -> float:
        self._sync_state_if_file_newer()
        equity = self.state["cash_usdt"]
        for pos in self.state["open_positions"]:
            try:
                current_price = self.client.get_price(pos["symbol"])
                equity += pos["quantity"] * current_price
            except Exception:
                equity += pos["position_usdt"]
        return equity

    def get_open_positions(self) -> List[Dict[str, Any]]:
        self._sync_state_if_file_newer()
        return self.state.get("open_positions", [])

    def execute_buy(self, plan: Dict[str, Any]) -> bool:
        self._sync_state_if_file_newer()
        symbol = plan["symbol"]
        cost = plan["position_usdt"]
        qty = plan["quantity"]
        entry_price = plan["entry_price"]

        fee = cost * (EFFECTIVE_FEE_PCT / 100.0)
        total_required = cost + fee

        if self.state["cash_usdt"] < total_required:
            return False

        if self.mode == "live":
            try:
                self.client.place_order(symbol, side="BUY", quote_order_qty=cost)
            except Exception as e:
                print(f"[Execution Error] Failed to place live order: {e}")
                return False

        # Deduct cash & record fee
        self.state["cash_usdt"] -= total_required
        self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee, 4)

        new_position = {
            "symbol": symbol,
            "entry_price": entry_price,
            "quantity": qty,
            "initial_quantity": qty,
            "position_usdt": cost,
            "initial_cost_usdt": cost,
            "buy_fee_usdt": round(fee, 4),
            "stop_loss_price": plan["stop_loss_price"],
            "stop_loss_pct": plan["stop_loss_pct"],
            "entry_stop_loss_pct": plan["stop_loss_pct"],
            "entry_atr": plan.get("atr", 0.0),
            "entry_atr_pct": plan.get("atr_pct", 0.0),
            "take_profit_1": plan["take_profit_1"],
            "take_profit_2": plan["take_profit_2"],
            "tp1_hit": False,
            "partial_pnl_realized": 0.0,
            "break_even_active": False,
            "trailing_active": False,
            "highest_price": entry_price,
            "trailing_stop_price": plan["stop_loss_price"],
            "trailing_trigger_pct": plan["trailing_trigger_pct"],
            "trailing_distance_pct": plan["trailing_distance_pct"],
            "entry_time": datetime.now(timezone.utc).isoformat(),
            "holding_minutes": 0
        }

        self.state["open_positions"].append(new_position)
        self._save_portfolio(self.state)
        self.record_equity_snapshot()
        return True

    def _slippage_pct(self, pos: Dict[str, Any], adverse: bool = True) -> float:
        """
        Simulated execution slippage for paper mode.

        Real fills are never exact: market orders cross the spread and stops on
        $8M-volume altcoins slip further when volatility is high. Without this,
        paper win rate is structurally optimistic versus live.
        """
        if self.mode == "live":
            return 0.0
        atr_pct = abs(float(pos.get("entry_atr_pct", 0.0) or 0.0))
        slip = config.PAPER_SLIPPAGE_BASE_PCT + config.PAPER_SLIPPAGE_ATR_FACTOR * atr_pct
        return min(slip, config.PAPER_SLIPPAGE_MAX_PCT)

    def update_and_monitor_positions(self) -> List[Dict[str, Any]]:
        self._sync_state_if_file_newer()
        actions = []
        remaining_positions = []

        for pos in self.state["open_positions"]:
            symbol = pos["symbol"]
            qty = pos["quantity"]
            entry_p = pos["entry_price"]

            try:
                current_p = self.client.get_price(symbol)
                pos["current_price"] = current_p
                pos["unrealized_pnl"] = round((current_p - entry_p) * qty, 4)
            except Exception:
                remaining_positions.append(pos)
                continue

            # Update holding duration in minutes
            try:
                entry_dt = datetime.fromisoformat(pos["entry_time"])
                hold_min = int((datetime.now(timezone.utc) - entry_dt).total_seconds() / 60.0)
                pos["holding_minutes"] = max(0, hold_min)
            except Exception:
                pos["holding_minutes"] = 0

            # Update highest price seen
            if current_p > pos["highest_price"]:
                pos["highest_price"] = current_p

            current_gain_pct = ((current_p - entry_p) / entry_p) * 100.0

            # -------------------------------------------------------------
            # FEATURE 1: PROACTIVE BREAK-EVEN PROTECTION AT EARLY +1.5% GAIN (Tighter)
            # -------------------------------------------------------------
            if not pos.get("break_even_active", False) and current_gain_pct >= config.EARLY_BREAK_EVEN_PCT:
                be_price = entry_p * (1.0 + (BREAK_EVEN_BUFFER_PCT / 100.0))
                pos["stop_loss_price"] = max(pos["stop_loss_price"], round(be_price, 6))
                pos["stop_loss_pct"] = -BREAK_EVEN_BUFFER_PCT
                pos["break_even_active"] = True

            # -------------------------------------------------------------
            # FEATURE 2: PARTIAL TAKE PROFIT 1 (TP1) & HARVEST 50%
            # -------------------------------------------------------------
            if not pos.get("tp1_hit", False) and current_p >= pos["take_profit_1"]:
                qty_to_sell = qty * PARTIAL_TP1_RATIO
                gross_tp1 = qty_to_sell * current_p
                fee_tp1 = gross_tp1 * (EFFECTIVE_FEE_PCT / 100.0)
                net_tp1 = gross_tp1 - fee_tp1
                cost_slice = pos["position_usdt"] * PARTIAL_TP1_RATIO
                slice_buy_fee = pos.get("buy_fee_usdt", 0.0) * PARTIAL_TP1_RATIO
                total_slice_fee = fee_tp1 + slice_buy_fee

                gross_slice_pnl = gross_tp1 - cost_slice
                net_slice_pnl = gross_slice_pnl - total_slice_fee
                slice_pct = (net_slice_pnl / cost_slice) * 100.0

                if self.mode == "live":
                    try:
                        self.client.place_order(symbol, side="SELL", quantity=qty_to_sell)
                    except Exception as e:
                        print(f"[Execution Error] Failed live TP1 partial order: {e}")

                # Realize cash & accounting
                self.state["cash_usdt"] += net_tp1
                self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_tp1, 4)
                self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_slice_pnl, 4)
                self.state["realized_pnl_usdt"] = round(self.state.get("realized_pnl_usdt", 0.0) + net_slice_pnl, 4)

                # Adjust remaining position
                pos["quantity"] -= qty_to_sell
                pos["position_usdt"] -= cost_slice
                pos["tp1_hit"] = True
                pos["partial_pnl_realized"] = round(net_slice_pnl, 4)

                # Confirm Break-Even
                be_price = entry_p * (1.0 + (BREAK_EVEN_BUFFER_PCT / 100.0))
                pos["stop_loss_price"] = max(pos["stop_loss_price"], round(be_price, 6))
                pos["stop_loss_pct"] = -BREAK_EVEN_BUFFER_PCT
                pos["break_even_active"] = True

                tp1_event = {
                    "symbol": symbol,
                    "action": "PARTIAL_TP1_TAKEN",
                    "reason": f"TP1_SCALED_OUT_{int(PARTIAL_TP1_RATIO * 100)}%_SL_MOVED_TO_BREAK_EVEN",
                    "entry_price": entry_p,
                    "exit_price": round(current_p, 6),
                    "gross_pnl_usdt": round(gross_slice_pnl, 4),
                    "fee_paid_usdt": round(total_slice_fee, 4),
                    "pnl_usdt": round(net_slice_pnl, 4),
                    "pnl_pct": round(slice_pct, 2),
                    "remaining_qty": round(pos["quantity"], 4),
                    "entry_time": pos["entry_time"],
                    "exit_time": datetime.now(timezone.utc).isoformat()
                }
                actions.append(tp1_event)
                self._log_trade(tp1_event)

            # -------------------------------------------------------------
            # FEATURE 3: ADAPTIVE VOLATILITY TRAILING STOP (Earlier Activation)
            # -------------------------------------------------------------
            if not pos.get("trailing_active", False) and current_gain_pct >= config.TRAILING_STOP_TRIGGER_PCT:
                pos["trailing_active"] = True
                # Adaptive trail: scale with the asset's own volatility (ATR), floored
                # by a fraction of original risk. A fixed % trail chokes winners on
                # volatile assets and gives too much room on quiet ones.
                atr_based = 1.5 * abs(float(pos.get("entry_atr_pct", 0.0) or 0.0))
                risk_based = abs(pos.get("entry_stop_loss_pct", pos.get("stop_loss_pct", 1.5))) * 0.75
                vol_trail_pct = max(0.9, min(3.0, max(atr_based, risk_based)))
                pos["trailing_distance_pct"] = round(vol_trail_pct, 2)
                new_trail = pos["highest_price"] * (1 - (vol_trail_pct / 100.0))
                pos["trailing_stop_price"] = max(pos["trailing_stop_price"], new_trail)

            if pos["trailing_active"]:
                vol_trail_pct = pos.get("trailing_distance_pct", config.TRAILING_STOP_DISTANCE_PCT)
                new_trail = pos["highest_price"] * (1 - (vol_trail_pct / 100.0))
                if new_trail > pos["trailing_stop_price"]:
                    pos["trailing_stop_price"] = new_trail

            close_reason = None
            exit_price = current_p
            slip_applied_pct = 0.0

            # 1. Take Profit 2 Target Hit (Full Extension Exit)
            if current_p >= pos["take_profit_2"]:
                close_reason = "TAKE_PROFIT_2_HIT"
                exit_price = pos["take_profit_2"]

            # 2. Trailing Stop Hit (Locked Profit) - fills below the trigger
            elif pos["trailing_active"] and current_p <= pos["trailing_stop_price"]:
                close_reason = "TRAILING_STOP_EXIT"
                slip_applied_pct = self._slippage_pct(pos)
                exit_price = pos["trailing_stop_price"] * (1 - slip_applied_pct / 100.0)

            # 3. Stop Loss Hit (Hard SL or Break-Even SL) - worst slippage case
            elif current_p <= pos["stop_loss_price"]:
                close_reason = "BREAK_EVEN_STOP_EXIT" if pos.get("break_even_active") else "STOP_LOSS_HIT"
                slip_applied_pct = self._slippage_pct(pos)
                exit_price = pos["stop_loss_price"] * (1 - slip_applied_pct / 100.0)

            else:
                try:
                    entry_dt = datetime.fromisoformat(pos["entry_time"])
                    hold_minutes = (datetime.now(timezone.utc) - entry_dt).total_seconds() / 60.0
                    hold_hours = hold_minutes / 60.0

                    # 4. MICRO-PROFIT SALVAGE: an aged position sitting on a small but
                    #    real net gain is banked as a win instead of being left to
                    #    decay back into the stop. Directly lifts realized win rate.
                    roundtrip_fee_pct = EFFECTIVE_FEE_PCT * 2.0
                    net_gain_pct = current_gain_pct - roundtrip_fee_pct
                    if (
                        hold_minutes >= config.MICRO_PROFIT_SALVAGE_AFTER_MIN
                        and net_gain_pct >= config.MICRO_PROFIT_SALVAGE_PCT
                        and not pos.get("trailing_active", False)
                    ):
                        close_reason = "MICRO_PROFIT_SALVAGE_EXIT"
                        exit_price = current_p

                    # 5. Stagnation / Time-Decay Exit (Recycle capital after max hold)
                    elif hold_hours >= MAX_HOLD_HOURS_STAGNANT and abs(current_gain_pct) < 0.60:
                        close_reason = "STAGNATION_TIMEOUT_EXIT"
                        exit_price = current_p
                except Exception:
                    pass

            if close_reason:
                remaining_qty = pos["quantity"]
                if self.mode == "live":
                    try:
                        self.client.place_order(symbol, side="SELL", quantity=remaining_qty)
                    except Exception as e:
                        print(f"[Execution Error] Failed live close order: {e}")

                gross_return = remaining_qty * exit_price
                fee_close = gross_return * (EFFECTIVE_FEE_PCT / 100.0)
                net_return = gross_return - fee_close
                remaining_buy_fee = pos.get("buy_fee_usdt", 0.0) * (remaining_qty / pos.get("initial_quantity", remaining_qty))
                total_trade_fee = round(fee_close + remaining_buy_fee, 4)

                gross_trade_pnl = gross_return - pos["position_usdt"]
                net_trade_pnl = gross_trade_pnl - total_trade_fee + pos.get("partial_pnl_realized", 0.0)
                total_trade_pct = (net_trade_pnl / pos.get("initial_cost_usdt", pos["position_usdt"])) * 100.0

                self.state["cash_usdt"] += net_return
                self.state["total_trades"] += 1
                self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_close, 4)
                self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_trade_pnl, 4)
                self.state["realized_pnl_usdt"] = round(self.state.get("realized_pnl_usdt", 0.0) + net_trade_pnl, 4)

                trade_event = {
                    "symbol": symbol,
                    "action": "CLOSED",
                    "reason": close_reason,
                    "entry_price": entry_p,
                    "exit_price": round(exit_price, 6),
                    "slippage_pct": round(slip_applied_pct, 4),
                    "gross_pnl_usdt": round(gross_trade_pnl, 4),
                    "fee_paid_usdt": total_trade_fee,
                    "pnl_usdt": round(net_trade_pnl, 4),
                    "pnl_pct": round(total_trade_pct, 2),
                    "entry_time": pos["entry_time"],
                    "exit_time": datetime.now(timezone.utc).isoformat()
                }

                # Honest win accounting: a flat/break-even scratch is NOT a win.
                # Counting zero-PnL exits as wins inflates the reported win rate
                # without adding any money to the account.
                scratch_threshold = pos.get("initial_cost_usdt", pos["position_usdt"]) * 0.0005
                if net_trade_pnl > scratch_threshold:
                    self.state["winning_trades"] += 1
                    trade_event["outcome"] = "WIN"
                elif net_trade_pnl < -scratch_threshold:
                    self.state["losing_trades"] += 1
                    trade_event["outcome"] = "LOSS"
                    try:
                        from agents.consciousness import consciousness_engine
                        consciousness_engine.record_trade_failure_and_learn(trade_event)
                    except Exception as e:
                        print(f"[Consciousness Learning Error] {e}")
                else:
                    self.state["scratch_trades"] = self.state.get("scratch_trades", 0) + 1
                    trade_event["outcome"] = "SCRATCH"

                actions.append(trade_event)
                self._log_trade(trade_event)
            else:
                remaining_positions.append(pos)

        self.state["open_positions"] = remaining_positions
        self._save_portfolio(self.state)
        self.record_equity_snapshot()
        return actions

    def reset_portfolio(self, initial_capital: float = INITIAL_PAPER_BALANCE_USDT):
        """Reset paper trading portfolio balance."""
        self.state = {
            "mode": self.mode,
            "cash_usdt": initial_capital,
            "initial_capital": initial_capital,
            "open_positions": [],
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "total_fees_paid_usdt": 0.0,
            "gross_realized_pnl_usdt": 0.0,
            "realized_pnl_usdt": 0.0,
            "equity_history": [
                {
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "equity": initial_capital,
                    "cash": initial_capital
                }
            ],
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        self._save_portfolio(self.state)

    def close_all_positions(self, reason: str = "BOT_SHUTDOWN_LIQUIDATION") -> List[Dict[str, Any]]:
        """
        Auto-liquidate / market sell all open positions immediately upon bot closure / emergency stop.
        Realizes PnL, accounts for fees, returns cash to portfolio, and records into trade history.
        """
        closed_events = []
        positions_to_close = list(self.state.get("open_positions", []))

        for pos in positions_to_close:
            symbol = pos["symbol"]
            qty = pos["quantity"]
            entry_p = pos["entry_price"]

            try:
                current_p = self.client.get_price(symbol)
            except Exception:
                current_p = entry_p

            if self.mode == "live":
                try:
                    self.client.place_order(symbol, side="SELL", quantity=qty)
                except Exception as e:
                    print(f"[Emergency Close Error] Failed live market order for {symbol}: {e}")

            gross_return = qty * current_p
            fee_close = gross_return * (EFFECTIVE_FEE_PCT / 100.0)
            net_return = gross_return - fee_close
            remaining_buy_fee = pos.get("buy_fee_usdt", 0.0) * (qty / pos.get("initial_quantity", qty))
            total_trade_fee = round(fee_close + remaining_buy_fee, 4)

            gross_trade_pnl = gross_return - pos["position_usdt"]
            net_trade_pnl = gross_trade_pnl - total_trade_fee + pos.get("partial_pnl_realized", 0.0)
            total_trade_pct = (net_trade_pnl / pos.get("initial_cost_usdt", pos["position_usdt"])) * 100.0

            self.state["cash_usdt"] += net_return
            self.state["total_trades"] += 1
            self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_close, 4)
            self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_trade_pnl, 4)
            self.state["realized_pnl_usdt"] = round(self.state.get("realized_pnl_usdt", 0.0) + net_trade_pnl, 4)

            if net_trade_pnl >= 0:
                self.state["winning_trades"] += 1
            else:
                self.state["losing_trades"] += 1

            event = {
                "symbol": symbol,
                "action": "CLOSED",
                "reason": reason,
                "entry_price": entry_p,
                "exit_price": round(current_p, 6),
                "gross_pnl_usdt": round(gross_trade_pnl, 4),
                "fee_paid_usdt": total_trade_fee,
                "pnl_usdt": round(net_trade_pnl, 4),
                "pnl_pct": round(total_trade_pct, 2),
                "entry_time": pos["entry_time"],
                "exit_time": datetime.now(timezone.utc).isoformat()
            }
            closed_events.append(event)
            self._log_trade(event)

        self.state["open_positions"] = []
        self._save_portfolio(self.state)
        self.record_equity_snapshot()
        print(f"\n[PortfolioManager] Auto-sold all {len(closed_events)} open positions due to {reason}.")
        return closed_events

    def get_periodic_performance(self) -> Dict[str, Any]:
        """
        Calculates periodic performance metrics (Today, This Week, This Month)
        aggregating realized profit, gross profit, fees paid, win rate, and trade counts.
        """
        now = datetime.now(timezone.utc)
        today_date = now.date()
        week_start = today_date - timedelta(days=7)
        current_month = now.month
        current_year = now.year

        trades = []
        import config
        trade_file = config.TRADE_LOG_FILE
        if trade_file.exists():
            try:
                with open(trade_file, "r", encoding="utf-8") as f:
                    trades = json.load(f)
            except Exception:
                trades = []

        def _aggregate(bucket_trades: List[Dict[str, Any]]) -> Dict[str, Any]:
            count = len(bucket_trades)
            wins = sum(1 for t in bucket_trades if t.get("pnl_usdt", 0.0) >= 0)
            losses = count - wins
            win_rate = round((wins / max(1, count)) * 100.0, 1)
            net_pnl = sum(t.get("pnl_usdt", 0.0) for t in bucket_trades)
            gross_pnl = sum(t.get("gross_pnl_usdt", t.get("pnl_usdt", 0.0)) for t in bucket_trades)
            fees = sum(t.get("fee_paid_usdt", 0.0) for t in bucket_trades)
            return {
                "trades": count,
                "wins": wins,
                "losses": losses,
                "win_rate": win_rate,
                "net_pnl_usdt": round(net_pnl, 4),
                "gross_pnl_usdt": round(gross_pnl, 4),
                "fees_paid_usdt": round(fees, 4)
            }

        today_trades = []
        week_trades = []
        month_trades = []

        for t in trades:
            time_str = t.get("exit_time") or t.get("entry_time")
            if not time_str:
                continue
            try:
                t_dt = datetime.fromisoformat(time_str)
                t_date = t_dt.date()

                if t_date == today_date:
                    today_trades.append(t)
                if t_date >= week_start:
                    week_trades.append(t)
                if t_dt.year == current_year and t_dt.month == current_month:
                    month_trades.append(t)
            except Exception:
                continue

        return {
            "today": _aggregate(today_trades),
            "this_week": _aggregate(week_trades),
            "this_month": _aggregate(month_trades)
        }

    def get_trade_history(self) -> List[Dict[str, Any]]:
        import config
        if config.TRADE_LOG_FILE.exists():
            try:
                with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []
        return []
