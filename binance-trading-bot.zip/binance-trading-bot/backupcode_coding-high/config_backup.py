import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Auto-load .env file if present
ENV_FILE = BASE_DIR / ".env"
if ENV_FILE.exists():
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip("'\""))

DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

PORTFOLIO_FILE = DATA_DIR / "portfolio.json"
TRADE_LOG_FILE = DATA_DIR / "trade_history.json"

# Binance API configuration
BINANCE_API_URL = os.getenv("BINANCE_API_URL", "https://api.binance.com")
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET", "")

# Operational Mode: 'paper' (simulated with real live Binance prices) or 'live'
TRADING_MODE = os.getenv("TRADING_MODE", "paper").lower()

# Paper Trading Capital
INITIAL_PAPER_BALANCE_USDT = float(os.getenv("INITIAL_PAPER_BALANCE", "1000.0"))

# OpenAI & Custom LLM Endpoint Configuration (Default: Clouvia Router)
CLOUVIA_API_KEY = os.getenv("CLOUVIA_API_KEY", os.getenv("OPENAI_API_KEY", "[REDACTED_SECRET:CLOUVIA_API_KEY]"))
OPENAI_API_KEY = CLOUVIA_API_KEY
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://router.clouvia.id/v1").rstrip("/")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", os.getenv("CLOUVIA_MODEL", "coding-high"))
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.3"))

# Web Visualization Dashboard
WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
WEB_PORT = int(os.getenv("WEB_PORT", "8080"))

# Universal Multi-Quote Pairing Configuration ("Pairing crypto bebas asalkan menguntungkan")
ACCEPTED_QUOTE_ASSETS = ["USDT", "FDUSD", "USDC"]
MIN_24H_VOLUME_USDT = float(os.getenv("MIN_VOLUME_USDT", "3000000"))  # $3,000,000 min volume for high liquidity
MIN_PRICE_CHANGE_24H = float(os.getenv("MIN_CHANGE_PCT", "0.5"))     # +0.5% min 24h change (catches early momentum)
MAX_PRICE_CHANGE_24H = float(os.getenv("MAX_CHANGE_PCT", "55.0"))    # avoid blow-off tops >55%
KLINES_TIMEFRAME = os.getenv("TIMEFRAME", "15m")                      # 15-minute primary timeframe
KLINES_LIMIT = 100

# Excluded tokens (stablecoin-to-stablecoin pairs, leveraged tokens, wrapped)
EXCLUDED_SYMBOLS = {
    "USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "EURUSDT", "DAIUSDT", "USDPUSDT",
    "BUSDUSDT", "AEURUSDT", "WBTCUSDT", "WBETHUSDT", "USDCFDUSD", "FDUSDUSDC",
    "EURUSDC", "USDTUSDC", "USDTFDUSD"
}

# Transaction Fee Engine Configuration ("Menghitung transaksi fee")
ESTIMATED_FEE_PCT = float(os.getenv("ESTIMATED_FEE_PCT", "0.10"))  # Standard Binance 0.10% fee per side
BNB_FEE_DISCOUNT = os.getenv("BNB_FEE_DISCOUNT", "false").lower() == "true"
EFFECTIVE_FEE_PCT = ESTIMATED_FEE_PCT * 0.75 if BNB_FEE_DISCOUNT else ESTIMATED_FEE_PCT

# Risk Management & Capital Preservation Guardrails
MAX_OPEN_POSITIONS = 3
RISK_PER_TRADE_PCT = 2.0         # Risk max 2% of total equity on SL
MAX_POSITION_SIZE_PCT = 25.0     # Max 25% of total portfolio in one asset
MIN_RISK_REWARD_RATIO = 2.0      # Minimum R:R ratio 1:2
MAX_ALLOWABLE_SPREAD_PCT = 0.20  # Max spread 0.20%

# Enhanced Win Rate Optimization Parameters (Target: 60-70% Win Rate)
ADAPTIVE_ATR_MULTIPLIER = 1.2    # Tighter ATR multiplier for stops (was 1.5x)
EARLY_BREAK_EVEN_PCT = 1.5       # Proactive break-even at +1.5% profit (was 1.8%)
FASTER_TP1_RATIO = 0.60          # Partial exit 60% at TP1 for faster capital recycling
ENHANCED_MIN_CONVICTION = 75     # Min executive conviction threshold (was 70%)
VOLUME_SURGE_FILTER = 1.3        # Require minimum 1.3x volume surge (up from 1.0x)
TREND_TIMEFRAME_1 = "1h"         # Primary trend confirmation timeframe
TREND_TIMEFRAME_2 = "4h"         # Secondary trend alignment timeframe

# Dynamic Exit & Profit Scaling Rules (Enhanced for Win Rate Optimization)
BREAK_EVEN_BUFFER_PCT = 0.20        # Move Stop Loss to Entry + 0.20% (covering round-trip fees)
TRAILING_STOP_TRIGGER_PCT = 2.0     # Activate trailing stop when profit hits +2.0% (was 2.5%)
TRAILING_STOP_DISTANCE_PCT = 1.0    # Baseline trailing distance behind peak price (tighter, was 1.2%)
HARD_STOP_LOSS_DEFAULT_PCT = 2.0    # Fallback max stop loss if ATR not available
TARGET_TAKE_PROFIT_PCT = 4.5        # Target minimum take-profit level
MAX_HOLD_HOURS_STAGNANT = 18.0      # Exit stagnant trades after 18h if profit < 0.5% (faster recycle, was 24h)

# Macro Market Sentinel (Bitcoin Beta & Global Circuit Breaker)
MACRO_BENCHMARK_SYMBOL = "BTCUSDT"
MACRO_CIRCUIT_BREAKER_ENABLED = True
MACRO_MIN_BTC_RSI = 42.0            # Veto altcoin entries if Bitcoin RSI < 42 (market selloff)
