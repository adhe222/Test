import os
import json
import asyncio
from datetime import datetime, timezone
from typing import Dict, Any, List
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from orchestrator import TradingOrchestrator
import config
from config import (
    WEB_HOST,
    WEB_PORT,
    TRADING_MODE,
    INITIAL_PAPER_BALANCE_USDT,
    EFFECTIVE_FEE_PCT,
    ACCEPTED_QUOTE_ASSETS,
    MAX_OPEN_POSITIONS
)
from agents.consciousness import consciousness_engine

orchestrator = TradingOrchestrator()
TEMPLATE_FILE = Path(__file__).resolve().parent / "templates" / "dashboard.html"

# Cache latest scan cycle results
latest_scan_data: Dict[str, Any] = {
    "last_updated": None,
    "ai_status": orchestrator.llm.status_summary,
    "macro_health": {},
    "candidates_scanned": 0,
    "candidates_evaluated": [],
    "executed_trades": [],
    "exit_events": [],
    "portfolio_summary": {}
}

cycle_count = 0
last_cycle_time = None
is_scanning = False
AUTO_SCAN_INTERVAL_SEC = 10
POSITION_GUARD_INTERVAL_SEC = 3


async def high_frequency_position_guard():
    """Runs every 3 seconds: guards open positions, trails stops, locks break-even, executes TP1 scaling in real time."""
    await asyncio.sleep(2)
    print("\n[PositionWatchdog] High-frequency real-time position guard active (3s interval).")
    while True:
        try:
            loop = asyncio.get_running_loop()
            actions = await loop.run_in_executor(None, orchestrator.portfolio.update_and_monitor_positions)
            if actions:
                for act in actions:
                    print(f"\n[RealAction] Position Event: {act['symbol']} ➔ {act['action']} ({act['reason']}) PnL: ${act['pnl_usdt']}")
        except Exception as e:
            print(f"[PositionWatchdog Error] {e}")
        await asyncio.sleep(POSITION_GUARD_INTERVAL_SEC)


async def market_deliberation_loop():
    """Runs every 10 seconds: scans Binance market, audits BTC macro regime, triggers 8 divisions, executes trades."""
    global cycle_count, last_cycle_time, is_scanning, latest_scan_data
    await asyncio.sleep(3)
    print("\n[MarketEngine] Continuous market scanning and multi-agent deliberation active (10s interval).")
    while True:
        try:
            is_scanning = True
            loop = asyncio.get_running_loop()
            res = await loop.run_in_executor(None, orchestrator.run_cycle)
            cycle_count += 1
            latest_scan_data = res
            latest_scan_data["last_updated"] = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
            last_cycle_time = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
            if res.get("executed_trades"):
                for tr in res["executed_trades"]:
                    print(f"\n[RealAction] NEW ORDER EXECUTED: {tr['symbol']} @ ${tr['price']} | Size: ${tr['risk_plan']['position_usdt']}")
        except Exception as e:
            print(f"[MarketEngine Error] {e}")
        finally:
            is_scanning = False

        await asyncio.sleep(AUTO_SCAN_INTERVAL_SEC)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task1 = asyncio.create_task(high_frequency_position_guard())
    task2 = asyncio.create_task(market_deliberation_loop())
    yield
    task1.cancel()
    task2.cancel()


app = FastAPI(title="Binance Institutional AI Multi-Agent Trading System", lifespan=lifespan)

# Serve PWA assets (manifest, service worker, icons) if present
STATIC_DIR = Path(__file__).resolve().parent / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/manifest.webmanifest")
async def pwa_manifest():
    f = STATIC_DIR / "manifest.webmanifest"
    if f.exists():
        return FileResponse(str(f), media_type="application/manifest+json")
    return JSONResponse({"detail": "manifest not found"}, status_code=404)


@app.get("/sw.js")
async def service_worker():
    f = STATIC_DIR / "sw.js"
    if f.exists():
        # Root scope is required for a service worker controlling "/"
        return FileResponse(
            str(f),
            media_type="application/javascript",
            headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"},
        )
    return JSONResponse({"detail": "service worker not found"}, status_code=404)


@app.get("/api/status")
async def get_status():
    global latest_scan_data, cycle_count, is_scanning, last_cycle_time
    open_positions = orchestrator.portfolio.get_open_positions()
    equity = orchestrator.portfolio.get_equity()
    state = orchestrator.portfolio.state

    enriched_positions = []
    total_unrealized_pnl = 0.0
    allocated_margin = 0.0

    for pos in open_positions:
        sym = pos["symbol"]
        qty = pos["quantity"]
        entry_p = pos["entry_price"]
        cost_usdt = pos.get("position_usdt", 0.0)
        allocated_margin += cost_usdt

        try:
            curr_p = orchestrator.client.get_price(sym)
            pnl_usdt = (curr_p - entry_p) * qty
            pnl_pct = ((curr_p - entry_p) / entry_p) * 100.0
        except Exception:
            curr_p = entry_p
            pnl_usdt = 0.0
            pnl_pct = 0.0

        total_unrealized_pnl += pnl_usdt

        # Parse quote and base for clean display
        pair_disp = sym
        for q in ACCEPTED_QUOTE_ASSETS:
            if sym.endswith(q):
                pair_disp = f"{sym[:-len(q)]}/{q}"
                break

        p = dict(pos)
        p["current_price"] = curr_p
        p["pair_display"] = pair_disp
        p["unrealized_pnl_usdt"] = round(pnl_usdt, 4)
        p["unrealized_pnl_pct"] = round(pnl_pct, 2)
        p["roundtrip_fee_usdt"] = round(cost_usdt * (EFFECTIVE_FEE_PCT / 100.0) * 2.0, 4)
        enriched_positions.append(p)

    initial_cap = state.get("initial_capital", INITIAL_PAPER_BALANCE_USDT)
    realized_pnl = state.get("realized_pnl_usdt", 0.0)
    gross_realized_pnl = state.get("gross_realized_pnl_usdt", 0.0)
    total_fees_paid = state.get("total_fees_paid_usdt", 0.0)

    total_net_pnl = round(realized_pnl + total_unrealized_pnl, 4)
    total_net_pnl_pct = round(((equity - initial_cap) / initial_cap) * 100.0, 2)

    macro_info = latest_scan_data.get("macro_health")
    if not macro_info:
        macro_info = orchestrator.macro_sentinel.evaluate_macro_health()

    # Load closed trades history
    trade_history = []
    all_events = []
    if config.TRADE_LOG_FILE.exists():
        try:
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                all_events = json.load(f)
                trade_history = all_events[-40:][::-1]
        except Exception:
            all_events = []
            trade_history = []

    # ----- Win-rate quality analytics (computed from the immutable ledger) -----
    closed = [e for e in all_events if e.get("action") == "CLOSED"]
    wins = [e for e in closed if float(e.get("pnl_usdt", 0.0)) > 0]
    losses = [e for e in closed if float(e.get("pnl_usdt", 0.0)) <= 0]
    gross_win = sum(float(e.get("pnl_usdt", 0.0)) for e in wins)
    gross_loss = abs(sum(float(e.get("pnl_usdt", 0.0)) for e in losses))
    avg_win = (gross_win / len(wins)) if wins else 0.0
    avg_loss = (gross_loss / len(losses)) if losses else 0.0
    ledger_win_rate = (len(wins) / len(closed) * 100.0) if closed else 0.0
    profit_factor = (gross_win / gross_loss) if gross_loss > 0 else (gross_win if gross_win > 0 else 0.0)
    expectancy = (
        (ledger_win_rate / 100.0) * avg_win - (1 - ledger_win_rate / 100.0) * avg_loss
    ) if closed else 0.0

    exit_breakdown: Dict[str, int] = {}
    for e in closed:
        key = e.get("reason", "UNKNOWN")
        exit_breakdown[key] = exit_breakdown.get(key, 0) + 1

    # Rolling win rate over the last 20 completed trades (regime-sensitive)
    recent = closed[-20:]
    recent_wins = sum(1 for e in recent if float(e.get("pnl_usdt", 0.0)) > 0)
    rolling_win_rate = (recent_wins / len(recent) * 100.0) if recent else 0.0

    state_total = state.get("total_trades", 0)
    state_wins = state.get("winning_trades", 0)
    state_win_rate = (state_wins / state_total * 100.0) if state_total > 0 else 0.0

    return {
        "mode": state.get("mode", TRADING_MODE).upper(),
        # Saldo Akun
        "initial_capital_usdt": round(initial_cap, 2),
        "equity_usdt": round(equity, 2),
        "cash_usdt": round(state.get("cash_usdt", 0.0), 2),
        "allocated_margin_usdt": round(allocated_margin, 2),
        "capacity_used": len(open_positions),
        "capacity_max": MAX_OPEN_POSITIONS,
        # Transaksi Fee & Profit Accounting
        "effective_fee_pct": EFFECTIVE_FEE_PCT,
        "total_fees_paid_usdt": round(total_fees_paid, 4),
        "gross_realized_pnl_usdt": round(gross_realized_pnl, 4),
        "realized_pnl_usdt": round(realized_pnl, 4),
        "unrealized_pnl_usdt": round(total_unrealized_pnl, 4),
        "unrealized_pnl_pct": round((total_unrealized_pnl / max(1.0, allocated_margin)) * 100.0, 2) if allocated_margin > 0 else 0.0,
        "total_net_pnl_usdt": total_net_pnl,
        "total_net_pnl_pct": total_net_pnl_pct,
        "total_trades": state_total,
        "winning_trades": state_wins,
        "losing_trades": state.get("losing_trades", 0),
        "win_rate": round(state_win_rate, 1),
        # Win-rate quality analytics (target 70%)
        "win_rate_target": 70.0,
        "ledger_win_rate": round(ledger_win_rate, 1),
        "rolling_win_rate_20": round(rolling_win_rate, 1),
        "rolling_sample_size": len(recent),
        "avg_win_usdt": round(avg_win, 4),
        "avg_loss_usdt": round(avg_loss, 4),
        "profit_factor": round(profit_factor, 2),
        "expectancy_usdt": round(expectancy, 4),
        "exit_reason_breakdown": exit_breakdown,
        "quality_gates": {
            "min_technical_score": config.MIN_TECHNICAL_SCORE,
            "min_conviction": config.ENHANCED_MIN_CONVICTION,
            "min_net_rr": config.MIN_RISK_REWARD_RATIO,
            "atr_stop_multiplier": config.ADAPTIVE_ATR_MULTIPLIER,
            "break_even_at_pct": config.EARLY_BREAK_EVEN_PCT,
            "tp1_exit_ratio": config.FASTER_TP1_RATIO,
            "trailing_trigger_pct": config.TRAILING_STOP_TRIGGER_PCT,
            "max_hold_hours": config.MAX_HOLD_HOURS_STAGNANT,
            "daily_loss_limit_pct": config.DAILY_LOSS_LIMIT_PCT,
        },
        "adaptive_guard": latest_scan_data.get("adaptive_guard", {}),
        "daily_loss_limit_hit": latest_scan_data.get("daily_loss_limit_hit", False),
        # Detail Data & Multi-Pairing
        "accepted_quotes": ACCEPTED_QUOTE_ASSETS,
        "open_positions": enriched_positions,
        "trade_history": trade_history,
        "equity_history": state.get("equity_history", []),
        "macro_health": macro_info,
        "ai_status": orchestrator.llm.status_summary,
        "periodic_performance": orchestrator.portfolio.get_periodic_performance(),
        "agent_consciousness": consciousness_engine.memory.get("divisions", {}),
        "total_mistakes_analyzed": consciousness_engine.memory.get("total_mistakes_analyzed", 0),
        "total_vetoes_prevented": consciousness_engine.memory.get("total_vetoes_prevented", 0),
        "total_upgrades_performed": consciousness_engine.memory.get("total_upgrades_performed", 0),
        "ai_intelligence_level": consciousness_engine.memory.get("ai_intelligence_level", "2.2.0-ULTRA"),
        "last_upgrade_mode": consciousness_engine.memory.get("last_upgrade_mode", "DETERMINISTIC"),
        "latest_scan": latest_scan_data,
        "autonomous_loop": {
            "active": True,
            "cycle_count": cycle_count,
            "is_scanning": is_scanning,
            "interval_sec": AUTO_SCAN_INTERVAL_SEC,
            "last_cycle_time": last_cycle_time
        }
    }


@app.get("/api/health")
async def health_check():
    """Liveness probe for the autonomous engine (read-only)."""
    return {
        "status": "ok",
        "mode": orchestrator.portfolio.mode,
        "cycle_count": cycle_count,
        "is_scanning": is_scanning,
        "last_cycle_time": last_cycle_time
    }


@app.get("/", response_class=HTMLResponse)
async def dashboard_page():
    if TEMPLATE_FILE.exists():
        with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>Dashboard Template not found</h1>", status_code=500)


def start_server():
    print(f"\n[Dashboard] Starting Binance AI Real-time Surveillance on http://{WEB_HOST}:{WEB_PORT}")
    uvicorn.run(app, host=WEB_HOST, port=WEB_PORT, log_level="warning")


if __name__ == "__main__":
    start_server()
