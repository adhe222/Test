import time
import hmac
import threading
import hashlib
from urllib.parse import urlencode
from typing import Dict, List, Optional, Any
import requests

import config as _cfg
from config import BINANCE_API_URL, BINANCE_API_KEY, BINANCE_API_SECRET
try:
    from config import BINANCE_PROXY_URL
except ImportError:
    BINANCE_PROXY_URL = ""

DEFAULT_ENDPOINTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com"
]


class BinanceClient:
    def __init__(self, base_url: str = BINANCE_API_URL, api_key: str = BINANCE_API_KEY, api_secret: str = BINANCE_API_SECRET):
        primary = base_url.rstrip("/") if base_url else "https://data-api.binance.vision"
        endpoints = [primary]
        for ep in DEFAULT_ENDPOINTS:
            if ep not in endpoints:
                endpoints.append(ep)
        self.endpoints = endpoints
        self.active_base_url = primary
        self._cache = {}
        self._cache_lock = threading.Lock()
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        if BINANCE_PROXY_URL:
            self.session.proxies = {"http": BINANCE_PROXY_URL, "https": BINANCE_PROXY_URL}
        if self.api_key:
            self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    def _sign_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _cache_get(self, key: str) -> Optional[Any]:
        with self._cache_lock:
            entry = self._cache.get(key)
            if entry and entry[0] > time.time():
                return entry[1]
        return None

    def _cache_set(self, key: str, ttl_sec: float, value: Any) -> None:
        with self._cache_lock:
            self._cache[key] = (time.time() + float(ttl_sec), value)

    def clear_cache(self) -> None:
        with self._cache_lock:
            self._cache.clear()

    def _request_with_fallback(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 4.0) -> requests.Response:
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}{path}"
            try:
                resp = self.session.request(method, url, params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_base_url = base
                return resp
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint")

    def get_24hr_tickers(self) -> List[Dict[str, Any]]:
        key = "tickers:24hr"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        resp = self._request_with_fallback("GET", "/api/v3/ticker/24hr", timeout=6.0)
        data = resp.json()
        self._cache_set(key, getattr(_cfg, "TICKER_CACHE_TTL_SEC", 25), data)
        return data

    def get_price(self, symbol: str) -> float:
        key = f"price:{symbol}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        resp = self._request_with_fallback("GET", "/api/v3/ticker/price", params={"symbol": symbol}, timeout=4.0)
        data = resp.json()
        price = float(data["price"])
        self._cache_set(key, getattr(_cfg, "PRICE_CACHE_TTL_SEC", 10), price)
        return price

    _KLINE_INTERVAL_SEC = {
        "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "8h": 28800,
        "12h": 43200, "1d": 86400,
    }

    def _klines_cache_ttl(self, interval: str) -> float:
        cap = float(getattr(_cfg, "KLINES_CACHE_TTL_SEC", 120))
        interval_sec = self._KLINE_INTERVAL_SEC.get(interval, 900)
        return max(15.0, min(cap, interval_sec / 4.0))

    def get_klines(self, symbol: str, interval: str = "15m", limit: int = 100) -> List[Dict[str, Any]]:
        key = f"klines:{symbol}:{interval}:{limit}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        resp = self._request_with_fallback("GET", "/api/v3/klines", params=params, timeout=5.0)
        raw_klines = resp.json()

        klines = []
        for k in raw_klines:
            klines.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "quote_volume": float(k[7]),
                "trades": int(k[8])
            })
        self._cache_set(key, self._klines_cache_ttl(interval), klines)
        return klines

    def get_orderbook(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        key = f"depth:{symbol}:{limit}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        params = {"symbol": symbol, "limit": limit}
        data = None
        for attempt in range(2):
            try:
                resp = self._request_with_fallback("GET", "/api/v3/depth", params=params, timeout=4.0)
                data = resp.json()
                break
            except Exception:
                if attempt:
                    raise
                time.sleep(0.6)
        bids = [[float(p), float(q)] for p, q in data.get("bids", [])]
        asks = [[float(p), float(q)] for p, q in data.get("asks", [])]
        book = {"bids": bids, "asks": asks}
        self._cache_set(key, getattr(_cfg, "ORDERBOOK_CACHE_TTL_SEC", 8), book)
        return book

    def get_account_info(self) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for private account endpoints.")
        params = self._sign_params({})
        resp = self._request_with_fallback("GET", "/api/v3/account", params=params, timeout=6.0)
        return resp.json()

    def place_order(self, symbol: str, side: str, order_type: str = "MARKET",
                    quantity: Optional[float] = None, quote_order_qty: Optional[float] = None) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper()
        }
        if quantity is not None:
            params["quantity"] = f"{quantity:.6f}"
        elif quote_order_qty is not None:
            params["quoteOrderQty"] = f"{quote_order_qty:.2f}"
        else:
            raise ValueError("Either quantity or quote_order_qty must be provided.")

        params = self._sign_params(params)
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}/api/v3/order"
            try:
                resp = self.session.post(url, params=params, timeout=6.0)
                resp.raise_for_status()
                self.active_base_url = base
                return resp.json()
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint for placing order")

    def _signed_request(self, method: str, path: str, params: Dict[str, Any], timeout: float = 8.0) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        params = self._sign_params(dict(params))
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}{path}"
            try:
                resp = self.session.request(method, url, params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_base_url = base
                return resp.json()
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError(f"No available Binance API endpoint for {path}")

    def place_oco_order(self, symbol: str, side: str, quantity: float,
                        take_profit_price: float, stop_price: float, stop_limit_price: float) -> Dict[str, Any]:
        """Server-side OCO (spot): TP limit + SL stop-limit on one order list.

        Live-mode insurance only: if this process dies, the exchange still
        executes the stop. Paper mode never calls this.
        """
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "quantity": f"{quantity:.6f}",
            "price": f"{take_profit_price:.6f}",
            "stopPrice": f"{stop_price:.6f}",
            "stopLimitPrice": f"{stop_limit_price:.6f}",
            "stopLimitTimeInForce": "GTC",
        }
        return self._signed_request("POST", "/api/v3/order/oco", params)

    def cancel_oco_order(self, symbol: str, order_list_id: int) -> Dict[str, Any]:
        params: Dict[str, Any] = {"symbol": symbol, "orderListId": int(order_list_id)}
        return self._signed_request("DELETE", "/api/v3/order/oco", params)

    def get_funding_rate(self, symbol: str) -> Optional[float]:
        """Futures funding (fraction, e.g. 0.0001 == 0.01%/8h) or None.

        fapi.* is blocked by some ISPs (TrustPositif). Each blocked call costs
        two 3s timeouts per SHORT candidate, so after a full failure we back
        off for FUNDING_FETCH_BACKOFF_SEC instead of paying it every candidate.
        """
        import config as _cfg
        now = time.time()
        if now < getattr(self, "_funding_backoff_until", 0.0):
            return None
        endpoints = [
            f"https://fapi.binance.com/fapi/v1/premiumIndex?symbol={symbol}",
            f"https://fapi1.binance.com/fapi/v1/premiumIndex?symbol={symbol}"
        ]
        reachable = False
        for url in endpoints:
            try:
                resp = self.session.get(url, timeout=3.0)
                reachable = True
                if resp.status_code == 200:
                    data = resp.json()
                    if "lastFundingRate" in data:
                        return float(data["lastFundingRate"])
            except Exception:
                continue
        if not reachable:
            self._funding_backoff_until = now + float(getattr(_cfg, "FUNDING_FETCH_BACKOFF_SEC", 900))
        return None
