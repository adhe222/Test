from typing import Dict, Any
from config import MAX_ALLOWABLE_SPREAD_PCT


class OrderbookAgent:
    def __init__(self, binance_client):
        self.client = binance_client
        self.name = "OrderbookAgent"

    def inspect_orderbook(self, symbol: str, direction: str = "LONG") -> Dict[str, Any]:
        direction = str(direction).upper()
        if direction not in ("LONG", "SHORT"):
            return {"symbol": symbol, "direction": direction, "passed": False, "reason": "Invalid trade direction"}
        try:
            depth = self.client.get_orderbook(symbol, limit=20)
        except Exception as e:
            return {
                "symbol": symbol,
                "direction": direction,
                "passed": False,
                "reason": f"Orderbook fetch error: {e}"
            }
        bids = depth.get("bids", [])
        asks = depth.get("asks", [])

        if not bids or not asks:
            return {
                "symbol": symbol,
                "direction": direction,
                "passed": False,
                "reason": "Empty orderbook received"
            }

        best_bid = bids[0][0]
        best_ask = asks[0][0]

        if best_bid <= 0:
            return {"symbol": symbol, "direction": direction, "passed": False, "reason": "Invalid bid price"}

        spread_pct = ((best_ask - best_bid) / best_bid) * 100.0
        if spread_pct > MAX_ALLOWABLE_SPREAD_PCT:
            return {
                "symbol": symbol,
                "direction": direction,
                "passed": False,
                "spread_pct": spread_pct,
                "reason": f"Wide spread ({spread_pct:.3f}%) exceeds safety threshold ({MAX_ALLOWABLE_SPREAD_PCT}%)"
            }

        bid_depth_usd = sum(p * q for p, q in bids[:15])
        ask_depth_usd = sum(p * q for p, q in asks[:15])
        total_depth = bid_depth_usd + ask_depth_usd
        imbalance = (bid_depth_usd - ask_depth_usd) / total_depth if total_depth > 0 else 0.0
        bid_depth_ratio = (bid_depth_usd / ask_depth_usd) if ask_depth_usd > 0 else 99.0

        opposing_depth = (direction == "LONG" and imbalance < -0.35) or (
            direction == "SHORT" and imbalance > 0.40
        )
        if opposing_depth:
            wall = "buy" if direction == "SHORT" else "sell"
            return {
                "symbol": symbol,
                "direction": direction,
                "passed": False,
                "spread_pct": spread_pct,
                "bid_depth_usd": bid_depth_usd,
                "ask_depth_usd": ask_depth_usd,
                "imbalance": imbalance,
                "reason": f"Orderbook {wall} wall dominant (imbalance {imbalance:.2f})"
            }

        return {
            "symbol": symbol,
            "direction": direction,
            "passed": True,
            "best_bid": best_bid,
            "best_ask": best_ask,
            "spread_pct": spread_pct,
            "bid_depth_usd": bid_depth_usd,
            "ask_depth_usd": ask_depth_usd,
            "imbalance": imbalance,
            "bid_depth_ratio": bid_depth_ratio,
            "reason": f"Tight spread ({spread_pct:.3f}%), liquidity compatible with {direction}"
        }
