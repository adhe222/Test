from typing import List, Dict, Any, Optional
import config
from config import (
    ACCEPTED_QUOTE_ASSETS,
    MIN_24H_VOLUME_USDT,
    MIN_PRICE_CHANGE_24H,
    MAX_PRICE_CHANGE_24H,
    EXCLUDED_SYMBOLS
)


class ScannerAgent:
    """
    Universal Market Scanner Agent:
    Scans Binance market to identify high-liquidity trending assets across any profitable pairing (USDT, FDUSD, USDC).
    Filters out illiquid tokens, stablecoin-to-stablecoin pairs, and over-extended pump-and-dump spikes.
    """

    def __init__(self, binance_client):
        self.client = binance_client
        self.name = "ScannerAgent"

    def get_symbol_pairing(self, symbol: str) -> Optional[Dict[str, str]]:
        """Parses base and quote asset, validating against accepted profitable quote pairs."""
        if symbol in EXCLUDED_SYMBOLS:
            return None

        # Filter leveraged tokens (UP, DOWN, BEAR, BULL)
        for token_type in ["UP", "DOWN", "BEAR", "BULL"]:
            for q in ACCEPTED_QUOTE_ASSETS:
                if symbol.endswith(token_type + q):
                    return None

        for quote in ACCEPTED_QUOTE_ASSETS:
            if symbol.endswith(quote):
                base = symbol[:-len(quote)]
                if len(base) >= 2 and base not in ["USD", "USDC", "FDUSD", "USDT", "TUSD", "BUSD", "DAI", "EUR"]:
                    return {
                        "base_asset": base,
                        "quote_asset": quote,
                        "pair_display": f"{base}/{quote}"
                    }
        return None

    def is_valid_symbol(self, symbol: str) -> bool:
        return self.get_symbol_pairing(symbol) is not None

    def scan_trending_pairs(self, top_limit: int = 15, direction_filter: str = "ALL") -> List[Dict[str, Any]]:
        """
        direction_filter: "ALL", "LONG", "SHORT" or "NONE".
        The orchestrator passes the macro permission here so that the limited
        top-N evaluation budget is never spent on a direction the Macro Sentinel
        has already paused (live: 23 of the top 40 slots were SHORTs blocked by
        a STRONG_BULLISH regime, starving executable LONG candidates).
        """
        if direction_filter == "NONE":
            return []
        tickers = self.client.get_24hr_tickers()
        candidates = []

        allow_longs = config.ENABLE_SPOT_LONGS if hasattr(config, "ENABLE_SPOT_LONGS") else True
        allow_shorts = config.ENABLE_FUTURES_SHORTS if hasattr(config, "ENABLE_FUTURES_SHORTS") else True

        if direction_filter == "LONG":
            allow_shorts = False
        elif direction_filter == "SHORT":
            allow_longs = False

        for t in tickers:
            symbol = t.get("symbol", "")
            pairing = self.get_symbol_pairing(symbol)
            if not pairing:
                continue

            try:
                price = float(t.get("lastPrice", 0.0))
                price_change = float(t.get("priceChangePercent", 0.0))
                quote_volume = float(t.get("quoteVolume", 0.0))
            except (ValueError, TypeError):
                continue

            if quote_volume < MIN_24H_VOLUME_USDT:
                continue

            direction = None
            target_market = None
            if allow_longs and (MIN_PRICE_CHANGE_24H <= price_change <= MAX_PRICE_CHANGE_24H):
                direction = "LONG"
                target_market = "SPOT"
            elif allow_shorts and (-MAX_PRICE_CHANGE_24H <= price_change <= -MIN_PRICE_CHANGE_24H):
                direction = "SHORT"
                target_market = "FUTURES"

            if not direction:
                continue

            candidates.append({
                "symbol": symbol,
                "base_asset": pairing["base_asset"],
                "quote_asset": pairing["quote_asset"],
                "pair_display": pairing["pair_display"],
                "price": price,
                "price_change_24h": price_change,
                "quote_volume_24h": quote_volume,
                "high_24h": float(t.get("highPrice", 0.0)),
                "low_24h": float(t.get("lowPrice", 0.0)),
                "count_trades": int(t.get("count", 0)),
                "direction": direction,
                "target_market": target_market
            })

        for c in candidates:
            span = c["high_24h"] - c["low_24h"]
            range_pos = ((c["price"] - c["low_24h"]) / span) if span > 0 else 0.5
            c["range_position_24h"] = round(range_pos, 4)

            chg = c["price_change_24h"]
            # Two valid entry archetypes, scored separately and the best wins:
            #  - pullback: mid-range;  - continuation: near the extreme in the
            #    trade direction. The old pullback-only score ranked BNB/XRP/BTC/
            #    ETH (all passing every gate) at 31-71 of 80, outside the budget,
            #    because a healthy trend sits at the top of its own range (PIT-017).
            if c["direction"] == "LONG":
                pullback = 1.0 - abs(range_pos - 0.40) / 0.60
                continuation = 1.0 - abs(range_pos - 0.88) / 0.30
                momentum_quality = 1.0 - min(1.0, abs(chg - 4.0) / 12.0)
            else:
                pullback = 1.0 - abs(range_pos - 0.60) / 0.60
                continuation = 1.0 - abs(range_pos - 0.12) / 0.30
                momentum_quality = 1.0 - min(1.0, abs(abs(chg) - 4.0) / 12.0)
            entry_quality = max(pullback, continuation)
            c["entry_archetype"] = "CONTINUATION" if continuation > pullback else "PULLBACK"

            liquidity_quality = min(1.0, c["quote_volume_24h"] / 60_000_000.0)
            participation = min(1.0, c["count_trades"] / 150_000.0)

            c["setup_score"] = round(
                0.40 * max(0.0, entry_quality)
                + 0.25 * max(0.0, momentum_quality)
                + 0.20 * liquidity_quality
                + 0.15 * participation,
                4,
            )

        candidates.sort(key=lambda x: x["setup_score"], reverse=True)
        # One candidate per base asset: INJUSDT + INJUSDC are the same coin and
        # were held simultaneously (double exposure, ledger 2026-10-16).
        seen_bases = set()
        unique = []
        for c in candidates:
            if c["base_asset"] in seen_bases:
                continue
            seen_bases.add(c["base_asset"])
            unique.append(c)
        return unique[:top_limit]
