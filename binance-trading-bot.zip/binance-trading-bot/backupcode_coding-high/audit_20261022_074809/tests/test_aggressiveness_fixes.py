"""Regression tests for the 2026-10-19 aggressiveness + accounting repair.

Every test runs on isolated temp state; none touches data/.
"""
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from agents.momentum import MomentumAnalystAgent
from agents.portfolio_manager import PortfolioManagerAgent, classify_outcome, event_outcome
from agents.risk_manager import RiskManagementAgent
from agents.scanner import ScannerAgent
from orchestrator import TradingOrchestrator


def _candles(direction, count, step_pct=0.004, wiggle=0.0, volume=1000.0, interval_ms=900_000, pullback=False):
    """Closed candles trending in `direction`. `pullback` uses an up-up-down
    pattern so RSI sits in a realistic 55-70 band instead of 100."""
    sign = -1 if direction == "SHORT" else 1
    price = 100.0
    now_ms = int(time.time() * 1000)
    start = now_ms - (count + 1) * interval_ms
    rows = []
    for i in range(count):
        noise = wiggle * (1 if i % 2 else -1)
        open_p = price
        step = step_pct
        if pullback and i % 3 == 2:
            step = -step_pct * 1.2
        close = price * (1 + sign * step + noise)
        high = max(open_p, close) * 1.001
        low = min(open_p, close) * 0.999
        is_pullback = pullback and i % 3 == 2
        if not is_pullback:
            if direction == "LONG":
                close = high - (high - low) * 0.1
            else:
                close = low + (high - low) * 0.1
        rows.append({
            "open_time": start + i * interval_ms, "open": open_p, "high": high, "low": low,
            "close": close, "volume": volume, "close_time": start + (i + 1) * interval_ms - 1,
        })
        price = close
    return rows


class FixtureClient:
    def __init__(self, direction, wiggle=0.0):
        self.feeds = {
            "15m": _candles(direction, 100, wiggle=wiggle),
            "1h": _candles(direction, 60, interval_ms=3_600_000, pullback=True),
            "4h": _candles(direction, 40, interval_ms=14_400_000, pullback=True),
            "5m": _candles(direction, 5, interval_ms=300_000),
        }
        self.funding = None

    def get_klines(self, symbol, interval="15m", limit=100):
        return self.feeds[interval][-limit:]

    def get_funding_rate(self, symbol):
        return self.funding


class TestScannerDirectionBudget(unittest.TestCase):
    def _tickers(self):
        return [
            {"symbol": "AAAUSDT", "lastPrice": "1", "priceChangePercent": "6", "quoteVolume": "9e7", "count": "200000", "highPrice": "1.1", "lowPrice": "0.9"},
            {"symbol": "BBBUSDT", "lastPrice": "1", "priceChangePercent": "-6", "quoteVolume": "9e7", "count": "200000", "highPrice": "1.1", "lowPrice": "0.9"},
        ]

    def test_direction_filter_drops_paused_direction(self):
        client = MagicMock()
        client.get_24hr_tickers.return_value = self._tickers()
        scanner = ScannerAgent(client)
        longs = scanner.scan_trending_pairs(direction_filter="LONG")
        self.assertEqual([c["direction"] for c in longs], ["LONG"])
        shorts = scanner.scan_trending_pairs(direction_filter="SHORT")
        self.assertEqual([c["direction"] for c in shorts], ["SHORT"])

    def test_none_filter_skips_network(self):
        client = MagicMock()
        self.assertEqual(ScannerAgent(client).scan_trending_pairs(direction_filter="NONE"), [])
        client.get_24hr_tickers.assert_not_called()


class TestEfficiencyConfluence(unittest.TestCase):
    def _efficiency_failures(self, result):
        return [g for g in result["gate_failures"] if g.startswith("Choppy regime")]

    def test_clean_trend_never_flagged_choppy(self):
        result = MomentumAnalystAgent(FixtureClient("LONG")).analyze_symbol("FIXUSDT", direction="LONG")
        self.assertEqual(self._efficiency_failures(result), [])

    def test_relaxed_floor_requires_htf_confluence(self):
        """Choppy 15m with full HTF confluence uses the relaxed floor; without
        HTF data the strict floor still applies."""
        agent = MomentumAnalystAgent(FixtureClient("LONG"))
        with patch.object(config, "MIN_TREND_EFFICIENCY", 1.01), \
                patch.object(config, "MIN_TREND_EFFICIENCY_CONFLUENCE", 0.0):
            confluent = agent.analyze_symbol("FIXUSDT", direction="LONG")
            self.assertGreaterEqual(confluent["htf_score"], config.MIN_HTF_CONFLUENCE_SCORE)
            self.assertEqual(self._efficiency_failures(confluent), [])

            no_htf_client = FixtureClient("LONG")
            no_htf_client.feeds["1h"] = []
            no_htf_client.feeds["4h"] = []
            strict = MomentumAnalystAgent(no_htf_client).analyze_symbol("FIXUSDT", direction="LONG")
            self.assertTrue(self._efficiency_failures(strict))

    def test_opposing_direction_gets_no_relaxation(self):
        with patch.object(config, "MIN_TREND_EFFICIENCY", 1.01), \
                patch.object(config, "MIN_TREND_EFFICIENCY_CONFLUENCE", 0.0):
            result = MomentumAnalystAgent(FixtureClient("LONG")).analyze_symbol("FIXUSDT", direction="SHORT")
            self.assertTrue(self._efficiency_failures(result))


class TestFundingUnits(unittest.TestCase):
    def _gates(self, funding):
        client = FixtureClient("SHORT")
        client.funding = funding
        with patch.object(config, "ENABLE_ANTI_SHORT_SQUEEZE_GUARD", True):
            result = MomentumAnalystAgent(client).analyze_symbol("FIXUSDT", direction="SHORT")
        return [g for g in result["gate_failures"] if "funding" in g.lower()]

    def test_minus_0_05_percent_funding_vetoes_short(self):
        # Binance returns a fraction: -0.0005 == -0.05% per 8h. The old check
        # (fr < -0.03) treated this as harmless.
        self.assertTrue(self._gates(-0.0005))

    def test_normal_funding_passes(self):
        self.assertEqual(self._gates(0.0001), [])
        self.assertEqual(self._gates(None), [])


class TestFundingBackoff(unittest.TestCase):
    def test_unreachable_fapi_backs_off(self):
        from binance_api import BinanceClient
        client = BinanceClient()
        client.session = MagicMock()
        client.session.get.side_effect = OSError("blocked")
        self.assertIsNone(client.get_funding_rate("BTCUSDT"))
        calls = client.session.get.call_count
        self.assertIsNone(client.get_funding_rate("ETHUSDT"))
        self.assertEqual(client.session.get.call_count, calls, "second call must be short-circuited")


class TestOutcomeClassification(unittest.TestCase):
    def test_scratch_band(self):
        self.assertEqual(classify_outcome(0.01, 200), "SCRATCH")
        self.assertEqual(classify_outcome(1.0, 200), "WIN")
        self.assertEqual(classify_outcome(-1.0, 200), "LOSS")

    def test_legacy_rows(self):
        self.assertEqual(event_outcome({"pnl_usdt": -0.0029, "pnl_pct": 0.0}), "SCRATCH")
        self.assertEqual(event_outcome({"pnl_usdt": -5.6, "pnl_pct": -2.4}), "LOSS")
        self.assertEqual(event_outcome({"outcome": "WIN", "pnl_usdt": -1}), "WIN")


class TestRealizedPnlNoDoubleCount(unittest.TestCase):
    def setUp(self):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", directory / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        self.client = MagicMock()
        self.client.get_price.return_value = 100.0
        self.portfolio = PortfolioManagerAgent(self.client, mode="paper")
        self.portfolio.reset_portfolio(1000.0)

    def _plan(self, direction):
        short = direction == "SHORT"
        return {
            "symbol": "FIXUSDT", "direction": direction, "target_market": "FUTURES" if short else "SPOT",
            "side": "SELL" if short else "BUY", "position_usdt": 100.0, "quantity": 1.0, "entry_price": 100.0,
            "stop_loss_price": 103.0 if short else 97.0, "stop_loss_pct": 3.0,
            "take_profit_1": 96.0 if short else 104.0, "take_profit_2": 92.0 if short else 108.0,
            "trailing_trigger_pct": 50.0, "trailing_distance_pct": 1.0,
        }

    def _run(self, direction, tp1_price, tp2_price):
        self.assertTrue(self.portfolio.execute_trade(self._plan(direction)))
        self.client.get_price.return_value = tp1_price
        self.portfolio.update_and_monitor_positions()
        self.client.get_price.return_value = tp2_price
        closes = self.portfolio.update_and_monitor_positions()
        self.assertEqual(closes[-1]["action"], "CLOSED")
        state = self.portfolio.state
        equity_gain = state["cash_usdt"] - 1000.0
        self.assertAlmostEqual(state["realized_pnl_usdt"], equity_gain, places=2,
                               msg="realized PnL must equal the actual cash gain")
        self.assertAlmostEqual(closes[-1]["pnl_usdt"], equity_gain, places=2)
        self.assertEqual(closes[-1]["direction"], direction)
        self.assertEqual(closes[-1]["outcome"], "WIN")

    def test_long_tp1_then_tp2(self):
        self._run("LONG", 105.0, 109.0)

    def test_short_tp1_then_tp2(self):
        self._run("SHORT", 95.0, 91.0)

    def test_periodic_counts_closed_trades_only(self):
        self._run("LONG", 105.0, 109.0)
        today = self.portfolio.get_periodic_performance()["today"]
        self.assertEqual(today["trades"], 1)
        self.assertEqual(today["wins"], 1)
        self.assertAlmostEqual(today["net_pnl_usdt"], self.portfolio.state["realized_pnl_usdt"], places=2)


class TestScratchesAreNotLosses(unittest.TestCase):
    def test_scratch_does_not_cooldown_or_streak(self):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        log = directory / "trades.json"
        now = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())
        log.write_text(json.dumps([
            {"symbol": "LOSSUSDT", "action": "CLOSED", "pnl_usdt": -5.0, "pnl_pct": -2.5, "exit_time": now},
            {"symbol": "LOSS2USDT", "action": "CLOSED", "pnl_usdt": -4.0, "pnl_pct": -2.0, "exit_time": now},
            {"symbol": "FLATUSDT", "action": "CLOSED", "pnl_usdt": -0.0029, "pnl_pct": 0.0, "exit_time": now},
        ]))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", log))
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        cooldown = orch._symbols_in_cooldown()
        self.assertIn("LOSSUSDT", cooldown)
        self.assertNotIn("FLATUSDT", cooldown)
        # trailing scratch neither breaks nor extends the 2-loss streak
        self.assertEqual(orch._consecutive_losses(), 2)


class TestDashboardDirectionRecovery(unittest.TestCase):
    def test_legacy_close_inherits_direction_from_tp1_sibling(self):
        from dashboard_telemetry import describe_market_record
        row = {"symbol": "BTCUSDT", "action": "CLOSED", "entry_time": "t1"}
        self.assertEqual(describe_market_record(row)["display_direction"], "UNKNOWN")
        self.assertEqual(describe_market_record(row, "SHORT")["display_direction"], "SHORT")
        self.assertEqual(describe_market_record({**row, "direction": "LONG"}, "SHORT")["display_direction"], "LONG")


class TestCycleSkipsLlmWhenBlocked(unittest.TestCase):
    """Correlation is per direction, and blocked candidates never reach the LLM."""

    def _orchestrator(self, open_positions, macro):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.llm = MagicMock(status_summary={})
        orch.portfolio = MagicMock()
        orch.portfolio.get_open_positions.return_value = open_positions
        orch.portfolio.get_equity.return_value = 1000.0
        orch.portfolio.state = {"cash_usdt": 500.0}
        orch.portfolio.update_and_monitor_positions.return_value = []
        orch.portfolio.get_periodic_performance.return_value = {"today": {"net_pnl_usdt": 0.0}}
        orch.portfolio.execute_trade.return_value = True
        orch.macro_sentinel = MagicMock()
        orch.macro_sentinel.evaluate_macro_health.return_value = macro
        orch.scanner = MagicMock()
        orch.scanner.scan_trending_pairs.return_value = [
            {"symbol": "NEWUSDT", "direction": "SHORT", "target_market": "FUTURES", "price": 10.0,
             "price_change_24h": -5.0, "quote_volume_24h": 9e7, "count_trades": 200000},
        ]
        orch.orderbook_data_agent = MagicMock()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "imbalance": 0.0, "spread_pct": 0.01,
            "best_bid": 9.99, "best_ask": 10.01,
        }
        orch.momentum_data_agent = MagicMock()
        orch.momentum_data_agent.analyze_symbol.return_value = {"passed": True, "score": 120, "price": 10.0, "atr": 0.1, "rsi": 40}
        orch.risk_data_agent = MagicMock()
        orch.risk_data_agent.evaluate_risk.return_value = {"approved": True, "side": "SELL", "position_usdt": 100}
        for name in ("narrative_spec", "price_action_spec", "exhaustion_spec", "microstructure_spec",
                     "sentiment_spec", "cro_spec", "profit_spec"):
            spec = MagicMock(role_name=name, lead_title="", icon="", staff=[])
            spec.analyze.return_value = {"specialist": name, "verdict": "APPROVE", "conviction": 90, "rationale": ""}
            setattr(orch, name, spec)
        orch.executive_spec = MagicMock(role_name="exec", lead_title="", icon="")
        orch.executive_spec.synthesize.return_value = {"final_verdict": "APPROVE", "consensus_conviction": 90}
        return orch

    def _run(self, orch):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        with patch("orchestrator.consciousness_engine") as ce:
            ce.audit_against_experience.return_value = None
            ce.get_ultra_context_summary.return_value = {}
            return orch.run_cycle()

    def test_short_hedge_allowed_next_to_two_longs(self):
        longs = [{"symbol": "AUSDT", "direction": "LONG"}, {"symbol": "BUSDT", "direction": "LONG"}]
        orch = self._orchestrator(longs, {"safe_to_trade": True, "safe_for_shorts": True})
        result = self._run(orch)
        rec = result["candidates_evaluated"][0]
        self.assertTrue(rec["can_execute"], rec["execution_note"])
        self.assertEqual(len(result["executed_trades"]), 1)

    def test_same_direction_cap_skips_llm(self):
        shorts = [{"symbol": "AUSDT", "direction": "SHORT"}, {"symbol": "BUSDT", "direction": "SHORT"}]
        orch = self._orchestrator(shorts, {"safe_to_trade": True, "safe_for_shorts": True})
        with patch.object(config, "MAX_CORRELATED_POSITIONS", 2):
            result = self._run(orch)
        rec = result["candidates_evaluated"][0]
        self.assertFalse(rec["can_execute"])
        self.assertIn("CORRELATION_CAP", rec["execution_note"])
        self.assertEqual(rec["executive_verdict"]["final_verdict"], "WATCHLIST")
        orch.narrative_spec.analyze.assert_not_called()
        orch.portfolio.execute_trade.assert_not_called()

    def test_scanner_receives_macro_direction_filter(self):
        orch = self._orchestrator([], {"safe_to_trade": True, "safe_for_shorts": False})
        self._run(orch)
        self.assertEqual(orch.scanner.scan_trending_pairs.call_args.kwargs["direction_filter"], "LONG")


def _btc_klines(step, n=60, start=60000.0, wiggle=0.0):
    rows = []
    price = start
    for i in range(n):
        o = price
        c = price + step + (wiggle if i % 2 else -wiggle)
        rows.append({"open": o, "high": max(o, c) + 5, "low": min(o, c) - 5, "close": c, "volume": 100.0})
        price = c
    return rows


class TestSelectiveShorts(unittest.TestCase):
    def test_bullish_btc_keeps_short_route_selective(self):
        client = MagicMock()
        # Steady uptrend with pullbacks -> STRONG_BULLISH but RSI below melt-up level
        client.get_klines.return_value = _btc_klines(10, wiggle=30)
        from agents.macro_sentinel import MacroMarketSentinel
        status = MacroMarketSentinel(client).evaluate_macro_health()
        self.assertEqual(status["regime"], "STRONG_BULLISH")
        self.assertLess(status["rsi"], config.MACRO_SHORT_SQUEEZE_RSI)
        self.assertTrue(status["safe_for_shorts"])
        self.assertTrue(status["selective_shorts"])

    def test_btc_melt_up_pauses_shorts(self):
        client = MagicMock()
        client.get_klines.return_value = _btc_klines(150)  # monotonic pump, RSI 100
        from agents.macro_sentinel import MacroMarketSentinel
        status = MacroMarketSentinel(client).evaluate_macro_health()
        self.assertFalse(status["safe_for_shorts"])
        self.assertIn("melt-up", status["short_block_reason"])

    def _short_result(self, alpha_btc_4h, htf_weak=False):
        client = FixtureClient("SHORT")
        if htf_weak:
            client.feeds["4h"] = _candles("LONG", 40, interval_ms=14_400_000, pullback=True)
        ctx = {"drop_4h_pct": alpha_btc_4h, "selective_shorts": True}
        return MomentumAnalystAgent(client).analyze_symbol("FIXUSDT", direction="SHORT", btc_context=ctx)

    def _selective(self, result):
        return [g for g in result["gate_failures"] if g.startswith("Selective short")]

    def test_weak_asset_passes_selective_gate(self):
        # asset falls hard while BTC is up 0.4% -> strongly negative alpha
        self.assertEqual(self._selective(self._short_result(0.4)), [])

    def test_asset_not_lagging_btc_is_rejected(self):
        # BTC "fell" more than the asset -> alpha positive -> no relative weakness
        failures = self._selective(self._short_result(-50.0))
        self.assertTrue(any("relative weakness" in f for f in failures))

    def test_mixed_htf_rejected_in_selective_mode(self):
        result = self._short_result(0.4, htf_weak=True)
        self.assertTrue(result["gate_failures"])

    def test_selective_short_risk_is_halved(self):
        from agents.risk_manager import RiskManagementAgent
        agent = RiskManagementAgent()
        full = agent.evaluate_risk("X", 100.0, 1.0, 1000.0, [], direction="SHORT", target_market="FUTURES")
        half = agent.evaluate_risk("X", 100.0, 1.0, 1000.0, [], direction="SHORT", target_market="FUTURES", risk_scale=0.5)
        self.assertTrue(full["approved"] and half["approved"])
        self.assertAlmostEqual(half["position_usdt"], full["position_usdt"] * 0.5, delta=0.02)
        self.assertEqual(half["stop_loss_price"], full["stop_loss_price"])

    def test_dashboard_route_marks_selective(self):
        from dashboard_telemetry import build_market_operations
        with patch.object(config, "ENABLE_SPOT_LONGS", True), patch.object(config, "ENABLE_FUTURES_SHORTS", True):
            ops = build_market_operations("paper", "paper", {}, [], {"safe_to_trade": True, "safe_for_shorts": True,
                                          "selective_shorts": True, "regime": "STRONG_BULLISH"}, {}, "https://x")
        short = ops["routes"][1]
        self.assertEqual(short["status"], "SELECTIVE")
        self.assertTrue(short["entry_eligible"])


class TestRunningBotFindings(unittest.TestCase):
    def test_scanner_keeps_one_candidate_per_base(self):
        client = MagicMock()
        t = lambda sym, vol: {"symbol": sym, "lastPrice": "1", "priceChangePercent": "6", "quoteVolume": vol,
                              "count": "200000", "highPrice": "1.1", "lowPrice": "0.9"}
        client.get_24hr_tickers.return_value = [t("INJUSDT", "9e7"), t("INJUSDC", "5e6"), t("SOLUSDT", "9e7")]
        syms = [c["symbol"] for c in ScannerAgent(client).scan_trending_pairs()]
        self.assertEqual(sorted(syms), ["INJUSDT", "SOLUSDT"])

    def test_trailing_uses_per_position_trigger(self):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", directory / "p.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "t.json"))
        client = MagicMock(); client.get_price.return_value = 100.0
        pm = PortfolioManagerAgent(client, mode="paper"); pm.reset_portfolio(1000.0)
        pm.execute_trade({"symbol": "FIXUSDT", "direction": "LONG", "side": "BUY", "position_usdt": 100.0,
                          "quantity": 1.0, "entry_price": 100.0, "stop_loss_price": 99.2, "stop_loss_pct": 0.8,
                          "take_profit_1": 150.0, "take_profit_2": 200.0,
                          "trailing_trigger_pct": 1.8, "trailing_distance_pct": 0.8})
        client.get_price.return_value = 101.9  # +1.9%: above plan 1.8, below global 2.2
        pm.update_and_monitor_positions()
        self.assertTrue(pm.get_open_positions()[0]["trailing_active"])


class TestDynamicPositionSlots(unittest.TestCase):
    def setUp(self):
        self.old = (config.MAX_OPEN_POSITIONS, config.MAX_CORRELATED_POSITIONS, config.MAX_POSITION_SIZE_PCT)

    def tearDown(self):
        config.MAX_OPEN_POSITIONS, config.MAX_CORRELATED_POSITIONS, config.MAX_POSITION_SIZE_PCT = self.old

    def test_slot_settings_derive_safe_limits(self):
        with patch.object(config, "_MAX_CORRELATED_EXPLICIT", False), patch.object(
            config, "_MAX_POSITION_SIZE_EXPLICIT", False
        ):
            self.assertEqual(config.apply_position_slots(3), {
                "max_open_positions": 3, "max_correlated_positions": 2, "max_position_size_pct": 25.0})
            self.assertEqual(config.apply_position_slots(5), {
                "max_open_positions": 5, "max_correlated_positions": 3, "max_position_size_pct": 18.0})
            self.assertEqual(config.apply_position_slots(10), {
                "max_open_positions": 10, "max_correlated_positions": 3, "max_position_size_pct": 9.0})

    def test_explicit_dependent_limits_override_derivation(self):
        got = config.apply_position_slots(6, correlated=3, position_size_pct=12.5)
        self.assertEqual(got["max_correlated_positions"], 3)
        self.assertEqual(got["max_position_size_pct"], 12.5)

    def test_slots_are_bounded(self):
        for bad in (0, -1, config.MAX_SLOTS_LIMIT + 1):
            with self.assertRaises(ValueError):
                config.apply_position_slots(bad)

    def test_risk_agent_reads_runtime_slot_limit(self):
        config.apply_position_slots(2)
        agent = RiskManagementAgent()
        blocked = agent.evaluate_risk("X", 100, 1, 1000, [{"symbol": "A"}, {"symbol": "B"}])
        self.assertFalse(blocked["approved"])
        self.assertIn("(2)", blocked["reason"])

    def test_size_cap_scales_with_slots(self):
        agent = RiskManagementAgent()
        with patch.object(config, "_MAX_POSITION_SIZE_EXPLICIT", False):
            config.apply_position_slots(3)
            three = agent.evaluate_risk("X", 100, 0.8, 1000, [])
            config.apply_position_slots(10)
            ten = agent.evaluate_risk("X", 100, 0.8, 1000, [])
        self.assertAlmostEqual(three["position_usdt"], 250.0, places=2)
        self.assertAlmostEqual(ten["position_usdt"], 90.0, places=2)


class TestAggressiveRanking(unittest.TestCase):
    def test_continuation_long_ranks_with_pullback(self):
        client = MagicMock()
        def t(sym, last, chg):
            return {"symbol": sym, "lastPrice": str(last), "priceChangePercent": str(chg), "quoteVolume": "9e7",
                    "count": "300000", "highPrice": "1.0", "lowPrice": "0.9"}
        client.get_24hr_tickers.return_value = [t("TRENDUSDT", 0.99, 2.5), t("DIPUSDT", 0.94, 2.5), t("TOPUSDT", 1.0, 2.5)]
        rows = {c["symbol"]: c for c in ScannerAgent(client).scan_trending_pairs()}
        # trend near top of range must not be ranked far below a mid-range dip
        self.assertGreater(rows["TRENDUSDT"]["setup_score"], 0.8 * rows["DIPUSDT"]["setup_score"])
        self.assertEqual(rows["TRENDUSDT"]["entry_archetype"], "CONTINUATION")

    def _vol_fail(self, client):
        r = MomentumAnalystAgent(client).analyze_symbol("FIXUSDT", direction="LONG")
        return [g for g in r["gate_failures"] if g.startswith("Volume surge")], r

    def test_low_volume_accepted_only_with_confluence(self):
        client = FixtureClient("LONG")
        for k in client.feeds["15m"][-3:]:
            k["volume"] = 900.0          # 0.9x of the 1000 baseline
        with patch.object(config, "VOLUME_SURGE_FILTER", 1.0), patch.object(config, "VOLUME_SURGE_FILTER_CONFLUENCE", 0.8):
            fails, r = self._vol_fail(client)
            self.assertTrue(r["mtf_confluence"])
            self.assertEqual(fails, [])
            client.feeds["1h"] = []; client.feeds["4h"] = []
            fails, r = self._vol_fail(client)
            self.assertFalse(r["mtf_confluence"])
            self.assertTrue(fails)


class TestWeakCandlePenalty(unittest.TestCase):
    def _client(self, ltf_bearish):
        client = FixtureClient("LONG")
        last = client.feeds["15m"][-1]
        last["close"] = last["low"] + (last["high"] - last["low"]) * 0.10   # weak 15m close
        ltf = client.feeds["5m"][-1]
        if ltf_bearish:
            ltf["open"], ltf["close"] = ltf["high"], ltf["low"] + (ltf["high"] - ltf["low"]) * 0.10
        return client

    def _run(self, client):
        return MomentumAnalystAgent(client).analyze_symbol("FIXUSDT", direction="LONG")

    def test_weak_candle_is_penalty_when_5m_not_opposing(self):
        with patch.object(config, "WEAK_CANDLE_MODE", "penalty"), patch.object(config, "WEAK_CANDLE_SCORE_PENALTY", 25):
            r = self._run(self._client(ltf_bearish=False))
        self.assertFalse([g for g in r["gate_failures"] if "Weak entry candle" in g])
        self.assertTrue(any("-25 score" in x for x in r["reasons"]))

    def test_weak_candle_rejects_when_5m_confirms_selling(self):
        with patch.object(config, "WEAK_CANDLE_MODE", "penalty"):
            r = self._run(self._client(ltf_bearish=True))
        self.assertTrue([g for g in r["gate_failures"] if "Weak entry candle" in g and "5m confirms" in g])

    def test_legacy_reject_mode(self):
        with patch.object(config, "WEAK_CANDLE_MODE", "reject"):
            r = self._run(self._client(ltf_bearish=False))
        self.assertTrue([g for g in r["gate_failures"] if "Weak entry candle" in g])


if __name__ == "__main__":
    unittest.main()
