import tempfile
import unittest
from pathlib import Path

from agents.consciousness import AgentConsciousnessEngine, STALENESS_FULL_RELAX_HOURS

PA = "Technical Price Action Division"
EXH = "Momentum Exhaustion Division"
OB = "Order Book Microstructure Division"


class TestStalenessDecay(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def _tighten(self):
        for _ in range(10):
            self.engine.record_trade_failure_and_learn({
                "symbol": "SOLUSDT", "pnl_usdt": -5.0, "pnl_pct": -2.0,
                "outcome": "LOSS", "reason": "STOP_LOSS",
            })

    def test_loss_ratchet_saturates_and_anchors(self):
        self._tighten()
        self.assertEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.30)
        anchor = self.engine.memory.get("ratchet_anchor", {}).get(PA, {})
        self.assertAlmostEqual(anchor.get("min_volume_surge"), 1.30)

    def test_no_decay_right_after_fresh_outcome(self):
        self._tighten()
        result = self.engine.apply_staleness_decay(0.0)
        self.assertFalse(result["applied"])
        self.assertEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.30)

    def test_sub_step_idle_does_not_decay_or_write(self):
        self._tighten()
        result = self.engine.apply_staleness_decay(0.1)
        self.assertFalse(result["applied"])
        self.assertEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.30)

    def test_partial_decay_interpolates_toward_base(self):
        self._tighten()
        hours = STALENESS_FULL_RELAX_HOURS / 2.0
        self.engine.apply_staleness_decay(hours)
        mid = self.engine.get_threshold(PA, "min_volume_surge", 1.10)
        self.assertLess(mid, 1.30)
        self.assertGreater(mid, 1.10)

    def test_full_decay_returns_to_foundation_base(self):
        self._tighten()
        self.engine.apply_staleness_decay(STALENESS_FULL_RELAX_HOURS * 2.0)
        self.assertAlmostEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.10)
        self.assertAlmostEqual(self.engine.get_threshold(OB, "min_imbalance", 0.05), 0.05)
        self.assertAlmostEqual(self.engine.get_threshold(EXH, "max_rsi", 74.0), 74.0)

    def test_decay_is_idempotent_at_fixed_idle_time(self):
        self._tighten()
        hours = STALENESS_FULL_RELAX_HOURS / 3.0
        self.engine.apply_staleness_decay(hours)
        first = self.engine.get_threshold(PA, "min_volume_surge", 1.10)
        self.engine.apply_staleness_decay(hours)
        second = self.engine.get_threshold(PA, "min_volume_surge", 1.10)
        self.assertAlmostEqual(first, second, places=6)

    def test_fresh_loss_rearms_to_full_tightness(self):
        self._tighten()
        self.engine.apply_staleness_decay(STALENESS_FULL_RELAX_HOURS * 2.0)
        self.assertAlmostEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.10)
        self.engine.record_trade_failure_and_learn({
            "symbol": "SOLUSDT", "pnl_usdt": -5.0, "pnl_pct": -2.0,
            "outcome": "LOSS", "reason": "STOP_LOSS",
        })
        self.assertEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.30)

    def test_decay_survives_reload(self):
        self._tighten()
        self.engine.apply_staleness_decay(STALENESS_FULL_RELAX_HOURS / 2.0)
        mid = self.engine.get_threshold(PA, "min_volume_surge", 1.10)
        reloaded = AgentConsciousnessEngine(self.engine.file_path)
        self.assertAlmostEqual(reloaded.get_threshold(PA, "min_volume_surge", 1.10), mid)
        anchor = reloaded.memory.get("ratchet_anchor", {}).get(PA, {})
        self.assertAlmostEqual(anchor.get("min_volume_surge"), 1.30)

    def test_win_does_not_rearm_tightness(self):
        self._tighten()
        self.engine.apply_staleness_decay(STALENESS_FULL_RELAX_HOURS)
        self.assertAlmostEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.10)
        self.engine.record_trade_success_and_reward({
            "pnl_usdt": 5.0, "pnl_pct": 2.0, "outcome": "WIN",
        })
        self.assertAlmostEqual(self.engine.get_threshold(PA, "min_volume_surge", 1.10), 1.10)

    def test_ai_upgrade_updates_anchor(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "test",
            "calibrated_thresholds": {
                OB: {"min_imbalance": 0.30},
            },
        })
        anchor = self.engine.memory.get("ratchet_anchor", {}).get(OB, {})
        self.assertAlmostEqual(anchor.get("min_imbalance"), 0.30)


if __name__ == "__main__":
    unittest.main()
