import sys
import types
import unittest
from contextlib import nullcontext
from datetime import datetime
from unittest.mock import MagicMock, patch


class TestDashboardCycleStatus(unittest.TestCase):
    def test_cli_scan_publishes_timestamp_cycle_and_scanning_state(self):
        import main

        dashboard = types.SimpleNamespace(
            is_scanning=False, cycle_count=0, latest_scan_data={}, last_cycle_time=None
        )
        result = {"macro_health": {}, "exit_events": [], "candidates_evaluated": [], "executed_trades": []}
        engine = MagicMock()
        engine.llm.status_summary = {}

        def run_cycle():
            self.assertTrue(dashboard.is_scanning)
            return result

        engine.run_cycle.side_effect = run_cycle
        console = MagicMock()
        console.status.return_value = nullcontext()
        with patch.dict(sys.modules, {"web_dashboard": dashboard}), patch.object(main, "console", console), patch.object(main, "show_portfolio_status"):
            main.run_single_scan(engine)
        self.assertFalse(dashboard.is_scanning)
        self.assertEqual(dashboard.cycle_count, 1)
        self.assertIs(dashboard.latest_scan_data, result)
        self.assertIsNotNone(datetime.fromisoformat(dashboard.last_cycle_time).tzinfo)
        self.assertEqual(result["completed_at"], dashboard.last_cycle_time)
        engine.portfolio.execute_trade.assert_not_called()

    def test_dual_mode_binds_dashboard_before_first_scan(self):
        import main

        engine = MagicMock()
        dashboard = types.SimpleNamespace(start_server=MagicMock())
        with patch.dict(sys.modules, {"web_dashboard": dashboard}), patch.object(sys, "argv", ["main.py", "--scan", "--web", "--interval", "17"]), patch.object(main, "TradingOrchestrator", return_value=engine), patch.object(main, "run_single_scan") as scan, patch("threading.Thread"):
            main.main()
            scan.assert_called_once_with(engine)
        self.assertIs(dashboard.orchestrator, engine)
        self.assertEqual(dashboard.AUTO_SCAN_INTERVAL_SEC, 17)
        self.assertFalse(dashboard.ENABLE_BACKGROUND_LOOP)

    def test_scan_failure_clears_scanning_without_claiming_completed_cycle(self):
        import main

        dashboard = types.SimpleNamespace(is_scanning=False, cycle_count=0)
        engine = MagicMock()
        engine.llm.status_summary = {}
        engine.run_cycle.side_effect = RuntimeError("Isolated scan failure")
        console = MagicMock()
        console.status.return_value = nullcontext()
        with patch.dict(sys.modules, {"web_dashboard": dashboard}), patch.object(main, "console", console):
            with self.assertRaisesRegex(RuntimeError, "Isolated scan failure"):
                main.run_single_scan(engine)
        self.assertFalse(dashboard.is_scanning)
        self.assertEqual(dashboard.cycle_count, 0)
