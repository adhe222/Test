import sys
import os
import time
import argparse
from pathlib import Path
from datetime import datetime, timezone
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from rich.text import Text
from rich import box

from orchestrator import TradingOrchestrator
from agents.consciousness import consciousness_engine
import config
from config import TRADING_MODE, INITIAL_PAPER_BALANCE_USDT, WEB_HOST, WEB_PORT

console = Console()


def format_usd(val: float) -> str:
    return f"${val:,.2f}"


def persist_env_assignment(key: str, value) -> bool:
    env_path = Path(__file__).resolve().parent / ".env"
    try:
        existing = env_path.read_text(encoding="utf-8") if env_path.exists() else ""
        lines = existing.splitlines()
        for i, line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}"
                break
        else:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(f"{key}={value}")
        tmp = env_path.with_name(f".env.{os.getpid()}.tmp")
        tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        tmp.replace(env_path)
        os.environ[key] = str(value)
        return True
    except Exception as e:
        print(f"[Config] Gagal menyimpan {key} ke .env: {e}")
        return False


def prompt_first_run_slots() -> int:
    console.print("[bold cyan]Setup pertama kali: tentukan jumlah slot posisi terbuka (1-20).[/bold cyan]")
    console.print("[dim]Pilihan disimpan permanen ke .env (MAX_OPEN_POSITIONS). Ubah kapan saja via .env atau flag --slots.[/dim]")
    for _ in range(3):
        raw = input(f"Jumlah slot posisi terbuka [default {config.MAX_OPEN_POSITIONS}]: ").strip()
        if not raw:
            return config.MAX_OPEN_POSITIONS
        try:
            n = int(raw)
            if 1 <= n <= config.MAX_SLOTS_LIMIT:
                return n
        except ValueError:
            pass
        console.print(f"[yellow]Masukkan angka 1-{config.MAX_SLOTS_LIMIT}.[/yellow]")
    return config.MAX_OPEN_POSITIONS


def show_portfolio_status(orchestrator: TradingOrchestrator):
    state = orchestrator.portfolio.state
    equity = orchestrator.portfolio.get_equity()
    cash = state.get("cash_usdt", 0.0)
    open_positions = state.get("open_positions", [])
    total_trades = state.get("total_trades", 0)
    winning_trades = state.get("winning_trades", 0)
    losing_trades = state.get("losing_trades", 0)
    realized_pnl = state.get("realized_pnl_usdt", 0.0)

    decided = winning_trades + losing_trades
    win_rate = (winning_trades / decided * 100.0) if decided > 0 else 0.0  # scratches excluded
    pnl_sign = "+" if realized_pnl >= 0 else ""
    pnl_color = "green" if realized_pnl >= 0 else "red"

    # KPI Table
    kpi_table = Table(title="BINANCE AI MULTI-AGENT PORTFOLIO METRICS", box=box.ROUNDED)
    kpi_table.add_column("Metric", style="cyan bold")
    kpi_table.add_column("Value", style="bold")

    c_summary = consciousness_engine.get_ultra_context_summary()
    kpi_table.add_row("Operational Mode", f"[yellow]{state.get('mode', TRADING_MODE).upper()}[/yellow]")
    kpi_table.add_row("AI Intelligence Engine", f"[bold magenta]ULTRA-CONTEXT {c_summary.get('ai_intelligence_level', '2.2.0')}[/bold magenta]")
    llm = orchestrator.llm
    if callable(getattr(llm, "_circuit_open", None)) and llm._circuit_open():
        mastery = "Deterministic Fallback (LLM circuit open)"
    else:
        mastery = f"AI Deliberation Active ({getattr(llm, 'model', 'llm')}, advisory)"
    kpi_table.add_row("Autonomous Mastery", f"[bold green]{mastery}[/bold green]")
    kpi_table.add_row("Total Portfolio Equity", f"[bold white]{format_usd(equity)}[/bold white]")
    kpi_table.add_row("Available Cash", f"[white]{format_usd(cash)}[/white]")
    kpi_table.add_row("Realized Net PnL", f"[{pnl_color}]{pnl_sign}{format_usd(realized_pnl)}[/{pnl_color}]")
    kpi_table.add_row("Completed Trades", f"{total_trades} (Wins: {winning_trades}, Losses: {losing_trades}, Scratch: {state.get('scratch_trades', 0)})")
    kpi_table.add_row("Win Rate", f"[bold {'green' if win_rate >= 50 else 'yellow'}]{win_rate:.1f}%[/]")
    kpi_table.add_row("Active Capacity", f"{len(open_positions)} / {config.MAX_OPEN_POSITIONS} positions (max {config.MAX_CORRELATED_POSITIONS} searah, {config.MAX_POSITION_SIZE_PCT}% equity/posisi)")
    kpi_table.add_row("Learned Lessons & Upgrades", f"{c_summary.get('total_mistakes_analyzed', 0)} RCA Rules | {c_summary.get('total_vetoes_prevented', 0)} Vetoes Enforced | {c_summary.get('total_upgrades_performed', 0)} Dynamic Upgrades")

    console.print(kpi_table)

    # Periodic Performance Report (Today, Week, Month)
    perf = orchestrator.portfolio.get_periodic_performance()
    perf_table = Table(title="LAPORAN KINERJA PERIODIK (HARI INI • MINGGU INI • BULAN INI)", box=box.ROUNDED)
    perf_table.add_column("Periode", style="cyan bold")
    perf_table.add_column("Net Realized Profit", style="bold")
    perf_table.add_column("Gross Profit", style="dim")
    perf_table.add_column("Fee Transaksi", style="red")
    perf_table.add_column("Selesai Trade", style="white")
    perf_table.add_column("Win Rate", style="bold")

    for label, key in [("Hari Ini (Today)", "today"), ("Minggu Ini (7 Hari)", "this_week"), ("Bulan Ini (Kalender)", "this_month")]:
        p_data = perf.get(key, {})
        net = p_data.get("net_pnl_usdt", 0.0)
        n_sign = "+" if net >= 0 else ""
        n_color = "green" if net >= 0 else "red"
        perf_table.add_row(
            label,
            f"[{n_color}]{n_sign}{format_usd(net)}[/{n_color}]",
            format_usd(p_data.get("gross_pnl_usdt", 0.0)),
            f"-{format_usd(p_data.get('fees_paid_usdt', 0.0))}",
            f"{p_data.get('trades', 0)} ({p_data.get('wins', 0)}W / {p_data.get('losses', 0)}L / {p_data.get('scratches', 0)}S)",
            f"{p_data.get('win_rate', 0.0):.1f}%"
        )
    console.print(perf_table)

    if not open_positions:
        console.print("[dim]Active Positions: None (AI agents scanning for optimal risk:reward setups)[/dim]\n")
    else:
        pos_table = Table(title="ACTIVE OPEN POSITIONS & REAL-TIME PnL", box=box.ROUNDED)
        pos_table.add_column("Symbol", style="bold cyan")
        pos_table.add_column("Entry Price", style="white")
        pos_table.add_column("Live Price", style="white")
        pos_table.add_column("Position Size", style="white")
        pos_table.add_column("Stop Loss (Protection)", style="red")
        pos_table.add_column("Targets (TP1 / TP2)", style="green")
        pos_table.add_column("Trailing Stop", style="magenta")
        pos_table.add_column("Unrealized PnL", style="bold")

        for pos in open_positions:
            sym = pos["symbol"]
            qty = pos["quantity"]
            entry_p = pos["entry_price"]
            is_short_pos = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")
            try:
                curr_p = orchestrator.client.get_price(sym)
                diff = (entry_p - curr_p) if is_short_pos else (curr_p - entry_p)
                unrealized_pnl_usdt = diff * qty
                unrealized_pnl_pct = (diff / entry_p) * 100.0
                p_sign = "+" if unrealized_pnl_usdt >= 0 else ""
                p_color = "green" if unrealized_pnl_usdt >= 0 else "red"
            except Exception:
                curr_p = entry_p
                unrealized_pnl_usdt = 0.0
                unrealized_pnl_pct = 0.0
                p_sign = ""
                p_color = "white"

            trailing_label = "[green]Active[/green]" if pos.get("trailing_active") else f"[dim]Armed (+{pos.get('trailing_trigger_pct', 2.2)}%)[/dim]"
            
            # SL label with break-even badge
            if pos.get("break_even_active"):
                sl_label = f"[bold green]${pos['stop_loss_price']} (Risk-Free BE)[/bold green]"
            else:
                sl_label = f"${pos['stop_loss_price']} (-{pos['stop_loss_pct']}%)"

            # TP label with partial badge
            tp_status = "[cyan]TP1 Taken (50%)[/cyan]" if pos.get("tp1_hit") else f"${pos['take_profit_1']}"
            targets_label = f"{tp_status} | TP2: ${pos['take_profit_2']}"

            is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")
            sym_label = f"{sym} [red][SHORT][/red]" if is_short else f"{sym} [green][LONG][/green]"

            pos_table.add_row(
                sym_label,
                f"${entry_p}",
                f"${curr_p}",
                f"{format_usd(pos['position_usdt'])} ({qty:.2f})",
                sl_label,
                targets_label,
                trailing_label,
                f"[{p_color}]{p_sign}{format_usd(unrealized_pnl_usdt)} ({p_sign}{unrealized_pnl_pct:.2f}%)[/{p_color}]"
            )
        console.print(pos_table)


def run_single_scan(orchestrator: TradingOrchestrator):
    ai_status = orchestrator.llm.status_summary
    console.print(Panel(
        f"[bold cyan]AI Engine[/bold cyan]: [bold white]{ai_status.get('model', config.OPENAI_MODEL)}[/bold white] | "
        f"[cyan]Provider[/cyan]: [yellow]{ai_status.get('provider_type', ai_status.get('provider', 'Clouvia Router'))}[/yellow] | "
        f"[cyan]Endpoint[/cyan]: [dim]{ai_status.get('base_url', '')}[/dim]\n"
        f"[cyan]Organizational Hierarchy[/cyan]: [bold green]Macro Sentinel + 8 Divisions (32 AI Roles Total)[/bold green]",
        title="[bold yellow]⚡ BINANCE INSTITUTIONAL AI MULTI-AGENT QUANT SYSTEM[/bold yellow]",
        border_style="blue"
    ))

    # Stepper visualization
    console.print("[dim]Pipeline: [bold cyan]1. Position Audit[/bold cyan] ➔ [bold cyan]2. Macro Sentinel (BTC)[/bold cyan] ➔ [bold cyan]3. 32-Agent Deliberation[/bold cyan] ➔ [bold cyan]4. CRO Veto & Sizing[/bold cyan] ➔ [bold cyan]5. Order Execution[/bold cyan][/dim]")

    with console.status("[bold green]Deliberating with Macro Sentinel & 32 AI Agents across Binance Spot...[/bold green]", spinner="dots"):
        start_time = time.time()
        dashboard = sys.modules.get("web_dashboard")
        if dashboard is not None:
            dashboard.is_scanning = True
        try:
            results = orchestrator.run_cycle()
            results["completed_at"] = datetime.now(timezone.utc).isoformat()
        finally:
            if dashboard is not None:
                dashboard.is_scanning = False
        elapsed = time.time() - start_time

    # Display Macro Sentinel Status
    macro = results.get("macro_health", {})
    if macro:
        circuit_color = "red bold" if macro.get("circuit_breaker") else "green bold"
        circuit_text = "CIRCUIT BREAKER TRIPPED (Altcoin entries paused)" if macro.get("circuit_breaker") else "CIRCUIT BREAKER DISARMED (Market safe)"
        console.print(Panel(
            f"[bold white]Benchmark ({macro.get('symbol', 'BTCUSDT')})[/bold white]: ${macro.get('price', 0):,.1f} | "
            f"[cyan]RSI[/cyan]: {macro.get('rsi', 50)} | "
            f"[cyan]4h Drop[/cyan]: {macro.get('drop_4h_pct', 0):+.2f}% | "
            f"[cyan]Regime[/cyan]: [{circuit_color}]{macro.get('regime')}[/{circuit_color}]\n"
            f"[dim]{macro.get('rationale')}[/dim]",
            title=f"🌐 [bold]Macro Market Sentinel (Bitcoin Beta Guard)[/bold] ➔ [{circuit_color}]{circuit_text}[/{circuit_color}]",
            border_style="magenta"
        ))

    # Display trade exits & partial take profits
    if results["exit_events"]:
        exit_table = Table(title="[bold red]TRADE EXIT & PROFIT SCALING ACTIONS[/bold red]", box=box.ROUNDED)
        exit_table.add_column("Symbol", style="bold cyan")
        exit_table.add_column("Action / Reason", style="yellow")
        exit_table.add_column("Entry Price", style="white")
        exit_table.add_column("Exit Price", style="white")
        exit_table.add_column("Realized Net PnL", style="bold")

        for ev in results["exit_events"]:
            p_sign = "+" if ev['pnl_usdt'] >= 0 else ""
            p_color = "green" if ev['pnl_usdt'] >= 0 else "red"
            exit_table.add_row(
                ev["symbol"],
                f"{ev['action']} ({ev['reason']})",
                f"${ev['entry_price']}",
                f"${ev['exit_price']}",
                f"[{p_color}]{p_sign}{format_usd(ev['pnl_usdt'])} ({p_sign}{ev['pnl_pct']}%)[/{p_color}]"
            )
        console.print(exit_table)

    # 8-Specialist Council Evaluation Table
    if results["candidates_evaluated"]:
        council_table = Table(title="AI SPECIALISTS COUNCIL VERDICT MATRIX (8 DIVISIONS)", box=box.ROUNDED)
        council_table.add_column("Asset", style="bold cyan")
        council_table.add_column("24h Chg / Vol", style="white")
        council_table.add_column("1. Flow", justify="center")
        council_table.add_column("2. Price", justify="center")
        council_table.add_column("3. RSI", justify="center")
        council_table.add_column("4. Depth", justify="center")
        council_table.add_column("5. Regime", justify="center")
        council_table.add_column("6. CRO", justify="center")
        council_table.add_column("7. Exit", justify="center")
        council_table.add_column("Consensus", justify="center", style="bold")

        for c in results["candidates_evaluated"]:
            specs = c["specialist_reports"]
            exec_res = c["executive_verdict"]

            def fmt_vote(spec):
                if not spec:
                    return "[dim]N/A[/dim]"
                verdict = spec.get("verdict", "REJECT")
                score = spec.get("conviction", 0)
                color = "green" if verdict == "APPROVE" else "red"
                short_v = "APP" if verdict == "APPROVE" else "REJ"
                return f"[{color}]{short_v}\n{score}%[/{color}]"

            v_color = "green" if exec_res["final_verdict"] == "APPROVE" else "red"
            consensus_str = f"[{v_color}]{exec_res['final_verdict']}\n({exec_res['consensus_conviction']}%)[/{v_color}]"

            dir_tag = "[red]SHORT[/red]" if c.get("direction") == "SHORT" else "[green]LONG[/green]"
            sym_display = f"{c['symbol']}\n{dir_tag}"

            council_table.add_row(
                sym_display,
                f"{c['price_change_24h']:+.2f}%\n${c['quote_volume_24h']/1e6:.1f}M",
                fmt_vote(specs[0] if len(specs) > 0 else None),
                fmt_vote(specs[1] if len(specs) > 1 else None),
                fmt_vote(specs[2] if len(specs) > 2 else None),
                fmt_vote(specs[3] if len(specs) > 3 else None),
                fmt_vote(specs[4] if len(specs) > 4 else None),
                fmt_vote(specs[5] if len(specs) > 5 else None),
                fmt_vote(specs[6] if len(specs) > 6 else None),
                consensus_str
            )
        console.print(council_table)

        # Full Hierarchical Sub-Agent Tree Breakdown for Top Candidate
        top = results["candidates_evaluated"][0]
        exec_verdict = top["executive_verdict"]

        tree_title = f"🏛️ [bold cyan]32-Agent Deliberation Hierarchy for Top Candidate: [white]{top['symbol']}[/white] (${top['price']})[/bold cyan]"
        org_tree = Tree(tree_title)

        # Iterate all 7 operational departments
        for dept in top["specialist_reports"]:
            d_verdict = dept["verdict"]
            d_color = "green" if d_verdict == "APPROVE" else "red"
            dept_node = org_tree.add(
                f"{dept['icon']} [bold]{dept['specialist']}[/bold] ([italic]{dept.get('lead_title', 'Division Lead')}[/italic]) "
                f"➔ [{d_color}]{d_verdict} ({dept['conviction']}%)[/{d_color}]\n   [dim]{dept['rationale']}[/dim]"
            )

            # Add each employee (sub-agent) under this department lead
            for staff in dept.get("staff_reports", []):
                s_verdict = staff["verdict"]
                s_color = "green" if s_verdict == "APPROVE" else "red"
                dept_node.add(
                    f"👤 [cyan]{staff['staff_name']}[/cyan] ({staff.get('role_title', 'Analyst')}) ➔ "
                    f"[{s_color}]{s_verdict} ({staff['conviction']}%)[/{s_color}] - [yellow]{staff.get('signal', '')}[/yellow]\n"
                    f"   [dim italic]{staff['rationale']}[/dim italic]"
                )

        # Add Department 8 (Executive Committee)
        exec_color = "green" if exec_verdict["final_verdict"] == "APPROVE" else "red"
        exec_node = org_tree.add(
            f"{exec_verdict['icon']} [bold]{exec_verdict['specialist']}[/bold] ([italic]{exec_verdict.get('lead_title', 'Managing Director')}[/italic]) "
            f"➔ [{exec_color}]{exec_verdict['final_verdict']} ({exec_verdict['consensus_conviction']}%)[/{exec_color}]\n   [bold]{exec_verdict['summary']}[/bold]"
        )
        for staff in exec_verdict.get("staff_reports", []):
            s_verdict = staff["verdict"]
            s_color = "green" if s_verdict == "APPROVE" else "red"
            exec_node.add(
                f"👤 [cyan]{staff['staff_name']}[/cyan] ➔ [{s_color}]{s_verdict} ({staff['conviction']}%)[/{s_color}] - [yellow]{staff.get('signal', '')}[/yellow]\n"
                f"   [dim italic]{staff['rationale']}[/dim italic]"
            )

        console.print(Panel(org_tree, border_style="cyan"))

    # Executed trades summary
    if results["executed_trades"]:
        exec_table = Table(title="[bold green]NEW POSITIONS EXECUTED[/bold green]", box=box.ROUNDED)
        exec_table.add_column("Symbol", style="bold cyan")
        exec_table.add_column("Entry Price", style="white")
        exec_table.add_column("Position Capital", style="yellow")
        exec_table.add_column("Stop Loss (ATR)", style="red")
        exec_table.add_column("Targets (TP1 / TP2)", style="green")
        exec_table.add_column("Risk:Reward", style="magenta")

        for t in results["executed_trades"]:
            plan = t["risk_plan"]
            exec_table.add_row(
                t["symbol"],
                f"${plan['entry_price']}",
                f"{format_usd(plan['position_usdt'])} ({plan['quantity']:.2f} units)",
                f"${plan['stop_loss_price']} (-{plan['stop_loss_pct']}%)",
                f"${plan['take_profit_1']} / ${plan['take_profit_2']}",
                f"1:{plan['risk_reward_ratio']}"
            )
        console.print(exec_table)

    show_portfolio_status(orchestrator)
    dashboard = sys.modules.get("web_dashboard")
    if dashboard is not None:
        results["last_updated"] = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
        dashboard.latest_scan_data = results
        dashboard.last_cycle_time = results["completed_at"]
        dashboard.cycle_count += 1
    console.print(f"[dim]Cycle finished in {elapsed:.2f}s[/dim]\n")


def main():
    parser = argparse.ArgumentParser(description="Binance Crypto Multi-Agent AI Trading System")
    parser.add_argument("--scan", action="store_true", help="Run a single multi-agent scan cycle")
    parser.add_argument("--run", action="store_true", help="Run continuous monitoring loop")
    parser.add_argument("--interval", type=int, default=10, help="Loop interval in seconds (default 10)")
    parser.add_argument("--portfolio", action="store_true", help="Display current portfolio balance and positions")
    parser.add_argument("--reset", action="store_true", help="Reset paper trading portfolio balance")
    parser.add_argument("--close-all", action="store_true", help="Auto-sell / liquidate all open positions and exit")
    parser.add_argument("--close-on-exit", action="store_true", help="Auto-sell all open positions when stopping continuous loop (Ctrl+C)")
    parser.add_argument("--web", "--dashboard", action="store_true", help="Start the live Web Dashboard UI")
    parser.add_argument("--port", type=int, default=WEB_PORT, help=f"Web dashboard port (default: {WEB_PORT})")
    parser.add_argument("--slots", type=int, default=None,
                        help=f"Max simultaneous open positions (1-{config.MAX_SLOTS_LIMIT}, default {config.MAX_OPEN_POSITIONS})")
    parser.add_argument("--max-same-direction", type=int, default=None,
                        help="Max positions in the same direction (default: ceil(2/3 x slots))")
    parser.add_argument("--position-size-pct", type=float, default=None,
                        help="Max equity %% per position (default: min(25, 90 / slots))")
    parser.add_argument("--autonomous-evolve", action="store_true", default=True,
                        help="Enable autonomous evolution (default: True). Disable to prevent self-upgrades.")
    args = parser.parse_args()

    if args.slots is not None or args.max_same_direction is not None or args.position_size_pct is not None:
        try:
            eff = config.apply_position_slots(
                args.slots if args.slots is not None else config.MAX_OPEN_POSITIONS,
                correlated=args.max_same_direction,
                position_size_pct=args.position_size_pct,
            )
        except ValueError as exc:
            parser.error(str(exc))
    elif "MAX_OPEN_POSITIONS" not in os.environ and sys.stdin.isatty():
        chosen = prompt_first_run_slots()
        if chosen != config.MAX_OPEN_POSITIONS:
            persist_env_assignment("MAX_OPEN_POSITIONS", chosen)
        eff = config.apply_position_slots(chosen)
    else:
        eff = config.apply_position_slots(config.MAX_OPEN_POSITIONS)
    console.print(
        f"[bold cyan]Slot posisi[/bold cyan]: {eff['max_open_positions']} total | "
        f"max {eff['max_correlated_positions']} searah | {eff['max_position_size_pct']}% equity per posisi"
    )
    console.print(
        f"[bold cyan]Profil trading[/bold cyan]: {config.TRADING_PROFILE.upper()} "
        f"(ubah via TRADING_PROFILE=conservative|balanced|aggressive di .env)"
    )

    if args.web and not (args.run or args.scan or args.portfolio or args.reset or args.close_all):
        import web_dashboard
        web_dashboard.WEB_PORT = args.port
        web_dashboard.start_server()
        return

    orchestrator = TradingOrchestrator()
    
    # Autonomous evolution background scheduler (Opsi A implementation)
    def schedule_evolution():
        """Background thread to run autonomous evolution every 6 hours."""
        from threading import Timer
        import logging
        
        interval_sec = 21600  # 6 hours in seconds
        logger = logging.getLogger("evolution")
        
        def run_cycle():
            try:
                console.print("[bold magenta]⚡ AUTO-EVOLUTION TRIGGERED (autonomous self-improvement)[/bold magenta]")
                orchestrator.autonomous_evolve()
                console.print(f"[dim]Evolution complete at {datetime.now(timezone.utc).isoformat()}[/dim]")
            except Exception as e:
                console.print(f"[red]Evolution failed: {e}[/red]")
                import traceback
                traceback.print_exc()
            finally:
                # Schedule next cycle
                if getattr(schedule_evolution, 'running', True):
                    next_timer = Timer(interval_sec, run_cycle)
                    next_timer.daemon = True
                    next_timer.start()
        
        schedule_evolution.running = True
        run_cycle()
    
    # Start scheduler if --autonomous-evolve enabled
    if hasattr(args, 'autonomous_evolve') and args.autonomous_evolve:
        try:
            schedule_evolution()
            console.print("[green]Autonomous evolution scheduler started (cycle: 6h)[/green]")
        except Exception as e:
            console.print(f"[yellow]Auto-evolution disabled: {e}. Run manually with --update-conscience if needed.[/yellow]")

    start_dashboard_thread = False
    if not any([args.scan, args.run, args.portfolio, args.reset, args.close_all, args.web]):
        print("[AUTO-MODE] Starting Dual Mode: Terminal Scan + Web Dashboard...")
        args.run = True
        start_dashboard_thread = True
    elif args.web and (args.run or args.scan):
        start_dashboard_thread = True

    if start_dashboard_thread:
        import threading

        import web_dashboard
        web_dashboard.WEB_PORT = args.port
        web_dashboard.AUTO_SCAN_INTERVAL_SEC = args.interval
        web_dashboard.ENABLE_BACKGROUND_LOOP = False
        web_dashboard.orchestrator = orchestrator
        web_dashboard.portfolio = orchestrator.portfolio
        web_thread = threading.Thread(target=web_dashboard.start_server, daemon=True)
        web_thread.start()
        print(f"[Dashboard] Web UI launching on http://localhost:{args.port}...")

    if args.close_all:
        closed = orchestrator.portfolio.close_all_positions(reason="MANUAL_BOT_CLOSE_ALL")
        console.print(f"[bold red]Auto-sold all {len(closed)} open positions. Capital returned to free cash balance.[/bold red]")
        show_portfolio_status(orchestrator)
        return

    if args.reset:
        orchestrator.portfolio.reset_portfolio(INITIAL_PAPER_BALANCE_USDT)
        console.print(f"[bold green]Portfolio successfully reset to {format_usd(INITIAL_PAPER_BALANCE_USDT)} USDT.[/bold green]")
        return

    if args.portfolio:
        show_portfolio_status(orchestrator)
        return

    if args.run:
        console.print(f"[bold green]STARTING CONTINUOUS MULTI-AGENT LOOP (INTERVAL: {args.interval}s)[/bold green]")
        console.print("[dim]Press Ctrl+C to stop.[/dim]\n")
        try:
            while True:
                run_single_scan(orchestrator)
                console.print(f"[dim]Sleeping {args.interval}s until next scan cycle...[/dim]\n")
                time.sleep(args.interval)
        except KeyboardInterrupt:
            console.print("\n[yellow]Bot interrupted by user.[/yellow]")
            if args.close_on_exit:
                closed = orchestrator.portfolio.close_all_positions(reason="BOT_SHUTDOWN_LIQUIDATION")
                console.print(f"[bold red]Auto-sold all {len(closed)} open positions before exit.[/bold red]")
            else:
                console.print("[dim]Positions remain open. Use 'python3 main.py --close-all' to liquidate at any time.[/dim]")
        return

    # Default action: run single scan
    run_single_scan(orchestrator)


if __name__ == "__main__":
    main()
