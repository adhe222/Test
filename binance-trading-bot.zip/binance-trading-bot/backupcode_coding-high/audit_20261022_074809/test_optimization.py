#!/usr/bin/env python3
"""
Quick validation script for win rate optimization changes
Run this to verify all configuration parameters are correctly loaded.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    ADAPTIVE_ATR_MULTIPLIER,
    EARLY_BREAK_EVEN_PCT,
    FASTER_TP1_RATIO,
    ENHANCED_MIN_CONVICTION,
    VOLUME_SURGE_FILTER,
    TREND_TIMEFRAME_1,
    TREND_TIMEFRAME_2,
    MAX_HOLD_HOURS_STAGNANT,
    MIN_RISK_REWARD_RATIO,
    RISK_PER_TRADE_PCT
)

print("=" * 70)
print("🎯 WIN RATE OPTIMIZATION - CONFIGURATION VALIDATION")
print("=" * 70)

# Check new parameters
checks = [
    ("ATR Multiplier (tighter stops)", ADAPTIVE_ATR_MULTIPLIER, 1.2),
    ("Early Break-Even Trigger", EARLY_BREAK_EVEN_PCT, 1.5),
    ("TP1 Partial Exit Ratio", FASTER_TP1_RATIO, 0.60),
    ("Enhanced Min Conviction", ENHANCED_MIN_CONVICTION, 75),
    ("Volume Surge Filter", VOLUME_SURGE_FILTER, 1.3),
    ("Primary Trend Timeframe", TREND_TIMEFRAME_1, "1h"),
    ("Secondary Trend Timeframe", TREND_TIMEFRAME_2, "4h"),
    ("Stagnant Hold Timeout", MAX_HOLD_HOURS_STAGNANT, 18.0)
]

all_passed = True
for name, actual, expected in checks:
    status = "✅ PASS" if actual == expected else "❌ FAIL"
    if actual != expected:
        all_passed = False
    print(f"{status} | {name}: {actual} (expected: {expected})")

# Print risk management settings
print("\n🛡️  RISK MANAGEMENT SETTINGS:")
print(f"   Risk Per Trade: {RISK_PER_TRADE_PCT}%")
print(f"   Min Risk:Reward Ratio: 1:{MIN_RISK_REWARD_RATIO}")

print("\n" + "=" * 70)
if all_passed:
    print("🎉 ALL OPTIMIZATION PARAMETERS LOADED SUCCESSFULLY!")
    print("=" * 70)
    print("\n📊 EXPECTED IMPACT:")
    print("   • Tighter stop-losses → Smaller losses on wrong trades")
    print("   • Faster break-even → More trades go risk-free")
    print("   • Stricter entry filters → Higher quality signals only")
    print("   • Multi-timeframe confirmation → Better trend alignment")
    print("   • Earlier profit protection → Lock gains before reversal")
    print("\n🚀 Ready to trade with 60-70% target win rate!")
else:
    print("⚠️  SOME PARAMETERS FAILED VALIDATION - CHECK CONFIG!")
    print("=" * 70)
    sys.exit(1)
