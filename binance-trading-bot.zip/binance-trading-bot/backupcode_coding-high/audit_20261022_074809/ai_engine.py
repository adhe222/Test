import os
import re
import json
import time
import logging
from typing import Dict, Any, Callable, List, Optional
from openai import OpenAI
import config
from config import CLOUVIA_API_KEY, OPENAI_MODEL, LLM_TEMPERATURE

logger = logging.getLogger("AIEngine")


class LLMClient:
    def __init__(
        self,
        api_key: str = CLOUVIA_API_KEY,
        base_url: str = "https://router.clouvia.id/v1",
        model: str = OPENAI_MODEL,
        temperature: float = LLM_TEMPERATURE
    ):
        self.api_key = api_key or os.getenv("CLOUVIA_API_KEY", "")
        self.base_url = base_url or os.getenv("CLOUVIA_BASE_URL", "https://router.clouvia.id/v1")
        self.model = model or OPENAI_MODEL
        self.temperature = temperature
        self._consecutive_failures = 0
        self._circuit_opened_at = 0.0

        try:
            timeout_val = getattr(config, "LLM_TIMEOUT", 45.0)
            self.client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=timeout_val,
                max_retries=1
            )
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client for Clouvia: {e}")
            self.client = None

    @property
    def status_summary(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "base_url": self.base_url,
            "provider": "Clouvia Router (OpenAI SDK)",
            "provider_type": "Clouvia Router (OpenAI SDK)",
            "configured": bool(self.api_key),
            "temperature": self.temperature
        }

    def _validate(self, parsed: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(parsed, dict):
            raise ValueError("model response is not a JSON object")

        verdict = str(parsed.get("verdict", "")).strip().upper()
        if verdict not in ("APPROVE", "REJECT"):
            raise ValueError(f"invalid verdict: {parsed.get('verdict')!r}")

        try:
            conviction = int(float(parsed.get("conviction", 0)))
        except (TypeError, ValueError):
            raise ValueError(f"invalid conviction: {parsed.get('conviction')!r}")
        conviction = max(0, min(100, conviction))

        return {
            "verdict": verdict,
            "conviction": conviction,
            "rationale": str(parsed.get("rationale", ""))[:600] or "No rationale provided.",
            "signal": str(parsed.get("signal", ""))[:120] or "Unlabelled",
        }

    @staticmethod
    def _strip_llm_noise(text: Optional[str]) -> str:
        if not text:
            return ""
        cleaned = text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        strip_think = re.compile(chr(60) + r"(?:think|answer|reasoning|output)" + chr(62) + r".*?" + chr(60) + r"/(?:think|answer|reasoning|output)" + chr(62), re.DOTALL | re.IGNORECASE)
        cleaned = strip_think.sub("", cleaned)
        cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
        return cleaned

    @staticmethod
    def _balanced_json(text: str, start: int) -> Optional[str]:
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
        return None

    def _parse_json(self, content: Optional[str]) -> Dict[str, Any]:
        if content is None:
            raise ValueError("empty model response (content is None)")
        cleaned = self._strip_llm_noise(content)
        last_err: Optional[Exception] = None
        for m in re.finditer(r"\{", cleaned):
            candidate = self._balanced_json(cleaned, m.start())
            if candidate is None:
                continue
            try:
                parsed = json.loads(candidate)
            except ValueError as e:
                last_err = e
                continue
            if isinstance(parsed, dict):
                return parsed
        raise last_err or ValueError("no JSON object found in model response")

    def _circuit_open(self) -> bool:
        if self._consecutive_failures < config.LLM_CIRCUIT_FAILURES:
            return False
        if time.monotonic() - self._circuit_opened_at >= config.LLM_CIRCUIT_COOLDOWN_SEC:
            self._consecutive_failures = 0
            return False
        return True

    def query_specialist(
        self,
        specialist_role: str,
        system_instruction: str,
        context_data: Dict[str, Any],
        fallback_fn: Callable[[Dict[str, Any]], Dict[str, Any]]
    ) -> Dict[str, Any]:
        baseline = fallback_fn(context_data)

        if not self.client or not self.api_key or self._circuit_open() or context_data.get("skip_llm"):
            baseline["engine"] = f"Deterministic Engine ({specialist_role})"
            baseline["engine_mode"] = "DETERMINISTIC"
            return baseline

        system_prompt = (
            f"Kamu adalah {specialist_role} pada quantitative crypto trading bot di Binance Spot.\n"
            f"Mandat Tugas: {system_instruction.strip()}\n\n"
            "Format Instruksi:\n"
            "Berikan analisis yang ringkas, objektif, dan solutif untuk mencapai target win rate > 70%.\n"
            "Kamu WAJIB menjawab HANYA dalam format JSON valid tanpa teks pengantar, dengan struktur keys:\n"
            "{\n"
            '  "verdict": "APPROVE" atau "REJECT",\n'
            '  "conviction": integer 0-100,\n'
            '  "rationale": "ringkasan analisis teknikal solutif maksimal 2-3 kalimat",\n'
            '  "signal": "label sinyal utama singkat"\n'
            "}"
        )

        user_content = (
            f"Analisis data real-time Binance berikut untuk aset {context_data.get('symbol', '')}:\n"
            f"{json.dumps(context_data, indent=2, default=str)}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content}
        ]

        try:
            timeout_val = getattr(config, "LLM_TIMEOUT", 45.0)
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=int(getattr(config, "LLM_MAX_TOKENS", 1500)),
                timeout=timeout_val
            )
            llm_res = self._validate(self._parse_json(response.choices[0].message.content))
            self._consecutive_failures = 0

            if config.LLM_VETO_ONLY:
                merged = dict(baseline)
                mode = getattr(config, "LLM_VETO_MODE", "advisory")
                if llm_res["verdict"] == "REJECT":
                    if mode == "veto":
                        merged["verdict"] = "REJECT"
                        merged["rationale"] = f"AI veto: {llm_res['rationale']}"
                        merged["signal"] = llm_res["signal"]
                        merged["conviction"] = min(int(baseline.get("conviction", 0)), llm_res["conviction"])
                    else:
                        # Advisory: the LLM re-reads the SAME inputs the
                        # deterministic gates already judged, so one dissent is
                        # not independent evidence (PIT-013). It costs a fixed
                        # conviction penalty; several dissents drag firm-wide
                        # conviction below the executive threshold.
                        penalty = int(getattr(config, "LLM_DISSENT_PENALTY", 12))
                        merged["conviction"] = max(0, int(baseline.get("conviction", 0)) - penalty)
                        merged["rationale"] = f"{baseline.get('rationale', '')} | AI dissent (-{penalty}): {llm_res['rationale']}"
                else:
                    merged["conviction"] = min(
                        int(baseline.get("conviction", 0)), max(llm_res["conviction"], int(baseline.get("conviction", 0)) - 10)
                    )
                merged["ai_verdict"] = llm_res["verdict"]
                merged["ai_conviction"] = llm_res["conviction"]
                merged["ai_rationale"] = llm_res["rationale"]
                merged["engine"] = f"{self.model} ({mode}) + Deterministic"
                merged["engine_mode"] = "AI_VETO_OVER_DETERMINISTIC" if mode == "veto" else "AI_ADVISORY_OVER_DETERMINISTIC"
                return merged

            llm_res["engine"] = f"{self.model} (Clouvia Router)"
            llm_res["engine_mode"] = "AI_AUTHORITATIVE"
            return llm_res
        except Exception as e:
            self._consecutive_failures += 1
            if self._consecutive_failures == config.LLM_CIRCUIT_FAILURES:
                self._circuit_opened_at = time.monotonic()
                logger.warning(
                    f"LLM circuit opened after {self._consecutive_failures} consecutive failures; "
                    f"running deterministic-only for {config.LLM_CIRCUIT_COOLDOWN_SEC}s. Last error: {e}"
                )
            elif self._consecutive_failures < config.LLM_CIRCUIT_FAILURES:
                logger.warning(f"LLM call error ({e}); using deterministic engine for this decision.")
            baseline["engine"] = f"Deterministic Fallback ({specialist_role})"
            baseline["engine_mode"] = "DETERMINISTIC_FALLBACK"
            return baseline

    def upgrade_agent_intelligence(
        self,
        consciousness_engine,
        trade_history: List[Dict[str, Any]],
        portfolio_state: Dict[str, Any]
    ) -> Dict[str, Any]:
        if not self.client or not self.api_key or self._circuit_open():
            consciousness_engine.evolve_heuristics_deterministically(trade_history[-10:])
            return {
                "success": True,
                "mode": "DETERMINISTIC_AUTONOMOUS",
                "version": consciousness_engine.memory.get("ai_intelligence_level", "2.2.0-ULTRA"),
                "summary": "Deterministic self-evolution executed based on empirical trade logs."
            }

        concise_trades = [
            {
                "symbol": t.get("symbol"),
                "outcome": t.get("outcome"),
                "pnl": t.get("pnl_usdt"),
                "reason": t.get("reason")
            }
            for t in trade_history[-6:]
        ]
        ultra_context = {
            "recent_trades": concise_trades,
            "total_trades": portfolio_state.get("total_trades", 0),
            "winning_trades": portfolio_state.get("winning_trades", 0),
            "realized_pnl_usdt": portfolio_state.get("realized_pnl_usdt", 0.0)
        }

        system_prompt = (
            "You are the Chief Intelligence Officer & Meta-Quant Architect for a Binance Spot Multi-Agent Trading System.\n"
            "Analyze recent trade outcomes and output calibrated thresholds and division weights in strict JSON format:\n"
            "{\n"
            '  "upgrade_version": "2.3.0-ULTRA",\n'
            '  "executive_diagnosis": "Concise 1 sentence diagnosis",\n'
            '  "calibrated_thresholds": {\n'
            '    "Technical Price Action Division": {"min_volume_surge": 1.15, "max_upper_wick_ratio": 0.32},\n'
            '    "Momentum Exhaustion Division": {"min_rsi": 49.0, "max_rsi": 73.5},\n'
            '    "Order Book Microstructure Division": {"max_spread_pct": 0.18, "min_imbalance": 0.06},\n'
            '    "Volatility & Market Regime Division": {"min_trend_efficiency": 0.12, "min_atr_pct": 0.85}\n'
            "  },\n"
            '  "dynamic_weights": {\n'
            '    "Technical Price Action Division": 1.18,\n'
            '    "Momentum Exhaustion Division": 1.12,\n'
            '    "Quantitative Risk & Capital Division": 1.30\n'
            "  },\n"
            '  "new_rules": [\n'
            "    {\n"
            '      "division": "Technical Price Action Division",\n'
            '      "rule_id": "PA-META-01",\n'
            '      "rule": "Actionable rule for sub-agents",\n'
            '      "origin": "Ultra-Context AI Meta-Quant Calibration"\n'
            "    }\n"
            "  ]\n"
            "}"
        )

        user_prompt = f"Perform Meta-Quant Calibration on this Ultra-Context state:\n{json.dumps(ultra_context, indent=2, default=str)}"

        try:
            timeout_val = getattr(config, "LLM_TIMEOUT", 30.0)
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.0,
                max_tokens=max(2000, int(getattr(config, "LLM_MAX_TOKENS", 1500))),
                timeout=timeout_val
            )
            parsed = self._parse_json(response.choices[0].message.content)
            consciousness_engine.apply_ai_upgrade(parsed)
            return {
                "success": True,
                "mode": "AI_ULTRA_CONTEXT",
                "version": parsed.get("upgrade_version", "2.3.0-ULTRA"),
                "diagnosis": parsed.get("executive_diagnosis", ""),
                "summary": "AI Ultra-Context successfully upgraded sub-agent heuristics and weights."
            }
        except Exception as e:
            logger.warning(f"AI Upgrade failed ({e}); falling back to autonomous deterministic self-evolution.")
            consciousness_engine.evolve_heuristics_deterministically(trade_history[-10:])
            return {
                "success": True,
                "mode": "DETERMINISTIC_AUTONOMOUS_FALLBACK",
                "version": consciousness_engine.memory.get("ai_intelligence_level", "2.2.0-ULTRA"),
                "summary": f"Deterministic self-evolution completed after AI upgrade glitch: {e}"
            }
