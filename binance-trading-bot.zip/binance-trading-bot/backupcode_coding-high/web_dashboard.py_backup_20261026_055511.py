import os
import re
import json
import time
import asyncio
from datetime import datetime, timezone
from typing import Dict, Any, List
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from orchestrator import TradingOrchestrator
import config
from dashboard_telemetry import build_market_operations, current_run_closed_events, describe_market_record
from config import (
    WEB_HOST,
    WEB_PORT,
    TRADING_MODE,
    INITIAL_PAPER_BALANCE_USDT,
    EFFECTIVE_FEE_PCT,
    ACCEPTED_QUOTE_ASSETS,
)
from agents.consciousness import consciousness_engine
from agents.portfolio_manager import event_outcome
from market_stream import market_stream

orchestrator = TradingOrchestrator()
TEMPLATE_FILE = Path(__file__).resolve().parent / "templates" / "dashboard.html"

# Cache latest scan cycle results
latest_scan_data: Dict[str, Any] = {
    "last_updated": None,
    "ai_status": orchestrator.llm.status_summary,
    "macro_health": {},
    "candidates_scanned": 0,
    "candidates_evaluated": [],
    "executed_trades": [],
    "exit_events": [],
    "portfolio_summary": {},
    "market_stream": {}
}

cycle_count = 0
last_cycle_time = None
is_scanning = False
AUTO_SCAN_INTERVAL_SEC = 10
TICK_SCAN_TRIGGER_PCT = float(getattr(config, "TICK_SCAN_TRIGGER_PCT", 0.5))
TICK_SCAN_WINDOW_SEC = float(getattr(config, "TICK_SCAN_WINDOW_SEC", 60.0))
TICK_SCAN_COOLDOWN_SEC = float(getattr(config, "TICK_SCAN_COOLDOWN_SEC", 45.0))
TICK_GUARD_COALESCE_SEC = float(getattr(config, "TICK_GUARD_COALESCE_SEC", 0.05))
pending_ticks: Dict[str, Dict[str, Any]] = {}
pending_trigger_symbols = set()
tick_wakeup = asyncio.Event()
scan_wakeup = asyncio.Event()
_TICK_LOOP = [None]
stream_event_stats = {
    "ticks_received": 0,
    "tick_batches": 0,
    "position_guard_runs": 0,
    "event_scan_triggers": 0,
    "last_trigger_symbols": [],
    "last_tick_at": None,
}
discovery_status: Dict[str, Any] = {
    "mode": "WARMING_UP",
    "candidate_count": 0,
    "symbols": [],
    "generated_at": None,
    "duration_sec": None,
    "next_analysis": "TICK_MOVER_EVENT",
    "error": None,
}


def _queue_tick(quote):
    symbol = str((quote or {}).get("symbol") or "").upper()
    market = str((quote or {}).get("market") or "SPOT").upper()
    if not symbol:
        return
    pending_ticks[f"{market}:{symbol}"] = quote
    stream_event_stats["ticks_received"] += 1
    stream_event_stats["last_tick_at"] = datetime.now(timezone.utc).isoformat()
    tick_wakeup.set()


def _tick_listener(quote):
    loop = _TICK_LOOP[0]
    if loop and not loop.is_closed():
        try:
            loop.call_soon_threadsafe(_queue_tick, quote)
        except RuntimeError:
            return


async def tick_event_consumer():
    last_mover_check = 0.0
    while True:
        try:
            await asyncio.wait_for(tick_wakeup.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            pass
        if tick_wakeup.is_set():
            await asyncio.sleep(TICK_GUARD_COALESCE_SEC)
        batch = list(pending_ticks.values())
        pending_ticks.clear()
        tick_wakeup.clear()
        if batch:
            stream_event_stats["tick_batches"] += 1
        now = time.monotonic()
        held = {
            str(pos.get("symbol") or "").upper()
            for pos in orchestrator.portfolio.get_open_positions()
            if pos.get("symbol")
        }
        ticked_held = sorted({
            str(quote.get("symbol") or "").upper()
            for quote in batch
            if str(quote.get("symbol") or "").upper() in held
        })
        if ticked_held:
            loop = asyncio.get_running_loop()
            try:
                actions = await loop.run_in_executor(
                    None,
                    lambda: orchestrator.portfolio.update_and_monitor_positions(symbols=ticked_held),
                )
                stream_event_stats["position_guard_runs"] += 1
                for act in actions or []:
                    try:
                        orchestrator.tv_verifier.journal_exit(act)
                    except Exception:
                        pass
                    print(f"\n[RealAction] {act['symbol']} -> {act['action']} ({act['reason']})")
            except Exception as e:
                print(f"[TickGuard Error] {e}")
        if now - last_mover_check >= 1.0:
            last_mover_check = now
            try:
                movers = market_stream.movers(
                    TICK_SCAN_TRIGGER_PCT,
                    TICK_SCAN_WINDOW_SEC,
                    TICK_SCAN_COOLDOWN_SEC,
                )
            except Exception:
                movers = []
            mover_symbols = {
                str(key).split(":", 1)[-1].upper()
                for key in movers
                if str(key).split(":", 1)[-1]
            }
            event_symbols = mover_symbols.intersection(
                set(getattr(orchestrator, "_candidate_watchlist", {}))
            ).difference(held)
            if event_symbols:
                pending_trigger_symbols.update(event_symbols)
                stream_event_stats["event_scan_triggers"] += 1
                stream_event_stats["last_trigger_symbols"] = sorted(event_symbols)
                scan_wakeup.set()
POSITION_GUARD_INTERVAL_SEC = float(getattr(config, "POSITION_GUARD_INTERVAL_SEC", 1.0))


def _positions_without_fresh_ticks():
    stale = []
    for pos in orchestrator.portfolio.get_open_positions():
        symbol = pos.get("symbol")
        if not symbol:
            continue
        market = "FUTURES" if str(pos.get("market") or "").upper() in ("FUTURES", "SWAP") else "SPOT"
        if market_stream.quote(symbol, market) is None:
            stale.append(str(symbol).upper())
    return stale


async def high_frequency_position_guard():
    """REST fallback for held symbols that lack a fresh websocket tick."""
    await asyncio.sleep(2)
    print(f"\n[PositionWatchdog] Tick-driven position guard active ({POSITION_GUARD_INTERVAL_SEC}s base interval, stream-first).")
    while True:
        stale_symbols = _positions_without_fresh_ticks()
        if not stale_symbols:
            await asyncio.sleep(POSITION_GUARD_INTERVAL_SEC)
            continue
        try:
            loop = asyncio.get_running_loop()
            actions = await loop.run_in_executor(
                None,
                lambda: orchestrator.portfolio.update_and_monitor_positions(symbols=stale_symbols),
            )
            if actions:
                for act in actions:
                    try:
                        orchestrator.tv_verifier.journal_exit(act)
                    except Exception:
                        pass
                    print(f"\n[RealAction] Position Event: {act['symbol']} ➔ {act['action']} ({act['reason']}) PnL: ${act['pnl_usdt']}")
        except Exception as e:
            print(f"[PositionWatchdog Error] {e}")
        await asyncio.sleep(POSITION_GUARD_INTERVAL_SEC)


async def tv_verification_loop():
    """Sub-agent verification heartbeat: refresh TradingView snapshots for every
    open position and journal a POSITION_MONITORED trail entry (max 1/min/symbol)."""
    await asyncio.sleep(6)
    while True:
        try:
            positions = orchestrator.portfolio.get_open_positions()
            if positions:
                loop = asyncio.get_running_loop()
                symbols = [p.get("symbol") for p in positions if p.get("symbol")]
                snapshots = await loop.run_in_executor(
                    None, lambda: orchestrator.tv_verifier.snapshot(symbols, force=False)
                )
                for pos in positions:
                    try:
                        # Reuse the batched snapshot: one scanner request per
                        # heartbeat, not one per open position.
                        symbol = pos.get("symbol")
                        verification = orchestrator.tv_verifier.verify_entry(
                            symbol,
                            str(pos.get("direction") or "LONG"),
                            market="FUTURES" if str(pos.get("market")).upper() in ("FUTURES", "SWAP") else "SPOT",
                            snapshot_item=snapshots.get(symbol),
                        )
                        orchestrator.tv_verifier.journal_monitor(pos, verification=verification)
                    except Exception:
                        pass
        except Exception as exc:
            print(f"[TradingView Verifier] heartbeat skipped: {exc}")
        await asyncio.sleep(12)


async def candidate_discovery_loop():
    """Refresh the REST/cached universe without blocking tick-triggered analysis."""
    global discovery_status
    while True:
        try:
            loop = asyncio.get_running_loop()
            discovery_status = await loop.run_in_executor(
                None, orchestrator.refresh_candidate_watchlist
            )
            discovery_status["error"] = None
        except Exception as exc:
            discovery_status = {
                **discovery_status,
                "mode": "DEGRADED",
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "error": f"{type(exc).__name__}: {exc}",
            }
            print(f"[CandidateDiscovery Error] {exc}")
        await asyncio.sleep(max(5.0, float(AUTO_SCAN_INTERVAL_SEC)))


async def market_deliberation_loop():
    """Analyze one tick-triggered watchlist mover at a time."""
    global cycle_count, last_cycle_time, is_scanning, latest_scan_data
    print("\n[MarketEngine] Tick-triggered targeted AI analysis worker active.")
    while True:
        await scan_wakeup.wait()
        scan_wakeup.clear()
        if not pending_trigger_symbols:
            continue
        triggered = [sorted(pending_trigger_symbols)[0]]
        pending_trigger_symbols.discard(triggered[0])
        try:
            is_scanning = True
            loop = asyncio.get_running_loop()
            res = await loop.run_in_executor(
                None,
                lambda: orchestrator.run_cycle(
                    triggered_symbols=triggered or None,
                    monitor_positions=False,
                ),
            )
            cycle_count += 1
            latest_scan_data = res
            latest_scan_data["completed_at"] = datetime.now(timezone.utc).isoformat()
            latest_scan_data["last_updated"] = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
            last_cycle_time = latest_scan_data["completed_at"]
            if res.get("executed_trades"):
                for tr in res["executed_trades"]:
                    print(f"\n[RealAction] NEW ORDER EXECUTED: {tr['symbol']} @ ${tr['price']} | Size: ${tr['risk_plan']['position_usdt']}")
        except Exception as e:
            print(f"[MarketEngine Error] {e}")
        finally:
            is_scanning = False
        if pending_trigger_symbols:
            scan_wakeup.set()


ENABLE_BACKGROUND_LOOP = True


@asynccontextmanager
async def lifespan(app: FastAPI):
    _TICK_LOOP[0] = asyncio.get_running_loop()
    market_stream.add_listener(_tick_listener)
    task_ticks = asyncio.create_task(tick_event_consumer())
    task1 = asyncio.create_task(high_frequency_position_guard())
    task_tv = asyncio.create_task(tv_verification_loop())
    task_discovery = asyncio.create_task(candidate_discovery_loop())
    task2 = None
    if ENABLE_BACKGROUND_LOOP:
        task2 = asyncio.create_task(market_deliberation_loop())
    yield
    task1.cancel()
    task_ticks.cancel()
    task_tv.cancel()
    task_discovery.cancel()
    if task2:
        task2.cancel()


app = FastAPI(title=f"{config.EXCHANGE_LABEL} Institutional AI Multi-Agent Trading System", lifespan=lifespan)

# Serve PWA assets (manifest, service worker, icons) if present
STATIC_DIR = Path(__file__).resolve().parent / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/manifest.webmanifest")
async def pwa_manifest():
    f = STATIC_DIR / "manifest.webmanifest"
    if f.exists():
        return FileResponse(str(f), media_type="application/manifest+json")
    return JSONResponse({"detail": "manifest not found"}, status_code=404)


@app.get("/sw.js")
async def service_worker():
    f = STATIC_DIR / "sw.js"
    if f.exists():
        # Root scope is required for a service worker controlling "/"
        return FileResponse(
            str(f),
            media_type="application/javascript",
            headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"},
        )
    return JSONResponse({"detail": "service worker not found"}, status_code=404)


_macro_cache: Dict[str, Any] = {"at": 0.0, "value": {}}


def _cached_macro() -> Dict[str, Any]:
    """Before the first scan completes, /api/status used to call the BTC
    sentinel synchronously on EVERY 2s poll (blocking network I/O inside the
    event loop). Cache it for 30s and run it off the loop."""
    import time as _t
    if _t.time() - _macro_cache["at"] > 30 or not _macro_cache["value"]:
        try:
            _macro_cache["value"] = orchestrator.macro_sentinel.evaluate_macro_health()
        except Exception as exc:
            _macro_cache["value"] = {"regime": "FALLBACK_NORMAL", "rationale": f"Macro unavailable: {exc}"}
        _macro_cache["at"] = _t.time()
    return _macro_cache["value"]


def _compact_scan(scan: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(scan, dict):
        return scan
    out = dict(scan)
    rows = scan.get("candidates_evaluated")
    if isinstance(rows, list) and rows:
        compact = [rows[0]] if isinstance(rows[0], dict) else []
        for rec in rows[1:]:
            if not isinstance(rec, dict):
                continue
            compact.append({
                key: rec.get(key)
                for key in (
                    "symbol", "direction", "target_market", "price", "technical_score",
                    "gates_passed", "can_execute", "execution_note", "hard_gate_failures",
                    "safety_gate_failures", "strategy_gate_failures", "external_research_status",
                )
                if key in rec
            })
        out["candidates_evaluated"] = compact
    return out


@app.api_route("/api/status", methods=["GET", "HEAD"])
def get_status():
    # Sync on purpose: FastAPI runs it in a worker thread, so the blocking
    # price/equity HTTP calls below no longer stall the asyncio event loop.
    global latest_scan_data, cycle_count, is_scanning, last_cycle_time
    open_positions = orchestrator.portfolio.get_open_positions()
    equity = orchestrator.portfolio.get_equity()
    state = orchestrator.portfolio.state

    enriched_positions = []
    total_unrealized_pnl = 0.0
    allocated_margin = 0.0

    for pos in open_positions:
        sym = pos["symbol"]
        qty = pos["quantity"]
        entry_p = pos["entry_price"]
        cost_usdt = pos.get("position_usdt", 0.0)
        allocated_margin += cost_usdt

        is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")

        try:
            curr_p = orchestrator.client.get_price(sym, market=pos.get("market"))
            if is_short:
                pnl_usdt = (entry_p - curr_p) * qty
                pnl_pct = ((entry_p - curr_p) / entry_p) * 100.0
            else:
                pnl_usdt = (curr_p - entry_p) * qty
                pnl_pct = ((curr_p - entry_p) / entry_p) * 100.0
        except Exception:
            curr_p = entry_p
            pnl_usdt = 0.0
            pnl_pct = 0.0

        total_unrealized_pnl += pnl_usdt

        # Parse quote and base for clean display
        pair_disp = sym
        for q in ACCEPTED_QUOTE_ASSETS:
            if sym.endswith(q):
                pair_disp = f"{sym[:-len(q)]}/{q}"
                break

        p = dict(pos)
        p["current_price"] = curr_p
        p["pair_display"] = pair_disp
        p["unrealized_pnl_usdt"] = round(pnl_usdt, 4)
        p["unrealized_pnl_pct"] = round(pnl_pct, 2)
        p["pnl_usdt"] = p["unrealized_pnl_usdt"]
        p["pnl_pct"] = p["unrealized_pnl_pct"]
        p["opened_at"] = p.get("entry_time") or p.get("opened_at")
        p["stop_loss"] = p.get("stop_loss_price") or p.get("stop_loss")
        p["roundtrip_fee_usdt"] = round(cost_usdt * (EFFECTIVE_FEE_PCT / 100.0) * 2.0, 4)
        # Per-position TradingView verdict, served from the shared cache so a
        # 2s status poll never triggers a scanner round-trip. Without this the
        # dashboard's position rows had no verification block at all.
        try:
            p["tv_verification"] = orchestrator.tv_verifier.verify_entry(
                sym,
                "SHORT" if is_short else "LONG",
                market="FUTURES" if str(pos.get("market")).upper() in ("FUTURES", "SWAP") else "SPOT",
                allow_fetch=False,
                allow_local=False,
            )
        except Exception:
            p["tv_verification"] = {"status": "UNVERIFIED", "veto": False}
        enriched_positions.append(p)

    initial_cap = state.get("initial_capital", INITIAL_PAPER_BALANCE_USDT)
    realized_pnl = state.get("realized_pnl_usdt", 0.0)
    gross_realized_pnl = state.get("gross_realized_pnl_usdt", 0.0)
    total_fees_paid = state.get("total_fees_paid_usdt", 0.0)

    total_net_pnl = round(realized_pnl + total_unrealized_pnl, 4)
    total_net_pnl_pct = round(((equity - initial_cap) / initial_cap) * 100.0, 2)

    macro_info = latest_scan_data.get("macro_health")
    if not macro_info:
        macro_info = _cached_macro()

    # Load closed trades history
    trade_history = []
    all_events = []
    if config.TRADE_LOG_FILE.exists():
        try:
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                all_events = json.load(f)
                trade_history = all_events[-40:][::-1]
        except Exception:
            all_events = []
            trade_history = []

    closed = current_run_closed_events(all_events, state.get("total_trades"))
    outcomes = [event_outcome(e) for e in closed]
    wins = [e for e, o in zip(closed, outcomes) if o == "WIN"]
    losses = [e for e, o in zip(closed, outcomes) if o == "LOSS"]
    scratches = [e for e, o in zip(closed, outcomes) if o == "SCRATCH"]
    decided = len(wins) + len(losses)
    gross_win = sum(float(e.get("pnl_usdt", 0.0)) for e in wins)
    gross_loss = abs(sum(float(e.get("pnl_usdt", 0.0)) for e in losses))
    avg_win = (gross_win / len(wins)) if wins else 0.0
    avg_loss = (gross_loss / len(losses)) if losses else 0.0
    ledger_win_rate = (len(wins) / decided * 100.0) if decided else 0.0
    profit_factor = (gross_win / gross_loss) if gross_loss > 0 else (gross_win if gross_win > 0 else 0.0)
    # Expectancy per CLOSED trade including scratches = realised net / trades.
    expectancy = (sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in closed) / len(closed)) if closed else 0.0
    breakeven_win_rate = (avg_loss / (avg_win + avg_loss) * 100.0) if (avg_win + avg_loss) > 0 else 0.0

    exit_breakdown: Dict[str, int] = {}
    for e in closed:
        key = e.get("reason", "UNKNOWN")
        exit_breakdown[key] = exit_breakdown.get(key, 0) + 1

    # Rolling win rate over the last 20 completed trades (regime-sensitive)
    recent = [o for o in outcomes if o != "SCRATCH"][-20:]
    recent_wins = recent.count("WIN")
    rolling_win_rate = (recent_wins / len(recent) * 100.0) if recent else 0.0

    state_total = state.get("total_trades", 0)
    state_wins = state.get("winning_trades", 0)
    state_losses = state.get("losing_trades", 0)
    state_decided = state_wins + state_losses
    state_win_rate = (state_wins / state_decided * 100.0) if state_decided > 0 else 0.0

    loop_info = {
        "active": True,
        "cycle_count": cycle_count,
        "is_scanning": is_scanning,
        "interval_sec": AUTO_SCAN_INTERVAL_SEC,
        "last_cycle_time": last_cycle_time,
    }
    operations = build_market_operations(
        orchestrator.portfolio.mode,
        state.get("mode", TRADING_MODE),
        latest_scan_data,
        enriched_positions,
        macro_info,
        loop_info,
        getattr(orchestrator.client, "active_base_url", ""),
    )
    enriched_positions = [describe_market_record(row) for row in enriched_positions]
    # Attach the shared TradingView sub-agent snapshot to every open position so
    # the dashboard can show verification state without a second HTTP request.
    for row in enriched_positions:
        try:
            # This is the LAST writer for the field: it must emit the composed
            # verdict (status/veto/directional_score), not the raw scanner row
            # that `peek` returns. Cache-only: a 2s poll never hits the network.
            row["tv_verification"] = orchestrator.tv_verifier.verify_entry(
                row.get("symbol") or "",
                str(row.get("direction") or "LONG"),
                market="FUTURES" if str(row.get("market")).upper() in ("FUTURES", "SWAP") else "SPOT",
                allow_fetch=False,
                allow_local=False,
            )
        except Exception:
            row["tv_verification"] = {"status": "UNVERIFIED"}
    # Legacy CLOSED rows lack `direction`; recover it from the sibling TP1 event
    # of the same position (symbol + entry_time). Never guess LONG (PIT-031).
    pos_dir = {
        (e.get("symbol"), e.get("entry_time")): str(e.get("direction")).upper()
        for e in all_events if str(e.get("direction", "")).upper() in ("LONG", "SHORT")
    }
    trade_history = [
        describe_market_record(row, pos_dir.get((row.get("symbol"), row.get("entry_time"))))
        for row in trade_history
    ]
    for record, row in zip(trade_history, all_events[-40:][::-1] if all_events else []):
        pnl_value = row.get("pnl_usdt")
        if pnl_value is None:
            pnl_value = row.get("pnl", row.get("net_pnl"))
        record["pnl_usdt"] = pnl_value
        record["pnl"] = pnl_value
        record["net_pnl"] = pnl_value
        record["pnl_pct"] = row.get("pnl_pct", row.get("roi_pct"))
        record["closed_at"] = row.get("exit_time")
    open_trades = [
        {
            "symbol": row.get("symbol"),
            "direction": row.get("display_direction"),
            "market": row.get("display_market"),
            "leverage": row.get("leverage", 1.0),
            "entry_price": row.get("entry_price"),
            "current_price": row.get("current_price"),
            "pnl_usdt": row.get("unrealized_pnl_usdt"),
            "pnl_pct": row.get("unrealized_pnl_pct"),
            "opened_at": row.get("entry_time"),
            "stop_loss_price": row.get("stop_loss_price"),
            "take_profit_1": row.get("take_profit_1"),
        }
        for row in enriched_positions
    ]
    history_issues = []
    if int(state_total) != len(closed):
        history_issues.append(
            f"Ledger mencatat {int(state_total)} trade tertutup, log berisi {len(closed)} event CLOSED."
        )
    logged_pnl = sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in closed)
    if closed and abs(logged_pnl - float(realized_pnl or 0.0)) > 0.01:
        history_issues.append(
            f"PnL log {logged_pnl:.2f} USDT tidak sama dengan ledger {float(realized_pnl or 0.0):.2f} USDT."
        )
    reconciliation = state.get("cash_reconciliation") or {}
    if reconciliation.get("status") not in (None, "OK"):
        history_issues.append(
            f"Rekonsiliasi kas {reconciliation.get('status')} (delta {reconciliation.get('delta_usdt')} USDT)."
        )
    history_summary = {
        "open": len(enriched_positions),
        "closed": len(closed),
        "shown": len(trade_history),
        "wins": len(wins),
        "losses": len(losses),
        "scratches": len(scratches),
        "fees_usdt": round(float(total_fees_paid or 0.0), 4),
        "realized_usdt": round(float(realized_pnl or 0.0), 4),
        "unrealized_usdt": round(float(total_unrealized_pnl or 0.0), 4),
        "integrity": "OK" if not history_issues else "MISMATCH",
        "issues": history_issues,
        "log_file": config.TRADE_LOG_FILE.name,
        "log_rows": len(all_events),
    }

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "mode": operations["mode"],
        "market_stream": {
            **market_stream.stats(),
            "event_bus": dict(stream_event_stats),
            "candidate_discovery": dict(discovery_status),
        },
        "market_operations": operations,
        # Saldo Akun
        "initial_capital_usdt": round(initial_cap, 2),
        "equity_usdt": round(equity, 2),
        "cash_usdt": round(state.get("cash_usdt", 0.0), 2),
        "allocated_margin_usdt": round(allocated_margin, 2),
        "capacity_used": len(open_positions),
        "capacity_max": config.MAX_OPEN_POSITIONS,
        "capacity_unlimited": config.MAX_OPEN_POSITIONS <= 0,
        "correlation_unlimited": config.MAX_CORRELATED_POSITIONS <= 0,
        # Transaksi Fee & Profit Accounting
        "effective_fee_pct": EFFECTIVE_FEE_PCT,
        "total_fees_paid_usdt": round(total_fees_paid, 4),
        "gross_realized_pnl_usdt": round(gross_realized_pnl, 4),
        "realized_pnl_usdt": round(realized_pnl, 4),
        "open_partial_pnl_usdt": round(float(state.get("open_partial_pnl_usdt", 0.0) or 0.0), 4),
        "cash_reconciliation": state.get("cash_reconciliation", {}),
        "counter_since": state.get("counter_since"),
        "unrealized_pnl_usdt": round(total_unrealized_pnl, 4),
        "unrealized_pnl_pct": round((total_unrealized_pnl / max(1.0, allocated_margin)) * 100.0, 2) if allocated_margin > 0 else 0.0,
        "total_net_pnl_usdt": total_net_pnl,
        "total_net_pnl_pct": total_net_pnl_pct,
        "total_trades": state_total,
        "winning_trades": state_wins,
        "losing_trades": state_losses,
        "scratch_trades": state.get("scratch_trades", 0),
        "win_rate": round(state_win_rate, 1),
        # Win-rate quality analytics (target 70%)
        "win_rate_target": 70.0,
        "ledger_win_rate": round(ledger_win_rate, 1),
        "rolling_win_rate_20": round(rolling_win_rate, 1),
        "rolling_sample_size": len(recent),
        "ledger_closed_trades": len(closed),
        "ledger_wins": len(wins),
        "ledger_losses": len(losses),
        "ledger_scratches": len(scratches),
        "ledger_net_pnl_usdt": round(sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in closed), 4),
        "breakeven_win_rate": round(breakeven_win_rate, 1),
        "avg_win_usdt": round(avg_win, 4),
        "avg_loss_usdt": round(avg_loss, 4),
        "profit_factor": round(profit_factor, 2),
        "expectancy_usdt": round(expectancy, 4),
        "exit_reason_breakdown": exit_breakdown,
        "quality_gates": {
            "min_technical_score": config.MIN_TECHNICAL_SCORE,
            "min_conviction": config.ENHANCED_MIN_CONVICTION,
            "min_net_rr": config.MIN_RISK_REWARD_RATIO,
            "atr_stop_multiplier": config.ADAPTIVE_ATR_MULTIPLIER,
            "break_even_at_pct": config.EARLY_BREAK_EVEN_PCT,
            "tp1_exit_ratio": config.FASTER_TP1_RATIO,
            "trailing_trigger_pct": config.TRAILING_STOP_TRIGGER_PCT,
            "max_hold_hours": config.MAX_HOLD_HOURS_STAGNANT,
            "daily_loss_limit_pct": config.DAILY_LOSS_LIMIT_PCT,
            "volume_surge_min": config.VOLUME_SURGE_FILTER,
            "trend_efficiency_min": config.MIN_TREND_EFFICIENCY,
            "trend_efficiency_confluence_min": getattr(config, "MIN_TREND_EFFICIENCY_CONFLUENCE", config.MIN_TREND_EFFICIENCY),
            "max_correlated_same_direction": config.MAX_CORRELATED_POSITIONS,
            "max_position_size_pct": config.MAX_POSITION_SIZE_PCT,
            "scanner_top_limit": config.SCANNER_TOP_LIMIT,
        },
        "rejection_funnel": latest_scan_data.get("rejection_funnel", []),
        "gates_passed_count": latest_scan_data.get("gates_passed_count", 0),
        "scan_direction_filter": latest_scan_data.get("scan_direction_filter"),
        "adaptive_guard": latest_scan_data.get("adaptive_guard", {}),
        "daily_loss_limit_hit": latest_scan_data.get("daily_loss_limit_hit", False),
        # Detail Data & Multi-Pairing
        "accepted_quotes": ACCEPTED_QUOTE_ASSETS,
        "tv_verification": {
            **orchestrator.tv_verifier.health(),
            "open_positions": [
                {
                    "symbol": row.get("symbol"),
                    "direction": row.get("direction"),
                    **(row.get("tv_verification") or {}),
                }
                for row in enriched_positions
            ],
        },
        "open_positions": enriched_positions,
        "trade_history": trade_history,
        "open_trades": open_trades,
        "history_summary": history_summary,
        "equity_history": state.get("equity_history", []),
        "macro_health": macro_info,
        "ai_status": {
            k: v for k, v in orchestrator.llm.status_summary.items()
            if k not in ("base_url", "provider", "provider_type")
        },
        "periodic_performance": orchestrator.portfolio.get_periodic_performance(),
        "agent_consciousness": consciousness_engine.memory.get("divisions", {}),
        "total_mistakes_analyzed": consciousness_engine.memory.get("total_mistakes_analyzed", 0),
        "total_vetoes_prevented": consciousness_engine.memory.get("total_vetoes_prevented", 0),
        "total_upgrades_performed": consciousness_engine.memory.get("total_upgrades_performed", 0),
        "ai_intelligence_level": consciousness_engine.memory.get("ai_intelligence_level", "2.2.0-ULTRA"),
        "last_upgrade_mode": consciousness_engine.memory.get("last_upgrade_mode", "DETERMINISTIC"),
        "last_upgrade": consciousness_engine.memory.get("last_upgrade", {}),
        "machine_rule_count": sum(
            1
            for _div in consciousness_engine.memory.get("divisions", {}).values()
            if isinstance(_div, dict)
            for _rule in (_div.get("lessons_learned", []) or [])
            if isinstance(_rule, dict) and _rule.get("machine_check")
        ),
        "latest_scan": _compact_scan(latest_scan_data),
        "autonomous_loop": loop_info
    }


CHART_INTERVALS = ("1m", "5m", "15m", "30m", "1h", "4h", "1d")
CHART_CACHE: Dict[str, Any] = {}
CHART_CACHE_TTL_SEC = 15.0


def _chart_payload(symbol: str, market_name: str, interval: str, limit: int) -> Dict[str, Any]:
    raw = orchestrator.client.get_klines(symbol, interval=interval, limit=limit, market=market_name)
    candles = []
    for row in raw:
        try:
            candles.append({
                "t": int(row["open_time"]),
                "o": float(row["open"]),
                "h": float(row["high"]),
                "l": float(row["low"]),
                "c": float(row["close"]),
                "v": float(row.get("volume") or 0.0),
                "closed": bool(row.get("is_closed", True)),
            })
        except (KeyError, TypeError, ValueError):
            continue
    last = candles[-1]["c"] if candles else 0.0
    first = candles[0]["o"] if candles else 0.0
    return {
        "symbol": symbol,
        "market": market_name,
        "interval": interval,
        "exchange": config.EXCHANGE_LABEL,
        "dns_route": getattr(orchestrator.client, "dns_route_label", lambda: None)() or (
            "DOH" if config.DOH_ROUTING_ENABLED else "SYSTEM"
        ),
        "last": last,
        "change_pct": round((last - first) / first * 100.0, 2) if first > 0 else 0.0,
        "candles": candles,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/market/chart")
async def market_chart(symbol: str = "", market: str = "", interval: str = "15m", limit: int = 120):
    name = re.sub(r"[^A-Z0-9]", "", str(symbol or "").upper())[:20]
    if len(name) < 5:
        return JSONResponse({"error": "symbol required", "candles": []}, status_code=400)
    market_name = "FUTURES" if str(market or "").upper() in ("FUTURES", "SWAP") else "SPOT"
    bar = str(interval or "15m").lower()
    if bar not in CHART_INTERVALS:
        bar = "15m"
    try:
        count = max(30, min(200, int(limit or 120)))
    except (TypeError, ValueError):
        count = 120
    key = f"{name}:{market_name}:{bar}:{count}"
    now = time.time()
    cached = CHART_CACHE.get(key)
    if cached and cached[0] > now:
        return JSONResponse(cached[1])
    loop = asyncio.get_running_loop()
    try:
        payload = await loop.run_in_executor(None, lambda: _chart_payload(name, market_name, bar, count))
    except Exception as exc:
        return JSONResponse(
            {"error": f"market feed unavailable: {type(exc).__name__}", "symbol": name, "market": market_name, "candles": []},
            status_code=503,
        )
    CHART_CACHE[key] = (now + CHART_CACHE_TTL_SEC, payload)
    return JSONResponse(payload)


# ---------------------------------------------------------------- position tape
POSITION_CHART_CACHE: Dict[str, Any] = {}
POSITION_CHART_CACHE_TTL_SEC = 8.0


def _position_levels(pos: Dict[str, Any], price: float) -> Dict[str, Any]:
    """Live risk/verification facts for one open position (no I/O)."""
    entry = float(pos.get("entry_price") or 0.0)
    qty = float(pos.get("quantity") or 0.0)
    direction = "SHORT" if (pos.get("direction") == "SHORT" or pos.get("side") == "SELL") else "LONG"
    sign = 1.0 if direction == "LONG" else -1.0
    pnl = (price - entry) * qty * sign if entry > 0 and price > 0 else 0.0
    pnl_pct = ((price - entry) / entry * 100.0 * sign) if entry > 0 and price > 0 else 0.0
    stop = float(pos.get("trailing_stop_price") or pos.get("stop_loss_price") or 0.0)
    tp1 = float(pos.get("take_profit_1") or 0.0)
    tp2 = float(pos.get("take_profit_2") or 0.0)
    return {
        "symbol": pos.get("symbol"),
        "direction": direction,
        "market": pos.get("market"),
        "quantity": qty,
        "entry_price": entry,
        "current_price": price,
        "unrealized_pnl_usdt": round(pnl, 4),
        "unrealized_pnl_pct": round(pnl_pct, 2),
        "stop_loss_price": stop,
        "take_profit_1": tp1,
        "take_profit_2": tp2,
        "tp1_hit": bool(pos.get("tp1_hit")),
        "trailing_active": bool(pos.get("trailing_active")),
        "break_even_active": bool(pos.get("break_even_active")),
        "opened_at": pos.get("entry_time"),
        "holding_minutes": pos.get("holding_minutes"),
        "distance_to_stop_pct": round(abs(price - stop) / price * 100.0, 2) if price > 0 and stop > 0 else None,
        "distance_to_tp1_pct": round(abs(tp1 - price) / price * 100.0, 2) if price > 0 and tp1 > 0 else None,
    }


def _position_prices(positions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for pos in positions:
        symbol = pos.get("symbol")
        try:
            price = float(orchestrator.client.get_price(symbol, market=pos.get("market")))
        except Exception:
            price = float(pos.get("current_price") or pos.get("entry_price") or 0.0)
        rows.append(_position_levels(pos, price))
    return rows


def _position_chart_payload(interval: str = "1m", limit: int = 90) -> Dict[str, Any]:
    from concurrent.futures import ThreadPoolExecutor

    positions = orchestrator.portfolio.get_open_positions()
    symbols = [p.get("symbol") for p in positions if p.get("symbol")]
    tv_map = orchestrator.tv_verifier.snapshot(symbols) if symbols else {}
    key = f"{interval}:{limit}:{','.join(sorted(symbols))}"
    now = time.time()
    cached = POSITION_CHART_CACHE.get(key)
    if cached and cached[0] > now:
        return cached[1]

    def fetch(pos: Dict[str, Any]):
        symbol = pos.get("symbol")
        try:
            candles = _chart_payload(symbol, "FUTURES" if str(pos.get("market")).upper() in ("FUTURES", "SWAP") else "SPOT", interval, limit).get("candles", [])
        except Exception as exc:
            candles = []
            print(f"[PositionChart] {symbol} candle fetch failed: {exc}")
        return symbol, candles

    candle_map: Dict[str, List[Dict[str, Any]]] = {}
    if positions:
        with ThreadPoolExecutor(max_workers=min(4, len(positions))) as pool:
            for symbol, candles in pool.map(fetch, positions):
                candle_map[symbol] = candles

    rows = []
    for pos in positions:
        symbol = pos.get("symbol")
        price = float(candle_map.get(symbol, [{}])[-1].get("c") or pos.get("entry_price") or 0.0) if candle_map.get(symbol) else float(pos.get("entry_price") or 0.0)
        row = _position_levels(pos, price)
        row["candles"] = candle_map.get(symbol, [])
        row["tv"] = tv_map.get(symbol) or orchestrator.tv_verifier.peek(symbol)
        try:
            verification = orchestrator.tv_verifier.verify_entry(
                symbol, row.get("direction") or "LONG",
                market="FUTURES" if str(row.get("market")).upper() in ("FUTURES", "SWAP") else "SPOT",
                snapshot_item=tv_map.get(symbol),
            )
        except Exception:
            verification = {"status": "UNVERIFIED", "local": None}
        row["verification"] = verification
        row["local"] = verification.get("local")
        row["trail"] = orchestrator.tv_verifier.trail(symbol, limit=6)
        rows.append(row)
    payload = {
        "type": "charts",
        "ts": datetime.now(timezone.utc).isoformat(),
        "interval": interval,
        "exchange": config.EXCHANGE_LABEL,
        "tv_health": orchestrator.tv_verifier.health(),
        "positions": rows,
    }
    POSITION_CHART_CACHE[key] = (now + POSITION_CHART_CACHE_TTL_SEC, payload)
    return payload


@app.get("/api/positions/charts")
async def position_charts(interval: str = "1m", limit: int = 90):
    bar = str(interval or "1m").lower()
    if bar not in ("1m", "3m", "5m", "15m", "1h"):
        bar = "1m"
    try:
        count = max(40, min(160, int(limit or 90)))
    except (TypeError, ValueError):
        count = 90
    loop = asyncio.get_running_loop()
    try:
        payload = await loop.run_in_executor(None, _position_chart_payload, bar, count)
        return JSONResponse(payload)
    except Exception as exc:
        return JSONResponse({"error": f"position charts unavailable: {type(exc).__name__}", "positions": []}, status_code=503)


@app.get("/api/tv/status")
def tv_status():
    symbols = [p.get("symbol") for p in orchestrator.portfolio.get_open_positions() if p.get("symbol")]
    snapshots = orchestrator.tv_verifier.snapshot(symbols) if symbols else {}
    return JSONResponse(
        {
            "health": orchestrator.tv_verifier.health(),
            "open_position_verification": [
                {
                    "symbol": symbol,
                    "bias": item.get("bias"),
                    "score": item.get("score"),
                    "aligned": item.get("aligned"),
                    "price": item.get("price"),
                    "age_sec": item.get("age_sec"),
                    "stale": item.get("stale"),
                    "timeframes": item.get("timeframes"),
                }
                for symbol, item in snapshots.items()
            ],
        }
    )


@app.get("/api/tv/trail")
def tv_trail(symbol: str = "", limit: int = 20):
    try:
        count = max(1, min(100, int(limit or 20)))
    except (TypeError, ValueError):
        count = 20
    return JSONResponse({"events": orchestrator.tv_verifier.trail(symbol or None, limit=count)})


@app.websocket("/ws/positions")
async def ws_positions(ws: WebSocket):
    """1 Hz live tape for every open position: price, PnL, TV verification and
    candle refresh every 30 s. Falls back to the REST chart endpoint client-side."""
    await ws.accept()
    last_symbols: tuple = ()
    last_charts = 0.0
    await ws.send_json({"type": "hello", "ts": datetime.now(timezone.utc).isoformat(), "interval_sec": 1})
    try:
        while True:
            positions = orchestrator.portfolio.get_open_positions()
            symbols = tuple(sorted({p.get("symbol") for p in positions if p.get("symbol")}))
            loop = asyncio.get_running_loop()
            if not symbols:
                await ws.send_json({"type": "empty", "ts": datetime.now(timezone.utc).isoformat(), "positions": []})
                last_symbols = ()
                await asyncio.sleep(1.5)
                continue
            now = time.time()
            if symbols != last_symbols or (now - last_charts) > 30:
                charts = await loop.run_in_executor(None, _position_chart_payload, "1m", 90)
                await ws.send_json(charts)
                last_symbols = symbols
                last_charts = now
            rows = await loop.run_in_executor(None, _position_prices, positions)
            for row in rows:
                row["tv"] = orchestrator.tv_verifier.peek(row.get("symbol") or "")
            await ws.send_json(
                {
                    "type": "tick",
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "exchange": config.EXCHANGE_LABEL,
                    "positions": rows,
                }
            )
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        return
    except Exception as exc:
        try:
            await ws.close(code=1011)
        except Exception:
            pass
        print(f"[PositionSocket] closed: {type(exc).__name__}: {exc}")


@app.api_route("/api/health", methods=["GET", "HEAD"])
async def health_check():
    """Liveness probe for the autonomous engine (read-only)."""
    return {
        "status": "ok",
        "mode": orchestrator.portfolio.mode,
        "cycle_count": cycle_count,
        "is_scanning": is_scanning,
        "last_cycle_time": last_cycle_time
    }


@app.get("/api/review")
def trade_review():
    from trade_reviewer import TradeReviewer

    try:
        return JSONResponse(TradeReviewer().review(persist=False))
    except Exception as exc:
        return JSONResponse({"error": f"review unavailable: {type(exc).__name__}"}, status_code=503)


def _approval_authorised(request: Request) -> bool:
    token = os.getenv("APPROVAL_API_TOKEN", "").strip()
    if token:
        return request.query_params.get("token", "") == token
    host = getattr(getattr(request, "client", None), "host", "") or ""
    return host in ("127.0.0.1", "::1", "localhost")


@app.get("/api/approvals")
def approvals_list(limit: int = 50):
    from approval_queue import approval_queue

    try:
        count = max(1, min(200, int(limit or 50)))
    except (TypeError, ValueError):
        count = 50
    try:
        return JSONResponse({"pending": approval_queue.pending(), "history": approval_queue.history(count)})
    except Exception as exc:
        return JSONResponse({"error": f"approval queue unavailable: {type(exc).__name__}"}, status_code=503)


@app.post("/api/approvals/{ticket_id}/approve")
def approvals_approve(ticket_id: str, request: Request, by: str = "operator", note: str = ""):
    if not _approval_authorised(request):
        return JSONResponse({"ok": False, "error": "not authorised"}, status_code=403)
    from approval_queue import approval_queue

    ok, ticket = approval_queue.decide(ticket_id, True, by, note)
    payload = {"ok": ok, "ticket": ticket}
    if ok and orchestrator.portfolio.mode == "live":
        payload["execution"] = orchestrator.execute_approved_ticket(ticket_id)
    return JSONResponse(payload)


@app.post("/api/approvals/{ticket_id}/reject")
def approvals_reject(ticket_id: str, request: Request, by: str = "operator", note: str = ""):
    if not _approval_authorised(request):
        return JSONResponse({"ok": False, "error": "not authorised"}, status_code=403)
    from approval_queue import approval_queue

    ok, ticket = approval_queue.decide(ticket_id, False, by, note)
    return JSONResponse({"ok": ok, "ticket": ticket})


@app.get("/api/brief")
def daily_brief_report():
    from daily_brief import DailyBrief

    try:
        return JSONResponse(DailyBrief().build(persist=False))
    except Exception as exc:
        return JSONResponse({"error": f"brief unavailable: {type(exc).__name__}"}, status_code=503)


@app.get("/api/playbooks")
def playbooks_report():
    from playbook_library import PlaybookLibrary

    try:
        return JSONResponse(PlaybookLibrary().build())
    except Exception as exc:
        return JSONResponse({"error": f"playbooks unavailable: {type(exc).__name__}"}, status_code=503)


@app.api_route("/", methods=["GET", "HEAD"], response_class=HTMLResponse)
async def dashboard_page():
    if TEMPLATE_FILE.exists():
        with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>Dashboard Template not found</h1>", status_code=500)


def start_server():
    print(f"\n[Dashboard] Starting {config.EXCHANGE_LABEL} AI Real-time Surveillance on http://{WEB_HOST}:{WEB_PORT}")
    uvicorn.run(app, host=WEB_HOST, port=WEB_PORT, log_level="warning")


if __name__ == "__main__":
    start_server()
