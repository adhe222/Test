(function () {
  'use strict';

  const U = window.AegisUtil;
  const POLL_MS = 3000;
  const THEME_KEY = 'aegis-theme';

  const state = {
    timer: 0,
    inflight: null,
    lastData: null,
    failures: 0,
    chartSymbol: '',
    chartMarket: 'SPOT',
    chartInterval: '15m',
    chartTimer: 0,
    chartBusy: false
  };

  const setConnection = (mode, text) => {
    const pill = document.getElementById('connection');
    const label = document.getElementById('connectionText');
    if (pill) {
      pill.className = `connection-pill ${mode === 'ok' ? 'connected' : mode === 'warn' ? 'reconnecting' : ''}`.trim();
    }
    if (label) label.textContent = text;
  };

  const applyTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem(THEME_KEY, theme); } catch (err) { void err; }
    if (window.AegisUniverse) window.AegisUniverse.setTheme(theme);
    if (window.AegisChart) window.AegisChart.redraw();
    if (window.AegisPipeline && state.lastData) window.AegisPipeline.render(state.lastData);
  };

  const initTheme = () => {
    let theme = document.documentElement.getAttribute('data-theme');
    if (!theme) {
      try { theme = localStorage.getItem(THEME_KEY); } catch (err) { theme = null; }
    }
    if (!theme) {
      theme = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    }
    document.documentElement.setAttribute('data-theme', theme);
    if (window.AegisUniverse) window.AegisUniverse.setTheme(theme);
    const toggle = document.getElementById('themeToggle');
    if (toggle) {
      toggle.addEventListener('click', () => {
        const next = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
        applyTheme(next);
      });
    }
  };

  const activateTab = (name, options) => {
    const opts = options || {};
    const tabs = U.$$('.tab');
    tabs.forEach((tab) => {
      const active = tab.dataset.tab === name;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
      tab.tabIndex = active ? 0 : -1;
    });
    U.$$('.view').forEach((view) => {
      view.classList.toggle('active', view.id === `view-${name}`);
    });
    if (!opts.silent) {
      try { history.replaceState(null, '', `#${name}`); } catch (err) { void err; }
    }
    if (name === 'agents' && window.AegisPipeline && state.lastData) {
      window.AegisPipeline.render(state.lastData);
    }
    if (name === 'summary' && window.AegisChart) {
      requestAnimationFrame(() => window.AegisChart.redraw());
    }
    const panel = document.getElementById(`view-${name}`);
    if (panel && opts.focus) {
      panel.setAttribute('tabindex', '-1');
      panel.focus({ preventScroll: true });
    }
  };

  const initTabs = () => {
    const tabs = U.$$('.tab');
    tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => activateTab(tab.dataset.tab));
      tab.addEventListener('keydown', (event) => {
        const keys = { ArrowRight: index + 1, ArrowLeft: index - 1, Home: 0, End: tabs.length - 1 };
        if (!(event.key in keys)) return;
        event.preventDefault();
        const target = tabs[(keys[event.key] + tabs.length) % tabs.length];
        if (target) {
          target.focus();
          activateTab(target.dataset.tab);
        }
      });
    });
    const initial = (location.hash || '#summary').replace('#', '');
    const valid = tabs.some((t) => t.dataset.tab === initial);
    activateTab(valid ? initial : 'summary', { silent: true });
    window.addEventListener('hashchange', () => {
      const name = (location.hash || '#summary').replace('#', '');
      if (tabs.some((t) => t.dataset.tab === name)) activateTab(name, { silent: true });
    });
  };

  const renderAll = (data) => {
    state.lastData = data;
    window.__aegisLastStatus = data;
    window.AegisViews.header(data);
    window.AegisViews.overview(data);
    window.AegisViews.macro(data);
    window.AegisViews.positions(data);
    window.AegisOperations.render(data);
    window.AegisViews2.agents(data);
    window.AegisViews2.history(data);
    window.AegisViews2.footer(data);
    window.AegisChart.render(data);
    if (document.getElementById('view-agents').classList.contains('active')) {
      window.AegisPipeline.render(data);
    }
    syncChartSymbols(data);
  };

  const candidateSymbols = (data) => {
    const out = [];
    const push = (symbol, market) => {
      const name = String(symbol || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (name.length < 5 || out.some((c) => c.symbol === name)) return;
      out.push({ symbol: name, market: String(market || 'SPOT').toUpperCase() });
    };
    (Array.isArray(data.open_positions) ? data.open_positions : []).forEach((p) => push(p && p.symbol, p && p.market));
    const ops = data.market_operations || {};
    (Array.isArray(ops.candidates) ? ops.candidates : []).forEach((c) => push(c && c.symbol, c && c.market));
    (Array.isArray(data.top_movers) ? data.top_movers : []).forEach((m) => push(m && m.symbol, m && m.market));
    (Array.isArray(data.accepted_quotes) ? data.accepted_quotes : []).forEach((q) => push(typeof q === 'string' ? q : q && q.symbol, 'SPOT'));
    return out;
  };

  const syncChartSymbols = (data) => {
    const list = candidateSymbols(data);
    if (!list.length) list.push({ symbol: 'BTCUSDT', market: 'SPOT' });
    const wrap = document.getElementById('chartSymbols');
    if (!wrap) return;
    const signature = list.map((c) => `${c.symbol}:${c.market}`).join(',');
    if (wrap.dataset.signature !== signature) {
      wrap.dataset.signature = signature;
      wrap.innerHTML = list.slice(0, 6).map((c) => `<button class="chip" type="button" data-symbol="${U.esc(c.symbol)}" `
        + `data-market="${U.esc(c.market)}" aria-pressed="false">${U.esc(c.symbol)}</button>`).join('');
      wrap.querySelectorAll('.chip').forEach((chip) => {
        chip.addEventListener('click', () => {
          state.chartSymbol = chip.dataset.symbol;
          state.chartMarket = chip.dataset.market;
          markActiveChip();
          loadChart();
        });
      });
    }
    if (!state.chartSymbol || !list.some((c) => c.symbol === state.chartSymbol)) {
      state.chartSymbol = list[0].symbol;
      state.chartMarket = list[0].market;
    }
    markActiveChip();
    loadChart();
  };

  const markActiveChip = () => {
    U.$$('#chartSymbols .chip').forEach((chip) => {
      chip.setAttribute('aria-pressed', chip.dataset.symbol === state.chartSymbol ? 'true' : 'false');
    });
    U.$$('#chartIntervals .chip').forEach((chip) => {
      chip.setAttribute('aria-pressed', chip.dataset.interval === state.chartInterval ? 'true' : 'false');
    });
  };

  const loadChart = () => {
    if (!state.chartSymbol || state.chartBusy) return;
    state.chartBusy = true;
    clearTimeout(state.chartTimer);
    const url = `/api/market/chart?symbol=${encodeURIComponent(state.chartSymbol)}`
      + `&market=${encodeURIComponent(state.chartMarket)}&interval=${encodeURIComponent(state.chartInterval)}&limit=120`;
    fetch(url, { headers: { Accept: 'application/json' } })
      .then((res) => res.json().then((body) => ({ ok: res.ok, status: res.status, body })))
      .then(({ ok, status, body }) => {
        const payload = body && typeof body === 'object' ? body : {};
        if (!ok || !Array.isArray(payload.candles) || !payload.candles.length) {
          window.AegisChart.market({
            symbol: state.chartSymbol,
            market: state.chartMarket,
            interval: state.chartInterval,
            candles: [],
            error: payload.error || `Feed pasar belum tersedia (HTTP ${status}).`
          });
          state.chartTimer = setTimeout(loadChart, 12000);
          return;
        }
        window.AegisChart.market(payload);
        state.chartTimer = setTimeout(loadChart, 20000);
      })
      .catch(() => {
        window.AegisChart.market({
          symbol: state.chartSymbol,
          market: state.chartMarket,
          interval: state.chartInterval,
          candles: [],
          error: 'Koneksi feed pasar terputus. Mencoba ulang otomatis.'
        });
        state.chartTimer = setTimeout(loadChart, 15000);
      })
      .finally(() => {
        state.chartBusy = false;
      });
  };

  const initChartControls = () => {
    U.$$('#chartIntervals .chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        state.chartInterval = chip.dataset.interval || '15m';
        markActiveChip();
        loadChart();
      });
    });
    markActiveChip();
  };

  const poll = () => {
    if (state.inflight) state.inflight.abort();
    const controller = new AbortController();
    state.inflight = controller;
    fetch('/api/status', { headers: { Accept: 'application/json' }, signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      })
      .then((data) => {
        state.failures = 0;
        setConnection('ok', 'Live');
        renderAll(data && typeof data === 'object' ? data : {});
      })
      .catch((err) => {
        if (err && err.name === 'AbortError') return;
        state.failures += 1;
        window.AegisOperations.stale(true);
        setConnection(state.failures > 2 ? 'bad' : 'warn', state.failures > 2 ? 'Offline' : 'Menyambung');
      })
      .finally(() => {
        state.inflight = null;
      });
  };

  const startPolling = () => {
    clearInterval(state.timer);
    poll();
    state.timer = setInterval(poll, POLL_MS);
  };

  const init = () => {
    initTheme();
    initTabs();
    initChartControls();
    const refresh = document.getElementById('refreshBtn');
    if (refresh) {
      refresh.addEventListener('click', () => {
        refresh.disabled = true;
        poll();
        loadChart();
        setTimeout(() => { refresh.disabled = false; }, 900);
      });
    }
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        clearInterval(state.timer);
        state.timer = 0;
      } else if (!state.timer) {
        startPolling();
      }
    });
    startPolling();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
