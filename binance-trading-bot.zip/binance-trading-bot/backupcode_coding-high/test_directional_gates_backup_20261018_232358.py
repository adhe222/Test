import unittest

from agents.momentum import MomentumAnalystAgent


def closed_candles(direction, count):
    sign = -1 if direction == "SHORT" else 1
    changes = (0.20, 0.18, -0.25, 0.16, -0.12, 0.14)
    price = 100.0
    rows = []
    for index in range(count):
        opened = price
        price += sign * changes[index % len(changes)]
        rows.append({
            "open": opened,
            "high": max(opened, price) + 0.06,
            "low": min(opened, price) - 0.06,
            "close": price,
            "volume": 2000.0 if index >= count - 3 else 1000.0,
            "close_time": 1000 + index,
        })
    return rows


class CandleFixtureClient:
    def __init__(self, direction):
        self.feeds = {
            "15m": closed_candles(direction, 96),
            "1h": closed_candles(direction, 60),
            "4h": closed_candles(direction, 36),
            "5m": closed_candles(direction, 6),
        }

    def get_klines(self, symbol, interval="15m", limit=100):
        return self.feeds[interval][-limit:]

    def get_funding_rate(self, symbol):
        return None


class TestDirectionalMomentum(unittest.TestCase):
    def test_bearish_short_passes_closed_bar_confirmation(self):
        result = MomentumAnalystAgent(CandleFixtureClient("SHORT")).analyze_symbol(
            "FIXTUREUSDT", direction="SHORT"
        )
        self.assertTrue(result["passed"], result["gate_failures"])
        self.assertTrue(result["htf_bearish"])
        self.assertEqual(result["htf_score"], 16)
        self.assertEqual(result["gate_failures"], [])
