import json
import logging
from typing import Dict, Any, Optional, Callable
import requests

from config import OPENAI_API_KEY, OPENAI_BASE_URL, OPENAI_MODEL, LLM_TEMPERATURE

logger = logging.getLogger("AIEngine")


class LLMClient:
    """
    OpenAI, Clouvia Router, and Custom Endpoint Compatible LLM Engine.
    Compatible with Clouvia (https://router.clouvia.id/v1), OpenAI, DeepSeek, Ollama, vLLM, etc.
    Follows each specialist agent's institutional system prompt.
    Provides automatic graceful fallback to algorithmic heuristic intelligence
    if no API key is provided, if key is invalid, or if the endpoint is temporarily unavailable.
    """

    def __init__(
        self,
        api_key: str = OPENAI_API_KEY,
        base_url: str = OPENAI_BASE_URL,
        model: str = OPENAI_MODEL,
        temperature: float = LLM_TEMPERATURE
    ):
        self.api_key = (api_key or "").strip()
        self.base_url = (base_url or "https://router.clouvia.id/v1").rstrip("/")
        self.model = model or "coding-high"
        self.temperature = temperature
        self.is_clouvia = "clouvia.id" in self.base_url
        self.is_custom_endpoint = bool(self.base_url and "api.openai.com" not in self.base_url)
        self.has_key = bool(self.api_key)
        self._last_error_time = 0.0
        self._circuit_open_duration = 30.0  # seconds to wait before probing LLM endpoint again on failure

    @property
    def status_summary(self) -> Dict[str, Any]:
        provider_name = "Clouvia Router" if self.is_clouvia else ("Custom Endpoint" if self.is_custom_endpoint else ("OpenAI" if self.has_key else "Heuristic Engine"))
        return {
            "model": self.model,
            "base_url": self.base_url,
            "is_clouvia": self.is_clouvia,
            "is_custom": self.is_custom_endpoint,
            "configured": self.has_key,
            "provider_type": provider_name,
            "temperature": self.temperature
        }

    def query_specialist(
        self,
        specialist_role: str,
        system_instruction: str,
        context_data: Dict[str, Any],
        fallback_fn: Callable[[Dict[str, Any]], Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Executes query to the specialist AI agent matching its specific institutional system prompt.
        If API endpoint is unavailable or returns an error, falls back seamlessly to fallback_fn.
        """
        # If no key set, use heuristic directly
        if not self.has_key:
            result = fallback_fn(context_data)
            result["engine"] = f"Heuristic Engine ({specialist_role})"
            return result

        import time
        now = time.time()
        # Fast-fail if recent network/API error occurred within circuit open window
        if now - self._last_error_time < self._circuit_open_duration:
            result = fallback_fn(context_data)
            result["engine"] = f"Heuristic Engine ({specialist_role})"
            return result

        # Construct persona-based system prompt following the specialist agent mandate
        system_prompt = (
            f"Kamu adalah Institutional Specialist untuk {specialist_role} pada quantitative crypto trading bot di Binance Spot.\n"
            f"Mandat Tugas: {system_instruction.strip()}\n\n"
            "Format Instruksi:\n"
            "Berikan analisis yang ringkas, objektif, dan solutif.\n"
            "Kamu WAJIB menjawab HANYA dalam format JSON valid tanpa teks pengantar, dengan struktur keys:\n"
            "{\n"
            '  "verdict": "APPROVE" atau "REJECT",\n'
            '  "conviction": integer 0-100,\n'
            '  "rationale": "ringkasan analisis teknikal solutif maksimal 2-3 kalimat",\n'
            '  "signal": "label sinyal utama singkat (e.g. Volume Expansion, Overbought Veto)"\n'
            "}"
        )

        user_content = (
            f"Analisis data real-time Binance berikut untuk aset {context_data.get('symbol', '')}:\n"
            f"{json.dumps(context_data, indent=2, default=str)}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content}
        ]

        endpoint = f"{self.base_url}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": "OpenAI/Python 1.50.0"
        }

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": 350
        }

        try:
            resp = requests.post(endpoint, json=payload, headers=headers, timeout=(1.5, 2.5))
            if resp.status_code == 200:
                data = resp.json()
                content = data["choices"][0]["message"]["content"].strip()
                # Strip markdown code blocks if any
                if content.startswith("```json"):
                    content = content[7:]
                if content.startswith("```"):
                    content = content[3:]
                if content.endswith("```"):
                    content = content[:-3]
                parsed = json.loads(content.strip())
                parsed["engine"] = f"{self.model} ({self.status_summary['provider_type']})"
                return parsed
            else:
                self._last_error_time = time.time()
                logger.warning(f"LLM API returned status {resp.status_code}: {resp.text[:120]}")
        except Exception as e:
            self._last_error_time = time.time()
            logger.warning(f"LLM endpoint call error ({e}), switching to Heuristic Specialist engine.")

        # Seamless Fallback to Deterministic Quant Engine
        result = fallback_fn(context_data)
        result["engine"] = f"Heuristic Fallback ({specialist_role})"
        return result
