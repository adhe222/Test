/* Aegis Telemetry — app shell service worker.
 *
 * Caching policy (deliberate):
 *   - App shell (document, icons, manifest) -> stale-while-revalidate.
 *   - /api/*  -> ALWAYS network, NEVER cached and NEVER served from cache.
 *     Telemetry must never be stale; the UI keeps its own last-good copy in memory.
 */
const VERSION = 'aegis-shell-v4';
const SHELL = [
  '/',
  '/manifest.webmanifest',
  '/static/css/base.css',
  '/static/css/components.css',
  '/static/css/pipeline.css',
  '/static/css/responsive.css',
  '/static/js/util.js',
  '/static/js/pipeline.js',
  '/static/js/views.js',
  '/static/js/views2.js',
  '/static/js/chart.js',
  '/static/js/app.js',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png',
  '/static/icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(VERSION)
      .then((cache) => cache.addAll(SHELL).catch(() => undefined))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Hard bypass: live telemetry is never cached.
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(req));
    return;
  }

  event.respondWith(staleWhileRevalidate(req));
});

async function staleWhileRevalidate(req) {
  const cache = await caches.open(VERSION);
  const cached = await cache.match(req);

  const network = fetch(req)
    .then((res) => {
      if (res && res.ok && res.type !== 'opaque') cache.put(req, res.clone()).catch(() => undefined);
      return res;
    })
    .catch(() => undefined);

  if (cached) {
    network.catch(() => undefined);
    return cached;
  }

  const fresh = await network;
  if (fresh) return fresh;

  // Offline and nothing cached: fall back to the shell document for navigations.
  if (req.mode === 'navigate') {
    const shell = await cache.match('/');
    if (shell) return shell;
  }
  return new Response('Offline', { status: 503, statusText: 'Offline', headers: { 'Content-Type': 'text/plain' } });
}
