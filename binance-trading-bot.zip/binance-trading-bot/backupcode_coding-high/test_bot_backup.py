import unittest
from unittest.mock import MagicMock

from indicators import (
    calculate_ema,
    calculate_rsi,
    calculate_atr,
    calculate_volume_surge,
    calculate_candle_metrics
)
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent
from agents.macro_sentinel import MacroMarketSentinel
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)


class TestIndicators(unittest.TestCase):
    def test_ema(self):
        prices = [10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0]
        ema = calculate_ema(prices, 5)
        self.assertGreater(len(ema), 0)
        self.assertAlmostEqual(ema[0], 12.0)

    def test_rsi(self):
        prices = [10.0 + i for i in range(25)]
        rsi = calculate_rsi(prices, 14)
        self.assertIsNotNone(rsi)
        self.assertGreater(rsi, 90.0)

    def test_atr(self):
        klines = [
            {"high": 105.0, "low": 95.0, "close": 100.0} for _ in range(20)
        ]
        atr = calculate_atr(klines, 14)
        self.assertIsNotNone(atr)
        self.assertAlmostEqual(atr, 10.0, places=1)

    def test_candle_metrics(self):
        kline = {"open": 100.0, "high": 110.0, "low": 98.0, "close": 109.0}
        metrics = calculate_candle_metrics(kline)
        self.assertTrue(metrics["is_bullish"])
        self.assertGreater(metrics["close_ratio"], 0.8)


class TestAgents(unittest.TestCase):
    def test_scanner_symbol_filtering(self):
        mock_client = MagicMock()
        scanner = ScannerAgent(mock_client)
        self.assertTrue(scanner.is_valid_symbol("BTCUSDT"))
        self.assertTrue(scanner.is_valid_symbol("SOLUSDT"))
        self.assertTrue(scanner.is_valid_symbol("BTCFDUSD"))
        self.assertTrue(scanner.is_valid_symbol("ETHUSDC"))
        self.assertFalse(scanner.is_valid_symbol("BTCTRY"))
        self.assertFalse(scanner.is_valid_symbol("USDCUSDT"))
        self.assertFalse(scanner.is_valid_symbol("BTCUPUSDT"))

    def test_orderbook_veto_on_wide_spread(self):
        mock_client = MagicMock()
        mock_client.get_orderbook.return_value = {
            "bids": [[100.0, 10.0]],
            "asks": [[101.0, 10.0]]
        }
        ob_agent = OrderbookAgent(mock_client)
        res = ob_agent.inspect_orderbook("TESTUSDT")
        self.assertFalse(res["passed"])
        self.assertIn("Wide spread", res["reason"])

    def test_risk_management_sizing_and_targets(self):
        risk_agent = RiskManagementAgent()
        total_equity = 1000.0
        current_price = 100.0
        atr = 1.0

        res = risk_agent.evaluate_risk(
            symbol="ETHUSDT",
            current_price=current_price,
            atr=atr,
            total_equity=total_equity,
            open_positions=[]
        )
        self.assertTrue(res["approved"])
        self.assertEqual(res["stop_loss_pct"], 1.5)
        self.assertEqual(res["risk_reward_ratio"], 2.5)
        self.assertLessEqual(res["position_usdt"], 250.0)

    def test_risk_management_veto_on_capacity(self):
        risk_agent = RiskManagementAgent()
        open_pos = [{"symbol": "A"}, {"symbol": "B"}, {"symbol": "C"}]
        res = risk_agent.evaluate_risk("D", 100.0, 1.0, 1000.0, open_pos)
        self.assertFalse(res["approved"])
        self.assertIn("Maximum open positions limit", res["reason"])

    def test_portfolio_execution_and_stop_loss(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio.json"
            temp_log_file = Path(tmp_dir) / "test_trades.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "SOLUSDT",
                    "entry_price": 100.0,
                    "quantity": 1.0,
                    "position_usdt": 100.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0,
                    "take_profit_2": 105.0,
                    "trailing_trigger_pct": 2.5,
                    "trailing_distance_pct": 1.2
                }

                bought = portfolio.execute_buy(plan)
                self.assertTrue(bought)
                self.assertEqual(len(portfolio.get_open_positions()), 1)

                mock_client.get_price.return_value = 97.0
                with unittest.mock.patch("agents.consciousness.consciousness_engine.record_trade_failure_and_learn") as mock_learn:
                    actions = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions), 1)
                self.assertEqual(actions[0]["reason"], "STOP_LOSS_HIT")
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                self.assertLess(portfolio.state["cash_usdt"], 1000.0)
                self.assertGreater(portfolio.state["total_fees_paid_usdt"], 0.0)
                self.assertIn("fee_paid_usdt", actions[0])
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log

    def test_partial_tp1_and_break_even_lock(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio_tp1.json"
            temp_log_file = Path(tmp_dir) / "test_trades_tp1.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "SOLUSDT",
                    "entry_price": 100.0,
                    "quantity": 2.0,
                    "position_usdt": 200.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 102.0,
                    "take_profit_2": 106.0,
                    "trailing_trigger_pct": 5.0,
                    "trailing_distance_pct": 1.2
                }

                bought = portfolio.execute_buy(plan)
                self.assertTrue(bought)

                # Price hits TP1 (102.2) without activating trailing stop (> 5.0%)
                mock_client.get_price.return_value = 102.2
                actions = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions), 1)
                self.assertEqual(actions[0]["action"], "PARTIAL_TP1_TAKEN")
                
                pos = portfolio.get_open_positions()[0]
                self.assertTrue(pos["tp1_hit"])
                self.assertTrue(pos["break_even_active"])
                self.assertAlmostEqual(pos["quantity"], 1.0)
                self.assertGreaterEqual(pos["stop_loss_price"], 100.2)  # Entry + 0.2% cushion

                # Price now dumps back to 100.1 (hitting Break-Even SL)
                mock_client.get_price.return_value = 100.1
                actions_exit = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions_exit), 1)
                self.assertEqual(actions_exit[0]["reason"], "BREAK_EVEN_STOP_EXIT")
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                # Overall portfolio should be NET POSITIVE because 50% was closed at +2.2%!
                self.assertGreater(portfolio.state["cash_usdt"], 1000.0)
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log

    def test_macro_market_sentinel(self):
        mock_client = MagicMock()
        # Normal upward BTC klines
        normal_klines = [
            {"open": 60000.0 + i*10, "high": 60050.0 + i*10, "low": 59950.0 + i*10, "close": 60020.0 + i*10, "volume": 100.0}
            for i in range(60)
        ]
        mock_client.get_klines.return_value = normal_klines
        sentinel = MacroMarketSentinel(mock_client)
        status = sentinel.evaluate_macro_health()
        self.assertTrue(status["safe_to_trade"])
        self.assertFalse(status["circuit_breaker"])

        # Dumping BTC klines (Drop from 65k to 55k)
        dumping_klines = [
            {"open": 65000.0 - i*200, "high": 65100.0 - i*200, "low": 64800.0 - i*200, "close": 64900.0 - i*200, "volume": 500.0}
            for i in range(60)
        ]
        mock_client.get_klines.return_value = dumping_klines
        status_dump = sentinel.evaluate_macro_health()
        self.assertFalse(status_dump["safe_to_trade"])
        self.assertTrue(status_dump["circuit_breaker"])


class TestSpecialistAgents(unittest.TestCase):
    def setUp(self):
        self.llm = LLMClient(api_key="", base_url="")

    def test_narrative_specialist(self):
        spec = MarketNarrativeSpecialist(self.llm)
        report = spec.analyze({
            "symbol": "SOLUSDT",
            "price_change_24h": 8.5,
            "quote_volume_24h": 25_000_000.0
        })
        self.assertEqual(report["verdict"], "APPROVE")
        self.assertGreaterEqual(report["conviction"], 65)

    def test_price_action_specialist(self):
        spec = PriceActionSpecialist(self.llm)
        report = spec.analyze({
            "momentum_data": {
                "score": 85,
                "rsi": 62.0,
                "volume_surge": 1.6,
                "reasons": ["Price > EMA9 > EMA21"]
            }
        })
        self.assertEqual(report["verdict"], "APPROVE")
        self.assertGreaterEqual(report["conviction"], 70)
        self.assertEqual(len(report["staff_reports"]), 3)

    def test_rsi_exhaustion_specialist(self):
        spec = MomentumExhaustionSpecialist(self.llm)
        # Healthy zone
        rep_ok = spec.analyze({"momentum_data": {"rsi": 60.0}})
        self.assertEqual(rep_ok["verdict"], "APPROVE")

        # Overbought exhaustion veto
        rep_veto = spec.analyze({"momentum_data": {"rsi": 82.0}})
        self.assertEqual(rep_veto["verdict"], "REJECT")
        self.assertIn("overbought", rep_veto["rationale"].lower())

    def test_sentiment_regime_specialist(self):
        spec = MarketSentimentSpecialist(self.llm)
        report = spec.analyze({
            "momentum_data": {"atr": 0.05},
            "ticker_data": {"count_trades": 60_000}
        })
        self.assertEqual(report["verdict"], "APPROVE")

    def test_profit_extraction_specialist(self):
        spec = ProfitExtractionSpecialist(self.llm)
        report = spec.analyze({
            "risk_plan": {
                "take_profit_1": 103.0,
                "take_profit_2": 106.0,
                "trailing_trigger_pct": 2.5,
                "trailing_distance_pct": 1.2
            }
        })
        self.assertEqual(report["verdict"], "APPROVE")

    def test_cro_veto_power(self):
        spec = ChiefRiskOfficerSpecialist(self.llm)
        report = spec.analyze({
            "risk_plan": {"approved": False, "reason": "R:R ratio below 2.0"}
        })
        self.assertEqual(report["verdict"], "REJECT")
        self.assertIn("VETO", report["rationale"])

    def test_executive_consensus_synthesis(self):
        exec_spec = ExecutiveStrategistSpecialist(self.llm)
        approved_reports = [
            {"specialist": "Narrative", "verdict": "APPROVE", "conviction": 80},
            {"specialist": "PriceAction", "verdict": "APPROVE", "conviction": 85},
            {"specialist": "Exhaustion", "verdict": "APPROVE", "conviction": 90},
            {"specialist": "Microstructure", "verdict": "APPROVE", "conviction": 75},
            {"specialist": "Sentiment", "verdict": "APPROVE", "conviction": 80},
            {"specialist": "CRO", "verdict": "APPROVE", "conviction": 90},
            {"specialist": "Profit", "verdict": "APPROVE", "conviction": 90}
        ]
        consensus = exec_spec.synthesize(approved_reports)
        self.assertEqual(consensus["final_verdict"], "APPROVE")
        self.assertGreaterEqual(consensus["consensus_conviction"], 70)

        # One veto triggers rejection
        vetoed_reports = list(approved_reports)
        vetoed_reports[5] = {"specialist": "CRO", "verdict": "REJECT", "rationale": "High drawdown"}
        rejected_consensus = exec_spec.synthesize(vetoed_reports)
        self.assertEqual(rejected_consensus["final_verdict"], "REJECT")

    def test_close_all_positions_and_periodic_perf(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        mock_client.get_price.return_value = 105.0

        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio.json"
            temp_log_file = Path(tmp_dir) / "test_trades.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "BTCUSDT",
                    "entry_price": 100.0,
                    "quantity": 2.0,
                    "position_usdt": 200.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0,
                    "take_profit_2": 108.0,
                    "trailing_trigger_pct": 2.5,
                    "trailing_distance_pct": 1.2
                }
                portfolio.execute_buy(plan)
                self.assertEqual(len(portfolio.get_open_positions()), 1)

                # Test emergency close all positions
                closed = portfolio.close_all_positions(reason="BOT_SHUTDOWN_LIQUIDATION")
                self.assertEqual(len(closed), 1)
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                self.assertEqual(closed[0]["reason"], "BOT_SHUTDOWN_LIQUIDATION")

                # Test periodic performance report
                perf = portfolio.get_periodic_performance()
                self.assertIn("today", perf)
                self.assertIn("this_week", perf)
                self.assertIn("this_month", perf)
                self.assertEqual(perf["today"]["trades"], 1)
                self.assertGreater(perf["today"]["wins"], 0)
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log


if __name__ == "__main__":
    unittest.main()
