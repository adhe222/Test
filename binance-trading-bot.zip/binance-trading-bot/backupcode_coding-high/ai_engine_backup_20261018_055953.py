import os
import json
import time
import logging
from typing import Dict, Any, Callable
from openai import OpenAI
import config
from config import CLOUVIA_API_KEY, OPENAI_MODEL, LLM_TEMPERATURE

logger = logging.getLogger("AIEngine")


class LLMClient:
    """
    Clouvia OpenAI-Compatible LLM Engine for Quantitative Trading Bot Specialists.
    Uses OpenAI official client pointing to https://router.clouvia.id/v1.
    API key and model loaded from environment variables (CLOUVIA_API_KEY, OPENAI_MODEL).
    """

    def __init__(
        self,
        api_key: str = CLOUVIA_API_KEY,
        base_url: str = "https://router.clouvia.id/v1",
        model: str = OPENAI_MODEL,
        temperature: float = LLM_TEMPERATURE
    ):
        self.api_key = api_key or os.getenv("CLOUVIA_API_KEY", "")
        self.base_url = base_url or os.getenv("CLOUVIA_BASE_URL", "https://router.clouvia.id/v1")
        self.model = model or os.getenv("OPENAI_MODEL", "coding-high")
        self.temperature = temperature
        self._consecutive_failures = 0
        self._circuit_opened_at = 0.0

        try:
            self.client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
        except Exception as e:
            logger.warning(f"Failed to initialize OpenAI client for Clouvia: {e}")
            self.client = None

    @property
    def status_summary(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "base_url": self.base_url,
            "provider": "Clouvia Router (OpenAI SDK)",
            "configured": bool(self.api_key),
            "temperature": self.temperature
        }

    def _validate(self, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """
        Harden raw model output. An LLM can return out-of-range convictions,
        unexpected verdict strings, or missing fields; unvalidated values would
        flow straight into position sizing and approval logic.
        """
        if not isinstance(parsed, dict):
            raise ValueError("model response is not a JSON object")

        verdict = str(parsed.get("verdict", "")).strip().upper()
        if verdict not in ("APPROVE", "REJECT"):
            raise ValueError(f"invalid verdict: {parsed.get('verdict')!r}")

        try:
            conviction = int(float(parsed.get("conviction", 0)))
        except (TypeError, ValueError):
            raise ValueError(f"invalid conviction: {parsed.get('conviction')!r}")
        conviction = max(0, min(100, conviction))

        return {
            "verdict": verdict,
            "conviction": conviction,
            "rationale": str(parsed.get("rationale", ""))[:600] or "No rationale provided.",
            "signal": str(parsed.get("signal", ""))[:120] or "Unlabelled",
        }

    def _circuit_open(self) -> bool:
        """True while the provider is temporarily disabled after repeated failures."""
        if self._consecutive_failures < config.LLM_CIRCUIT_FAILURES:
            return False
        if time.monotonic() - self._circuit_opened_at >= config.LLM_CIRCUIT_COOLDOWN_SEC:
            # Cooldown elapsed: allow one probe attempt.
            self._consecutive_failures = 0
            return False
        return True

    def query_specialist(
        self,
        specialist_role: str,
        system_instruction: str,
        context_data: Dict[str, Any],
        fallback_fn: Callable[[Dict[str, Any]], Dict[str, Any]]
    ) -> Dict[str, Any]:
        # Deterministic baseline is ALWAYS computed first. It is the decision of
        # record; the model may only veto or lower conviction (config.LLM_VETO_ONLY).
        baseline = fallback_fn(context_data)

        if not self.client or not self.api_key or self._circuit_open():
            baseline["engine"] = f"Deterministic Engine ({specialist_role})"
            baseline["engine_mode"] = "DETERMINISTIC"
            return baseline

        system_prompt = (
            f"Kamu adalah {specialist_role} pada quantitative crypto trading bot di Binance Spot.\n"
            f"Mandat Tugas: {system_instruction.strip()}\n\n"
            "Format Instruksi:\n"
            "Berikan analisis yang ringkas, objektif, dan solutif untuk mencapai target win rate > 70%.\n"
            "Kamu WAJIB menjawab HANYA dalam format JSON valid tanpa teks pengantar, dengan struktur keys:\n"
            "{\n"
            '  "verdict": "APPROVE" atau "REJECT",\n'
            '  "conviction": integer 0-100,\n'
            '  "rationale": "ringkasan analisis teknikal solutif maksimal 2-3 kalimat",\n'
            '  "signal": "label sinyal utama singkat"\n'
            "}"
        )

        user_content = (
            f"Analisis data real-time Binance berikut untuk aset {context_data.get('symbol', '')}:\n"
            f"{json.dumps(context_data, indent=2, default=str)}"
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content}
        ]

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=350
            )
            content = response.choices[0].message.content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
            llm_res = self._validate(json.loads(content.strip()))
            self._consecutive_failures = 0

            if config.LLM_VETO_ONLY:
                # AI holds VETO power only: it may reject a setup the deterministic
                # engine approved, and may lower conviction, but it can never turn a
                # deterministic REJECT into an APPROVE. This keeps every executed
                # trade reproducible and backtestable.
                merged = dict(baseline)
                if llm_res["verdict"] == "REJECT":
                    merged["verdict"] = "REJECT"
                    merged["rationale"] = f"AI veto: {llm_res['rationale']}"
                    merged["signal"] = llm_res["signal"]
                merged["conviction"] = min(
                    int(baseline.get("conviction", 0)), llm_res["conviction"]
                )
                merged["ai_verdict"] = llm_res["verdict"]
                merged["ai_conviction"] = llm_res["conviction"]
                merged["ai_rationale"] = llm_res["rationale"]
                merged["engine"] = f"{self.model} (veto-only) + Deterministic"
                merged["engine_mode"] = "AI_VETO_OVER_DETERMINISTIC"
                return merged

            llm_res["engine"] = f"{self.model} (Clouvia Router)"
            llm_res["engine_mode"] = "AI_AUTHORITATIVE"
            return llm_res
        except Exception as e:
            self._consecutive_failures += 1
            if self._consecutive_failures == config.LLM_CIRCUIT_FAILURES:
                self._circuit_opened_at = time.monotonic()
                logger.warning(
                    f"LLM circuit opened after {self._consecutive_failures} consecutive failures; "
                    f"running deterministic-only for {config.LLM_CIRCUIT_COOLDOWN_SEC}s. Last error: {e}"
                )
            elif self._consecutive_failures < config.LLM_CIRCUIT_FAILURES:
                logger.warning(f"LLM call error ({e}); using deterministic engine for this decision.")
            baseline["engine"] = f"Deterministic Fallback ({specialist_role})"
            baseline["engine_mode"] = "DETERMINISTIC_FALLBACK"
            return baseline
