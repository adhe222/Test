from typing import Dict, Any, Optional
import config
from config import KLINES_TIMEFRAME, KLINES_LIMIT
from indicators import (
    calculate_ema,
    calculate_rsi,
    calculate_ema_and_metrics,
    calculate_volume_surge,
    calculate_candle_metrics,
    drop_forming_bar
)


class MomentumAnalystAgent:
    """
    Enhanced Momentum & Technical Analyst Agent with Higher Win Rate Filters:
    - Analyzes candlestick price action, exponential moving average alignment,
    - RSI momentum health, volume expansion, and multi-timeframe (15m + 1h + 4h) trend confluence.
    """

    def __init__(self, binance_client):
        self.client = binance_client
        self.name = "MomentumAnalystAgent"

    def analyze_symbol(self, symbol: str, extra_score_required: int = 0) -> Dict[str, Any]:
        try:
            raw_klines = self.client.get_klines(symbol, interval=KLINES_TIMEFRAME, limit=KLINES_LIMIT)
        except Exception as e:
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "gate_failures": [f"Market feed fetch error: {e}"],
                "reason": f"Market feed fetch error: {e}"
            }

        # CRITICAL: decisions must use CLOSED candles only. The in-progress bar's
        # volume ramps from zero across the interval, so signals computed on it
        # depend on scan timing rather than on the market.
        klines = drop_forming_bar(raw_klines)
        live_price = raw_klines[-1]["close"] if raw_klines else None

        if len(klines) < 55:
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "gate_failures": ["Insufficient closed historical klines"],
                "reason": "Insufficient closed historical klines"
            }

        closes = [k["close"] for k in klines]
        latest_price = closes[-1]

        # Enhanced Analysis using consolidated function
        metrics = calculate_ema_and_metrics(klines, KLINES_TIMEFRAME)
        vol_surge = calculate_volume_surge(klines, 20)
        candle_info = calculate_candle_metrics(klines[-1])

        if not (metrics["ema9"] and metrics["ema21"] and metrics["ema50"] and metrics["atr"]):
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "gate_failures": ["Indicator calculation returned None/invalid"],
                "reason": "Indicator calculation returned None/invalid"
            }

        ema9 = metrics["ema9"]
        ema21 = metrics["ema21"]
        ema50 = metrics["ema50"]
        rsi = metrics["rsi"]
        atr = metrics["atr"]
        base_score = metrics["score"]

        score = base_score
        reasons = []

        # 1. Multi-Timeframe Trend Alignment (Enhanced) - Max 40 points
        # Check primary timeframe (15m/1h)
        if latest_price > ema9 > ema21 > ema50:
            score += 40
            reasons.append("Perfect bullish stack (Price > EMA9 > EMA21 > EMA50)")
        elif latest_price > ema21 and ema9 > ema21:
            score += 30
            reasons.append("Moderate bullish alignment (Price & EMA9 > EMA21)")
        elif latest_price < ema21:
            score = max(0, score - 10)
            reasons.append("Price below EMA21 (Bearish structure warning)")

        # 2. RSI Momentum Health - Enhanced Tighter Thresholds (Max 30 points)
        if 52 <= rsi <= 68:
            score += 30
            reasons.append(f"Ideal acceleration zone (RSI {rsi:.1f})")
        elif 68 < rsi <= 74:
            score += 18
            reasons.append(f"Elevated but sustainable (RSI {rsi:.1f})")
        elif 74 < rsi <= 76:
            score += 8
            reasons.append(f"Caution zone approaching (RSI {rsi:.1f})")
        elif 45 <= rsi < 52:
            score += 12
            reasons.append(f"Building momentum from neutral (RSI {rsi:.1f})")
        else:
            score = max(0, score - 10)
            reasons.append(f"Weak/negative momentum (RSI {rsi:.1f})")

        # 3. Volume Expansion - Enhanced Minimum Threshold (Max 20 points)
        if vol_surge >= 2.0:
            score += 20
            reasons.append(f"Explosive volume surge ({vol_surge:.2f}x average)")
        elif vol_surge >= 1.5:
            score += 16
            reasons.append(f"Strong volume breakout ({vol_surge:.2f}x average)")
        elif vol_surge >= config.VOLUME_SURGE_FILTER:
            score += 12
            reasons.append(f"Healthy volume support ({vol_surge:.2f}x average)")
        elif vol_surge >= 0.9:
            score += 5
            reasons.append(f"Average volume ({vol_surge:.2f}x average)")
        else:
            score = max(0, score - 8)
            reasons.append(f"Low volume caution (Drought: {vol_surge:.2f}x)")

        # 4. Candlestick Strength (Max 10 points)
        if candle_info["is_bullish"] and candle_info["close_ratio"] > 0.75:
            score += 10
            reasons.append("Dominant bullish close (>75% of range)")
        elif candle_info["is_bullish"] and candle_info["close_ratio"] > 0.65:
            score += 7
            reasons.append("Strong bullish close")
        elif candle_info["is_bullish"]:
            score += 3
            reasons.append("Moderate bullish candle")
        else:
            score = max(0, score - 5)
            reasons.append("Bearish wick / rejection zone")

        # 5. Multi-Timeframe Confirmation (1h + 4h Confluence) - Enhanced
        htf_score = 0
        htf_available = False
        htf_bearish = False
        try:
            # Check 1H trend alignment (closed bars only)
            klines_1h = drop_forming_bar(
                self.client.get_klines(symbol, interval=config.TREND_TIMEFRAME_1, limit=60)
            )
            if len(klines_1h) >= 55:
                closes_1h = [k["close"] for k in klines_1h]
                ema21_1h = calculate_ema(closes_1h, 21)
                ema50_1h = calculate_ema(closes_1h, 50)
                htf_available = True

                if ema21_1h and ema50_1h and closes_1h[-1] > ema21_1h[-1] > ema50_1h[-1]:
                    score += 8
                    htf_score += 8
                    reasons.append("HTF Bullish Stack (1h Price > EMA21 > EMA50)")
                elif ema21_1h and closes_1h[-1] > ema21_1h[-1]:
                    score += 5
                    htf_score += 5
                    reasons.append("HTF Support (1h Price > EMA21)")
                elif ema21_1h and closes_1h[-1] < ema21_1h[-1]:
                    score = max(0, score - 12)
                    htf_bearish = True
                    reasons.append("HTF Rejection (1h Price < EMA21)")

            # Check 4H alignment for major trend confirmation (closed bars only)
            klines_4h = drop_forming_bar(
                self.client.get_klines(symbol, interval=config.TREND_TIMEFRAME_2, limit=40)
            )
            if len(klines_4h) >= 25:
                closes_4h = [k["close"] for k in klines_4h]
                rsi_4h = calculate_rsi(closes_4h, 14)
                ema21_4h = calculate_ema(closes_4h, 21)

                if rsi_4h is not None and 48 <= rsi_4h <= 72:
                    score += 5
                    htf_score += 5
                    reasons.append("4H RSI Healthy ({:.1f})".format(rsi_4h))
                elif rsi_4h is not None and (rsi_4h > 76 or rsi_4h < 42):
                    score = max(0, score - 8)
                    htf_bearish = True
                    reasons.append("4H RSI Warning ({:.1f})".format(rsi_4h))

                # 4H structural trend filter: never buy against the macro structure
                if ema21_4h and closes_4h[-1] < ema21_4h[-1]:
                    score = max(0, score - 10)
                    htf_bearish = True
                    reasons.append("4H Downtrend Structure (Price < EMA21 4h)")
                elif ema21_4h:
                    score += 3
                    htf_score += 3
                    reasons.append("4H Uptrend Structure confirmed")
        except Exception as e:
            reasons.append(f"HTF confirmation unavailable ({type(e).__name__})")

        # Higher Timeframe Bonus
        if htf_score >= 13:
            score += 5
            reasons.append("Multi-HTF Confluence Bonus")

        # -----------------------------------------------------------------
        # REGIME FILTER: trend-following gates are meaningless in a chop.
        # Measured as directional efficiency over the last 20 closed bars:
        # net displacement / total path travelled. Low value = sideways noise.
        # -----------------------------------------------------------------
        recent = closes[-21:]
        net_move = abs(recent[-1] - recent[0])
        path = sum(abs(recent[i] - recent[i - 1]) for i in range(1, len(recent)))
        trend_efficiency = (net_move / path) if path > 0 else 0.0

        # Support proximity: where does price sit inside its recent range?
        lows = [k["low"] for k in klines[-21:]]
        highs = [k["high"] for k in klines[-21:]]
        range_low, range_high = min(lows), max(highs)
        range_span = range_high - range_low
        range_position = ((latest_price - range_low) / range_span) if range_span > 0 else 0.5

        # -----------------------------------------------------------------
        # HARD ENTRY GATES - win-rate critical. Any failed gate = no trade.
        # These run independently of the point score so a high score can
        # never override a structural disqualifier.
        # -----------------------------------------------------------------
        gate_failures = []

        atr_pct = (atr / latest_price * 100.0) if latest_price > 0 else 99.0

        if trend_efficiency < config.MIN_TREND_EFFICIENCY:
            gate_failures.append(
                f"Choppy regime: trend efficiency {trend_efficiency:.2f} < {config.MIN_TREND_EFFICIENCY}"
            )
        # NOTE: range_position is telemetry only, never a hard gate. In a healthy
        # uptrend price sits at the top of its own recent range by definition, so
        # gating on it would reject exactly the setups we want. Overextension is
        # correctly handled by MAX_DISTANCE_FROM_EMA21_PCT below.

        if rsi < config.RSI_ENTRY_MIN:
            gate_failures.append(f"RSI {rsi:.1f} below entry floor {config.RSI_ENTRY_MIN}")
        if rsi > config.RSI_ENTRY_MAX:
            gate_failures.append(f"RSI {rsi:.1f} above exhaustion ceiling {config.RSI_ENTRY_MAX}")
        if latest_price <= ema21:
            gate_failures.append("Price below EMA21 (no bullish structure)")
        if ema21 <= ema50:
            gate_failures.append("EMA21 below EMA50 (trend not established)")

        dist_from_ema21 = ((latest_price - ema21) / ema21 * 100.0) if ema21 > 0 else 99.0
        if dist_from_ema21 > config.MAX_DISTANCE_FROM_EMA21_PCT:
            gate_failures.append(
                f"Overextended {dist_from_ema21:.2f}% above EMA21 (max {config.MAX_DISTANCE_FROM_EMA21_PCT}%)"
            )

        if vol_surge < config.VOLUME_SURGE_FILTER:
            gate_failures.append(f"Volume surge {vol_surge:.2f}x below {config.VOLUME_SURGE_FILTER}x requirement")
        if not candle_info["is_bullish"] or candle_info["close_ratio"] < config.MIN_CANDLE_CLOSE_RATIO:
            gate_failures.append(
                f"Weak entry candle (close ratio {candle_info['close_ratio']:.2f} < {config.MIN_CANDLE_CLOSE_RATIO})"
            )
        if atr_pct > config.MAX_ATR_VOLATILITY_PCT:
            gate_failures.append(f"Volatility too high (ATR {atr_pct:.2f}% of price)")

        if config.REQUIRE_HTF_CONFIRMATION:
            if not htf_available:
                gate_failures.append("Higher-timeframe data unavailable (cannot confirm trend)")
            elif htf_bearish:
                gate_failures.append("Higher-timeframe structure bearish")
            elif htf_score < config.MIN_HTF_SCORE:
                gate_failures.append(f"HTF confirmation weak ({htf_score} < {config.MIN_HTF_SCORE})")

        min_score = config.MIN_TECHNICAL_SCORE + extra_score_required
        if score < min_score:
            gate_failures.append(f"Technical score {score} below required {min_score}")

        passed = len(gate_failures) == 0

        return {
            "symbol": symbol,
            "passed": passed,
            "score": score,
            "min_score_required": min_score,
            "gate_failures": gate_failures,
            "price": latest_price,
            "live_price": live_price,
            "trend_efficiency": round(trend_efficiency, 3),
            "range_position": round(range_position, 3),
            "ema9": ema9,
            "ema21": ema21,
            "ema50": ema50,
            "rsi": rsi,
            "atr": atr,
            "atr_pct": round(atr_pct, 3),
            "dist_from_ema21_pct": round(dist_from_ema21, 3),
            "volume_surge": vol_surge,
            "candle": candle_info,
            "htf_score": htf_score,
            "htf_available": htf_available,
            "htf_bearish": htf_bearish,
            "reasons": reasons
        }
