import json
import re
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Dict, List, Optional

import requests

import config


class ExternalResearchAgent:
    def __init__(self, session: Optional[requests.Session] = None, timeout: Optional[float] = None):
        self.session = session or requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
            "Accept": "application/json,text/xml,application/xml,text/html;q=0.9,*/*;q=0.8",
        })
        self.timeout = float(timeout if timeout is not None else getattr(config, "EXTERNAL_INTEL_TIMEOUT_SEC", 6.0))
        self.ttl = float(getattr(config, "EXTERNAL_INTEL_TTL_SEC", 180))
        self.enabled = bool(getattr(config, "EXTERNAL_INTEL_ENABLED", True))
        self.min_sources = int(getattr(config, "EXTERNAL_INTEL_MIN_SOURCES", 2))
        self._cache: Dict[str, Any] = {}
        self._news_cache: Optional[Dict[str, Any]] = None
        self._fng_cache: Optional[Dict[str, Any]] = None
        self._lock = threading.Lock()

    @staticmethod
    def _iso_ms(value: Any) -> Optional[str]:
        try:
            return datetime.fromtimestamp(float(value) / 1000.0, tz=timezone.utc).isoformat()
        except (TypeError, ValueError, OSError):
            return None

    @staticmethod
    def _pct_change(first: float, last: float) -> float:
        if not first:
            return 0.0
        return round((last - first) / abs(first) * 100.0, 3)

    @staticmethod
    def _trend(first: float, last: float, flat_band: float = 1.0) -> str:
        change = ExternalResearchAgent._pct_change(first, last)
        if change > flat_band:
            return "RISING"
        if change < -flat_band:
            return "FALLING"
        return "FLAT"

    def _get_json(self, url: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        started = time.monotonic()
        response = self.session.get(url, params=params, timeout=self.timeout)
        response.raise_for_status()
        data = response.json()
        latency = round((time.monotonic() - started) * 1000.0, 1)
        return {"data": data, "latency_ms": latency}

    def _get_text(self, url: str) -> Dict[str, Any]:
        started = time.monotonic()
        response = self.session.get(url, timeout=self.timeout)
        response.raise_for_status()
        latency = round((time.monotonic() - started) * 1000.0, 1)
        return {"data": response.text, "latency_ms": latency}

    def _source(self, name: str, ok: bool, latency_ms: float = 0.0, error: Optional[str] = None) -> Dict[str, Any]:
        item = {"name": name, "ok": bool(ok), "latency_ms": latency_ms}
        if error:
            item["error"] = str(error)[:180]
        return item

    def _fetch_news(self) -> Dict[str, Any]:
        now = time.monotonic()
        if self._news_cache and self._news_cache.get("_expires", 0) > now:
            return self._news_cache
        feeds = [
            ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"),
            ("Cointelegraph", "https://cointelegraph.com/rss"),
        ]
        headlines: List[Dict[str, Any]] = []
        sources: List[Dict[str, Any]] = []
        for name, url in feeds:
            try:
                result = self._get_text(url)
                root = ET.fromstring(result["data"])
                count = 0
                for node in root.iter():
                    if not str(node.tag).lower().endswith("item"):
                        continue
                    fields = {}
                    for child in list(node):
                        key = str(child.tag).split("}")[-1].lower()
                        fields[key] = (child.text or "").strip()
                    title = fields.get("title", "")
                    if not title:
                        continue
                    published = fields.get("pubdate") or fields.get("published") or ""
                    try:
                        dt = parsedate_to_datetime(published)
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=timezone.utc)
                        published_iso = dt.astimezone(timezone.utc).isoformat()
                        sort_ts = dt.timestamp()
                    except (TypeError, ValueError, OverflowError):
                        published_iso = published[:40]
                        sort_ts = 0.0
                    headlines.append({
                        "title": re.sub(r"\s+", " ", title).strip()[:220],
                        "link": fields.get("link", "")[:300],
                        "source": name,
                        "published_at": published_iso,
                        "_sort_ts": sort_ts,
                    })
                    count += 1
                    if count >= 25:
                        break
                sources.append(self._source(f"news:{name}", count > 0, result["latency_ms"], None if count else "no items"))
            except Exception as exc:
                sources.append(self._source(f"news:{name}", False, 0.0, type(exc).__name__ + ": " + str(exc)))
        deduped = {}
        for item in headlines:
            key = re.sub(r"\s+", " ", item["title"].lower()).strip()
            if key and key not in deduped:
                deduped[key] = item
        ordered = sorted(deduped.values(), key=lambda x: x.get("_sort_ts", 0.0), reverse=True)
        for item in ordered:
            item.pop("_sort_ts", None)
        result = {"headlines": ordered[:12], "sources": sources, "_expires": now + self.ttl}
        self._news_cache = result
        return result

    def _fetch_fear_greed(self) -> Dict[str, Any]:
        now = time.monotonic()
        if self._fng_cache and self._fng_cache.get("_expires", 0) > now:
            return self._fng_cache
        try:
            result = self._get_json("https://api.alternative.me/fng/", {"limit": 1})
            row = (result["data"].get("data") or [{}])[0]
            payload = {
                "value": int(float(row.get("value", 0) or 0)),
                "classification": str(row.get("value_classification", "Unknown")),
                "timestamp": self._iso_ms(row.get("timestamp")),
                "ok": True,
                "latency_ms": result["latency_ms"],
            }
        except Exception as exc:
            payload = {"ok": False, "error": type(exc).__name__ + ": " + str(exc), "latency_ms": 0.0}
        payload["_expires"] = now + max(self.ttl, 300.0)
        self._fng_cache = payload
        return payload

    @staticmethod
    def _venue() -> str:
        name = str(getattr(config, "EXCHANGE", "binance") or "binance").strip().lower()
        return "okx" if name == "okx" else "binance"

    @staticmethod
    def _base_asset(symbol: str) -> str:
        base = str(symbol or "").upper()
        for quote in sorted(getattr(config, "ACCEPTED_QUOTE_ASSETS", ["USDT"]), key=len, reverse=True):
            if base.endswith(quote) and len(base) > len(quote):
                return base[: -len(quote)]
        return base

    def _fetch_symbol(self, symbol: str) -> Dict[str, Any]:
        if self._venue() == "okx":
            return self._fetch_symbol_okx(symbol)
        return self._fetch_symbol_binance(symbol)

    def _fetch_symbol_okx(self, symbol: str) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"sources": [], "venue": "OKX"}
        base = self._base_asset(symbol)
        inst_id = f"{base}-USDT-SWAP"
        try:
            result = self._get_json("https://www.okx.com/api/v5/public/funding-rate", {"instId": inst_id})
            rows = (result["data"] or {}).get("data") or []
            row = rows[0] if rows else {}
            rate = float(row.get("fundingRate") or 0.0)
            payload["funding"] = {
                "rate_pct": round(rate * 100.0, 5),
                "annualized_pct": round(rate * 3.0 * 365.0 * 100.0, 2),
                "mark_price": 0.0,
                "index_price": 0.0,
                "next_funding_time": self._iso_ms(row.get("nextFundingTime") or row.get("fundingTime")),
            }
            payload["sources"].append(self._source("okx_funding", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("okx_funding", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-volume",
                {"ccy": base, "period": "5m"},
            )
            rows = (result["data"] or {}).get("data") or []
            values = [float(r[1]) for r in reversed(rows) if isinstance(r, list) and len(r) > 1]
            if not values:
                raise ValueError("empty open interest history")
            payload["open_interest"] = {
                "latest_usdt": round(values[-1], 2),
                "change_pct_1h": self._pct_change(values[0], values[-1]),
                "trend": self._trend(values[0], values[-1], 1.0),
            }
            payload["sources"].append(self._source("okx_open_interest", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("okx_open_interest", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://www.okx.com/api/v5/rubik/stat/contracts/long-short-account-ratio",
                {"ccy": base, "period": "5m"},
            )
            rows = (result["data"] or {}).get("data") or []
            ratios = [float(r[1]) for r in reversed(rows) if isinstance(r, list) and len(r) > 1]
            if not ratios:
                raise ValueError("empty long/short history")
            last_ratio = ratios[-1]
            long_pct = round(last_ratio / (1.0 + last_ratio) * 100.0, 2)
            payload["positioning"] = {
                "long_short_ratio": round(last_ratio, 4),
                "long_pct": long_pct,
                "short_pct": round(100.0 - long_pct, 2),
                "trend": self._trend(ratios[0], last_ratio, 2.0),
                "crowding": "LONG_CROWDED" if last_ratio >= 1.6 else ("SHORT_CROWDED" if last_ratio <= 0.625 else "BALANCED"),
            }
            payload["sources"].append(self._source("okx_long_short_ratio", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("okx_long_short_ratio", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://www.okx.com/api/v5/rubik/stat/taker-volume",
                {"ccy": base, "instType": "CONTRACTS", "period": "5m"},
            )
            rows = (result["data"] or {}).get("data") or []
            flows = [
                (float(r[1]), float(r[2]))
                for r in reversed(rows)
                if isinstance(r, list) and len(r) > 2
            ]
            if not flows:
                raise ValueError("empty taker flow history")
            ratios = [
                (buy / sell) if sell > 0 else (99.0 if buy > 0 else 1.0)
                for sell, buy in flows
            ]
            last_sell, last_buy = flows[-1]
            last_ratio = ratios[-1]
            payload["taker_flow"] = {
                "buy_sell_ratio": round(last_ratio, 4),
                "buy_volume": round(last_buy, 2),
                "sell_volume": round(last_sell, 2),
                "trend": self._trend(ratios[0], last_ratio, 3.0),
                "pressure": "BUYERS" if last_ratio >= 1.1 else ("SELLERS" if last_ratio <= 0.9 else "BALANCED"),
            }
            payload["sources"].append(self._source("okx_taker_flow", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("okx_taker_flow", False, 0.0, type(exc).__name__ + ": " + str(exc)))
        return payload

    def _fetch_symbol_binance(self, symbol: str) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"sources": [], "venue": "BINANCE"}
        try:
            result = self._get_json("https://fapi.binance.com/fapi/v1/premiumIndex", {"symbol": symbol})
            data = result["data"]
            rate = float(data.get("lastFundingRate", 0.0) or 0.0)
            payload["funding"] = {
                "rate_pct": round(rate * 100.0, 5),
                "annualized_pct": round(rate * 3.0 * 365.0 * 100.0, 2),
                "mark_price": float(data.get("markPrice", 0.0) or 0.0),
                "index_price": float(data.get("indexPrice", 0.0) or 0.0),
                "next_funding_time": self._iso_ms(data.get("nextFundingTime")),
            }
            payload["sources"].append(self._source("binance_futures_funding", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("binance_futures_funding", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://fapi.binance.com/futures/data/openInterestHist",
                {"symbol": symbol, "period": "5m", "limit": 12},
            )
            rows = result["data"] if isinstance(result["data"], list) else []
            if not rows:
                raise ValueError("empty open interest history")
            values = [float(r.get("sumOpenInterestValue", 0.0) or 0.0) for r in rows]
            payload["open_interest"] = {
                "latest_usdt": round(values[-1], 2),
                "change_pct_1h": self._pct_change(values[0], values[-1]),
                "trend": self._trend(values[0], values[-1], 1.0),
            }
            payload["sources"].append(self._source("binance_futures_open_interest", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("binance_futures_open_interest", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://fapi.binance.com/futures/data/globalLongShortAccountRatio",
                {"symbol": symbol, "period": "5m", "limit": 12},
            )
            rows = result["data"] if isinstance(result["data"], list) else []
            if not rows:
                raise ValueError("empty long/short history")
            first_ratio = float(rows[0].get("longShortRatio", 0.0) or 0.0)
            last = rows[-1]
            last_ratio = float(last.get("longShortRatio", 0.0) or 0.0)
            payload["positioning"] = {
                "long_short_ratio": round(last_ratio, 4),
                "long_pct": round(float(last.get("longAccount", 0.0) or 0.0) * 100.0, 2),
                "short_pct": round(float(last.get("shortAccount", 0.0) or 0.0) * 100.0, 2),
                "trend": self._trend(first_ratio, last_ratio, 2.0),
                "crowding": "LONG_CROWDED" if last_ratio >= 1.6 else ("SHORT_CROWDED" if last_ratio <= 0.625 else "BALANCED"),
            }
            payload["sources"].append(self._source("binance_futures_long_short_ratio", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("binance_futures_long_short_ratio", False, 0.0, type(exc).__name__ + ": " + str(exc)))

        try:
            result = self._get_json(
                "https://fapi.binance.com/futures/data/takerlongshortRatio",
                {"symbol": symbol, "period": "5m", "limit": 12},
            )
            rows = result["data"] if isinstance(result["data"], list) else []
            if not rows:
                raise ValueError("empty taker flow history")
            first_ratio = float(rows[0].get("buySellRatio", 0.0) or 0.0)
            last = rows[-1]
            last_ratio = float(last.get("buySellRatio", 0.0) or 0.0)
            payload["taker_flow"] = {
                "buy_sell_ratio": round(last_ratio, 4),
                "buy_volume": round(float(last.get("buyVol", 0.0) or 0.0), 2),
                "sell_volume": round(float(last.get("sellVol", 0.0) or 0.0), 2),
                "trend": self._trend(first_ratio, last_ratio, 3.0),
                "pressure": "BUYERS" if last_ratio >= 1.1 else ("SELLERS" if last_ratio <= 0.9 else "BALANCED"),
            }
            payload["sources"].append(self._source("binance_futures_taker_flow", True, result["latency_ms"]))
        except Exception as exc:
            payload["sources"].append(self._source("binance_futures_taker_flow", False, 0.0, type(exc).__name__ + ": " + str(exc)))
        return payload

    @staticmethod
    def _bias(payload: Dict[str, Any], direction: str, price_change_24h: Optional[float]) -> Dict[str, Any]:
        score = 0
        flags: List[str] = []
        funding = payload.get("funding") or {}
        positioning = payload.get("positioning") or {}
        taker = payload.get("taker_flow") or {}
        oi = payload.get("open_interest") or {}
        if funding.get("annualized_pct", 0.0) > 20.0:
            score -= 1
            flags.append("FUNDING_LONG_CROWDED")
        elif funding.get("annualized_pct", 0.0) < -20.0:
            score += 1
            flags.append("FUNDING_SHORT_CROWDED")
        if positioning.get("crowding") == "LONG_CROWDED":
            score -= 1
            flags.append("ACCOUNT_LONG_CROWDED")
        elif positioning.get("crowding") == "SHORT_CROWDED":
            score += 1
            flags.append("ACCOUNT_SHORT_CROWDED")
        if taker.get("pressure") == "BUYERS":
            score += 1
        elif taker.get("pressure") == "SELLERS":
            score -= 1
        if oi.get("trend") == "RISING" and isinstance(price_change_24h, (int, float)):
            if price_change_24h < 0:
                flags.append("OI_RISING_PRICE_FALLING")
                score -= 1
            elif price_change_24h > 0:
                score += 1
        if direction == "SHORT":
            score = -score
        if score >= 2:
            bias = "BULLISH"
        elif score <= -2:
            bias = "BEARISH"
        else:
            bias = "MIXED"
        return {"bias": bias, "score": score, "flags": flags}

    def collect(self, symbol: str, direction: str = "LONG", price_change_24h: Optional[float] = None) -> Dict[str, Any]:
        symbol = str(symbol or "").upper()
        if not self.enabled:
            return {"symbol": symbol, "status": "DISABLED", "generated_at": datetime.now(timezone.utc).isoformat(), "sources": []}
        now = time.monotonic()
        with self._lock:
            cached = self._cache.get(symbol)
            if cached and cached.get("_expires", 0) > now:
                return cached
        payload = self._fetch_symbol(symbol)
        news = self._fetch_news()
        fng = self._fetch_fear_greed()
        sources = list(payload.get("sources", [])) + list(news.get("sources", []))
        if fng.get("ok"):
            sources.append(self._source("alternative_me_fear_greed", True, fng.get("latency_ms", 0.0)))
        else:
            sources.append(self._source("alternative_me_fear_greed", False, 0.0, fng.get("error")))
        base = symbol
        for quote in getattr(config, "ACCEPTED_QUOTE_ASSETS", []):
            if base.endswith(quote):
                base = base[: -len(quote)]
                break
        matched = []
        market = []
        for item in news.get("headlines", []):
            haystack = (item.get("title", "") + " " + item.get("link", "")).upper()
            if base and base.upper() in haystack:
                matched.append(item)
            elif len(market) < 5:
                market.append(item)
        healthy = sum(1 for item in sources if item.get("ok"))
        status = "OK" if healthy >= 4 else ("PARTIAL" if healthy >= self.min_sources else "DEGRADED")
        result = {
            "symbol": symbol,
            "direction": direction,
            "status": status,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "healthy_sources": healthy,
            "sources": sources,
            "funding": payload.get("funding"),
            "open_interest": payload.get("open_interest"),
            "positioning": payload.get("positioning"),
            "taker_flow": payload.get("taker_flow"),
            "fear_greed": {
                "value": fng.get("value"),
                "classification": fng.get("classification"),
            } if fng.get("ok") else None,
            "news": {"symbol": matched[:4], "market": market[:5]},
            "bias": self._bias(payload, direction, price_change_24h),
        }
        result["_expires"] = now + self.ttl
        with self._lock:
            self._cache[symbol] = result
        return result

    @staticmethod
    def format_for_prompt(dossier: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not dossier:
            return {"status": "UNAVAILABLE", "sources": []}
        return {
            "status": dossier.get("status"),
            "generated_at": dossier.get("generated_at"),
            "healthy_sources": dossier.get("healthy_sources"),
            "sources": [
                {k: v for k, v in item.items() if k in ("name", "ok", "latency_ms", "error")}
                for item in dossier.get("sources", [])
            ],
            "funding": dossier.get("funding"),
            "open_interest": dossier.get("open_interest"),
            "positioning": dossier.get("positioning"),
            "taker_flow": dossier.get("taker_flow"),
            "fear_greed": dossier.get("fear_greed"),
            "news": dossier.get("news"),
            "bias": dossier.get("bias"),
        }
