from typing import Dict, Any
import config
from indicators import calculate_ema_and_metrics
from config import (
    MACRO_BENCHMARK_SYMBOL,
    MACRO_CIRCUIT_BREAKER_ENABLED,
    MACRO_MIN_BTC_RSI
)


class MacroMarketSentinel:
    """
    Macro Market Sentinel & Bitcoin Regime Guard:
    Monitors Bitcoin (BTCUSDT) macro trend & volatility.
    Acts as a global Circuit Breaker: If Bitcoin is in a severe selloff or breakdown,
    altcoin long entries are instantly suspended to protect capital from high-beta market crashes.
    """

    def __init__(self, binance_client, llm_client=None):
        self.client = binance_client
        self.llm = llm_client
        self.benchmark_symbol = MACRO_BENCHMARK_SYMBOL
        self.circuit_breaker_enabled = MACRO_CIRCUIT_BREAKER_ENABLED
        self.min_btc_rsi = MACRO_MIN_BTC_RSI

    def evaluate_macro_health(self) -> Dict[str, Any]:
        """
        Pulls latest BTCUSDT market data and calculates macro health status.
        """
        try:
            klines = self.client.get_klines(self.benchmark_symbol, interval="15m", limit=60)
            if len(klines) < 50:
                return {
                    "symbol": self.benchmark_symbol,
                    "safe_to_trade": True,
                    "status": "INSUFFICIENT_DATA",
                    "circuit_breaker": False,
                    "rationale": "Insufficient historical klines for BTCUSDT, defaulting to normal operations."
                }

            closes = [k["close"] for k in klines]
            btc_price = closes[-1]
            
            # Use consolidated indicator calculation (calculate once, reuse)
            indicator_result = calculate_ema_and_metrics(closes, "BTCUSDT")
            if isinstance(indicator_result, list):
                ema_series = indicator_result
                btc_rsi = ema_series[-1]["rsi"] if len(ema_series) > 0 else 50.0
            elif isinstance(indicator_result, dict):
                btc_rsi = indicator_result.get("rsi") or 50.0
                ema_series = [indicator_result]
            
            ema21 = ema_series[-1]["ema21"] if len(ema_series) > 0 and "ema21" in ema_series[-1] else btc_price
            ema50 = ema_series[-1]["ema50"] if len(ema_series) > 0 and "ema50" in ema_series[-1] else btc_price

            # Check 4-hour drop
            price_4h_ago = closes[-16] if len(closes) >= 16 else closes[0]
            drop_4h_pct = ((btc_price - price_4h_ago) / price_4h_ago) * 100.0

            circuit_breaker = False
            safe_to_trade = True
            reasons = []

            # 1. Extreme RSI breakdown check (Panic selling)
            if btc_rsi < self.min_btc_rsi:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append(f"BTC RSI ({btc_rsi:.1f}) is oversold/collapsing below {self.min_btc_rsi}")

            # 2. Steep 4h dump check
            if drop_4h_pct < -2.5:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append(f"BTC experienced sharp 4h dump of {drop_4h_pct:.2f}%")

            # 3. Severe trend breakdown
            if btc_price < ema50 and ema21 < ema50 and drop_4h_pct < -1.0:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append("BTC is trading below EMA50 with bearish EMA death cross")

            if not self.circuit_breaker_enabled:
                safe_to_trade = True

            if safe_to_trade:
                if btc_price > ema21 > ema50:
                    regime = "STRONG_BULLISH"
                    rationale = f"Bitcoin in strong bullish expansion (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Altcoin longs approved."
                elif btc_price > ema50:
                    regime = "HEALTHY_CONSOLIDATION"
                    rationale = f"Bitcoin holding above key EMA50 support (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Altcoin longs approved."
                else:
                    regime = "NEUTRAL_CAUTION"
                    rationale = f"Bitcoin displaying neutral behavior (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Normal position limits apply."
            else:
                regime = "CIRCUIT_BREAKER_ACTIVE"
                rationale = f"CIRCUIT BREAKER TRIPPED: {' | '.join(reasons)}. All new altcoin entries suspended."

            return {
                "symbol": self.benchmark_symbol,
                "price": btc_price,
                "rsi": round(btc_rsi, 1),
                "ema21": round(ema21, 2),
                "ema50": round(ema50, 2),
                "drop_4h_pct": round(drop_4h_pct, 2),
                "safe_to_trade": safe_to_trade,
                "circuit_breaker": circuit_breaker,
                "regime": regime,
                "rationale": rationale
            }
        except Exception as e:
            # Fallback safe mode
            return {
                "symbol": self.benchmark_symbol,
                "price": 0.0,
                "rsi": 50.0,
                "safe_to_trade": True,
                "circuit_breaker": False,
                "regime": "FALLBACK_NORMAL",
                "rationale": f"Benchmark check bypassed due to API error: {e}"
            }
