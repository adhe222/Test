import unittest
from unittest.mock import MagicMock, patch

import config
from agents.momentum import MomentumAnalystAgent
from agents.orderbook import OrderbookAgent


def closed_candles(direction, count):
    sign = -1 if direction == "SHORT" else 1
    changes = (0.20, 0.18, -0.25, 0.16, -0.12, 0.14)
    price = 100.0
    rows = []
    for index in range(count):
        opened = price
        price += sign * changes[index % len(changes)]
        rows.append({
            "open": opened,
            "high": max(opened, price) + 0.06,
            "low": min(opened, price) - 0.06,
            "close": price,
            "volume": 2000.0 if index >= count - 3 else 1000.0,
            "close_time": 1000 + index,
        })
    return rows


class CandleFixtureClient:
    def __init__(self, direction):
        self.feeds = {
            "15m": closed_candles(direction, 96),
            "1h": closed_candles(direction, 60),
            "4h": closed_candles(direction, 36),
            "5m": closed_candles(direction, 6),
        }

    def get_klines(self, symbol, interval="15m", limit=100):
        return self.feeds[interval][-limit:]

    def get_funding_rate(self, symbol):
        return None


class TestDirectionalMomentum(unittest.TestCase):
    def test_bearish_short_passes_closed_bar_confirmation(self):
        result = MomentumAnalystAgent(CandleFixtureClient("SHORT")).analyze_symbol(
            "FIXTUREUSDT", direction="SHORT"
        )
        self.assertTrue(result["passed"], result["gate_failures"])
        self.assertTrue(result["htf_bearish"])
        self.assertEqual(result["htf_score"], 16)
        self.assertEqual(result["gate_failures"], [])


class TestDirectionalMomentumSafety(unittest.TestCase):
    def test_bullish_long_still_passes(self):
        result = MomentumAnalystAgent(CandleFixtureClient("LONG")).analyze_symbol("FIXTUREUSDT")
        self.assertTrue(result["passed"], result["gate_failures"])
        self.assertEqual(result["htf_score"], 16)

    def test_short_rejects_bullish_higher_timeframes(self):
        client = CandleFixtureClient("SHORT")
        client.feeds["1h"] = closed_candles("LONG", 60)
        client.feeds["4h"] = closed_candles("LONG", 36)
        result = MomentumAnalystAgent(client).analyze_symbol("FIXTUREUSDT", direction="SHORT")
        self.assertFalse(result["passed"])
        self.assertEqual(result["htf_score"], 0)
        self.assertIn("Higher-timeframe structure is not bearish", result["gate_failures"])

    def test_long_rejects_bearish_higher_timeframes(self):
        client = CandleFixtureClient("LONG")
        client.feeds["1h"] = closed_candles("SHORT", 60)
        client.feeds["4h"] = closed_candles("SHORT", 36)
        result = MomentumAnalystAgent(client).analyze_symbol("FIXTUREUSDT")
        self.assertFalse(result["passed"])
        self.assertIn("Higher-timeframe structure bearish", result["gate_failures"])

    def test_short_rejects_mixed_higher_timeframe_trends(self):
        client = CandleFixtureClient("SHORT")
        client.feeds["1h"] = closed_candles("LONG", 60)
        result = MomentumAnalystAgent(client).analyze_symbol("FIXTUREUSDT", direction="SHORT")
        self.assertFalse(result["passed"])
        self.assertIn("Higher-timeframe structure is not bearish", result["gate_failures"])

    def test_missing_four_hour_data_cannot_confirm_either_direction(self):
        for direction in ("LONG", "SHORT"):
            with self.subTest(direction=direction):
                client = CandleFixtureClient(direction)
                client.feeds["4h"] = []
                result = MomentumAnalystAgent(client).analyze_symbol("FIXTUREUSDT", direction=direction)
                self.assertFalse(result["passed"])
                self.assertFalse(result["htf_available"])
                self.assertTrue(any("unavailable" in reason.lower() for reason in result["gate_failures"]))


class DepthFixtureClient:
    def __init__(self, bid_quantity=10.0, ask_quantity=30.0, ask_price=100.0):
        self.depth = {
            "bids": [[99.99, bid_quantity]],
            "asks": [[ask_price, ask_quantity]],
        }

    def get_orderbook(self, symbol, limit=20):
        return self.depth


class TestDirectionalOrderbook(unittest.TestCase):
    def test_short_accepts_seller_dominated_depth(self):
        result = OrderbookAgent(DepthFixtureClient()).inspect_orderbook(
            "FIXTUREUSDT", direction="SHORT"
        )
        self.assertTrue(result["passed"], result["reason"])
        self.assertLess(result["imbalance"], -0.35)
        self.assertEqual(result["direction"], "SHORT")

    def test_short_rejects_buyer_absorption(self):
        result = OrderbookAgent(DepthFixtureClient(30.0, 10.0)).inspect_orderbook(
            "FIXTUREUSDT", direction="SHORT"
        )
        self.assertFalse(result["passed"])
        self.assertIn("buy wall", result["reason"])

    def test_long_still_rejects_sell_wall(self):
        result = OrderbookAgent(DepthFixtureClient()).inspect_orderbook("FIXTUREUSDT")
        self.assertFalse(result["passed"])
        self.assertEqual(result["direction"], "LONG")

    def test_long_accepts_buyer_support(self):
        result = OrderbookAgent(DepthFixtureClient(30.0, 10.0)).inspect_orderbook("FIXTUREUSDT")
        self.assertTrue(result["passed"], result["reason"])

    def test_spread_guard_applies_to_both_directions(self):
        for direction in ("LONG", "SHORT"):
            with self.subTest(direction=direction):
                result = OrderbookAgent(DepthFixtureClient(ask_price=101.0)).inspect_orderbook(
                    "FIXTUREUSDT", direction=direction
                )
                self.assertFalse(result["passed"])
                self.assertIn("Wide spread", result["reason"])

    def test_empty_book_is_rejected_for_both_directions(self):
        for direction in ("LONG", "SHORT"):
            with self.subTest(direction=direction):
                client = DepthFixtureClient()
                client.depth = {"bids": [], "asks": []}
                result = OrderbookAgent(client).inspect_orderbook("FIXTUREUSDT", direction=direction)
                self.assertFalse(result["passed"])
                self.assertEqual(result["direction"], direction)

    def test_invalid_direction_cannot_pass(self):
        result = OrderbookAgent(DepthFixtureClient()).inspect_orderbook("FIXTUREUSDT", direction="INVALID")
        self.assertFalse(result["passed"])
        self.assertEqual(result["reason"], "Invalid trade direction")


class TestDirectionalPipeline(unittest.TestCase):
    def test_short_direction_reaches_upstream_orderbook(self):
        import orchestrator as module

        engine = module.TradingOrchestrator.__new__(module.TradingOrchestrator)
        engine.llm = MagicMock()
        engine.llm.status_summary = {}
        engine.portfolio = MagicMock()
        engine.portfolio.update_and_monitor_positions.return_value = []
        engine.portfolio.get_open_positions.return_value = []
        engine.portfolio.get_equity.return_value = 1000.0
        engine.portfolio.state = {"cash_usdt": 1000.0}
        engine._adaptive_tightening = lambda: {"steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        engine._daily_loss_limit_hit = lambda: False
        engine._symbols_in_cooldown = lambda: {}
        engine.macro_sentinel = MagicMock()
        engine.macro_sentinel.evaluate_macro_health.return_value = {
            "safe_to_trade": True, "safe_for_shorts": True
        }
        engine.scanner = MagicMock()
        engine.scanner.scan_trending_pairs.return_value = [{
            "symbol": "FIXTUREUSDT", "direction": "SHORT", "price": 100.0,
            "price_change_24h": -3.0, "quote_volume_24h": 5000000.0,
            "count_trades": 100000,
        }]
        engine.orderbook_data_agent = MagicMock()
        engine.orderbook_data_agent.inspect_orderbook.return_value = {"passed": True, "imbalance": -0.5}
        engine.momentum_data_agent = MagicMock()
        engine.momentum_data_agent.analyze_symbol.return_value = {
            "passed": False, "score": 0, "gate_failures": ["Fixture prevents execution"]
        }
        engine.risk_data_agent = MagicMock()
        engine.risk_data_agent.evaluate_risk.return_value = {"approved": True, "side": "SELL"}
        for name in ("narrative_spec", "price_action_spec", "exhaustion_spec", "microstructure_spec", "sentiment_spec", "cro_spec", "profit_spec", "executive_spec"):
            setattr(engine, name, MagicMock())
        engine._deterministic_specialist_report = lambda *args: {}
        with patch.object(module, "consciousness_engine"):
            result = engine.run_cycle()
        self.assertEqual(len(result["candidates_evaluated"]), 1)
        engine.orderbook_data_agent.inspect_orderbook.assert_called_once_with(
            "FIXTUREUSDT", direction="SHORT"
        )
        engine.portfolio.execute_trade.assert_not_called()
