/* Aegis Telemetry — formatting + animation primitives */
window.AegisUtil = (() => {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const previous = Object.create(null);

  const safe = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
  const num = (v, d = 2) => safe(v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
  const money = (v, d = 2) => 'US$ ' + num(v, d);
  const signed = (v, d = 2) => (safe(v) >= 0 ? '+' : '') + money(v, d);
  const pct = (v, d = 2) => (safe(v) >= 0 ? '+' : '') + num(v, d) + '%';
  const cls = (v) => (safe(v) > 0 ? 'positive' : safe(v) < 0 ? 'negative' : 'neutral');
  const esc = (s) => String(s ?? '').replace(/[&<>'"]/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]
  ));
  const title = (s) => String(s ?? '').replace(/_/g, ' ');

  function setText(id, text) {
    const el = typeof id === 'string' ? $('#' + id) : id;
    if (!el) return;
    el.classList.remove('skeleton');
    el.textContent = text;
  }

  function setHTML(id, html) {
    const el = typeof id === 'string' ? $('#' + id) : id;
    if (!el) return;
    el.classList.remove('skeleton');
    el.innerHTML = html;
  }

  /* Animated count-up driven by requestAnimationFrame (GPU-light, text only). */
  function countTo(id, value, format, ms = 520) {
    const el = $('#' + id);
    if (!el) return;
    el.classList.remove('skeleton');
    const end = safe(value);
    const start = Number.isFinite(previous[id]) ? previous[id] : end;
    previous[id] = end;
    if (reduced || start === end) { el.innerHTML = format(end); return; }
    const t0 = performance.now();
    const step = (t) => {
      const p = Math.min(1, (t - t0) / ms);
      const eased = 1 - Math.pow(1 - p, 3);
      el.innerHTML = format(start + (end - start) * eased);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* Green/red pulse when a tracked value changes direction. */
  function flash(id, next) {
    const el = $('#' + id);
    if (!el) return;
    const key = 'flash_' + id;
    const old = previous[key];
    previous[key] = safe(next);
    if (old === undefined || old === safe(next) || reduced) return;
    el.classList.remove('flash-up', 'flash-down');
    void el.offsetWidth;
    el.classList.add(safe(next) > old ? 'flash-up' : 'flash-down');
  }

  function setProgress(id, percent) {
    const el = $('#' + id);
    if (el) el.style.width = Math.max(0, Math.min(100, safe(percent))) + '%';
  }

  function formatTime(s) {
    if (!s) return '—';
    const d = new Date(s);
    if (isNaN(d.getTime())) return String(s).slice(0, 16);
    return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }

  return { reduced, $, $$, safe, num, money, signed, pct, cls, esc, title,
           setText, setHTML, countTo, flash, setProgress, formatTime };
})();

window.AegisTheme = (() => {
  'use strict';
  const listeners = [];
  function current() {
    return document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
  }
  function apply(theme) {
    const t = theme === 'light' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', t);
    try { localStorage.setItem('aegis-theme', t); } catch (e) {}
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t === 'light' ? '#f4f6f8' : '#070d18');
    listeners.forEach((cb) => { try { cb(t); } catch (e) {} });
  }
  function toggle() { apply(current() === 'light' ? 'dark' : 'light'); }
  function onChange(cb) { if (typeof cb === 'function') listeners.push(cb); }
  return { current, apply, toggle, onChange };
})();
