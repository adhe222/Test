from typing import Dict, Any, List
import config
from ai_engine import LLMClient
from config import (
    MIN_PRICE_CHANGE_24H,
    MAX_PRICE_CHANGE_24H,
    MIN_24H_VOLUME_USDT,
    MAX_ALLOWABLE_SPREAD_PCT,
    MIN_RISK_REWARD_RATIO
)


# =====================================================================
# BASE SUB-AGENT (STAFF / EMPLOYEE)
# =====================================================================

class BaseStaffAgent:
    """Base class for departmental staff sub-agents with individual persona and system role."""
    def __init__(self, name: str, role_title: str, llm_client: LLMClient, system_role: str = ""):
        self.name = name
        self.role_title = role_title
        self.llm = llm_client
        self.system_role = system_role


# =====================================================================
# DEPARTMENT 1: MARKET FLOW & NARRATIVE DIVISION
# =====================================================================

class VolumeVelocityStaff(BaseStaffAgent):
    """Sub-Agent 1.1: Analyzes 24h volume magnitude and velocity (Higher Minimum)."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Volume Velocity Analyst",
            "Market Flow Staff",
            llm_client,
            system_role="Kamu adalah Volume Velocity Analyst di divisi Market Flow. Tugasmu: Memverifikasi volume transaksi 24 jam di atas ambang batas tinggi untuk menjamin likuiditas institusional."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        vol = data.get("quote_volume_24h", 0.0)
        if vol >= 50_000_000:
            res = {"verdict": "APPROVE", "conviction": 98, "rationale": f"Institutional-tier volume (${vol/1e6:.1f}M > $50M)", "signal": "Elite Liquidity Tier"}
        elif vol >= 25_000_000:
            res = {"verdict": "APPROVE", "conviction": 92, "rationale": f"High institutional volume (${vol/1e6:.1f}M > $25M)", "signal": "Institutional Volume"}
        elif vol >= config.MIN_24H_VOLUME_USDT:
            res = {"verdict": "APPROVE", "conviction": 82, "rationale": f"Adequate liquid volume (${vol/1e6:.1f}M >= ${config.MIN_24H_VOLUME_USDT/1e6:.0f}M threshold)", "signal": "Acceptable Liquidity"}
        else:
            res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Illiquid volume (${vol/1e6:.1f}M below ${config.MIN_24H_VOLUME_USDT/1e6:.0f}M minimum)", "signal": "Veto: Insufficient Liquidity"}
        res["system_role"] = self.system_role
        return res


class SmartMoneyFlowStaff(BaseStaffAgent):
    """Sub-Agent 1.2: Evaluates trade distribution and smart money footprint."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Smart Money Tracker",
            "Market Flow Staff",
            llm_client,
            system_role="Kamu adalah Smart Money Tracker di divisi Market Flow. Tugasmu: Mengaudit rata-rata ukuran transaksi per order untuk mendeteksi jejak whale vs retail."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        trades = data.get("count_trades", 0)
        vol = data.get("quote_volume_24h", 0.0)
        avg_trade_size = (vol / max(1, trades)) if trades > 0 else 0

        if avg_trade_size >= 300:
            res = {"verdict": "APPROVE", "conviction": 90, "rationale": f"High avg trade size (${avg_trade_size:.0f}) signals smart money/whales", "signal": "Whale Footprint Detected"}
        elif avg_trade_size >= 100:
            res = {"verdict": "APPROVE", "conviction": 75, "rationale": f"Balanced trade sizing (${avg_trade_size:.0f}) across retail & algorithmic flow", "signal": "Balanced Order Flow"}
        else:
            res = {"verdict": "APPROVE", "conviction": 65, "rationale": f"Small average trade size (${avg_trade_size:.0f}), predominantly retail", "signal": "Retail Dominated"}
        res["system_role"] = self.system_role
        return res


class MomentumCorridorStaff(BaseStaffAgent):
    """Sub-Agent 1.3: Verifies 24h price gains are inside the sustainable trend window (+0.5% to +55%)."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Trend Corridor Sentinel",
            "Market Flow Staff",
            llm_client,
            system_role="Kamu adalah Trend Corridor Sentinel di divisi Market Flow. Tugasmu: Menjaga kenaikan harga 24 jam berada dalam koridor momentum yang sehat dan berkelanjutan (+0.5% s.d. +55%)."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        chg = data.get("price_change_24h", 0.0)
        direction = data.get("direction", "LONG")
        if direction == "SHORT":
            if -20.0 <= chg <= -MIN_PRICE_CHANGE_24H:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Ideal breakdown momentum corridor ({chg:.2f}%)", "signal": "Optimal Short Momentum"}
            elif -MAX_PRICE_CHANGE_24H <= chg < -20.0:
                res = {"verdict": "APPROVE", "conviction": 75, "rationale": f"Aggressive breakdown ({chg:.2f}%), elevated volatility", "signal": "Aggressive Short"}
            else:
                res = {"verdict": "REJECT", "conviction": 15, "rationale": f"Veto: Abnormal price drop ({chg:.2f}%) outside safe window", "signal": "Veto: Unsafe Corridor"}
        else:
            if MIN_PRICE_CHANGE_24H <= chg <= 20.0:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Ideal early/mid momentum corridor (+{chg:.2f}%)", "signal": "Optimal Momentum Corridor"}
            elif 20.0 < chg <= MAX_PRICE_CHANGE_24H:
                res = {"verdict": "APPROVE", "conviction": 75, "rationale": f"Aggressive extension (+{chg:.2f}%), elevated volatility", "signal": "Aggressive Momentum"}
            else:
                res = {"verdict": "REJECT", "conviction": 15, "rationale": f"Veto: Abnormal price velocity (+{chg:.2f}%) outside safe window", "signal": "Veto: Unsafe Corridor"}
        res["system_role"] = self.system_role
        return res


class MarketNarrativeSpecialist:
    """Lead: Head of Flow & Volume Strategy (🌐)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Market Flow & Narrative Division"
        self.lead_title = "Head of Flow Strategy"
        self.icon = "🌐"
        self.llm = llm_client
        self.staff = [
            VolumeVelocityStaff(llm_client),
            SmartMoneyFlowStaff(llm_client),
            MomentumCorridorStaff(llm_client)
        ]

    def analyze(self, ticker_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(ticker_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": min(s["conviction"] for s in staff_reports),
                    "rationale": f"Department Veto: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Flow approved: Solid volume & smart money participation confirmed in healthy corridor.",
                "signal": "Flow Consensus"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head of Market Flow & Volume Strategy",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Menganalisis volume transaksi 24 jam dan jejak smart money/whales pada Binance Spot. "
                "Validasi apakah likuiditas aman ($3M+) dan momentum harga berada di koridor yang sehat (+0.5% s.d. +55%)."
            ),
            context_data={
                "symbol": ticker_data.get("symbol"),
                "price": ticker_data.get("price"),
                "price_change_24h": ticker_data.get("price_change_24h"),
                "quote_volume_24h": ticker_data.get("quote_volume_24h"),
                "staff_reports": staff_reports
            },
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = min(llm_res.get("conviction", 80), min(s["conviction"] for s in staff_reports)) if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Department Veto: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 2: TECHNICAL & PRICE ACTION DIVISION
# =====================================================================

class TrendAlignmentStaff(BaseStaffAgent):
    """Sub-Agent 2.1: Evaluates EMA 9/21/50 trend stack."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "EMA Trend Alignment Quant",
            "Price Action Staff",
            llm_client,
            system_role="Kamu adalah EMA Trend Alignment Quant di divisi Price Action. Tugasmu: Memvalidasi struktur tren EMA 9 > 21 > 50 pada candle 15m dan 1h."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        price = mom.get("price", 0.0)
        ema9 = mom.get("ema9", 0.0)
        ema21 = mom.get("ema21", 0.0)
        ema50 = mom.get("ema50", 0.0)
        score = mom.get("score", 0)
        direction = mom.get("direction", data.get("direction", "LONG"))

        if direction == "SHORT":
            if (0 < price < ema9 < ema21 < ema50) or (score >= 65 and (price == 0 or ema21 == 0)):
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": "Bearish EMA cascade: Price < EMA9 < EMA21 < EMA50", "signal": "Bearish Trend Confluence"}
            elif 0 < price < ema21 and ema9 < ema21:
                res = {"verdict": "APPROVE", "conviction": 80, "rationale": "Moderate trend: Price & EMA9 below EMA21", "signal": "Moderate Bearish Alignment"}
            else:
                res = {"verdict": "REJECT", "conviction": 30, "rationale": "Price held above EMA21, counter-trend risk", "signal": "Bullish / Counter Trend"}
        else:
            if (price > ema9 > ema21 > ema50) or (score >= 65 and (price == 0 or ema21 == 0)):
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": "Bullish EMA stack: Price > EMA9 > EMA21 > EMA50", "signal": "Bullish Trend Confluence"}
            elif price > ema21 and ema9 > ema21:
                res = {"verdict": "APPROVE", "conviction": 80, "rationale": "Moderate trend: Price & EMA9 above EMA21", "signal": "Moderate Bullish Alignment"}
            else:
                res = {"verdict": "REJECT", "conviction": 30, "rationale": "Price broke below EMA21, correction underway", "signal": "Bearish / Broken Trend"}
        res["system_role"] = self.system_role
        return res


class CandleGeometryStaff(BaseStaffAgent):
    """Sub-Agent 2.2: Audits candlestick body vs wick rejection."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Candle Geometry Analyst",
            "Price Action Staff",
            llm_client,
            system_role="Kamu adalah Candle Geometry Analyst di divisi Price Action. Tugasmu: Mengukur rasio body close dan menolak candle dengan upper wick rejection > 35%."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        candle = mom.get("candle", {})
        is_bullish = candle.get("is_bullish", False)
        close_ratio = candle.get("close_ratio", 0.5)
        direction = mom.get("direction", data.get("direction", "LONG"))

        if direction == "SHORT":
            if not is_bullish and close_ratio <= 0.30:
                res = {"verdict": "APPROVE", "conviction": 90, "rationale": f"High seller closing dominance ({close_ratio:.2f}) indicates aggressive supply", "signal": "Strong Bearish Close"}
            elif not is_bullish:
                res = {"verdict": "APPROVE", "conviction": 75, "rationale": f"Bearish body close ({close_ratio:.2f})", "signal": "Standard Bearish Close"}
            else:
                res = {"verdict": "APPROVE", "conviction": 60, "rationale": "Bullish bounce close, caution against shorting bottom", "signal": "Bullish Bounce Caution"}
        else:
            if is_bullish and close_ratio >= 0.70:
                res = {"verdict": "APPROVE", "conviction": 90, "rationale": f"High closing ratio ({close_ratio:.2f}) indicates aggressive buyer control", "signal": "Strong Bullish Close"}
            elif is_bullish:
                res = {"verdict": "APPROVE", "conviction": 75, "rationale": f"Bullish body close ({close_ratio:.2f})", "signal": "Standard Bullish Close"}
            else:
                res = {"verdict": "APPROVE", "conviction": 60, "rationale": "Bearish candle close, minor upper wick resistance", "signal": "Wick Rejection Caution"}
        res["system_role"] = self.system_role
        return res


class VolumeExpansionStaff(BaseStaffAgent):
    """Sub-Agent 2.3: Audits volume expansion factor vs 20-period SMA."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Volume Surge Auditor",
            "Price Action Staff",
            llm_client,
            system_role="Kamu adalah Volume Surge Auditor di divisi Price Action. Tugasmu: Mengukur volume expansion factor terhadap rata-rata 20 candle terakhir."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        surge = mom.get("volume_surge", 1.0)

        if surge >= 1.5:
            res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Exceptional volume surge ({surge:.2f}x average)", "signal": "Heavy Volume Expansion"}
        elif surge >= 1.0:
            res = {"verdict": "APPROVE", "conviction": 80, "rationale": f"Healthy active volume ({surge:.2f}x average)", "signal": "Active Expansion"}
        else:
            res = {"verdict": "APPROVE", "conviction": 65, "rationale": f"Below average volume ({surge:.2f}x), cautious breakout", "signal": "Low Volume Anomaly"}
        res["system_role"] = self.system_role
        return res


class PriceActionSpecialist:
    """Lead: Head Quantitative Chartist (📈)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Technical Price Action Division"
        self.lead_title = "Head Quantitative Chartist"
        self.icon = "📈"
        self.llm = llm_client
        self.staff = [
            TrendAlignmentStaff(llm_client),
            CandleGeometryStaff(llm_client),
            VolumeExpansionStaff(llm_client)
        ]

    def analyze(self, technical_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(technical_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": min(s["conviction"] for s in staff_reports),
                    "rationale": f"Price Action Veto: {vetoes[0]['staff_name']} flagged broken structure: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Technical structure confirmed: EMA trend and candlestick breakout geometry align.",
                "signal": "Trend Alignment"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head Quantitative Chartist",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Memvalidasi susunan tren EMA (EMA 9 > EMA 21 > EMA 50), geometri penutupan candlestick, "
                "dan konfirmasi momentum tren time-frame 15m & 1h. Tolak jika candle memiliki sumbu atas panjang atau tren patah."
            ),
            context_data=technical_data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = min(llm_res.get("conviction", 80), min(s["conviction"] for s in staff_reports)) if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Price Action Veto: {vetoes[0]['staff_name']} flagged: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 3: MOMENTUM & EXHAUSTION DIVISION
# =====================================================================

class RSIZoneAuditorStaff(BaseStaffAgent):
    """Sub-Agent 3.1: Validates RSI is in the prime acceleration band (Tighter)."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "RSI Velocity Auditor",
            "Momentum Staff",
            llm_client,
            system_role="Kamu adalah RSI Velocity Auditor di divisi Momentum RSI. Tugasmu: Memverifikasi akselerasi RSI berada pada zona prime 50-68 untuk menghindari overbought."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        rsi = mom.get("rsi", 50.0)
        direction = mom.get("direction", data.get("direction", "LONG"))

        if direction == "SHORT":
            short_min = getattr(config, "SHORT_RSI_ENTRY_MIN", 26.0)
            short_max = getattr(config, "SHORT_RSI_ENTRY_MAX", 55.0)
            if 30.0 <= rsi <= 48.0:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Prime short RSI breakdown zone ({rsi:.1f}) - clean seller momentum", "signal": "Optimal Short RSI Zone"}
            elif short_min <= rsi <= short_max:
                res = {"verdict": "APPROVE", "conviction": 78, "rationale": f"Acceptable short RSI momentum ({rsi:.1f})", "signal": "Healthy Short Momentum"}
            elif rsi < short_min:
                res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Veto: RSI {rsi:.1f} severely oversold, high snapback risk", "signal": "Veto: Oversold Climax"}
            else:
                res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Veto: RSI {rsi:.1f} too high for short breakdown", "signal": "Veto: Bullish RSI"}
        else:
            if 52.0 <= rsi <= 68.0:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Prime RSI momentum zone ({rsi:.1f}) - optimal acceleration", "signal": "Optimal Momentum Zone"}
            elif config.RSI_ENTRY_MIN <= rsi < 52.0 or 68.0 < rsi <= 74.0:
                res = {"verdict": "APPROVE", "conviction": 78, "rationale": f"Acceptable RSI momentum ({rsi:.1f}), building strength", "signal": "Healthy Momentum Build"}
            elif 74.0 < rsi <= 76.0:
                res = {"verdict": "REJECT", "conviction": 30, "rationale": f"Elevated RSI warning ({rsi:.1f}), approaching overbought danger zone", "signal": "Caution: Approaching Overbought"}
            else:
                res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Veto: RSI {rsi:.1f} outside healthy momentum range", "signal": "Veto: Weak/Overextended RSI"}
        res["system_role"] = self.system_role
        return res


class OverboughtDivergenceStaff(BaseStaffAgent):
    """Sub-Agent 3.2: Prevents buying at tops - Tighter Early Warning."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Overbought Divergence Guard",
            "Momentum Staff",
            llm_client,
            system_role="Kamu adalah Overbought Divergence Guard di divisi Momentum RSI. Tugasmu: Memveto transaksi jika RSI > 74 untuk mencegah beli di pucuk."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        rsi = mom.get("rsi", 50.0)
        direction = mom.get("direction", data.get("direction", "LONG"))

        if direction == "SHORT":
            short_min = getattr(config, "SHORT_RSI_ENTRY_MIN", 26.0)
            if rsi < short_min:
                res = {"verdict": "REJECT", "conviction": 85, "rationale": f"Oversold exhaustion detected (RSI {rsi:.1f}) - high probability of dead cat bounce", "signal": "VETO: Oversold Exhaustion"}
            else:
                res = {"verdict": "APPROVE", "conviction": 92, "rationale": f"RSI {rsi:.1f} shows sufficient breakdown room before exhaustion", "signal": "Safe Short Momentum"}
        else:
            if rsi > 74.0:
                res = {"verdict": "REJECT", "conviction": 85, "rationale": f"Early overbought warning detected (RSI {rsi:.1f}) - high probability of mean-reversion pullback", "signal": "VETO: Early Overbought Alert"}
            else:
                res = {"verdict": "APPROVE", "conviction": 92, "rationale": f"RSI {rsi:.1f} shows safe momentum headroom before exhaustion zone", "signal": "No Overbought Risk"}
        res["system_role"] = self.system_role
        return res


class MeanReversionGuardStaff(BaseStaffAgent):
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Mean Reversion Quant",
            "Momentum Staff",
            llm_client,
            system_role="Kamu adalah Mean Reversion Quant di divisi Momentum RSI. Tugasmu: Mengukur jarak regangan harga dari EMA21 untuk mencegah snapback kerugian."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        price = mom.get("price", 1.0)
        ema21 = mom.get("ema21", price)
        distance_pct = abs((price - ema21) / max(1e-9, ema21)) * 100.0

        if distance_pct <= 6.0:
            res = {"verdict": "APPROVE", "conviction": 90, "rationale": f"Price is within {distance_pct:.2f}% of EMA21 (healthy base)", "signal": "Tight Base"}
        elif distance_pct <= 12.0:
            res = {"verdict": "APPROVE", "conviction": 70, "rationale": f"Extended {distance_pct:.2f}% from EMA21, trail stops closely", "signal": "Moderate Extension"}
        else:
            res = {"verdict": "REJECT", "conviction": 25, "rationale": f"Parabolic overextension ({distance_pct:.2f}% from EMA21)", "signal": "Veto: Parabolic Stretch"}
        res["system_role"] = self.system_role
        return res


class MomentumExhaustionSpecialist:
    """Lead: Head Momentum & Pullback Auditor (⚡)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Momentum Exhaustion Division"
        self.lead_title = "Head Momentum Auditor"
        self.icon = "⚡"
        self.llm = llm_client
        self.staff = [
            RSIZoneAuditorStaff(llm_client),
            OverboughtDivergenceStaff(llm_client),
            MeanReversionGuardStaff(llm_client)
        ]

    def analyze(self, technical_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(technical_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": min(s["conviction"] for s in staff_reports),
                    "rationale": f"Momentum Veto: {vetoes[0]['staff_name']} triggered overbought protection: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Momentum health verified: Healthy RSI acceleration with zero overbought exhaustion.",
                "signal": "Momentum Verified"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head Momentum & Exhaustion Auditor",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugas utamamu: Melindungi modal dari overbought tops dan momentum exhaustion. "
                "Tolak transaksi dengan VETO mutlak jika RSI 15m > 75 atau terdeteksi divergensi kelelahan tren."
            ),
            context_data=technical_data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = min(llm_res.get("conviction", 80), min(s["conviction"] for s in staff_reports)) if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Momentum Veto: {vetoes[0]['staff_name']} triggered overbought protection: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 4: ORDER BOOK MICROSTRUCTURE DIVISION
# =====================================================================

class SpreadSlippageStaff(BaseStaffAgent):
    """Sub-Agent 4.1: Protects against spread friction and slippage."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Spread & Slippage Guard",
            "Microstructure Staff",
            llm_client,
            system_role="Kamu adalah Spread & Slippage Guard di divisi Microstructure. Tugasmu: Memveto jika spread bid/ask > 0.20% untuk meminimalkan slippage eksekusi."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ob = data.get("orderbook_data", {})
        spread = ob.get("spread_pct", 1.0)
        if spread <= 0.05:
            res = {"verdict": "APPROVE", "conviction": 98, "rationale": f"Institutional spread ({spread:.3f}%) minimizes slippage", "signal": "Ultra Tight Spread"}
        elif spread <= MAX_ALLOWABLE_SPREAD_PCT:
            res = {"verdict": "APPROVE", "conviction": 80, "rationale": f"Acceptable spread ({spread:.3f}% <= {MAX_ALLOWABLE_SPREAD_PCT}%)", "signal": "Acceptable Spread"}
        else:
            res = {"verdict": "REJECT", "conviction": 10, "rationale": f"Veto: Spread ({spread:.3f}%) exceeds safety threshold ({MAX_ALLOWABLE_SPREAD_PCT}%)", "signal": "Veto: Wide Spread"}
        res["system_role"] = self.system_role
        return res


class DepthImbalanceStaff(BaseStaffAgent):
    """Sub-Agent 4.2: Measures top 20 bid depth vs ask depth wall imbalance."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Depth Imbalance Quant",
            "Microstructure Staff",
            llm_client,
            system_role="Kamu adalah Depth Imbalance Quant di divisi Microstructure. Tugasmu: Menimbang rasio antrean beli vs antrean jual di 15 level orderbook."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ob = data.get("orderbook_data", {})
        imb = ob.get("imbalance", 0.0)
        direction = ob.get("direction", data.get("direction", "LONG"))

        # Thresholds come from the same config the upstream hard gate uses
        # (MIN_ORDERBOOK_IMBALANCE / SHORT_MAX_ORDERBOOK_IMBALANCE). They used
        # to be -0.25 / +0.25 here vs -0.35 / +0.40 upstream, so a book the
        # hard gate accepted (SOLUSDT -0.296) was vetoed one layer later.
        long_floor = getattr(config, "MIN_ORDERBOOK_IMBALANCE", -0.35)
        short_ceiling = getattr(config, "SHORT_MAX_ORDERBOOK_IMBALANCE", 0.40)
        if direction == "SHORT":
            if imb <= -0.15:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Heavy sell wall overhang ({imb*100:.1f}%) pressuring price downward", "signal": "Heavy Seller Dominance"}
            elif imb <= short_ceiling:
                res = {"verdict": "APPROVE", "conviction": 75 if imb <= 0.25 else 70, "rationale": f"Balanced book depth ({imb*100:+.1f}%)", "signal": "Balanced Book"}
            else:
                res = {"verdict": "REJECT", "conviction": 25, "rationale": f"Massive bid absorption wall (+{imb*100:.1f}%) resisting downward move", "signal": "Veto: Strong Buyer Wall"}
        else:
            if imb >= 0.15:
                res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Strong bid wall imbalance (+{imb*100:.1f}%) supporting price", "signal": "Heavy Buyer Absorption"}
            elif imb >= long_floor:
                res = {"verdict": "APPROVE", "conviction": 75 if imb >= -0.25 else 70, "rationale": f"Balanced book depth ({imb*100:+.1f}%)", "signal": "Balanced Book"}
            else:
                res = {"verdict": "REJECT", "conviction": 25, "rationale": f"Heavy sell overhang ({imb*100:.1f}%) dominating depth", "signal": "Veto: Sell Overhang"}
        res["system_role"] = self.system_role
        return res


class ResistanceWallStaff(BaseStaffAgent):
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Order Book Wall Scanner",
            "Microstructure Staff",
            llm_client,
            system_role="Kamu adalah Order Book Wall Scanner di divisi Microstructure. Tugasmu: Mendeteksi tembok antrean jual abnormal yang menghadang kenaikan harga."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ob = data.get("orderbook_data", {})
        ask_usd = ob.get("ask_depth_usd")
        bid_usd = ob.get("bid_depth_usd")
        if not all(isinstance(x, (int, float)) and x > 0 for x in (ask_usd, bid_usd)):
            return {"verdict": "REJECT", "conviction": 0,
                    "rationale": "Measured orderbook depth unavailable", "signal": "DATA_UNAVAILABLE",
                    "system_role": self.system_role}
        direction = ob.get("direction", data.get("direction", "LONG"))

        if direction == "SHORT":
            if bid_usd > 0 and (bid_usd / max(1.0, ask_usd)) > 3.0:
                res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Bid depth ($ {bid_usd:.0f}) is > 3x ask depth ($ {ask_usd:.0f})", "signal": "Veto: Giant Bid Wall"}
            else:
                res = {"verdict": "APPROVE", "conviction": 85, "rationale": "No abnormal bid walls blocking downward progression", "signal": "Clean Order Book Path"}
        else:
            if ask_usd > 0 and (ask_usd / max(1.0, bid_usd)) > 3.0:
                res = {"verdict": "REJECT", "conviction": 20, "rationale": f"Ask depth ($ {ask_usd:.0f}) is > 3x bid depth ($ {bid_usd:.0f})", "signal": "Veto: Giant Ask Wall"}
            else:
                res = {"verdict": "APPROVE", "conviction": 85, "rationale": "No abnormal sell walls blocking immediate upside", "signal": "Clean Order Book Path"}
        res["system_role"] = self.system_role
        return res


class MicrostructureSpecialist:
    """Lead: Head Market Maker & Liquidity Specialist (🔬)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Order Book Microstructure Division"
        self.lead_title = "Head Market Maker & Liquidity Quant"
        self.icon = "🔬"
        self.llm = llm_client
        self.staff = [
            SpreadSlippageStaff(llm_client),
            DepthImbalanceStaff(llm_client),
            ResistanceWallStaff(llm_client)
        ]

    def analyze(self, orderbook_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(orderbook_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": min(s["conviction"] for s in staff_reports),
                    "rationale": f"Microstructure Veto: {vetoes[0]['staff_name']} rejected liquidity profile: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Liquidity depth approved: Tight spread and positive bid support eliminate execution friction.",
                "signal": "Liquidity Approved"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head Market Maker & Order Book Microstructure Quant",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Memeriksa spread bid/ask dan ketahanan kedalaman orderbook 20 level. "
                "Tolak transaksi dengan VETO mutlak jika spread > 0.20% atau rasio antrean jual mendominasi secara tidak wajar."
            ),
            context_data=orderbook_data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = min(llm_res.get("conviction", 80), min(s["conviction"] for s in staff_reports)) if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Microstructure Veto: {vetoes[0]['staff_name']} rejected: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 5: VOLATILITY & MARKET REGIME DIVISION
# =====================================================================

class ATRExpansionStaff(BaseStaffAgent):
    """Sub-Agent 5.1: Checks ATR expansion vs sideways chop."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "ATR Volatility Engineer",
            "Regime Staff",
            llm_client,
            system_role="Kamu adalah ATR Volatility Engineer di divisi Volatility Regime. Tugasmu: Memastikan ekspansi volatilitas ATR 14 sehat (0.5% s.d. 4.0%) dan menolak pergerakan sideways flat."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        mom = data.get("momentum_data", {})
        atr = mom.get("atr", 0.0)
        price = mom.get("price", 1.0)
        atr_pct = (atr / max(1e-9, price)) * 100.0

        # Floor is fee-aware, not a fixed 0.5%: on 15m bars BTC/ETH/XRP sit at
        # 0.17-0.28% ATR, so 0.5% vetoed every major. The risk desk already
        # rejects plans whose fee-adjusted R:R is insufficient.
        low_floor = getattr(config, "MIN_ATR_VOLATILITY_PCT", 0.15)
        if 0.5 <= atr_pct <= 4.0:
            res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Optimal volatility band (ATR {atr_pct:.2f}% of price)", "signal": "Optimal ATR Band"}
        elif low_floor <= atr_pct < 0.5:
            res = {"verdict": "APPROVE", "conviction": 76, "rationale": f"Low but tradable volatility (ATR {atr_pct:.2f}%); fee-adjusted R:R enforced by risk desk", "signal": "Compressed ATR Band"}
        elif atr_pct > 4.0:
            res = {"verdict": "APPROVE", "conviction": 70, "rationale": f"High volatility regime (ATR {atr_pct:.2f}%)", "signal": "High Volatility Regime"}
        else:
            res = {"verdict": "REJECT", "conviction": 30, "rationale": f"Dead market chop (ATR {atr_pct:.2f}% too flat)", "signal": "Veto: Flat Chop"}
        res["system_role"] = self.system_role
        return res


class TradeVelocityStaff(BaseStaffAgent):
    """Sub-Agent 5.2: Audits trade execution frequency."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Trade Velocity Scout",
            "Regime Staff",
            llm_client,
            system_role="Kamu adalah Trade Velocity Scout di divisi Volatility Regime. Tugasmu: Memverifikasi keaktifan frekuensi transaksi pasar organik (8,000+ trades)."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ticker = data.get("ticker_data", {})
        trades = ticker.get("count_trades", 0)

        if trades >= 40_000:
            res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Extremely active market participation ({trades:,} trades)", "signal": "High Trade Frequency"}
        elif trades >= 8_000:
            res = {"verdict": "APPROVE", "conviction": 80, "rationale": f"Adequate trade frequency ({trades:,} trades)", "signal": "Adequate Activity"}
        else:
            res = {"verdict": "APPROVE", "conviction": 65, "rationale": f"Moderate trade frequency ({trades:,} trades)", "signal": "Moderate Activity"}
        res["system_role"] = self.system_role
        return res


class NoiseFilterStaff(BaseStaffAgent):
    """Sub-Agent 5.3: Filters out spoofed/low-interest artificial pumps."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Market Noise Filter",
            "Regime Staff",
            llm_client,
            system_role="Kamu adalah Market Noise Filter di divisi Volatility Regime. Tugasmu: Menyaring anomali volume palsu atau wash trading."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ticker = data.get("ticker_data", {})
        vol = ticker.get("quote_volume_24h", 0.0)
        trades = ticker.get("count_trades", 0)

        if vol > 10_000_000 and trades < 1_000:
            res = {"verdict": "REJECT", "conviction": 20, "rationale": "Wash trading anomaly: High volume with suspiciously low trade count", "signal": "Veto: Wash Trading"}
        else:
            res = {"verdict": "APPROVE", "conviction": 90, "rationale": "Clean volume-to-trade ratio; no artificial wash trading signatures", "signal": "Authentic Flow"}
        res["system_role"] = self.system_role
        return res


class MarketSentimentSpecialist:
    """Lead: Head Volatility & Regime Analyst (📡)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Volatility & Market Regime Division"
        self.lead_title = "Head Volatility & Regime Analyst"
        self.icon = "📡"
        self.llm = llm_client
        self.staff = [
            ATRExpansionStaff(llm_client),
            TradeVelocityStaff(llm_client),
            NoiseFilterStaff(llm_client)
        ]

    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": min(s["conviction"] for s in staff_reports),
                    "rationale": f"Regime Veto: {vetoes[0]['staff_name']} flagged market anomaly: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Regime confirmed: Active volatility and authentic liquidity confirm breakout environment.",
                "signal": "Active Volatility Regime"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head Volatility & Market Regime Analyst",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Mengukur ekspansi volatilitas ATR 14 dan memastikan likuiditas organik autentik. "
                "Tolak transaksi dengan VETO mutlak jika pasar flat/mati atau terdeteksi anomali volume tanpa frekuensi trade."
            ),
            context_data=data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = min(llm_res.get("conviction", 80), min(s["conviction"] for s in staff_reports)) if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Regime Veto: {vetoes[0]['staff_name']} flagged: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 6: QUANTITATIVE RISK & CAPITAL DIVISION (ABSOLUTE VETO)
# =====================================================================

class PositionSizingStaff(BaseStaffAgent):
    """Sub-Agent 6.1: Enforces 2% risk rule and maximum 25% single-asset cap."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Position Sizing Auditor",
            "Risk Staff",
            llm_client,
            system_role="Kamu adalah Position Sizing Auditor di divisi Risk & Capital. Tugasmu: Menegakkan batas risiko modal 2% dan alokasi per posisi maks 25%."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        plan = data.get("risk_plan", {})
        if not plan.get("approved"):
            res = {"verdict": "REJECT", "conviction": 0, "rationale": f"Veto: Sizing unapproved ({plan.get('reason')})", "signal": "Veto: Capacity/Sizing"}
        else:
            pos_usdt = plan.get("position_usdt", 0.0)
            res = {"verdict": "APPROVE", "conviction": 98, "rationale": f"Position allocated strictly at ${pos_usdt:.2f} within risk limits", "signal": "2% Risk Cap Enforced"}
        res["system_role"] = self.system_role
        return res


class DynamicStopLossStaff(BaseStaffAgent):
    """Sub-Agent 6.2: Verifies volatility-based stop-loss placement."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Stop Loss Engineer",
            "Risk Staff",
            llm_client,
            system_role="Kamu adalah Stop Loss Engineer di divisi Risk & Capital. Tugasmu: Menghitung penempatan stop loss dinamis 1.5x ATR."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        plan = data.get("risk_plan", {})
        sl_pct = plan.get("stop_loss_pct", 0.0)
        sl_price = plan.get("stop_loss_price", 0.0)

        if 0.8 <= sl_pct <= 3.5:
            res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Calculated ATR stop-loss at ${sl_price} (-{sl_pct:.2f}%)", "signal": "ATR Stop-Loss Armed"}
        else:
            res = {"verdict": "REJECT", "conviction": 10, "rationale": f"Stop loss (-{sl_pct:.2f}%) outside permissible boundaries", "signal": "Veto: Stop-Loss Out-of-Bounds"}
        res["system_role"] = self.system_role
        return res


class AsymmetryExpectancyStaff(BaseStaffAgent):
    """Sub-Agent 6.3: Mathematically enforces positive expectancy >= 1:2.0."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Risk-to-Reward Calculator",
            "Risk Staff",
            llm_client,
            system_role="Kamu adalah Risk-to-Reward Calculator di divisi Risk & Capital. Tugasmu: Menjamin rasio Risk-to-Reward asimetris minimal 1:2.0."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        plan = data.get("risk_plan", {})
        rr = plan.get("risk_reward_ratio", 0.0)

        if rr >= 2.0:
            res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Asymmetric favorable expectancy (1:{rr:.2f})", "signal": "High Asymmetry Confirmed"}
        else:
            res = {"verdict": "REJECT", "conviction": 15, "rationale": f"Insufficient R:R ratio (1:{rr:.2f} < 1:2.0)", "signal": "Veto: Sub-optimal R:R"}
        res["system_role"] = self.system_role
        return res


class ChiefRiskOfficerSpecialist:
    """Lead: Chief Risk Officer (CRO) (🛡️) - HAS ABSOLUTE VETO POWER"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Quantitative Risk & Capital Division"
        self.lead_title = "Chief Risk Officer (CRO)"
        self.icon = "🛡️"
        self.llm = llm_client
        self.staff = [
            PositionSizingStaff(llm_client),
            DynamicStopLossStaff(llm_client),
            AsymmetryExpectancyStaff(llm_client)
        ]

    def analyze(self, risk_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(risk_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": 0,
                    "rationale": f"CRO ABSOLUTE VETO: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "CRO Approved: Asymmetric risk-reward confirmed with strict capital preservation.",
                "signal": "Capital Preserved"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Chief Risk Officer (CRO) Veto Authority",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Pemegang hak veto mutlak. Tegakkan batasan risiko maks 2% per transaksi, "
                "rasio Risk-to-Reward asimetris minimal 1:2.0, dan penempatan stop-loss ATR 1.5x terverifikasi ketat."
            ),
            context_data=risk_data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = 0 if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"CRO ABSOLUTE VETO: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 7: PROFIT EXTRACTION & TACTICAL EXITS DIVISION
# =====================================================================

class TakeProfitArchitectStaff(BaseStaffAgent):
    """Sub-Agent 7.1: Designs multi-tier take-profit ladders."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Take Profit Architect",
            "Profit Staff",
            llm_client,
            system_role="Kamu adalah Take Profit Architect di divisi Tactical Exits. Tugasmu: Merancang tangga profit multi-tahap (TP1 50% dan TP2 penuh)."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        plan = data.get("risk_plan", {})
        tp1 = plan.get("take_profit_1")
        tp2 = plan.get("take_profit_2")
        res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Multi-stage harvest: TP1 at ${tp1} ({config.TP1_R_MULTIPLE:g}R) and TP2 at ${tp2} ({config.TP2_R_MULTIPLE:g}R)", "signal": "2-Stage TP Ladder Armed"}
        res["system_role"] = self.system_role
        return res


class TrailingStopEngineerStaff(BaseStaffAgent):
    """Sub-Agent 7.2: Configures dynamic trailing stops to lock peak gains."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Trailing Stop Specialist",
            "Profit Staff",
            llm_client,
            system_role="Kamu adalah Trailing Stop Specialist di divisi Tactical Exits. Tugasmu: Mengunci keuntungan puncak dengan trailing stop adaptif (+2.5%)."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        plan = data.get("risk_plan", {})
        trig = plan.get("trailing_trigger_pct", 2.5)
        dist = plan.get("trailing_distance_pct", 1.2)
        res = {"verdict": "APPROVE", "conviction": 95, "rationale": f"Dynamic trailing activates at +{trig}% gain, trails {dist}% from peak", "signal": "Dynamic Trail Armed"}
        res["system_role"] = self.system_role
        return res


class ExecutionCostAuditorStaff(BaseStaffAgent):
    """Sub-Agent 7.3: Verifies net profitability after exchange taker fees."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Fee & Friction Auditor",
            "Profit Staff",
            llm_client,
            system_role="Kamu adalah Fee & Friction Auditor di divisi Tactical Exits. Tugasmu: Memastikan estimasi net profit setelah fee bursa 0.10% tetap positif."
        )

    def evaluate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        res = {"verdict": "APPROVE", "conviction": 90, "rationale": "Net profit expectancy fully accounts for 0.10% Binance round-trip fee", "signal": "Net Profit Positive"}
        res["system_role"] = self.system_role
        return res


class ProfitExtractionSpecialist:
    """Lead: Head Profit Extraction Strategist (🎯)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Profit Extraction & Tactical Exits Division"
        self.lead_title = "Head Profit Extraction Strategist"
        self.icon = "🎯"
        self.llm = llm_client
        self.staff = [
            TakeProfitArchitectStaff(llm_client),
            TrailingStopEngineerStaff(llm_client),
            ExecutionCostAuditorStaff(llm_client)
        ]

    def analyze(self, risk_data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for member in self.staff:
            res = member.evaluate(risk_data)
            staff_reports.append({
                "staff_name": member.name,
                "role_title": member.role_title,
                "system_role": getattr(member, "system_role", ""),
                "verdict": res["verdict"],
                "conviction": res["conviction"],
                "rationale": res["rationale"],
                "signal": res["signal"]
            })

        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]

        def _fallback(ctx):
            if vetoes:
                return {
                    "verdict": "REJECT",
                    "conviction": 0,
                    "rationale": f"Exit Strategy Veto: {vetoes[0]['staff_name']} rejected exit plan: {vetoes[0]['rationale']}",
                    "signal": vetoes[0]["signal"]
                }
            return {
                "verdict": "APPROVE",
                "conviction": int(sum(s["conviction"] for s in staff_reports) / len(staff_reports)),
                "rationale": "Tactical exit armed: 2-stage TP ladder and trailing stop configured to capture maximum gain.",
                "signal": "Tactical Exit Armed"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Head Profit Extraction & Tactical Exits Strategist",
            system_instruction=(
                "Kamu asisten kuantitatif arsitektur teknis yang ringkas dan solutif. "
                f"Tugasmu: Merancang strategi panen profit optimal: penjualan parsial 50% di TP1 ({config.TP1_R_MULTIPLE:g}R), "
                f"penguncian Stop Loss ke Break-Even (+{config.BREAK_EVEN_BUFFER_PCT:g}% fee cushion), dan trailing stop dinamis mengikuti puncak harga."
            ),
            context_data=risk_data,
            fallback_fn=_fallback
        )

        final_verdict = "REJECT" if vetoes else llm_res.get("verdict", "APPROVE")
        final_conviction = 0 if vetoes else llm_res.get("conviction", 80)
        final_rationale = f"Exit Strategy Veto: {vetoes[0]['staff_name']} rejected: {vetoes[0]['rationale']}" if vetoes else llm_res.get("rationale", _fallback({})["rationale"])

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "verdict": final_verdict,
            "conviction": final_conviction,
            "rationale": final_rationale,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }


# =====================================================================
# DEPARTMENT 8: EXECUTIVE INVESTMENT COMMITTEE
# =====================================================================

class ConsensusAuditorStaff(BaseStaffAgent):
    """Sub-Agent 8.1: Audits all department votes for any veto."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Department Consensus Auditor",
            "Executive Staff",
            llm_client,
            system_role="Kamu adalah Department Consensus Auditor di Executive Committee. Tugasmu: Memastikan persetujuan bulat tanpa ada satu pun veto divisi."
        )

    def evaluate(self, reports: List[Dict[str, Any]]) -> Dict[str, Any]:
        vetoes = [r for r in reports if r.get("verdict") == "REJECT"]
        if vetoes:
            lead_names = [v.get("specialist", "Division") for v in vetoes]
            res = {"verdict": "REJECT", "conviction": 0, "rationale": f"Veto triggered by {', '.join(lead_names)}", "signal": "Veto Detected"}
        else:
            res = {"verdict": "APPROVE", "conviction": 100, "rationale": "All 7 operational departments approved transaction with zero vetoes", "signal": "Unanimous Department Approval"}
        res["system_role"] = self.system_role
        return res


class ConvictionWeightStaff(BaseStaffAgent):
    """Sub-Agent 8.2: Aggregates weighted conviction scores (Higher Threshold)."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Conviction Weight Synthesizer",
            "Executive Staff",
            llm_client,
            system_role="Kamu adalah Conviction Weight Synthesizer di Executive Committee. Tugasmu: Mengagregasi rata-rata konviksi tertimbang minimal {}%. Hanya setujui trade dengan keyakinan tinggi.".format(config.ENHANCED_MIN_CONVICTION)
        )

    def evaluate(self, reports: List[Dict[str, Any]], extra_required: int = 0) -> Dict[str, Any]:
        convictions = [r.get("conviction", 0) for r in reports]
        from agents.consciousness import consciousness_engine
        weighted_sum = 0.0
        total_w = 0.0
        for r in reports:
            c = float(r.get("conviction", 0))
            w = consciousness_engine.get_weight(r.get("specialist", ""), 1.0)
            weighted_sum += c * w
            total_w += w
        avg = (weighted_sum / total_w) if total_w > 0 else (sum(convictions) / len(convictions) if convictions else 0)
        threshold = config.ENHANCED_MIN_CONVICTION + extra_required
        weakest = min(convictions) if convictions else 0
        floor = max(60, threshold - 18)
        if avg >= threshold and weakest >= floor:
            res = {"verdict": "APPROVE", "conviction": int(avg), "rationale": f"Firm-wide conviction ({avg:.1f}%) exceeds enhanced {threshold}% threshold, weakest division {weakest}%", "signal": f"High Conviction ({avg:.1f}%)" }
        elif avg < threshold:
            res = {"verdict": "REJECT", "conviction": int(avg), "rationale": f"Insufficient conviction ({avg:.1f}%) below {threshold}% quality standard", "signal": "Low Conviction"}
        else:
            res = {"verdict": "REJECT", "conviction": int(avg), "rationale": f"Weakest division conviction ({weakest}%) below quality floor {floor}% despite {avg:.1f}% average", "signal": "Weak Link Detected"}
        res["system_role"] = self.system_role
        return res


class OrderExecutionCommanderStaff(BaseStaffAgent):
    """Sub-Agent 8.3: Authorizes final order ticket."""
    def __init__(self, llm_client: LLMClient):
        super().__init__(
            "Order Execution Commander",
            "Executive Staff",
            llm_client,
            system_role="Kamu adalah Order Execution Commander di Executive Committee. Tugasmu: Menandatangani tiket eksekusi order ke bursa Binance Spot."
        )

    def evaluate(self, consensus_ok: bool, conviction_ok: bool) -> Dict[str, Any]:
        if consensus_ok and conviction_ok:
            res = {"verdict": "APPROVE", "conviction": 100, "rationale": "Execution ticket authorized. Transmitting order to Binance execution desk.", "signal": "Execution Authorized"}
        else:
            res = {"verdict": "REJECT", "conviction": 0, "rationale": "Execution ticket declined due to unmet departmental criteria.", "signal": "Ticket Declined"}
        res["system_role"] = self.system_role
        return res


class ExecutiveStrategistSpecialist:
    """Lead: Managing Director & Executive Judge (👑)"""
    def __init__(self, llm_client: LLMClient):
        self.role_name = "Executive Investment Committee"
        self.lead_title = "Managing Director & Executive Judge"
        self.icon = "👑"
        self.llm = llm_client
        self.staff = [
            ConsensusAuditorStaff(llm_client),
            ConvictionWeightStaff(llm_client),
            OrderExecutionCommanderStaff(llm_client)
        ]

    def synthesize(self, reports: List[Dict[str, Any]], extra_conviction_required: int = 0) -> Dict[str, Any]:
        res_auditor = self.staff[0].evaluate(reports)
        res_weight = self.staff[1].evaluate(reports, extra_required=extra_conviction_required)
        consensus_ok = res_auditor["verdict"] == "APPROVE"
        conviction_ok = res_weight["verdict"] == "APPROVE"
        res_commander = self.staff[2].evaluate(consensus_ok, conviction_ok)

        staff_reports = [
            {"staff_name": self.staff[0].name, "role_title": self.staff[0].role_title, "system_role": self.staff[0].system_role, **res_auditor},
            {"staff_name": self.staff[1].name, "role_title": self.staff[1].role_title, "system_role": self.staff[1].system_role, **res_weight},
            {"staff_name": self.staff[2].name, "role_title": self.staff[2].role_title, "system_role": self.staff[2].system_role, **res_commander}
        ]

        if not consensus_ok:
            vetoes = [r for r in reports if r.get("verdict") == "REJECT"]
            reasons = [v.get("rationale", "") for v in vetoes]
            return {
                "specialist": self.role_name,
                "lead_title": self.lead_title,
                "icon": self.icon,
                "final_verdict": "REJECT",
                "consensus_conviction": 0,
                "consensus_status": "VETOED",
                "engine_mode": "DETERMINISTIC",
                "summary": f"Trade rejected due to departmental veto: {reasons[0]}",
                "staff_reports": staff_reports
            }

        if not conviction_ok:
            return {
                "specialist": self.role_name,
                "lead_title": self.lead_title,
                "icon": self.icon,
                "final_verdict": "REJECT",
                "consensus_conviction": res_weight["conviction"],
                "consensus_status": "LOW_CONVICTION",
                "engine_mode": "DETERMINISTIC",
                "summary": f"Trade rejected: {res_weight['rationale']}",
                "staff_reports": staff_reports
            }

        avg_conviction = res_weight["conviction"]
        summary = (
            f"Unanimous approval across all 8 divisions ({config.ENHANCED_MIN_CONVICTION}%+ conviction). "
            f"Firm-wide conviction at {avg_conviction}%. Asymmetric profit opportunity authorized."
        )

        def _fallback(ctx):
            return {
                "verdict": "APPROVE",
                "conviction": avg_conviction,
                "rationale": summary,
                "signal": "Execution Authorized"
            }

        llm_res = self.llm.query_specialist(
            specialist_role="Managing Director & Executive Judge",
            system_instruction=(
                "Kamu asisten arsitektur teknis yang ringkas dan solutif. "
                "Tugasmu: Mensintesis konsensus dari 8 divisi spesialis kuantitatif, mengesahkan otorisasi eksekusi tiket trading ke bursa Binance Spot. "
                "Berikan ringkasan eksekutif keputusan yang tegas, ringkas, dan solutif."
            ),
            context_data={"department_verdicts": [r.get("verdict") for r in reports], "avg_conviction": avg_conviction},
            fallback_fn=_fallback
        )

        final_summary = llm_res.get("rationale", summary)

        return {
            "specialist": self.role_name,
            "lead_title": self.lead_title,
            "icon": self.icon,
            "final_verdict": "APPROVE",
            "consensus_conviction": avg_conviction,
            "consensus_status": "UNANIMOUS_CONSENSUS",
            "summary": final_summary,
            "engine": llm_res.get("engine", "Specialist Engine"),
            "engine_mode": llm_res.get("engine_mode", "DETERMINISTIC"),
            "ai_verdict": llm_res.get("ai_verdict"),
            "staff_reports": staff_reports
        }
