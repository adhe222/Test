import json
import os
import time
import threading
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path
from binance_api import BinanceClient
import config
from indicators import drop_forming_bar, calculate_ema
from market_stream import market_stream

from config import (
    INITIAL_PAPER_BALANCE_USDT,
    ESTIMATED_FEE_PCT,
    EFFECTIVE_FEE_PCT,
    FUTURES_FEE_PCT,
    TRADING_MODE,
    FASTER_TP1_RATIO as PARTIAL_TP1_RATIO,
    EARLY_BREAK_EVEN_PCT,
    MAX_HOLD_HOURS_STAGNANT,
    BREAK_EVEN_BUFFER_PCT,
    TRAILING_STOP_TRIGGER_PCT,
    TRAILING_STOP_DISTANCE_PCT
)


_STATE_LOCK = threading.RLock()


def classify_outcome(net_pnl: float, cost_basis: float) -> str:
    """WIN / LOSS / SCRATCH with a fee-scaled band (PIT-015)."""
    threshold = abs(float(cost_basis or 0.0)) * 0.0005
    if net_pnl > threshold:
        return "WIN"
    if net_pnl < -threshold:
        return "LOSS"
    return "SCRATCH"


def event_outcome(event: Dict[str, Any]) -> str:
    """Outcome of a ledger event, reconstructing it for legacy rows."""
    if event.get("outcome") in ("WIN", "LOSS", "SCRATCH"):
        return event["outcome"]
    pnl = float(event.get("pnl_usdt", 0.0) or 0.0)
    pct = float(event.get("pnl_pct", 0.0) or 0.0)
    if abs(pct) <= 0.05:
        return "SCRATCH"
    return "WIN" if pnl > 0 else "LOSS"


class PortfolioManagerAgent:
    """
    Portfolio & Execution Agent:
    Tracks wallet balance, open positions, exact transaction fee accounting (Binance Spot),
    partial profit-taking (TP1 scaling), proactive break-even stop adjustments,
    dynamic volatility-adjusted trailing stops, simulated or live execution, and trade ledger history.
    """

    def __init__(self, binance_client, mode: str = TRADING_MODE):
        self.client = binance_client
        self.mode = mode
        self.market_stream = market_stream
        self._last_loaded_mtime = 0.0
        self.last_equity_stale_symbols: List[str] = []
        self.state = self._load_portfolio()

    def _price_for(self, symbol: str, market: Optional[str] = None) -> float:
        """Stream price first (millisecond freshness), REST only as fallback."""
        try:
            price = self.market_stream.price(symbol, market, max_age=config.MARKET_STREAM_STALE_SEC)
            if price and price > 0:
                return float(price)
        except Exception:
            pass
        return self.client.get_price(symbol, market=market)

    def _sync_state_if_file_newer(self):
        target = config.PORTFOLIO_FILE
        if target.exists():
            try:
                mtime = target.stat().st_mtime
                if mtime > getattr(self, "_last_loaded_mtime", 0.0):
                    self.state = self._load_portfolio()
            except Exception:
                pass

    def _load_portfolio(self) -> Dict[str, Any]:
        # Resolve via the config module (not a stale import binding) so tests and
        # isolated runs honouring BOT_DATA_DIR / config overrides never write to
        # the live production state file.
        portfolio_file = config.PORTFOLIO_FILE
        if portfolio_file.exists():
            try:
                self._last_loaded_mtime = portfolio_file.stat().st_mtime
                with open(portfolio_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if "equity_history" not in data:
                        data["equity_history"] = []
                    if "total_fees_paid_usdt" not in data:
                        data["total_fees_paid_usdt"] = 0.0
                    if "gross_realized_pnl_usdt" not in data:
                        data["gross_realized_pnl_usdt"] = 0.0
                    self._reconcile_counters_from_ledger(data)
                    return data
            except Exception:
                pass
        # Default fresh state
        default_state = {
            "mode": self.mode,
            "cash_usdt": INITIAL_PAPER_BALANCE_USDT,
            "initial_capital": INITIAL_PAPER_BALANCE_USDT,
            "open_positions": [],
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "scratch_trades": 0,
            "total_fees_paid_usdt": 0.0,
            "gross_realized_pnl_usdt": 0.0,
            "realized_pnl_usdt": 0.0,
            "counter_since": datetime.now(timezone.utc).isoformat(),
            "equity_history": [
                {
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "equity": INITIAL_PAPER_BALANCE_USDT,
                    "cash": INITIAL_PAPER_BALANCE_USDT
                }
            ],
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        self._save_portfolio(default_state)
        return default_state

    def _reconcile_counters_from_ledger(self, data: Dict[str, Any]) -> None:
        """Single source of truth: derived counters are RECOUNTED from the
        trade ledger on every load. Increment updates at close time kept
        drifting from the ledger after crashes/restarts (events were logged
        but the state file never got saved), so the header showed stale
        numbers (42 trades at 32.4% WR) that represented nothing real while
        the ledger held 106 closed trades. If `counter_since` exists (set by
        reset_portfolio), only trades closed AFTER that moment count."""
        try:
            events = []
            if config.TRADE_LOG_FILE.exists():
                with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                    events = json.load(f)
        except Exception:
            return
        if not isinstance(events, list):
            return
        since = str(data.get("counter_since") or "")

        def _in_run(e):
            return isinstance(e, dict) and (not since or str(e.get("exit_time", "")) > since)

        closed = [e for e in events if _in_run(e) and e.get("action") == "CLOSED"]
        fee_events = [
            e for e in events
            if _in_run(e) and e.get("action") in ("CLOSED", "PARTIAL_TP1_TAKEN", "PYRAMID_ADD")
        ]
        wins = losses = scratches = 0
        for e in closed:
            o = event_outcome(e)
            if o == "WIN":
                wins += 1
            elif o == "LOSS":
                losses += 1
            else:
                scratches += 1
        closed_keys = {(str(e.get("symbol")), str(e.get("entry_time"))) for e in closed}
        open_partials = [
            e for e in fee_events
            if e.get("action") == "PARTIAL_TP1_TAKEN"
            and (str(e.get("symbol")), str(e.get("entry_time"))) not in closed_keys
        ]
        closed_net = sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in closed)
        open_partial_net = sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in open_partials)
        realized = round(closed_net + open_partial_net, 4)
        fees = round(sum(float(e.get("fee_paid_usdt", 0.0) or 0.0) for e in fee_events), 4)
        data["total_trades"] = len(closed)
        data["winning_trades"] = wins
        data["losing_trades"] = losses
        data["scratch_trades"] = scratches
        data["realized_pnl_usdt"] = realized
        data["open_partial_pnl_usdt"] = round(open_partial_net, 4)
        data["total_fees_paid_usdt"] = fees
        data["gross_realized_pnl_usdt"] = round(realized + fees, 4)
        data["cash_reconciliation"] = self._cash_reconciliation(data, realized)

    def _cash_reconciliation(self, data: Dict[str, Any], realized: float) -> Dict[str, Any]:
        """Compare ledger-implied cash with the persisted cash balance."""
        try:
            initial = float(data.get("initial_capital", 0.0) or 0.0)
            positions = [p for p in data.get("open_positions", []) if isinstance(p, dict)]
            open_cost = sum(float(p.get("position_usdt", 0.0) or 0.0) for p in positions)
            open_fees = sum(
                float(p.get("buy_fee_usdt", 0.0) or 0.0)
                * (float(p.get("quantity", 0.0) or 0.0) / float(p.get("initial_quantity", 0.0) or 1.0))
                for p in positions
            )
            expected = round(initial + float(realized) - open_cost - open_fees, 4)
            actual = round(float(data.get("cash_usdt", 0.0) or 0.0), 4)
            delta = round(actual - expected, 4)
            tolerance = max(0.5, abs(initial) * 0.001)
            return {
                "expected_cash_usdt": expected,
                "actual_cash_usdt": actual,
                "delta_usdt": delta,
                "status": "OK" if abs(delta) <= tolerance else "MISMATCH",
            }
        except Exception:
            return {"status": "UNAVAILABLE"}

    def _save_portfolio(self, state: Dict[str, Any]):
        state["updated_at"] = datetime.now(timezone.utc).isoformat()
        try:
            state["cash_reconciliation"] = self._cash_reconciliation(
                state, float(state.get("realized_pnl_usdt", 0.0) or 0.0)
            )
        except Exception:
            pass
        target = config.PORTFOLIO_FILE
        tmp = target.with_name(f"{target.name}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, target)
            try:
                self._last_loaded_mtime = target.stat().st_mtime
            except Exception:
                pass
        except Exception:
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            raise

    def record_equity_snapshot(self):
        current_eq = round(self.get_equity(), 2)
        history = self.state.get("equity_history", [])
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

        if not history or history[-1]["time"] != now_str:
            history.append({
                "time": now_str,
                "equity": current_eq,
                "cash": round(self.state.get("cash_usdt", 0.0), 2)
            })
            if len(history) > 150:
                history = history[-150:]
            self.state["equity_history"] = history
            self._save_portfolio(self.state)

    def _log_trade(self, trade_data: Dict[str, Any]):
        trade_file = config.TRADE_LOG_FILE
        trades = []
        if trade_file.exists():
            try:
                with open(trade_file, "r", encoding="utf-8") as f:
                    trades = json.load(f)
            except Exception:
                trades = []
        is_dup = False
        t_sym = trade_data.get("symbol")
        t_action = trade_data.get("action")
        t_entry = trade_data.get("entry_time")
        t_exit = trade_data.get("exit_time")
        if t_sym and t_action:
            for existing in trades:
                if existing.get("symbol") != t_sym or existing.get("action") != t_action:
                    continue
                if t_entry and existing.get("entry_time") == t_entry:
                    is_dup = True
                    break
                if not t_entry and t_exit and existing.get("exit_time") == t_exit:
                    is_dup = True
                    break
        if not is_dup:
            trades.append(trade_data)
        tmp = trade_file.with_name(f"{trade_file.name}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(trades, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, trade_file)
        except Exception:
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            raise

    def get_equity(self) -> float:
        self._sync_state_if_file_newer()
        equity = self.state["cash_usdt"]
        stale_symbols: List[str] = []
        for pos in self.state["open_positions"]:
            try:
                current_price = self._price_for(pos["symbol"], pos.get("market"))
                if pos.get("side") == "SELL" or pos.get("direction") == "SHORT":
                    equity += pos["position_usdt"] + (pos["entry_price"] - current_price) * pos["quantity"]
                else:
                    equity += pos["quantity"] * current_price
            except Exception:
                # Retain last known book value for continuity, but expose that it
                # is stale instead of presenting it as measured market equity.
                stale_symbols.append(pos["symbol"])
                equity += pos["position_usdt"]
        self.last_equity_stale_symbols = stale_symbols
        return equity

    def get_open_positions(self) -> List[Dict[str, Any]]:
        self._sync_state_if_file_newer()
        return self.state.get("open_positions", [])

    @staticmethod
    def _degenerate_bracket(direction: str, entry_price: Any, plan: Dict[str, Any]) -> str:
        try:
            entry = float(entry_price)
            sl = float(plan.get("stop_loss_price") or 0.0)
            tp1 = float(plan.get("take_profit_1") or 0.0)
            tp2 = float(plan.get("take_profit_2") or 0.0)
        except (TypeError, ValueError):
            return "non-numeric bracket levels"
        if min(entry, sl, tp1, tp2) <= 0:
            return "missing bracket levels"
        gap = entry * (float(getattr(config, "MIN_TARGET_GAP_PCT", 0.05)) / 100.0)
        if str(direction).upper() == "SHORT":
            ordered = sl > entry > tp1 > tp2
        else:
            ordered = sl < entry < tp1 < tp2
        gaps = (abs(entry - tp1), abs(tp1 - tp2), abs(sl - entry))
        if not ordered or any(g < gap for g in gaps):
            return f"degenerate bracket entry={entry} SL={sl} TP1={tp1} TP2={tp2} min_gap={gap}"
        return ""

    def execute_buy(self, plan: Dict[str, Any]) -> bool:
        return self.execute_trade(plan)

    def execute_trade(self, plan: Dict[str, Any]) -> bool:
        # Web watchdog thread + scan loop share this object; serialize mutations.
        with _STATE_LOCK:
            return self._execute_trade_locked(plan)

    def _execute_trade_locked(self, plan: Dict[str, Any]) -> bool:
        self._sync_state_if_file_newer()
        symbol = plan["symbol"]
        cost = plan["position_usdt"]
        qty = plan["quantity"]
        entry_price = plan["entry_price"]
        direction = plan.get("direction", "LONG")
        target_market = plan.get("target_market", "SPOT" if direction == "LONG" else "FUTURES")
        side = plan.get("side", "SELL" if direction == "SHORT" else "BUY")

        bracket_error = self._degenerate_bracket(direction, entry_price, plan)
        if bracket_error:
            print(f"[Risk Guard] Rejected {symbol}: {bracket_error}")
            return False

        if self.mode == "live" and getattr(config, "REQUIRE_APPROVAL_TICKET", True):
            from approval_queue import approval_queue

            ticket_ok, ticket_reason = approval_queue.consume(plan.get("approval_ticket_id"), plan)
            if not ticket_ok:
                print(f"[Approval Gate] {symbol} blocked: {ticket_reason}")
                return False

        fee = cost * (self._fee_pct(target_market) / 100.0)
        total_required = cost + fee

        if self.state["cash_usdt"] < total_required:
            return False

        if self.mode == "live":
            try:
                self.client.place_order(symbol, side=side, quote_order_qty=cost, market=target_market)
            except Exception as e:
                print(f"[Execution Error] Failed to place live order: {e}")
                return False

        self.state["cash_usdt"] -= total_required
        self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee, 4)

        new_position = {
            "symbol": symbol,
            "direction": direction,
            "market": target_market,
            # Venue stamp: lets the monitor refuse to manage a position that
            # belongs to a different exchange after an EXCHANGE switch.
            "exchange": plan.get("exchange") or str(getattr(self.client, "exchange_name", "") or "").lower(),
            "leverage": round(max(1.0, float(plan.get("leverage") or 1.0)), 2),
            "market_decision": plan.get("market_decision"),
            "side": side,
            "entry_price": entry_price,
            "quantity": qty,
            "initial_quantity": qty,
            "position_usdt": cost,
            "initial_cost_usdt": cost,
            "buy_fee_usdt": round(fee, 4),
            "stop_loss_price": plan["stop_loss_price"],
            "stop_loss_pct": plan["stop_loss_pct"],
            "entry_stop_loss_pct": plan["stop_loss_pct"],
            "entry_atr": plan.get("atr", 0.0),
            "entry_atr_pct": plan.get("atr_pct", 0.0),
            "take_profit_1": plan["take_profit_1"],
            "take_profit_2": plan["take_profit_2"],
            "tp1_hit": False,
            "partial_pnl_realized": 0.0,
            "break_even_active": False,
            "trailing_active": False,
            "highest_price": entry_price,
            "lowest_price": entry_price,
            "trailing_stop_price": plan["stop_loss_price"],
            "trailing_trigger_pct": plan["trailing_trigger_pct"],
            "trailing_distance_pct": plan["trailing_distance_pct"],
            "entry_time": datetime.now(timezone.utc).isoformat(),
            "holding_minutes": 0,
            "entry_metrics": plan.get("entry_metrics", {}) or {},
            "pyramids_added": 0
        }

        self.state["open_positions"].append(new_position)

        # Server-side OCO (live only): TP2 limit + SL stop-limit on the exchange
        # so the position is never naked if this process dies. Paper never calls.
        if self.mode == "live" and getattr(config, "LIVE_OCO_ENABLED", True) and direction == "LONG" and target_market == "SPOT":
            try:
                sl = float(new_position["stop_loss_price"])
                oco_resp = self.client.place_oco_order(
                    symbol, "SELL", qty,
                    take_profit_price=new_position["take_profit_2"],
                    stop_price=sl,
                    stop_limit_price=round(sl * (1.0 - 0.005), 6),
                    market=target_market,
                )
                if isinstance(oco_resp, dict) and oco_resp.get("orderListId") is not None:
                    new_position["oco_order_list_id"] = oco_resp.get("orderListId")
            except Exception as e:
                print(f"[Live OCO] placement failed (polling fallback stays active): {e}")

        self._save_portfolio(self.state)
        self.record_equity_snapshot()
        return True

    def _refresh_live_oco(self, pos: Dict[str, Any]) -> None:
        """Re-place the exchange OCO after SL/TP mutations (live LONG only)."""
        if self.mode != "live" or not getattr(config, "LIVE_OCO_ENABLED", True):
            return
        if pos.get("direction", "LONG") != "LONG":
            return
        if str(pos.get("market") or "SPOT").upper() != "SPOT":
            return
        try:
            oco_id = pos.get("oco_order_list_id")
            if oco_id:
                try:
                    self.client.cancel_oco_order(pos["symbol"], oco_id, market=pos.get("market"))
                except Exception:
                    pass
            stop_price = pos.get("trailing_stop_price") if pos.get("trailing_active") else pos.get("stop_loss_price")
            qty_now = float(pos.get("quantity", 0.0) or 0.0)
            if stop_price and qty_now > 0 and pos.get("take_profit_2"):
                resp = self.client.place_oco_order(
                    pos["symbol"], "SELL", qty_now,
                    take_profit_price=pos["take_profit_2"],
                    stop_price=float(stop_price),
                    stop_limit_price=round(float(stop_price) * (1.0 - 0.005), 6),
                    market=pos.get("market"),
                )
                if isinstance(resp, dict):
                    pos["oco_order_list_id"] = resp.get("orderListId")
        except Exception as e:
            print(f"[Live OCO] refresh failed (polling fallback stays active): {e}")

    def get_banned_symbols(self) -> List[str]:
        """Statistical auto-ban: symbols with a persistently losing recent
        history are excluded from NEW entries (existing positions unaffected)."""
        try:
            history = self.get_trade_history()
        except Exception:
            return []
        closed = [t for t in (history or []) if isinstance(t, dict) and t.get("action") == "CLOSED"]
        lookback = int(getattr(config, "SYMBOL_AUTOBAN_LOOKBACK", 20))
        min_trades = int(getattr(config, "SYMBOL_AUTOBAN_MIN_TRADES", 6))
        win_floor = float(getattr(config, "SYMBOL_AUTOBAN_WIN_RATE", 25.0))
        by_symbol: Dict[str, List[Dict[str, Any]]] = {}
        for t in closed:
            by_symbol.setdefault(t.get("symbol"), []).append(t)
        banned = []
        for sym, trades in by_symbol.items():
            if not sym:
                continue
            recent = trades[-lookback:]
            if len(recent) < min_trades:
                continue
            wins = sum(1 for t in recent if t.get("outcome") == "WIN")
            net = sum(float(t.get("pnl_usdt") or 0.0) for t in recent)
            if (wins / len(recent)) * 100.0 < win_floor and net < 0.0:
                banned.append(sym)
        return banned

    def _time_stop_ema_flip(self, pos: Dict[str, Any], current_p: float) -> bool:
        """Momentum time-stop: a trade that has gone nowhere for
        TIME_STOP_AFTER_MIN minutes exits when price crosses the 15m EMA9
        against the position - the momentum that justified entry has flipped."""
        try:
            klines = drop_forming_bar(self.client.get_klines(pos["symbol"], interval="15m", limit=50, market=pos.get("market")))
            if len(klines) < 12:
                return False
            closes = [k["close"] for k in klines]
            ema_list = calculate_ema(closes, int(getattr(config, "TIME_STOP_EMA_PERIOD", 9)))
            if not ema_list:
                return False
            ema_val = float(ema_list[-1])
            is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")
            return current_p > ema_val if is_short else current_p < ema_val
        except Exception:
            return False

    def _fee_pct(self, market: Optional[str]) -> float:
        """Per-side fee for the venue that actually fills the order.

        FUTURES taker is half the spot rate on both venues this bot supports,
        so charging the spot rate on a futures fill overstated every futures
        trade's cost by 2x and made the ledger disagree with the risk desk,
        which already priced futures with FUTURES_FEE_PCT.
        """
        return FUTURES_FEE_PCT if str(market or "").upper() == "FUTURES" else EFFECTIVE_FEE_PCT

    def _fee_aware_break_even_price(self, pos: Dict[str, Any]) -> float:
        """Break-even stop that covers round-trip fees and paper slippage."""
        entry = float(pos["entry_price"])
        is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")
        fee_pct = self._fee_pct(pos.get("market")) * 2.0
        slip_pct = self._slippage_pct(pos) if self.mode != "live" else 0.0
        cushion = max(
            float(getattr(config, "BREAK_EVEN_BUFFER_PCT", 0.60)),
            fee_pct + slip_pct + 0.10,
        )
        if is_short:
            return round(entry * (1.0 - cushion / 100.0), 8)
        return round(entry * (1.0 + cushion / 100.0), 8)

    def _slippage_pct(self, pos: Dict[str, Any], adverse: bool = True) -> float:
        """
        Simulated execution slippage for paper mode.

        Real fills are never exact: market orders cross the spread and stops on
        $8M-volume altcoins slip further when volatility is high. Without this,
        paper win rate is structurally optimistic versus live.
        """
        if self.mode == "live":
            return 0.0
        atr_pct = abs(float(pos.get("entry_atr_pct", 0.0) or 0.0))
        slip = config.PAPER_SLIPPAGE_BASE_PCT + config.PAPER_SLIPPAGE_ATR_FACTOR * atr_pct
        return min(slip, config.PAPER_SLIPPAGE_MAX_PCT)

    def update_and_monitor_positions(self, symbols=None) -> List[Dict[str, Any]]:
        # Without this lock the 3s web watchdog and the scan loop could both
        # close the same position (ledger showed HBARUSDT CLOSED twice, 7s apart).
        with _STATE_LOCK:
            return self._update_and_monitor_locked(symbols=symbols)

    def _update_and_monitor_locked(self, symbols=None) -> List[Dict[str, Any]]:
        self._sync_state_if_file_newer()
        actions = []
        remaining_positions = []
        selected = {str(s).upper() for s in (symbols or []) if s}

        for pos in self.state["open_positions"]:
            symbol = pos["symbol"]
            if selected and str(symbol).upper() not in selected:
                remaining_positions.append(pos)
                continue
            try:
                self.market_stream.ensure_position(symbol, pos.get("market"))
            except Exception:
                pass
            # Venue isolation: after EXCHANGE=binance, an OKX position cannot be
            # priced or closed through the Binance client. Leave it untouched
            # (and visible) instead of firing failing orders at the wrong venue.
            pos_exchange = str(pos.get("exchange") or "").lower()
            active_exchange = str(
                getattr(self.client, "exchange_name", "") or getattr(config, "EXCHANGE", "")
            ).lower()
            if pos_exchange and active_exchange and pos_exchange != active_exchange:
                warn_key = f"{pos_exchange}:{symbol}"
                warned = getattr(self, "_venue_mismatch_warned", set())
                if warn_key not in warned:
                    warned.add(warn_key)
                    self._venue_mismatch_warned = warned
                    print(
                        f"[VenueGuard] {symbol} was opened on {pos_exchange.upper()} but the "
                        f"active venue is {active_exchange.upper()}; position left untouched. "
                        "Close it on the original exchange or switch EXCHANGE back."
                    )
                remaining_positions.append(pos)
                continue
            qty = pos["quantity"]
            entry_p = pos["entry_price"]

            is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")

            try:
                current_p = self._price_for(symbol, pos.get("market"))
                pos["current_price"] = current_p
                if is_short:
                    pos["unrealized_pnl"] = round((entry_p - current_p) * qty, 4)
                else:
                    pos["unrealized_pnl"] = round((current_p - entry_p) * qty, 4)
            except Exception:
                remaining_positions.append(pos)
                continue

            try:
                entry_dt = datetime.fromisoformat(pos["entry_time"])
                hold_min = int((datetime.now(timezone.utc) - entry_dt).total_seconds() / 60.0)
                pos["holding_minutes"] = max(0, hold_min)
            except Exception:
                pos["holding_minutes"] = 0

            if current_p > pos.get("highest_price", entry_p):
                pos["highest_price"] = current_p
            if current_p < pos.get("lowest_price", entry_p):
                pos["lowest_price"] = current_p

            if is_short:
                current_gain_pct = ((entry_p - current_p) / entry_p) * 100.0
            else:
                current_gain_pct = ((current_p - entry_p) / entry_p) * 100.0

            if getattr(config, "MOMENTUM_FADE_EXIT_ENABLED", True) and not pos.get("tp1_hit") and pos.get("holding_minutes", 0) >= 5:
                try:
                    vel = self.market_stream.velocity(symbol, pos.get("market"), float(getattr(config, "MOMENTUM_FADE_WINDOW_SEC", 300.0)))
                except Exception:
                    vel = None
                thr = float(getattr(config, "MOMENTUM_FADE_THRESHOLD_PCT", 0.40))
                if vel is not None and ((is_short and vel >= thr) or ((not is_short) and vel <= -thr)):
                    pos["stop_loss_price"] = current_p
                    pos["_fade_exit"] = True

            # Break-even lock at 1R (risk-relative): a 3.5%-stop trade locks at
            # +3.5%, a 1%-stop trade at +1% - not at a flat 1.6% for both.
            be_trigger_gain = abs(float(pos.get("entry_stop_loss_pct", 0.0) or 0.0)) * float(getattr(config, "BREAK_EVEN_TRIGGER_R", 1.0))
            if be_trigger_gain <= 0:
                be_trigger_gain = config.EARLY_BREAK_EVEN_PCT
            if not pos.get("break_even_active", False) and current_gain_pct >= be_trigger_gain:
                be_price = self._fee_aware_break_even_price(pos)
                if is_short:
                    pos["stop_loss_price"] = min(float(pos["stop_loss_price"]), be_price)
                    pos["trailing_stop_price"] = min(
                        float(pos.get("trailing_stop_price", be_price)), pos["stop_loss_price"]
                    )
                else:
                    pos["stop_loss_price"] = max(float(pos["stop_loss_price"]), be_price)
                    pos["trailing_stop_price"] = max(
                        float(pos.get("trailing_stop_price", be_price)), pos["stop_loss_price"]
                    )
                pos["stop_loss_pct"] = round(float(getattr(config, "BREAK_EVEN_BUFFER_PCT", 0.60)), 2)
                pos["break_even_active"] = True
                self._refresh_live_oco(pos)

            tp1_triggered = (current_p <= pos["take_profit_1"]) if is_short else (current_p >= pos["take_profit_1"])
            if not pos.get("tp1_hit", False) and tp1_triggered:
                qty_to_sell = qty * PARTIAL_TP1_RATIO
                fee_tp1 = (qty_to_sell * current_p) * (self._fee_pct(pos.get("market")) / 100.0)
                cost_slice = pos["position_usdt"] * PARTIAL_TP1_RATIO
                slice_buy_fee = pos.get("buy_fee_usdt", 0.0) * PARTIAL_TP1_RATIO
                total_slice_fee = fee_tp1 + slice_buy_fee

                if is_short:
                    gross_slice_pnl = qty_to_sell * (entry_p - current_p)
                    net_tp1 = cost_slice + gross_slice_pnl - fee_tp1
                else:
                    gross_tp1 = qty_to_sell * current_p
                    gross_slice_pnl = gross_tp1 - cost_slice
                    net_tp1 = gross_tp1 - fee_tp1

                net_slice_pnl = gross_slice_pnl - total_slice_fee
                slice_pct = (net_slice_pnl / cost_slice) * 100.0 if cost_slice > 0 else 0.0

                if self.mode == "live":
                    try:
                        self.client.place_order(
                            symbol, side="BUY" if is_short else "SELL", quantity=qty_to_sell,
                            market=pos.get("market"), reduce_only=is_short,
                        )
                    except Exception as e:
                        print(f"[Execution Error] Failed live TP1 partial order: {e}")

                self.state["cash_usdt"] += net_tp1
                self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_tp1, 4)
                self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_slice_pnl, 4)
                self.state["realized_pnl_usdt"] = round(self.state.get("realized_pnl_usdt", 0.0) + net_slice_pnl, 4)

                pos["quantity"] -= qty_to_sell
                pos["position_usdt"] -= cost_slice
                pos["tp1_hit"] = True
                pos["partial_pnl_realized"] = round(net_slice_pnl, 4)

                be_price = self._fee_aware_break_even_price(pos)
                if is_short:
                    pos["stop_loss_price"] = min(float(pos["stop_loss_price"]), be_price)
                    pos["trailing_stop_price"] = min(
                        float(pos.get("trailing_stop_price", be_price)), pos["stop_loss_price"]
                    )
                else:
                    pos["stop_loss_price"] = max(float(pos["stop_loss_price"]), be_price)
                    pos["trailing_stop_price"] = max(
                        float(pos.get("trailing_stop_price", be_price)), pos["stop_loss_price"]
                    )
                pos["stop_loss_pct"] = round(float(getattr(config, "BREAK_EVEN_BUFFER_PCT", 0.60)), 2)
                pos["break_even_active"] = True
                self._refresh_live_oco(pos)

                tp1_event = {
                    "symbol": symbol,
                    "direction": "SHORT" if is_short else "LONG",
                    "market": pos.get("market", "FUTURES" if is_short else "SPOT"),
                    "action": "PARTIAL_TP1_TAKEN",
                    "reason": f"TP1_SCALED_OUT_{int(PARTIAL_TP1_RATIO * 100)}%_SL_MOVED_TO_BREAK_EVEN",
                    "entry_price": entry_p,
                    "exit_price": round(current_p, 6),
                    "gross_pnl_usdt": round(gross_slice_pnl, 4),
                    "fee_paid_usdt": round(total_slice_fee, 4),
                    "pnl_usdt": round(net_slice_pnl, 4),
                    "pnl_pct": round(slice_pct, 2),
                    "remaining_qty": round(pos["quantity"], 4),
                    "entry_time": pos["entry_time"],
                    "exit_time": datetime.now(timezone.utc).isoformat()
                }
                actions.append(tp1_event)
                self._log_trade(tp1_event)

            # Honour the per-position ATR-adaptive plan from the risk desk. The
            # global TRAILING_STOP_TRIGGER_PCT used to override it, so every
            # position armed at +2.2% regardless of its volatility.
            trail_trigger = float(pos.get("trailing_trigger_pct") or config.TRAILING_STOP_TRIGGER_PCT)
            if not pos.get("trailing_active", False) and current_gain_pct >= trail_trigger:
                pos["trailing_active"] = True
                # The plan's chandelier distance (2.5x ATR) is authoritative;
                # clamp only for safety, never back down to the old 0.8-3.5%.
                planned = float(pos.get("trailing_distance_pct") or config.TRAILING_STOP_DISTANCE_PCT)
                dist_floor = float(getattr(config, "TRAILING_MIN_DIST_PCT", 1.2))
                dist_cap = float(getattr(config, "TRAILING_MAX_DIST_PCT", 6.0))
                vol_trail_pct = max(dist_floor, min(dist_cap, planned))
                pos["trailing_distance_pct"] = round(vol_trail_pct, 2)
                if is_short:
                    new_trail = pos["lowest_price"] * (1 + (vol_trail_pct / 100.0))
                    pos["trailing_stop_price"] = min(
                        float(pos.get("trailing_stop_price", new_trail)),
                        new_trail,
                        float(pos["stop_loss_price"]),
                    )
                else:
                    new_trail = pos["highest_price"] * (1 - (vol_trail_pct / 100.0))
                    pos["trailing_stop_price"] = max(
                        float(pos.get("trailing_stop_price", new_trail)),
                        new_trail,
                        float(pos["stop_loss_price"]),
                    )
                self._refresh_live_oco(pos)

            if pos["trailing_active"]:
                vol_trail_pct = pos.get("trailing_distance_pct", config.TRAILING_STOP_DISTANCE_PCT)
                if is_short:
                    new_trail = pos["lowest_price"] * (1 + (vol_trail_pct / 100.0))
                    pos["trailing_stop_price"] = min(
                        float(pos["trailing_stop_price"]), new_trail, float(pos["stop_loss_price"])
                    )
                else:
                    new_trail = pos["highest_price"] * (1 - (vol_trail_pct / 100.0))
                    pos["trailing_stop_price"] = max(
                        float(pos["trailing_stop_price"]), new_trail, float(pos["stop_loss_price"])
                    )

            entry_ref = float(pos.get("entry_price") or 0.0)
            gap_ref = entry_ref * (float(getattr(config, "MIN_TARGET_GAP_PCT", 0.05)) / 100.0)
            tp2_valid = abs(entry_ref - float(pos.get("take_profit_2") or 0.0)) >= gap_ref > 0

            exit_pending = (
                (
                    tp2_valid
                    and (current_p <= pos["take_profit_2"] if is_short else current_p >= pos["take_profit_2"])
                )
                or (
                    pos.get("trailing_active", False)
                    and (
                        current_p >= pos["trailing_stop_price"]
                        if is_short
                        else current_p <= pos["trailing_stop_price"]
                    )
                )
                or (
                    current_p >= pos["stop_loss_price"]
                    if is_short
                    else current_p <= pos["stop_loss_price"]
                )
            )

            if (
                not exit_pending
                and getattr(config, "ENABLE_PYRAMIDING", False)
                and pos.get("tp1_hit", False)
                and pos.get("trailing_active", False)
                and int(pos.get("pyramids_added", 0) or 0) < int(getattr(config, "PYRAMID_MAX_ADDS", 1))
            ):
                pyr_trigger_gain = abs(float(pos.get("entry_stop_loss_pct", 0.0) or 0.0)) * float(getattr(config, "PYRAMID_TRIGGER_R", 1.5))
                if pyr_trigger_gain > 0 and current_gain_pct >= pyr_trigger_gain:
                    add_budget = float(pos.get("initial_cost_usdt", 0.0) or 0.0) * (float(getattr(config, "PYRAMID_ADD_PCT", 50.0)) / 100.0)
                    add_fee = add_budget * (self._fee_pct(pos.get("market")) / 100.0)
                    add_qty = add_budget / current_p if current_p > 0 else 0.0
                    trail_stop = float(pos.get("trailing_stop_price", 0.0) or 0.0)
                    if is_short:
                        add_risk = max(0.0, trail_stop - current_p) * add_qty
                    else:
                        add_risk = max(0.0, current_p - trail_stop) * add_qty
                    house_money = add_risk + add_fee <= float(pos.get("partial_pnl_realized", 0.0) or 0.0)
                    if add_budget > 0 and add_qty > 0 and house_money and self.state["cash_usdt"] >= add_budget + add_fee:
                        if self.mode == "live":
                            try:
                                self.client.place_order(
                                    symbol, side=pos.get("side", "BUY"), quote_order_qty=add_budget,
                                    market=pos.get("market"),
                                )
                            except Exception as e:
                                print(f"[Execution Error] Failed live pyramid add order: {e}")
                        self.state["cash_usdt"] -= (add_budget + add_fee)
                        self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + add_fee, 4)
                        weighted_entry = ((entry_p * qty) + (current_p * add_qty)) / (qty + add_qty)
                        pos["entry_price"] = round(weighted_entry, 8)
                        pos["quantity"] = round(qty + add_qty, 8)
                        pos["initial_quantity"] = round(float(pos.get("initial_quantity", qty) or 0.0) + add_qty, 8)
                        pos["position_usdt"] = round(pos["position_usdt"] + add_budget, 4)
                        pos["initial_cost_usdt"] = round(float(pos.get("initial_cost_usdt", 0.0) or 0.0) + add_budget, 4)
                        pos["buy_fee_usdt"] = round(pos.get("buy_fee_usdt", 0.0) + add_fee, 4)
                        pos["pyramids_added"] = int(pos.get("pyramids_added", 0) or 0) + 1
                        qty = pos["quantity"]
                        entry_p = pos["entry_price"]
                        pyramid_event = {
                            "symbol": symbol,
                            "direction": "SHORT" if is_short else "LONG",
                            "market": pos.get("market", "FUTURES" if is_short else "SPOT"),
                            "action": "PYRAMID_ADD",
                            "reason": f"ADDED_{float(getattr(config, 'PYRAMID_ADD_PCT', 50.0)):.0f}PCT_AT_{pyr_trigger_gain:.1f}R_GAIN",
                            "entry_price": pos["entry_price"],
                            "exit_price": round(current_p, 6),
                            "added_cost_usdt": round(add_budget, 4),
                            "added_quantity": round(add_qty, 8),
                            "gross_pnl_usdt": 0.0,
                            "fee_paid_usdt": round(add_fee, 4),
                            "pnl_usdt": 0.0,
                            "pnl_pct": 0.0,
                            "entry_time": pos["entry_time"],
                            "exit_time": datetime.now(timezone.utc).isoformat()
                        }
                        actions.append(pyramid_event)
                        self._log_trade(pyramid_event)
                        self._refresh_live_oco(pos)

            close_reason = None
            exit_price = current_p
            slip_applied_pct = 0.0

            if is_short:
                if tp2_valid and current_p <= pos["take_profit_2"]:
                    close_reason = "TAKE_PROFIT_2_HIT"
                    exit_price = pos["take_profit_2"]
                elif pos["trailing_active"] and current_p >= pos["trailing_stop_price"]:
                    close_reason = "TRAILING_STOP_EXIT"
                    slip_applied_pct = self._slippage_pct(pos)
                    exit_price = max(pos["trailing_stop_price"], current_p) * (1 + slip_applied_pct / 100.0)
                elif current_p >= pos["stop_loss_price"]:
                    close_reason = "MOMENTUM_FADE_EXIT" if pos.get("_fade_exit") else ("BREAK_EVEN_STOP_EXIT" if pos.get("break_even_active") else "STOP_LOSS_HIT")
                    slip_applied_pct = self._slippage_pct(pos)
                    exit_price = max(pos["stop_loss_price"], current_p) * (1 + slip_applied_pct / 100.0)
            else:
                if tp2_valid and current_p >= pos["take_profit_2"]:
                    close_reason = "TAKE_PROFIT_2_HIT"
                    exit_price = pos["take_profit_2"]
                elif pos["trailing_active"] and current_p <= pos["trailing_stop_price"]:
                    close_reason = "TRAILING_STOP_EXIT"
                    slip_applied_pct = self._slippage_pct(pos)
                    exit_price = min(pos["trailing_stop_price"], current_p) * (1 - slip_applied_pct / 100.0)
                elif current_p <= pos["stop_loss_price"]:
                    close_reason = "MOMENTUM_FADE_EXIT" if pos.get("_fade_exit") else ("BREAK_EVEN_STOP_EXIT" if pos.get("break_even_active") else "STOP_LOSS_HIT")
                    slip_applied_pct = self._slippage_pct(pos)
                    exit_price = min(pos["stop_loss_price"], current_p) * (1 - slip_applied_pct / 100.0)

            if not close_reason:
                try:
                    entry_dt = datetime.fromisoformat(pos["entry_time"])
                    hold_minutes = (datetime.now(timezone.utc) - entry_dt).total_seconds() / 60.0
                    hold_hours = hold_minutes / 60.0
                    roundtrip_fee_pct = self._fee_pct(pos.get("market")) * 2.0
                    net_gain_pct = current_gain_pct - roundtrip_fee_pct
                    dead_trade = (
                        not pos.get("tp1_hit", False)
                        and not pos.get("trailing_active", False)
                        and current_gain_pct < float(getattr(config, "TIME_STOP_MIN_GAIN_PCT", 0.3))
                    )
                    soft_window = int(getattr(config, "TIME_STOP_AFTER_MIN", 30))
                    hard_window = max(soft_window, int(getattr(config, "TIME_STOP_HARD_MIN", 90)))
                    net_floor = float(getattr(config, "TIME_STOP_MIN_NET_GAIN_PCT", -0.10))
                    soft_cut = (
                        bool(getattr(config, "TIME_STOP_SOFT_ENABLED", False))
                        and hold_minutes >= soft_window
                        and net_gain_pct <= net_floor
                        and self._time_stop_ema_flip(pos, current_p)
                    )
                    if dead_trade and (soft_cut or hold_minutes >= hard_window):
                        # Dead trade: no progress and (soft) the 15m EMA9 flipped
                        # against the entry, or (hard) the hard window expired.
                        # The soft stage only fires once the exit would actually
                        # book a loss after fees, so a flat trade is not donated
                        # to the exchange as pure fee drag.
                        close_reason = "MOMENTUM_TIME_STOP_EXIT"
                        exit_price = current_p
                    elif (
                        hold_minutes >= config.MICRO_PROFIT_SALVAGE_AFTER_MIN
                        and net_gain_pct >= config.MICRO_PROFIT_SALVAGE_PCT
                        and not pos.get("trailing_active", False)
                    ):
                        close_reason = "MICRO_PROFIT_SALVAGE_EXIT"
                        exit_price = current_p
                    elif hold_hours >= MAX_HOLD_HOURS_STAGNANT and abs(current_gain_pct) < 0.60:
                        close_reason = "STAGNATION_TIMEOUT_EXIT"
                        exit_price = current_p
                except Exception:
                    pass

            if close_reason:
                remaining_qty = pos["quantity"]
                if self.mode == "live":
                    try:
                        self.client.place_order(
                            symbol, side="BUY" if is_short else "SELL", quantity=remaining_qty,
                            market=pos.get("market"), reduce_only=is_short, close_full=True,
                        )
                    except Exception as e:
                        print(f"[Execution Error] Live close failed; position kept for retry: {e}")
                        remaining_positions.append(pos)
                        continue
                    if pos.get("oco_order_list_id"):
                        try:
                            self.client.cancel_oco_order(symbol, pos["oco_order_list_id"], market=pos.get("market"))
                        except Exception as e:
                            print(f"[Live OCO] cancel after close failed (leg may already be filled): {e}")

                fee_close = (remaining_qty * exit_price) * (self._fee_pct(pos.get("market")) / 100.0)
                remaining_buy_fee = pos.get("buy_fee_usdt", 0.0) * (remaining_qty / pos.get("initial_quantity", remaining_qty))
                total_trade_fee = round(fee_close + remaining_buy_fee, 4)

                if is_short:
                    gross_trade_pnl = remaining_qty * (entry_p - exit_price)
                    net_return = pos["position_usdt"] + gross_trade_pnl - fee_close
                else:
                    gross_return = remaining_qty * exit_price
                    gross_trade_pnl = gross_return - pos["position_usdt"]
                    net_return = gross_return - fee_close

                net_trade_pnl = gross_trade_pnl - total_trade_fee + pos.get("partial_pnl_realized", 0.0)
                total_trade_pct = (net_trade_pnl / pos.get("initial_cost_usdt", pos["position_usdt"])) * 100.0

                self.state["cash_usdt"] += net_return
                self.state["total_trades"] += 1
                self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_close, 4)
                self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_trade_pnl, 4)
                # net_trade_pnl already includes the TP1 slice, which was booked
                # into realized_pnl when TP1 filled; add only the remainder.
                self.state["realized_pnl_usdt"] = round(
                    self.state.get("realized_pnl_usdt", 0.0) + net_trade_pnl - pos.get("partial_pnl_realized", 0.0), 4
                )

                trade_event = {
                    "symbol": symbol,
                    "direction": "SHORT" if is_short else "LONG",
                    "market": pos.get("market", "FUTURES" if is_short else "SPOT"),
                    "exchange": pos.get("exchange") or str(getattr(self.client, "exchange_name", "") or ""),
                    "action": "CLOSED",
                    "reason": close_reason,
                    "entry_price": entry_p,
                    "exit_price": round(exit_price, 6),
                    "stop_loss_price": pos.get("stop_loss_price"),
                    "take_profit_1": pos.get("take_profit_1"),
                    "take_profit_2": pos.get("take_profit_2"),
                    "holding_minutes": pos.get("holding_minutes"),
                    "slippage_pct": round(slip_applied_pct, 4),
                    "gross_pnl_usdt": round(gross_trade_pnl, 4),
                    "fee_paid_usdt": total_trade_fee,
                    "pnl_usdt": round(net_trade_pnl, 4),
                    "pnl_pct": round(total_trade_pct, 2),
                    "entry_metrics": pos.get("entry_metrics", {}) or {},
                    "entry_time": pos["entry_time"],
                    "exit_time": datetime.now(timezone.utc).isoformat()
                }

                # Honest win accounting: a flat/break-even scratch is NOT a win.
                # Counting zero-PnL exits as wins inflates the reported win rate
                # without adding any money to the account.
                scratch_threshold = pos.get("initial_cost_usdt", pos["position_usdt"]) * 0.0005
                if net_trade_pnl > scratch_threshold:
                    self.state["winning_trades"] += 1
                    trade_event["outcome"] = "WIN"
                elif net_trade_pnl < -scratch_threshold:
                    self.state["losing_trades"] += 1
                    trade_event["outcome"] = "LOSS"
                else:
                    self.state["scratch_trades"] = self.state.get("scratch_trades", 0) + 1
                    trade_event["outcome"] = "SCRATCH"

                actions.append(trade_event)
                self._log_trade(trade_event)
            else:
                remaining_positions.append(pos)

        self.state["open_positions"] = remaining_positions
        if not selected or actions:
            self._save_portfolio(self.state)
            self.record_equity_snapshot()
        return actions

    def reset_portfolio(self, initial_capital: float = INITIAL_PAPER_BALANCE_USDT):
        """Reset paper trading portfolio balance."""
        self.state = {
            "mode": self.mode,
            "cash_usdt": initial_capital,
            "initial_capital": initial_capital,
            "open_positions": [],
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "scratch_trades": 0,
            "total_fees_paid_usdt": 0.0,
            "gross_realized_pnl_usdt": 0.0,
            "realized_pnl_usdt": 0.0,
            "counter_since": datetime.now(timezone.utc).isoformat(),
            "equity_history": [
                {
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "equity": initial_capital,
                    "cash": initial_capital
                }
            ],
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        self._save_portfolio(self.state)

    def close_all_positions(self, reason: str = "BOT_SHUTDOWN_LIQUIDATION") -> List[Dict[str, Any]]:
        with _STATE_LOCK:
            return self._close_all_locked(reason)

    def _close_all_locked(self, reason: str = "BOT_SHUTDOWN_LIQUIDATION") -> List[Dict[str, Any]]:
        """
        Auto-liquidate / market sell all open positions immediately upon bot closure / emergency stop.
        Realizes PnL, accounts for fees, returns cash to portfolio, and records into trade history.
        """
        closed_events = []
        positions_to_close = list(self.state.get("open_positions", []))
        remaining_positions = []

        for pos in positions_to_close:
            symbol = pos["symbol"]
            qty = pos["quantity"]
            entry_p = pos["entry_price"]

            try:
                current_p = self._price_for(symbol, pos.get("market"))
            except Exception:
                current_p = entry_p

            is_short = (pos.get("direction") == "SHORT" or pos.get("side") == "SELL")

            if self.mode == "live":
                try:
                    self.client.place_order(
                        symbol, side="BUY" if is_short else "SELL", quantity=qty,
                        market=pos.get("market"), reduce_only=is_short, close_full=True,
                    )
                except Exception as e:
                    print(f"[Emergency Close Error] Live order failed; position kept: {symbol}: {e}")
                    remaining_positions.append(pos)
                    continue

            fee_close = (qty * current_p) * (self._fee_pct(pos.get("market")) / 100.0)
            remaining_buy_fee = pos.get("buy_fee_usdt", 0.0) * (qty / pos.get("initial_quantity", qty))
            total_trade_fee = round(fee_close + remaining_buy_fee, 4)

            if is_short:
                gross_trade_pnl = qty * (entry_p - current_p)
                net_return = pos["position_usdt"] + gross_trade_pnl - fee_close
            else:
                gross_return = qty * current_p
                gross_trade_pnl = gross_return - pos["position_usdt"]
                net_return = gross_return - fee_close
            net_trade_pnl = gross_trade_pnl - total_trade_fee + pos.get("partial_pnl_realized", 0.0)
            total_trade_pct = (net_trade_pnl / pos.get("initial_cost_usdt", pos["position_usdt"])) * 100.0

            self.state["cash_usdt"] += net_return
            self.state["total_trades"] += 1
            self.state["total_fees_paid_usdt"] = round(self.state.get("total_fees_paid_usdt", 0.0) + fee_close, 4)
            self.state["gross_realized_pnl_usdt"] = round(self.state.get("gross_realized_pnl_usdt", 0.0) + gross_trade_pnl, 4)
            self.state["realized_pnl_usdt"] = round(
                self.state.get("realized_pnl_usdt", 0.0) + net_trade_pnl - pos.get("partial_pnl_realized", 0.0), 4
            )

            outcome = classify_outcome(net_trade_pnl, pos.get("initial_cost_usdt", pos["position_usdt"]))
            if outcome == "WIN":
                self.state["winning_trades"] += 1
            elif outcome == "LOSS":
                self.state["losing_trades"] += 1
            else:
                self.state["scratch_trades"] = self.state.get("scratch_trades", 0) + 1

            event = {
                "symbol": symbol,
                "direction": "SHORT" if is_short else "LONG",
                "market": pos.get("market", "FUTURES" if is_short else "SPOT"),
                "outcome": outcome,
                "action": "CLOSED",
                "reason": reason,
                "entry_price": entry_p,
                "exit_price": round(current_p, 6),
                "gross_pnl_usdt": round(gross_trade_pnl, 4),
                "fee_paid_usdt": total_trade_fee,
                "pnl_usdt": round(net_trade_pnl, 4),
                "pnl_pct": round(total_trade_pct, 2),
                "entry_time": pos["entry_time"],
                "exit_time": datetime.now(timezone.utc).isoformat()
            }
            closed_events.append(event)
            self._log_trade(event)

        self.state["open_positions"] = remaining_positions
        self._save_portfolio(self.state)
        self.record_equity_snapshot()
        print(f"\n[PortfolioManager] Auto-sold {len(closed_events)} open positions due to {reason}; {len(remaining_positions)} kept after live errors.")
        return closed_events

    def get_periodic_performance(self) -> Dict[str, Any]:
        """
        Calculates periodic performance metrics (Today, This Week, This Month)
        aggregating realized profit, gross profit, fees paid, win rate, and trade counts.
        """
        now = datetime.now(timezone.utc)
        today_date = now.date()
        week_start = today_date - timedelta(days=7)
        current_month = now.month
        current_year = now.year

        trades = []
        import config
        trade_file = config.TRADE_LOG_FILE
        if trade_file.exists():
            try:
                with open(trade_file, "r", encoding="utf-8") as f:
                    trades = json.load(f)
            except Exception:
                trades = []

        def _aggregate(bucket_trades: List[Dict[str, Any]]) -> Dict[str, Any]:
            # Only CLOSED events are trades. A CLOSED event's pnl_usdt already
            # contains its TP1 slice, so summing partial rows too double-counted
            # profit; break-even scratches were also counted as wins.
            closed = [t for t in bucket_trades if t.get("action") == "CLOSED"]
            outcomes = [event_outcome(t) for t in closed]
            count = len(closed)
            wins = outcomes.count("WIN")
            losses = outcomes.count("LOSS")
            scratches = outcomes.count("SCRATCH")
            decided = wins + losses
            win_rate = round((wins / decided) * 100.0, 1) if decided else 0.0
            net_pnl = sum(float(t.get("pnl_usdt", 0.0) or 0.0) for t in closed)
            gross_pnl = sum(float(t.get("gross_pnl_usdt", t.get("pnl_usdt", 0.0)) or 0.0) for t in bucket_trades)
            fees = sum(float(t.get("fee_paid_usdt", 0.0) or 0.0) for t in bucket_trades)
            return {
                "trades": count,
                "wins": wins,
                "losses": losses,
                "scratches": scratches,
                "win_rate": win_rate,
                "net_pnl_usdt": round(net_pnl, 4),
                "gross_pnl_usdt": round(gross_pnl, 4),
                "fees_paid_usdt": round(fees, 4)
            }

        today_trades = []
        week_trades = []
        month_trades = []

        since = str(self.state.get("counter_since") or "")
        for t in trades:
            time_str = t.get("exit_time") or t.get("entry_time")
            if not time_str:
                continue
            if since and str(t.get("exit_time", "")) <= since:
                continue
            try:
                t_dt = datetime.fromisoformat(time_str)
                t_date = t_dt.date()

                if t_date == today_date:
                    today_trades.append(t)
                if t_date >= week_start:
                    week_trades.append(t)
                if t_dt.year == current_year and t_dt.month == current_month:
                    month_trades.append(t)
            except Exception:
                continue

        return {
            "today": _aggregate(today_trades),
            "this_week": _aggregate(week_trades),
            "this_month": _aggregate(month_trades)
        }

    def get_trade_history(self) -> List[Dict[str, Any]]:
        import config
        if config.TRADE_LOG_FILE.exists():
            try:
                with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []
        return []
