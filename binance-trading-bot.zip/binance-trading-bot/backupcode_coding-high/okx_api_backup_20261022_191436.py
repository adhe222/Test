import base64
import hashlib
import hmac
import json
import threading
import time
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import requests

import config as _cfg
import dns_route

OKX_ENDPOINTS = ["https://www.okx.com", "https://app.okx.com"]
OKX_INTERVAL_MAP = {
    "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m",
    "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6H", "8h": "8H",
    "12h": "12H", "1d": "1Dutc",
}
OKX_INTERVAL_SEC = {
    "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
    "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "8h": 28800,
    "12h": 43200, "1d": 86400,
}
QUOTE_ASSETS = ("USDT", "USDC", "FDUSD", "USD")


class OKXAPIError(RuntimeError):
    def __init__(self, code: Any, message: str, payload: Optional[Dict[str, Any]] = None):
        self.code = str(code)
        self.message = message
        self.payload = payload or {}
        super().__init__(f"OKX API error {self.code}: {message}")


def _decimal(value: Any) -> Decimal:
    return Decimal(str(value))


def _floor_step(value: Any, step: Any) -> Decimal:
    step_d = _decimal(step)
    if step_d <= 0:
        return _decimal(value)
    return (_decimal(value) / step_d).to_integral_value(rounding=ROUND_DOWN) * step_d


def _decimal_str(value: Decimal) -> str:
    text = format(value.normalize(), "f")
    return text if text else "0"


class OKXClient:
    exchange_name = "okx"

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        passphrase: Optional[str] = None,
        demo: Optional[bool] = None,
        default_market: str = "SPOT",
        session: Optional[requests.Session] = None,
    ):
        primary = (base_url or getattr(_cfg, "OKX_API_URL", OKX_ENDPOINTS[0]) or OKX_ENDPOINTS[0]).rstrip("/")
        self.endpoints = [primary] + [ep for ep in OKX_ENDPOINTS if ep != primary]
        self.active_base_url = primary
        self.api_key = api_key if api_key is not None else getattr(_cfg, "OKX_API_KEY", "")
        self.api_secret = api_secret if api_secret is not None else getattr(_cfg, "OKX_API_SECRET", "")
        self.passphrase = passphrase if passphrase is not None else getattr(_cfg, "OKX_API_PASSPHRASE", "")
        self.demo = bool(getattr(_cfg, "OKX_DEMO", False) if demo is None else demo)
        provided = [bool(self.api_key), bool(self.api_secret), bool(self.passphrase)]
        if any(provided) and not all(provided):
            raise ValueError("OKX requires OKX_API_KEY, OKX_API_SECRET and OKX_API_PASSPHRASE together.")
        self.default_market = self._normalize_market(default_market)
        self.margin_mode = str(getattr(_cfg, "OKX_MARGIN_MODE", "cross")).lower()
        self.leverage = max(1.0, float(getattr(_cfg, "FUTURES_DEFAULT_LEVERAGE", 1.0) or 1.0))
        self.supports_spot = bool(getattr(_cfg, "OKX_SPOT_ENABLED", True))
        self.supports_futures = bool(getattr(_cfg, "OKX_FUTURES_ENABLED", True))
        self.session = session or requests.Session()
        self.session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
        if self.demo:
            self.session.headers.update({"x-simulated-trading": "1"})
        self._cache: Dict[str, Any] = {}
        self._cache_lock = threading.Lock()
        self._instruments_cache: Dict[str, Any] = {}
        self._instruments_lock = threading.Lock()
        self._funding_backoff_until = 0.0
        self._time_offset_ms = 0.0
        self._leverage_prepared = set()
        self._pos_mode: Optional[str] = None
        dns_route.ensure_routing()

    @staticmethod
    def _normalize_market(market: Optional[str]) -> str:
        value = str(market or "SPOT").strip().upper()
        if value in ("FUTURES", "SWAP", "PERP", "PERPETUAL"):
            return "FUTURES"
        return "SPOT"

    @staticmethod
    def from_inst_id(inst_id: str) -> str:
        parts = str(inst_id).upper().split("-")
        if len(parts) >= 2:
            return f"{parts[0]}{parts[1]}"
        return str(inst_id).upper()

    @staticmethod
    def to_inst_id(symbol: str, market: str = "SPOT") -> str:
        raw = str(symbol).upper().strip()
        if "-" in raw:
            parts = raw.split("-")
            base, quote = parts[0], parts[1]
        else:
            base = quote = None
            for candidate in QUOTE_ASSETS:
                if raw.endswith(candidate) and len(raw) > len(candidate):
                    base, quote = raw[: -len(candidate)], candidate
                    break
            if base is None:
                raise ValueError(f"Unsupported OKX symbol: {symbol}")
        suffix = "-SWAP" if OKXClient._normalize_market(market) == "FUTURES" else ""
        return f"{base}-{quote}{suffix}"

    def _market(self, market: Optional[str]) -> str:
        return self._normalize_market(market or self.default_market)

    def _cache_get(self, key: str) -> Optional[Any]:
        with self._cache_lock:
            entry = self._cache.get(key)
            if entry and entry[0] > time.time():
                return entry[1]
        return None

    def _cache_set(self, key: str, ttl_sec: float, value: Any) -> None:
        with self._cache_lock:
            self._cache[key] = (time.time() + float(ttl_sec), value)

    def clear_cache(self) -> None:
        with self._cache_lock:
            self._cache.clear()

    def _timestamp_ms(self) -> int:
        return int(time.time() * 1000 + self._time_offset_ms)

    @staticmethod
    def _iso_timestamp(ms: int) -> str:
        dt = datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{int(ms) % 1000:03d}Z"

    @staticmethod
    def sign(secret: str, timestamp: str, method: str, request_path: str, body: str = "") -> str:
        message = f"{timestamp}{method.upper()}{request_path}{body}"
        digest = hmac.new(secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).digest()
        return base64.b64encode(digest).decode("ascii")

    def _auth_headers(self, method: str, request_path: str, body: str) -> Dict[str, str]:
        timestamp = self._iso_timestamp(self._timestamp_ms())
        return {
            "OK-ACCESS-KEY": self.api_key,
            "OK-ACCESS-SIGN": self.sign(self.api_secret, timestamp, method, request_path, body),
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": self.passphrase,
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Any] = None,
        signed: bool = False,
        timeout: float = 6.0,
    ) -> List[Dict[str, Any]]:
        query = urlencode({k: v for k, v in (params or {}).items() if v is not None})
        request_path = f"{path}?{query}" if query else path
        body_str = json.dumps(body, separators=(",", ":")) if body is not None else ""
        last_exc: Optional[Exception] = None
        for base in [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]:
            try:
                headers = self._auth_headers(method, request_path, body_str) if signed else None
                resp = self.session.request(
                    method.upper(),
                    f"{base}{request_path}",
                    data=body_str if body_str else None,
                    headers=headers,
                    timeout=timeout,
                )
                payload = resp.json()
                code = str(payload.get("code", ""))
                if code != "0":
                    raise OKXAPIError(code, payload.get("msg", "unknown error"), payload)
                self.active_base_url = base
                return payload.get("data") or []
            except OKXAPIError as exc:
                if exc.code == "50102" and signed:
                    self._sync_server_time()
                    headers = self._auth_headers(method, request_path, body_str)
                    resp = self.session.request(
                        method.upper(),
                        f"{base}{request_path}",
                        data=body_str if body_str else None,
                        headers=headers,
                        timeout=timeout,
                    )
                    payload = resp.json()
                    if str(payload.get("code", "")) != "0":
                        raise OKXAPIError(payload.get("code"), payload.get("msg", "unknown error"), payload)
                    self.active_base_url = base
                    return payload.get("data") or []
                raise
            except (requests.exceptions.RequestException, ValueError) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available OKX API endpoint")

    def _public(self, path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 6.0) -> List[Dict[str, Any]]:
        return self._request("GET", path, params=params, timeout=timeout)

    def _private(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Any] = None,
        timeout: float = 8.0,
    ) -> List[Dict[str, Any]]:
        if not self.api_key or not self.api_secret or not self.passphrase:
            raise ValueError("OKX API key, secret and passphrase are required for private endpoints.")
        return self._request(method, path, params=params, body=body, signed=True, timeout=timeout)

    def _sync_server_time(self) -> None:
        try:
            data = self._public("/api/v5/public/time", timeout=3.0)
            server_ms = float(data[0]["ts"])
            self._time_offset_ms = server_ms - time.time() * 1000.0
        except Exception:
            self._time_offset_ms = 0.0

    def _instruments(self, inst_type: str) -> Dict[str, Dict[str, Any]]:
        with self._instruments_lock:
            cached = self._instruments_cache.get(inst_type)
            if cached and cached[0] > time.time():
                return cached[1]
        try:
            rows = self._public("/api/v5/public/instruments", {"instType": inst_type}, timeout=8.0)
            mapping = {row["instId"]: row for row in rows}
            ttl = 3600.0
        except Exception:
            mapping = {}
            ttl = 60.0
        with self._instruments_lock:
            self._instruments_cache[inst_type] = (time.time() + ttl, mapping)
        return mapping

    def _instrument(self, inst_id: str) -> Dict[str, Any]:
        inst_type = "SWAP" if inst_id.endswith("-SWAP") else "SPOT"
        return self._instruments(inst_type).get(inst_id, {})

    def _format_quantity(self, inst_id: str, quantity: float, market: str) -> str:
        inst = self._instrument(inst_id)
        lot = inst.get("lotSz", "0.00000001")
        minimum = _decimal(inst.get("minSz", "0"))
        value = _floor_step(quantity, lot)
        if value <= 0 or (minimum > 0 and value < minimum):
            raise ValueError(
                f"OKX order size {quantity} below minimum {minimum} (lot {lot}) for {inst_id}"
            )
        return _decimal_str(value)

    def _contracts_for_quantity(self, inst_id: str, quantity: float) -> str:
        inst = self._instrument(inst_id)
        ct_val = _decimal(inst.get("ctVal", "1") or "1")
        if ct_val <= 0:
            ct_val = _decimal("1")
        contracts = _floor_step(_decimal(quantity) / ct_val, inst.get("lotSz", "0.01"))
        minimum = _decimal(inst.get("minSz", "0"))
        if contracts <= 0 or (minimum > 0 and contracts < minimum):
            raise ValueError(
                f"OKX contract size {contracts} below minimum {minimum} for {inst_id} "
                f"(quantity {quantity}, ctVal {ct_val})"
            )
        return _decimal_str(contracts)

    def _position_contracts(self, inst_id: str, pos_side: Optional[str] = None) -> Optional[str]:
        try:
            rows = self._private("GET", "/api/v5/account/positions", {"instId": inst_id})
        except Exception:
            return None
        for row in rows:
            if pos_side and str(row.get("posSide", "")).lower() != pos_side:
                continue
            try:
                size = abs(_decimal(row.get("pos", "0")))
            except Exception:
                continue
            if size > 0:
                lot = self._instrument(inst_id).get("lotSz", "0.01")
                return _decimal_str(_floor_step(size, lot))
        return None

    def _position_mode(self) -> str:
        if self._pos_mode:
            return self._pos_mode
        try:
            rows = self._private("GET", "/api/v5/account/config")
            mode = str(rows[0].get("posMode", "net_mode")) if rows else "net_mode"
        except Exception:
            mode = "net_mode"
        self._pos_mode = "hedge" if mode == "long_short_mode" else "net"
        return self._pos_mode

    def _prepare_leverage(self, inst_id: str) -> None:
        if inst_id in self._leverage_prepared:
            return
        self._leverage_prepared.add(inst_id)
        sides = [None]
        if self._position_mode() == "hedge":
            sides = ["long", "short"]
        for pos_side in sides:
            body = {
                "instId": inst_id,
                "lever": _decimal_str(_decimal(self.leverage)),
                "mgnMode": self.margin_mode,
            }
            if pos_side:
                body["posSide"] = pos_side
            try:
                self._private("POST", "/api/v5/account/set-leverage", body=body)
            except Exception as exc:
                print(f"[OKX] set-leverage warning for {inst_id} ({pos_side or 'net'}): {exc}")

    def get_24hr_tickers(self, market: Optional[str] = None) -> List[Dict[str, Any]]:
        requested = market or "ALL"
        key = f"okx:tickers:24hr:{requested}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        markets: List[str] = []
        if market:
            markets = [self._market(market)]
        else:
            if self.supports_spot:
                markets.append("SPOT")
            if self.supports_futures:
                markets.append("FUTURES")
        merged: Dict[str, Dict[str, Any]] = {}
        for market_name in markets:
            inst_type = "SPOT" if market_name == "SPOT" else "SWAP"
            try:
                rows = self._public("/api/v5/market/tickers", {"instType": inst_type}, timeout=8.0)
            except Exception:
                continue
            instruments = self._instruments(inst_type)
            for row in rows:
                inst_id = row.get("instId", "")
                if instruments:
                    info = instruments.get(inst_id)
                    if not info:
                        continue
                    category = str(info.get("instCategory") or "1")
                    if category != "1":
                        continue
                symbol = self.from_inst_id(inst_id)
                if not symbol or not any(symbol.endswith(q) for q in QUOTE_ASSETS):
                    continue
                try:
                    last = float(row.get("last") or 0.0)
                    open_24h = float(row.get("open24h") or 0.0)
                except (TypeError, ValueError):
                    continue
                if last <= 0:
                    continue
                change_pct = ((last - open_24h) / open_24h * 100.0) if open_24h > 0 else 0.0
                if inst_type == "SPOT":
                    quote_volume = float(row.get("volCcy24h") or 0.0)
                    base_volume = float(row.get("vol24h") or 0.0)
                else:
                    base_volume = float(row.get("volCcy24h") or 0.0)
                    quote_volume = base_volume * last
                normalized = {
                    "symbol": symbol,
                    "instId": inst_id,
                    "lastPrice": str(last),
                    "priceChangePercent": str(change_pct),
                    "quoteVolume": str(quote_volume),
                    "volume": str(base_volume),
                    "highPrice": str(row.get("high24h") or last),
                    "lowPrice": str(row.get("low24h") or last),
                    "bidPrice": str(row.get("bidPx") or last),
                    "askPrice": str(row.get("askPx") or last),
                    "count": 0,
                    "markets": [market_name],
                }
                existing = merged.get(symbol)
                if existing is None:
                    merged[symbol] = normalized
                else:
                    existing_markets = set(existing.get("markets", [])) | {market_name}
                    if quote_volume > float(existing.get("quoteVolume") or 0.0):
                        normalized["markets"] = sorted(existing_markets)
                        merged[symbol] = normalized
                    else:
                        existing["markets"] = sorted(existing_markets)
        result = sorted(merged.values(), key=lambda row: float(row.get("quoteVolume") or 0.0), reverse=True)
        self._cache_set(key, getattr(_cfg, "TICKER_CACHE_TTL_SEC", 25), result)
        return result

    def get_price(self, symbol: str, market: Optional[str] = None) -> float:
        market_name = self._market(market)
        key = f"okx:price:{market_name}:{symbol}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        inst_id = self.to_inst_id(symbol, market_name)
        rows = self._public("/api/v5/market/ticker", {"instId": inst_id}, timeout=4.0)
        price = float(rows[0]["last"])
        self._cache_set(key, getattr(_cfg, "PRICE_CACHE_TTL_SEC", 3), price)
        return price

    def get_klines(self, symbol: str, interval: str = "15m", limit: int = 100,
                   market: Optional[str] = None) -> List[Dict[str, Any]]:
        market_name = self._market(market)
        bar = OKX_INTERVAL_MAP.get(str(interval).lower(), str(interval))
        capped_limit = max(1, min(300, int(limit)))
        key = f"okx:klines:{market_name}:{symbol}:{bar}:{capped_limit}"
        cached = self._cache_get(key)
        if cached is not None:
            return cached
        inst_id = self.to_inst_id(symbol, market_name)
        rows = self._public(
            "/api/v5/market/candles",
            {"instId": inst_id, "bar": bar, "limit": capped_limit},
            timeout=6.0,
        )
        interval_sec = OKX_INTERVAL_SEC.get(str(interval).lower(), 900)
        klines = []
        for row in reversed(rows):
            ts = int(row[0])
            is_swap = market_name == "FUTURES"
            klines.append({
                "open_time": ts,
                "open": float(row[1]),
                "high": float(row[2]),
                "low": float(row[3]),
                "close": float(row[4]),
                "volume": float(row[6] if is_swap else row[5]),
                "close_time": ts + interval_sec * 1000 - 1,
                "quote_volume": float(row[7]) if len(row) > 7 and row[7] else 0.0,
                "trades": 0,
                "is_closed": str(row[8]) == "1" if len(row) > 8 else True,
            })
        ttl = max(15.0, min(float(getattr(_cfg, "KLINES_CACHE_TTL_SEC", 120)), interval_sec / 4.0))
        if klines and not klines[-1]["is_closed"]:
            seconds_to_close = (klines[-1]["close_time"] + 1.0) / 1000.0 - time.time()
            ttl = min(ttl, max(0.0, seconds_to_close))
        self._cache_set(key, ttl, klines)
        return klines

    def get_orderbook(self, symbol: str, limit: int = 20, use_cache: bool = True,
                      market: Optional[str] = None) -> Dict[str, Any]:
        market_name = self._market(market)
        capped = max(1, min(400, int(limit)))
        key = f"okx:depth:{market_name}:{symbol}:{capped}"
        if use_cache:
            cached = self._cache_get(key)
            if cached is not None:
                return cached
        inst_id = self.to_inst_id(symbol, market_name)
        rows = self._public("/api/v5/market/books", {"instId": inst_id, "sz": capped}, timeout=4.0)
        book = rows[0] if rows else {}
        contract_value = 1.0
        if market_name == "FUTURES":
            try:
                contract_value = float(self._instrument(inst_id).get("ctVal", "1") or 1)
            except Exception:
                contract_value = 1.0
        result = {
            "bids": [[float(p), float(q) * contract_value] for p, q, *_ in book.get("bids", [])],
            "asks": [[float(p), float(q) * contract_value] for p, q, *_ in book.get("asks", [])],
        }
        if use_cache:
            self._cache_set(key, getattr(_cfg, "ORDERBOOK_CACHE_TTL_SEC", 8), result)
        return result

    def get_account_info(self) -> Dict[str, Any]:
        rows = self._private("GET", "/api/v5/account/balance")
        return rows[0] if rows else {}

    def get_positions(self, market: Optional[str] = None) -> List[Dict[str, Any]]:
        market_name = self._normalize_market(market) if market else None
        if market_name == "SPOT":
            balances = self._private("GET", "/api/v5/account/balance")
            holdings: List[Dict[str, Any]] = []
            for account in balances:
                for detail in account.get("details", []) or []:
                    ccy = str(detail.get("ccy") or "")
                    try:
                        available = float(detail.get("availBal") or detail.get("cashBal") or 0.0)
                    except (TypeError, ValueError):
                        continue
                    if not ccy or ccy in QUOTE_ASSETS or available <= 0:
                        continue
                    holdings.append({
                        "instId": f"{ccy}-USDT",
                        "ccy": ccy,
                        "pos": str(available),
                        "market": "SPOT",
                        "raw": detail,
                    })
            return holdings
        rows = self._private("GET", "/api/v5/account/positions", {"instType": "SWAP"})
        return [dict(row, market="FUTURES") for row in rows]

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str = "MARKET",
        quantity: Optional[float] = None,
        quote_order_qty: Optional[float] = None,
        market: Optional[str] = None,
        reduce_only: bool = False,
        close_full: bool = False,
    ) -> Dict[str, Any]:
        market_name = self._market(market)
        if market_name == "SPOT" and not self.supports_spot:
            raise ValueError("OKX spot trading is disabled (OKX_SPOT_ENABLED=false).")
        if market_name == "FUTURES" and not self.supports_futures:
            raise ValueError("OKX futures trading is disabled (OKX_FUTURES_ENABLED=false).")
        inst_id = self.to_inst_id(symbol, market_name)
        side_l = str(side).lower()
        body: Dict[str, Any] = {
            "instId": inst_id,
            "side": side_l,
            "ordType": str(order_type).lower(),
        }
        if market_name == "SPOT":
            body["tdMode"] = "cash"
            if quantity is not None:
                body["sz"] = self._format_quantity(inst_id, quantity, market_name)
                body["tgtCcy"] = "base_ccy"
            elif quote_order_qty is not None:
                body["sz"] = _decimal_str(_decimal(quote_order_qty))
                body["tgtCcy"] = "quote_ccy"
            else:
                raise ValueError("Either quantity or quote_order_qty must be provided.")
        else:
            self._prepare_leverage(inst_id)
            hedge = self._position_mode() == "hedge"
            body["tdMode"] = self.margin_mode
            if reduce_only:
                if hedge:
                    body["posSide"] = "short" if side_l == "buy" else "long"
                else:
                    body["reduceOnly"] = True
                if close_full:
                    size = self._position_contracts(inst_id, body.get("posSide"))
                    if size is None:
                        if quantity is None:
                            raise ValueError("Cannot determine OKX position size for full close.")
                        size = self._contracts_for_quantity(inst_id, quantity)
                    body["sz"] = size
                elif quantity is not None:
                    body["sz"] = self._contracts_for_quantity(inst_id, quantity)
                else:
                    raise ValueError("quantity is required for a futures partial close.")
            else:
                if hedge:
                    body["posSide"] = "long" if side_l == "buy" else "short"
                if quote_order_qty is not None:
                    body["sz"] = _decimal_str(_decimal(quote_order_qty))
                    body["tgtCcy"] = "quote_ccy"
                elif quantity is not None:
                    body["sz"] = self._contracts_for_quantity(inst_id, quantity)
                else:
                    raise ValueError("Either quantity or quote_order_qty must be provided.")
        rows = self._private("POST", "/api/v5/trade/order", body=body)
        row = rows[0] if rows else {}
        if str(row.get("sCode", "0")) != "0":
            raise OKXAPIError(row.get("sCode"), row.get("sMsg", "order rejected"), row)
        return {
            "orderId": row.get("ordId"),
            "clientOrderId": row.get("clOrdId"),
            "symbol": symbol,
            "market": market_name,
            "instId": inst_id,
            "raw": row,
        }

    def place_oco_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        take_profit_price: float,
        stop_price: float,
        stop_limit_price: Optional[float] = None,
        market: Optional[str] = None,
    ) -> Dict[str, Any]:
        market_name = self._market(market)
        if market_name == "SPOT" and not self.supports_spot:
            raise ValueError("OKX spot trading is disabled (OKX_SPOT_ENABLED=false).")
        if market_name == "FUTURES" and not self.supports_futures:
            raise ValueError("OKX futures trading is disabled (OKX_FUTURES_ENABLED=false).")
        inst_id = self.to_inst_id(symbol, market_name)
        body: Dict[str, Any] = {
            "instId": inst_id,
            "side": str(side).lower(),
            "ordType": "oco" if market_name == "SPOT" else "conditional",
            "tpTriggerPx": _decimal_str(_decimal(take_profit_price)),
            "tpOrdPx": "-1",
            "slTriggerPx": _decimal_str(_decimal(stop_price)),
            "slOrdPx": "-1",
        }
        if market_name == "SPOT":
            body["tdMode"] = "cash"
            body["sz"] = self._format_quantity(inst_id, quantity, market_name)
        else:
            body["tdMode"] = self.margin_mode
            pos_side = None
            if self._position_mode() == "hedge":
                pos_side = "short" if str(side).lower() == "buy" else "long"
                body["posSide"] = pos_side
            else:
                body["reduceOnly"] = True
            body["sz"] = self._position_contracts(inst_id, pos_side) or self._contracts_for_quantity(inst_id, quantity)
        rows = self._private("POST", "/api/v5/trade/order-algo", body=body)
        row = rows[0] if rows else {}
        if str(row.get("sCode", "0")) != "0":
            raise OKXAPIError(row.get("sCode"), row.get("sMsg", "algo order rejected"), row)
        algo_id = row.get("algoId")
        return {"orderListId": algo_id, "algoId": algo_id, "symbol": symbol, "raw": row}

    def cancel_oco_order(self, symbol: str, order_list_id: Any, market: Optional[str] = None) -> Dict[str, Any]:
        market_name = self._market(market)
        inst_id = self.to_inst_id(symbol, market_name)
        rows = self._private(
            "POST",
            "/api/v5/trade/cancel-algos",
            body=[{"algoId": str(order_list_id), "instId": inst_id}],
        )
        return rows[0] if rows else {}

    def get_funding_rate(self, symbol: str, market: Optional[str] = None) -> Optional[float]:
        if not self.supports_futures:
            return None
        now = time.time()
        if now < self._funding_backoff_until:
            return None
        try:
            inst_id = self.to_inst_id(symbol, "FUTURES")
            rows = self._public("/api/v5/public/funding-rate", {"instId": inst_id}, timeout=4.0)
            if rows and rows[0].get("fundingRate") not in (None, ""):
                return float(rows[0]["fundingRate"])
            return None
        except Exception:
            self._funding_backoff_until = now + float(getattr(_cfg, "FUNDING_FETCH_BACKOFF_SEC", 900))
            return None
