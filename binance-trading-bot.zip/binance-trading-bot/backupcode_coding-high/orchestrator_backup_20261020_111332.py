from typing import Dict, Any, List
from datetime import datetime, timezone
from binance_api import BinanceClient
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.momentum import MomentumAnalystAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent
from agents.macro_sentinel import MacroMarketSentinel
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)
from agents.consciousness import consciousness_engine
import config


class TradingOrchestrator:
    def __init__(self):
        self.client = BinanceClient()
        self.llm = LLMClient()
        self.macro_sentinel = MacroMarketSentinel(self.client, self.llm)
        self.scanner = ScannerAgent(self.client)
        self.momentum_data_agent = MomentumAnalystAgent(self.client)
        self.orderbook_data_agent = OrderbookAgent(self.client)
        self.risk_data_agent = RiskManagementAgent()
        self.portfolio = PortfolioManagerAgent(self.client)

        self.narrative_spec = MarketNarrativeSpecialist(self.llm)
        self.price_action_spec = PriceActionSpecialist(self.llm)
        self.exhaustion_spec = MomentumExhaustionSpecialist(self.llm)
        self.microstructure_spec = MicrostructureSpecialist(self.llm)
        self.sentiment_spec = MarketSentimentSpecialist(self.llm)
        self.cro_spec = ChiefRiskOfficerSpecialist(self.llm)
        self.profit_spec = ProfitExtractionSpecialist(self.llm)
        self.executive_spec = ExecutiveStrategistSpecialist(self.llm)

    @staticmethod
    def _is_real_loss(event: Dict[str, Any]) -> bool:
        """A loss must clear the scratch band (PIT-015). Break-even scratches such
        as -0.0029 USDT are not losses and must not tighten gates or trigger
        symbol cooldowns."""
        outcome = event.get("outcome")
        if outcome:
            return outcome == "LOSS"
        pnl = float(event.get("pnl_usdt", 0.0))
        pnl_pct = abs(float(event.get("pnl_pct", 0.0) or 0.0))
        return pnl < 0 and pnl_pct > 0.05

    def _consecutive_losses(self) -> int:
        import json
        try:
            if not config.TRADE_LOG_FILE.exists():
                return 0
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
            streak = 0
            for event in reversed(events):
                if event.get("action") != "CLOSED":
                    continue
                if event.get("outcome") == "SCRATCH" or (
                    not event.get("outcome") and not self._is_real_loss(event)
                    and abs(float(event.get("pnl_pct", 0.0) or 0.0)) <= 0.05
                ):
                    continue  # scratches neither extend nor break a streak
                if self._is_real_loss(event):
                    streak += 1
                else:
                    break
            return streak
        except (OSError, ValueError, TypeError):
            return 0

    def _adaptive_tightening(self) -> Dict[str, int]:
        streak = self._consecutive_losses()
        if not config.ADAPTIVE_GATES_ENABLED or streak < config.LOSS_STREAK_TIGHTEN_AFTER:
            return {"loss_streak": streak, "steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        steps = min(
            config.MAX_TIGHTEN_STEPS,
            1 + (streak - config.LOSS_STREAK_TIGHTEN_AFTER),
        )
        return {
            "loss_streak": streak,
            "steps": steps,
            "score_bonus": steps * config.LOSS_STREAK_SCORE_BONUS,
            "conviction_bonus": steps * config.LOSS_STREAK_CONVICTION_BONUS,
        }

    def _daily_loss_limit_hit(self) -> bool:
        perf = self.portfolio.get_periodic_performance().get("today", {})
        net = float(perf.get("net_pnl_usdt", 0.0))
        initial = float(self.portfolio.state.get("initial_capital", config.INITIAL_PAPER_BALANCE_USDT))
        return net < 0 and abs(net) >= initial * (config.DAILY_LOSS_LIMIT_PCT / 100.0)

    def _symbols_in_cooldown(self) -> Dict[str, str]:
        blocked: Dict[str, str] = {}
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return blocked
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
        except (OSError, ValueError, TypeError):
            return blocked

        tf_minutes = {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240}
        bar_min = tf_minutes.get(config.KLINES_TIMEFRAME, 15)
        window_min = bar_min * config.SYMBOL_COOLDOWN_BARS
        now = datetime.now(timezone.utc)

        for event in reversed(events[-60:]):
            if event.get("action") != "CLOSED":
                continue
            if not self._is_real_loss(event):
                continue
            try:
                exited = datetime.fromisoformat(event["exit_time"])
            except (KeyError, ValueError):
                continue
            age_min = (now - exited).total_seconds() / 60.0
            if age_min < window_min:
                remaining = window_min - age_min
                blocked[event["symbol"]] = f"Cooldown after loss ({remaining:.0f}m left)"
        return blocked

    def _deterministic_specialist_report(self, spec, data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for m in spec.staff:
            r = m.evaluate(data)
            staff_reports.append({
                "staff_name": m.name,
                "role_title": m.role_title,
                "system_role": getattr(m, "system_role", ""),
                "verdict": r["verdict"],
                "conviction": r["conviction"],
                "rationale": r["rationale"],
                "signal": r["signal"]
            })
        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]
        verdict = "REJECT" if vetoes else "APPROVE"
        if not staff_reports:
            conv = 0
        elif vetoes:
            conv = min(s["conviction"] for s in staff_reports)
        else:
            conv = int(sum(s["conviction"] for s in staff_reports) / len(staff_reports))
        rat = f"Department Veto: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}" if vetoes else f"{spec.role_name} approved."

        return {
            "specialist": spec.role_name,
            "lead_title": spec.lead_title,
            "icon": spec.icon,
            "verdict": verdict,
            "conviction": conv,
            "rationale": rat,
            "engine": "Deterministic Engine (Learned Heuristics)",
            "engine_mode": "DETERMINISTIC_LEARNED",
            "ai_verdict": None,
            "staff_reports": staff_reports
        }

    def maybe_upgrade_agent_intelligence(self) -> Dict[str, Any]:
        try:
            trade_history = self.portfolio.get_trade_history()
            portfolio_state = self.portfolio.state
            return self.llm.upgrade_agent_intelligence(consciousness_engine, trade_history, portfolio_state)
        except Exception as e:
            print(f"[Consciousness] Intelligence upgrade skipped: {type(e).__name__}: {e}")
            return {"success": False, "mode": "SKIPPED"}

    def run_cycle(self) -> Dict[str, Any]:
        import time as _time
        _t0 = _time.monotonic()
        timing: Dict[str, float] = {}
        adaptive = self._adaptive_tightening()
        results = {
            "ai_status": self.llm.status_summary,
            "macro_health": {},
            "exit_events": [],
            "candidates_scanned": 0,
            "candidates_evaluated": [],
            "executed_trades": [],
            "portfolio_summary": {},
            "adaptive_guard": adaptive,
            "daily_loss_limit_hit": False,
        }

        exit_events = self.portfolio.update_and_monitor_positions()
        results["exit_events"] = exit_events

        if exit_events:
            for ev in exit_events:
                if float(ev.get("pnl_usdt", 0.0)) < 0:
                    consciousness_engine.record_trade_failure_and_learn(ev)
                else:
                    consciousness_engine.record_trade_success_and_reward(ev)
            self.maybe_upgrade_agent_intelligence()

        open_positions = self.portfolio.get_open_positions()
        current_equity = self.portfolio.get_equity()

        macro_health = self.macro_sentinel.evaluate_macro_health()
        results["macro_health"] = macro_health

        available_slots = config.MAX_OPEN_POSITIONS - len(open_positions)
        circuit_breaker_active = not macro_health.get("safe_to_trade", True)
        daily_limit_hit = self._daily_loss_limit_hit()
        results["daily_loss_limit_hit"] = daily_limit_hit
        cooldowns = self._symbols_in_cooldown()
        results["symbols_in_cooldown"] = cooldowns

        def _dir(pos: Dict[str, Any]) -> str:
            return "SHORT" if (pos.get("direction") == "SHORT" or pos.get("side") == "SELL") else "LONG"

        def _correlation_full(positions: List[Dict[str, Any]], direction: str) -> bool:
            # Correlated beta = same-direction exposure. A SHORT next to two
            # LONGs is a hedge; the old global count blocked it at slot 3.
            return sum(1 for p in positions if _dir(p) == direction) >= config.MAX_CORRELATED_POSITIONS

        # Spend the evaluation budget only on directions that can actually
        # execute. Live 2026-10-19: STRONG_BULLISH regime paused shorts, yet 23
        # of the top-40 slots were shorts, crowding out executable longs.
        longs_allowed = not circuit_breaker_active
        shorts_allowed = bool(macro_health.get("safe_for_shorts", True))
        if longs_allowed and shorts_allowed:
            direction_filter = "ALL"
        elif longs_allowed:
            direction_filter = "LONG"
        elif shorts_allowed:
            direction_filter = "SHORT"
        else:
            direction_filter = "NONE"
        results["scan_direction_filter"] = direction_filter

        top_limit = getattr(config, "SCANNER_TOP_LIMIT", 20)
        candidates = self.scanner.scan_trending_pairs(top_limit=top_limit, direction_filter=direction_filter)
        results["candidates_scanned"] = len(candidates)

        # Market-data prefetch is read-only, so it runs in parallel (bounded to
        # stay far below Binance request-weight limits). Decisions, sizing and
        # execution below remain strictly sequential.
        def _base(sym: str) -> str:
            for q in config.ACCEPTED_QUOTE_ASSETS:
                if sym.endswith(q):
                    return sym[: -len(q)]
            return sym

        held = {pos["symbol"] for pos in open_positions}
        held_bases = {_base(s) for s in held}
        # Same coin on another quote (SOLUSDT vs SOLUSDC) = same exposure.
        to_eval = [c for c in candidates if c["symbol"] not in held and _base(c["symbol"]) not in held_bases]

        def _fetch(cand: Dict[str, Any]):
            d = cand.get("direction", "LONG")
            try:
                ob = self.orderbook_data_agent.inspect_orderbook(cand["symbol"], direction=d)
            except Exception as exc:
                ob = {"passed": False, "reason": f"Orderbook fetch error: {exc}"}
            try:
                mom = self.momentum_data_agent.analyze_symbol(
                    cand["symbol"], extra_score_required=adaptive["score_bonus"], direction=d, btc_context=macro_health
                )
            except Exception as exc:
                mom = {"passed": False, "score": 0, "gate_failures": [f"Market feed error: {exc}"]}
            return ob, mom

        timing["scan_s"] = round(_time.monotonic() - _t0, 2)
        from concurrent.futures import ThreadPoolExecutor
        prefetch: Dict[str, Any] = {}
        if to_eval:
            with ThreadPoolExecutor(max_workers=min(6, len(to_eval))) as pool:
                for cand, res in zip(to_eval, pool.map(_fetch, to_eval)):
                    prefetch[cand["symbol"]] = res
        timing["market_data_s"] = round(_time.monotonic() - _t0 - timing["scan_s"], 2)
        _t_delib = _time.monotonic()

        for candidate in to_eval:
            try:
                symbol = candidate["symbol"]
                direction = candidate.get("direction", "LONG")
                target_market = candidate.get("target_market", "SPOT" if direction == "LONG" else "FUTURES")

                if any(pos["symbol"] == symbol or _base(pos["symbol"]) == _base(symbol) for pos in open_positions):
                    continue

                ob_eval, mom_eval = prefetch[symbol]
                correlation_full = _correlation_full(open_positions, direction)
                risk_scale = (
                    getattr(config, "SELECTIVE_SHORT_RISK_MULT", 0.5)
                    if direction == "SHORT" and macro_health.get("selective_shorts") else 1.0
                )
                # Size and place stops from the executable side of the LIVE
                # book (LONG pays the ask, SHORT receives the bid). The last
                # closed 15m close was 0.3-1.8% away from the real market on
                # 2026-10-19 and silently shrank a 0.8% stop to ~0.45%.
                quote_key = "best_ask" if direction == "LONG" else "best_bid"
                live_quote = ob_eval.get(quote_key)
                signal_price = mom_eval.get("price")
                price_failures: List[str] = []
                if not (isinstance(live_quote, (int, float)) and live_quote > 0):
                    price_failures.append("Live price unavailable (no executable orderbook quote)")
                    live_quote = None
                elif isinstance(signal_price, (int, float)) and signal_price > 0:
                    drift_pct = abs(live_quote - signal_price) / signal_price * 100.0
                    max_drift = getattr(config, "MAX_SIGNAL_DRIFT_PCT", 1.0)
                    if drift_pct > max_drift:
                        price_failures.append(
                            f"Stale signal: live {quote_key} drifted {drift_pct:.2f}% from analysed close (> {max_drift}%)"
                        )
                risk_eval = self.risk_data_agent.evaluate_risk(
                    symbol=symbol,
                    current_price=live_quote or 0.0,
                    atr=mom_eval.get("atr", 0.0),
                    total_equity=current_equity,
                    open_positions=open_positions,
                    direction=direction,
                    target_market=target_market,
                    risk_scale=risk_scale
                ) if live_quote is not None else {"approved": False, "reason": "Live price unavailable"}

                hard_gate_failures: List[str] = list(price_failures)
                if risk_eval.get("approved"):
                    risk_eval["price_source"] = "ORDERBOOK_BEST_ASK" if direction == "LONG" else "ORDERBOOK_BEST_BID"
                    risk_eval["signal_price"] = signal_price

                if symbol in cooldowns:
                    hard_gate_failures.append(cooldowns[symbol])
                if config.REQUIRE_MOMENTUM_PASS and not mom_eval.get("passed", False):
                    hard_gate_failures.extend(
                        mom_eval.get("gate_failures") or [mom_eval.get("reason", "Momentum gate failed")]
                    )
                if config.REQUIRE_ORDERBOOK_PASS and not ob_eval.get("passed", False):
                    hard_gate_failures.append(
                        f"Orderbook gate: {ob_eval.get('reason', 'liquidity check failed')}"
                    )
                if ob_eval.get("passed"):
                    if direction == "LONG" and ob_eval.get("imbalance", 0.0) < config.MIN_ORDERBOOK_IMBALANCE:
                        hard_gate_failures.append(
                            f"Orderbook bid support weak (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                        )
                    elif direction == "SHORT" and ob_eval.get("imbalance", 0.0) > 0.40:
                        hard_gate_failures.append(
                            f"Heavy buyer absorption opposing short (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                        )
                if candidate.get("count_trades", 0) < config.MIN_TRADE_COUNT_24H:
                    hard_gate_failures.append(
                        f"Thin participation ({candidate.get('count_trades', 0):,} trades/24h < {config.MIN_TRADE_COUNT_24H:,})"
                    )
                if not risk_eval.get("approved"):
                    hard_gate_failures.append(f"Risk desk: {risk_eval.get('reason', 'risk plan rejected')}")

                if direction == "LONG" and circuit_breaker_active:
                    hard_gate_failures.append("Macro Sentinel: Bitcoin circuit breaker active (altcoin longs suspended)")
                elif direction == "SHORT" and not macro_health.get("safe_for_shorts", True):
                    hard_gate_failures.append(
                        "Macro Sentinel: " + (macro_health.get("short_block_reason") or "Market regime not suitable for short entries")
                    )

                is_macro_blocked = (circuit_breaker_active if direction == "LONG" else not macro_health.get("safe_for_shorts", True))
                # Capacity/correlation/daily blocks are known BEFORE deliberation;
                # querying 8 LLM divisions for a trade that cannot execute cost
                # up to ~90s per candidate (live cycle measured 297s).
                execution_blocked = available_slots <= 0 or is_macro_blocked or daily_limit_hit or correlation_full
                if not hard_gate_failures and not execution_blocked:
                    lesson_audits = (
                        ("Technical Price Action Division", {"candle": mom_eval.get("candle", {}), "volume_surge": mom_eval.get("volume_surge")}),
                        ("Momentum Exhaustion Division", {"rsi": mom_eval.get("rsi", 50.0)}),
                        ("Order Book Microstructure Division", {"spread_pct": ob_eval.get("spread_pct", 0.0)}),
                    )
                    for lesson_div, lesson_metrics in lesson_audits:
                        audit = consciousness_engine.audit_against_experience(lesson_div, lesson_metrics)
                        if audit and audit.get("violation") and audit.get("action") in ("VETO", "PENALTY_OR_VETO"):
                            hard_gate_failures.append(
                                f"Learned Lesson Veto ({audit.get('rule_id', '?')}): {audit.get('reason', '')}"
                            )
                gates_passed = len(hard_gate_failures) == 0
                skip_llm = (not gates_passed) or execution_blocked

                if skip_llm:
                    rep_narrative = self._deterministic_specialist_report(self.narrative_spec, candidate)
                    rep_pa = self._deterministic_specialist_report(self.price_action_spec, {"momentum_data": mom_eval})
                    rep_exhaustion = self._deterministic_specialist_report(self.exhaustion_spec, {"momentum_data": mom_eval})
                    rep_micro = self._deterministic_specialist_report(self.microstructure_spec, {"orderbook_data": {**ob_eval, "direction": direction}})
                    rep_sentiment = self._deterministic_specialist_report(self.sentiment_spec, {"momentum_data": mom_eval, "ticker_data": candidate})
                    rep_cro = self._deterministic_specialist_report(self.cro_spec, {"risk_plan": risk_eval})
                    rep_profit = self._deterministic_specialist_report(self.profit_spec, {"risk_plan": risk_eval})
                else:
                    from concurrent.futures import ThreadPoolExecutor
                    with ThreadPoolExecutor(max_workers=7) as executor:
                        fn = executor.submit(self.narrative_spec.analyze, {**candidate, "skip_llm": False})
                        fp = executor.submit(self.price_action_spec.analyze, {"momentum_data": mom_eval, "skip_llm": False})
                        fe = executor.submit(self.exhaustion_spec.analyze, {"momentum_data": mom_eval, "skip_llm": False})
                        fm = executor.submit(self.microstructure_spec.analyze, {"orderbook_data": {**ob_eval, "direction": direction}, "skip_llm": False})
                        fs = executor.submit(self.sentiment_spec.analyze, {"momentum_data": mom_eval, "ticker_data": candidate, "skip_llm": False})
                        fc = executor.submit(self.cro_spec.analyze, {"risk_plan": risk_eval, "skip_llm": False})
                        fr = executor.submit(self.profit_spec.analyze, {"risk_plan": risk_eval, "skip_llm": False})
                        rep_narrative = fn.result()
                        rep_pa = fp.result()
                        rep_exhaustion = fe.result()
                        rep_micro = fm.result()
                        rep_sentiment = fs.result()
                        rep_cro = fc.result()
                        rep_profit = fr.result()

                all_specialist_reports = [
                    rep_narrative,
                    rep_pa,
                    rep_exhaustion,
                    rep_micro,
                    rep_sentiment,
                    rep_cro,
                    rep_profit
                ]

                if gates_passed and execution_blocked:
                    executive_verdict = {
                        "specialist": self.executive_spec.role_name,
                        "lead_title": self.executive_spec.lead_title,
                        "icon": self.executive_spec.icon,
                        "final_verdict": "WATCHLIST",
                        "consensus_conviction": 0,
                        "consensus_status": "WATCHLIST_ONLY",
                        "engine_mode": "DETERMINISTIC",
                        "summary": "Setup valid, but execution capacity/risk caps are active; tracked on watchlist.",
                        "direction": direction,
                        "target_market": target_market,
                        "staff_reports": []
                    }
                elif not gates_passed:
                    executive_verdict = {
                        "specialist": self.executive_spec.role_name,
                        "lead_title": self.executive_spec.lead_title,
                        "icon": self.executive_spec.icon,
                        "final_verdict": "REJECT",
                        "consensus_conviction": 0,
                        "consensus_status": "GATES_BLOCKED",
                        "engine_mode": "DETERMINISTIC",
                        "summary": f"Trade blocked by Quality Gates: {hard_gate_failures[0]}",
                        "direction": direction,
                        "target_market": target_market,
                        "staff_reports": []
                    }
                else:
                    executive_verdict = self.executive_spec.synthesize(
                        all_specialist_reports,
                        extra_conviction_required=adaptive["conviction_bonus"]
                    )
                    executive_verdict["direction"] = direction
                    executive_verdict["target_market"] = target_market

                can_execute = (
                    available_slots > 0
                    and not is_macro_blocked
                    and not daily_limit_hit
                    and not correlation_full
                    and gates_passed
                )
                if available_slots <= 0:
                    execution_note = "CAPACITY_FULL_SURVEILLANCE"
                elif is_macro_blocked:
                    execution_note = "CIRCUIT_BREAKER_ACTIVE" if direction == "LONG" else "MACRO_REGIME_SHORT_PAUSE"
                elif daily_limit_hit:
                    execution_note = "DAILY_LOSS_LIMIT_PAUSE"
                elif correlation_full:
                    execution_note = f"CORRELATION_CAP_REACHED ({config.MAX_CORRELATED_POSITIONS} {direction} positions)"
                elif not gates_passed:
                    execution_note = f"QUALITY_GATE_BLOCKED: {hard_gate_failures[0]}"
                else:
                    execution_note = "READY_TO_EXECUTE"

                eval_record = {
                    "symbol": symbol,
                    "direction": direction,
                    "target_market": target_market,
                    "side": risk_eval.get("side", "BUY"),
                    "price": candidate["price"],
                    "price_change_24h": candidate["price_change_24h"],
                    "quote_volume_24h": candidate["quote_volume_24h"],
                    "technical_score": mom_eval.get("score", 0),
                    "min_score_required": mom_eval.get("min_score_required"),
                    "hard_gate_failures": hard_gate_failures,
                    "gates_passed": gates_passed,
                    "specialist_reports": all_specialist_reports,
                    "executive_verdict": executive_verdict,
                    "risk_plan": risk_eval,
                    "can_execute": can_execute,
                    "execution_note": execution_note
                }
                results["candidates_evaluated"].append(eval_record)

                if can_execute and executive_verdict["final_verdict"] == "APPROVE" and risk_eval.get("approved"):
                    success = self.portfolio.execute_trade(risk_eval)
                    if success:
                        results["executed_trades"].append(eval_record)
                        open_positions = self.portfolio.get_open_positions()
                        available_slots = config.MAX_OPEN_POSITIONS - len(open_positions)

                if available_slots <= 0 and len(results["candidates_evaluated"]) >= 2:
                    break
            except Exception as e:
                print(f"[Orchestrator Warning] Candidate {candidate.get('symbol')} skipped ({type(e).__name__}): {e}")
                continue

        if available_slots <= 0:
            status = f"Capacity full ({config.MAX_OPEN_POSITIONS}/{config.MAX_OPEN_POSITIONS}) - Watchlist surveillance active"
        elif daily_limit_hit:
            status = f"Daily loss guard active (-{config.DAILY_LOSS_LIMIT_PCT}%) - entries paused, surveillance live"
        elif circuit_breaker_active:
            status = "Macro circuit breaker active - entries paused, surveillance live"
        elif adaptive["steps"] > 0:
            status = f"Active scanning (defensive mode: +{adaptive['score_bonus']} score / +{adaptive['conviction_bonus']}% conviction required)"
        else:
            status = "Active scanning"

        timing["deliberation_s"] = round(_time.monotonic() - _t_delib, 2)
        timing["total_s"] = round(_time.monotonic() - _t0, 2)
        results["timing"] = timing
        import re as _re
        funnel: Dict[str, int] = {}
        for rec in results["candidates_evaluated"]:
            for reason in set(_re.sub(r"\(.*?\)|[-+]?\d[\d.,]*%?x?", "", str(r)).strip(" :") for r in rec.get("hard_gate_failures", [])):
                funnel[reason] = funnel.get(reason, 0) + 1
        results["rejection_funnel"] = sorted(
            ({"reason": k, "count": v} for k, v in funnel.items()), key=lambda x: -x["count"]
        )[:12]
        results["gates_passed_count"] = sum(1 for rec in results["candidates_evaluated"] if rec.get("gates_passed"))

        results["portfolio_summary"] = {
            "equity_usdt": round(self.portfolio.get_equity(), 2),
            "cash_usdt": round(self.portfolio.state["cash_usdt"], 2),
            "open_positions": self.portfolio.get_open_positions(),
            "realized_pnl_usdt": round(self.portfolio.state.get("realized_pnl_usdt", 0.0), 4),
            "total_trades": self.portfolio.state.get("total_trades", 0),
            "winning_trades": self.portfolio.state.get("winning_trades", 0),
            "status": status
        }
        results["consciousness"] = consciousness_engine.get_ultra_context_summary()

        return results
