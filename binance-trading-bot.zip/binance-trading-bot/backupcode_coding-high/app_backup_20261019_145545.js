/* Aegis Telemetry — app controller: polling, tabs, service worker.
 * Read-only: this file issues GET /api/status only. No control endpoints.
 */
(() => {
  'use strict';
  const U = window.AegisUtil;
  const V = window.AegisViews;
  const V2 = window.AegisViews2;
  const C = window.AegisChart;

  const POLL_MS = 2000;
  let lastGood = null;
  let pipeline = null;
  let timer = null;

  function paint(d) {
    V.header(d);
    V.overview(d);
    V.macro(d);
    V.positions(d);
    window.AegisOperations.render(d);
    V2.agents(d);
    V2.history(d);
    V2.footer(d);
    C.render(d);
    if (pipeline) pipeline.setData(d);
  }

  /* Poll loop: on failure keep the last-good data on screen and show reconnecting. */
  async function poll() {
    try {
      const res = await fetch('/api/status', { cache: 'no-store', headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      lastGood = data;
      paint(data);
    } catch (err) {
      console.warn('Telemetry reconnecting:', err && err.message);
      const conn = U.$('#connection');
      if (conn) conn.className = 'connection-pill reconnecting';
      U.setText('connectionText', 'Reconnecting');
      U.setText('updatedAt', lastGood ? 'Last-good data retained' : 'Waiting for first response');
      window.AegisOperations.stale(true);
    } finally {
      clearTimeout(timer);
      timer = setTimeout(poll, POLL_MS);
    }
  }

  function initTabs() {
    U.$$('.tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.tab;
        U.$$('.tab').forEach((b) => {
          const on = b === btn;
          b.classList.toggle('active', on);
          b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        U.$$('.view').forEach((v) => v.classList.toggle('active', v.dataset.view === name));
        window.scrollTo({ top: 0, behavior: U.reduced ? 'auto' : 'smooth' });
        // Canvases sized while display:none need a re-measure once visible.
        if (name === 'agents' && pipeline) pipeline.resize();
        if (name === 'overview' && lastGood) C.render(lastGood);
      });
    });
  }

  function init() {
    try {
      pipeline = window.AegisPipeline.create(U.$('#pipelineCanvas'), U.$('#pipelineTooltip'));
    } catch (err) {
      console.warn('Pipeline canvas unavailable:', err && err.message);
    }
    initTabs();
    poll();

    // If the Chart.js CDN is blocked, switch the equity curve to the local renderer.
    setTimeout(() => {
      if (!window.Chart) {
        C.forceFallback();
        if (lastGood) C.render(lastGood);
      }
    }, 2500);

    window.addEventListener('resize', () => { if (lastGood) C.render(lastGood); }, { passive: true });

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .catch((err) => console.warn('Service worker unavailable:', err && err.message));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
