/* Aegis Telemetry — view renderers (Overview / Positions) */
window.AegisViews = (() => {
  'use strict';
  const U = window.AegisUtil;

  function header(d) {
    const loop = d.autonomous_loop || {};
    U.setText('mode', d.mode || 'PAPER');
    U.setText('scanMeta', 'Autonomous loop · ' + U.safe(loop.interval_sec, 10) + 's · ' +
      (loop.last_cycle_time || 'warming up'));
    U.setText('updatedAt', 'Updated ' + new Date().toLocaleTimeString('id-ID',
      { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    const conn = U.$('#connection');
    conn.className = 'connection-pill connected';
    U.setText('connectionText', 'Live');
    const wave = '<span class="scan-wave" aria-hidden="true"><i></i><i></i><i></i></span>';
    U.setHTML('engineState', (loop.is_scanning ? 'SCANNING' + wave : 'MONITORING'));
  }

  function overview(d) {
    U.flash('netPnl', d.total_net_pnl_usdt);
    U.flash('unrealized', d.unrealized_pnl_usdt);

    U.countTo('equity', d.equity_usdt, (v) => U.money(v) + ' <small>USDT</small>');
    U.countTo('netPnl', d.total_net_pnl_usdt,
      (v) => U.signed(v) + ' · ' + U.pct(d.total_net_pnl_pct));
    U.$('#netPnl').className = 'pnl-line ' + U.cls(d.total_net_pnl_usdt);

    U.countTo('cash', d.cash_usdt, (v) => U.money(v));
    U.countTo('allocated', d.allocated_margin_usdt, (v) => U.money(v));
    U.countTo('realized', d.realized_pnl_usdt, (v) => U.money(v));
    U.countTo('unrealized', d.unrealized_pnl_usdt, (v) => U.signed(v));
    U.$('#unrealized').className = 'stat-value ' + U.cls(d.unrealized_pnl_usdt);
    U.setText('unrealizedPct', U.pct(d.unrealized_pnl_pct) + ' on allocation');

    // Win-rate gauge: ledger rate vs the configured target.
    const ledger = d.ledger_win_rate != null ? d.ledger_win_rate : d.win_rate;
    const target = U.safe(d.win_rate_target, 70);
    U.countTo('winRate', ledger, (v) => U.num(v, 1) + '%');
    U.$('#winRate').className = 'metric-value ' + (U.safe(ledger) >= target ? 'positive' : '');
    U.setText('tradeRecord', U.safe(d.winning_trades) + 'W · ' + U.safe(d.losing_trades) + 'L · ' +
      U.safe(d.total_trades) + ' total');
    U.setProgress('winProgress', ledger);
    U.setText('winTarget', 'Target ' + U.num(target, 0) + '% · rolling ' +
      U.num(d.rolling_win_rate_20, 1) + '% (n=' + U.safe(d.rolling_sample_size) + ')');

    U.setText('capacity', U.safe(d.capacity_used) + ' / ' + U.safe(d.capacity_max, 3));
    U.setProgress('capacityProgress', U.safe(d.capacity_used) / Math.max(1, U.safe(d.capacity_max, 3)) * 100);

    U.countTo('profitFactor', d.profit_factor, (v) => U.num(v, 2));
    U.$('#profitFactor').className = 'metric-value ' + (U.safe(d.profit_factor) >= 1 ? 'positive' : 'negative');
    U.setText('expectancy', 'Expectancy ' + U.signed(d.expectancy_usdt, 4) + ' / trade');

    U.countTo('avgWin', d.avg_win_usdt, (v) => U.money(v, 2));
    U.setText('avgLoss', 'Avg loss ' + U.money(d.avg_loss_usdt, 2) + ' · fees ' + U.money(d.total_fees_paid_usdt, 2));

    U.countTo('cycles', (d.autonomous_loop || {}).cycle_count, (v) => Math.round(v));
    U.setText('scanCount', U.safe((d.latest_scan || {}).candidates_scanned) + ' assets scanned this cycle');
  }

  function macro(d) {
    const m = d.macro_health || {};
    U.setText('macroPrice', m.price ? U.money(m.price) : '—');
    U.setText('regimeName', U.title(m.regime || 'UNKNOWN'));
    const bad = m.circuit_breaker || m.safe_to_trade === false;
    const badge = U.$('#regimeBadge');
    badge.textContent = bad ? 'RISK GUARD' : 'SAFE';
    badge.className = 'regime-badge' + (bad ? ' risk' : '');
    U.setText('macroRsi', m.rsi != null ? U.num(m.rsi, 1) : '—');
    U.setText('macroEma', m.ema21 != null ? U.num(m.ema21, 0) : '—');
    U.setText('macroDrop', m.drop_4h_pct != null ? U.pct(m.drop_4h_pct) : '—');
    U.$('#macroDrop').className = U.cls(m.drop_4h_pct);
    U.setText('macroRationale', m.rationale || 'Menunggu evaluasi kondisi makro.');

    const guard = d.adaptive_guard || {};
    const chips = [
      '<span class="guard-chip">Loss streak <b>' + U.safe(guard.loss_streak) + '</b></span>',
      '<span class="guard-chip">Guard steps <b>' + U.safe(guard.steps) + '</b></span>',
      '<span class="guard-chip">Score bonus <b>' + U.safe(guard.score_bonus) + '</b></span>',
      d.daily_loss_limit_hit
        ? '<span class="guard-chip alert">Daily loss limit reached</span>'
        : '<span class="guard-chip">Daily limit clear</span>',
    ];
    U.setHTML('guardRow', chips.join(''));
    U.setHTML('quotes', (d.accepted_quotes || [])
      .map((q) => '<span class="quote-chip">' + U.esc(q) + '</span>').join(''));
  }

  function positions(d) {
    const items = d.open_positions || [];
    U.setText('positionMeta', items.length + ' active · ' + U.money(d.allocated_margin_usdt) + ' allocated');
    const root = U.$('#positions');
    if (!items.length) {
      root.innerHTML = '<article class="card empty-state"><div><div class="empty-orbit"></div>' +
        '<div class="empty-title">Tidak ada posisi terbuka</div>' +
        '<div class="empty-copy">Engine tetap memantau pasar dan kandidat baru.</div></div></article>';
      return;
    }
    root.innerHTML = items.map((p) => {
      const low = U.safe(p.stop_loss_price);
      const high = U.safe(p.take_profit_2) || U.safe(p.take_profit_1);
      const cur = U.safe(p.current_price);
      const at = high > low ? Math.max(0, Math.min(100, (cur - low) / (high - low) * 100)) : 50;
      const stateLabel = p.trailing_active ? 'Trailing active'
        : p.break_even_active ? 'Break-even locked'
        : p.tp1_hit ? 'TP1 harvested' : 'Risk guarded';
      return '<article class="card position-card">' +
        '<div class="position-head"><div><div class="pair">' + U.esc(p.pair_display || p.symbol) + '</div>' +
        '<div class="pair-sub">' + U.safe(p.holding_minutes) + ' min · ' + U.num(p.quantity, 4) + ' qty</div></div>' +
        '<div class="pos-pnl ' + U.cls(p.unrealized_pnl_usdt) + '">' + U.signed(p.unrealized_pnl_usdt, 4) +
        '<small>' + U.pct(p.unrealized_pnl_pct) + '</small></div></div>' +
        '<div class="price-strip">' +
        '<div class="price-cell"><span>Entry</span><strong>' + U.num(p.entry_price, 6) + '</strong></div>' +
        '<div class="price-cell"><span>Mark</span><strong>' + U.num(p.current_price, 6) + '</strong></div>' +
        '<div class="price-cell"><span>TP2</span><strong>' + U.num(p.take_profit_2, 6) + '</strong></div></div>' +
        '<div class="risk-track"><i class="risk-marker" style="left:' + at + '%"></i></div>' +
        '<div class="position-foot"><span>SL ' + U.num(p.stop_loss_price, 6) + '</span><span>' +
        stateLabel + '</span><span>TP1 ' + U.num(p.take_profit_1, 6) + '</span></div></article>';
    }).join('');
  }

  return { header, overview, macro, positions };
})();
