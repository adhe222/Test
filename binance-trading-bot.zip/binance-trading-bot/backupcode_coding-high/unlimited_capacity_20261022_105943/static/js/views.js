/* Aegis Telemetry — view renderers (Ringkasan / Pasar macro / Posisi) */
window.AegisViews = (() => {
  'use strict';
  const U = window.AegisUtil;

  function header(d) {
    const loop = d.autonomous_loop || {};
    U.setText('mode', d.mode || 'UNKNOWN');
    U.setText('scanMeta', 'Jeda antar-scan ' + U.safe(loop.interval_sec, 10) + 's · scan terakhir ' +
      window.AegisOperations.stamp(loop.last_cycle_time));
    U.setText('updatedAt', 'Diperbarui ' + new Date().toLocaleTimeString('id-ID',
      { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    const conn = U.$('#connection');
    if (conn) conn.className = 'connection-pill connected';
    U.setText('connectionText', 'Terhubung');
    const wave = '<span class="scan-wave" aria-hidden="true"><i></i><i></i><i></i></span>';
    U.setHTML('engineState', (loop.is_scanning ? 'SCANNING' + wave : 'MONITORING'));
    const count = U.$('#tabPositionsCount');
    if (count) {
      const n = U.safe(d.capacity_used);
      count.textContent = String(n);
      count.hidden = n === 0;
    }
  }

  /* One-line answer to "what is the bot doing and why" — top of Ringkasan. */
  function statusBanner(d) {
    const scan = d.latest_scan || {};
    const loop = d.autonomous_loop || {};
    const ops = d.market_operations || {};
    const routes = Array.isArray(ops.routes) ? ops.routes : [];
    const eligible = routes.filter((r) => r.entry_eligible);
    const passed = U.safe(d.gates_passed_count);
    const executed = (scan.executed_trades || []).length;
    const banner = U.$('#statusBanner');
    let tone = 'idle';
    let title = 'Menunggu scan pertama';
    let sub = 'Engine sedang menyiapkan data pasar.';

    if (d.daily_loss_limit_hit) {
      tone = 'alert'; title = 'Entry dijeda: batas rugi harian tercapai';
      sub = 'Posisi terbuka tetap dijaga; entry baru dilanjutkan besok (UTC).';
    } else if (U.safe(d.capacity_used) >= U.safe(d.capacity_max, 3)) {
      tone = 'busy'; title = 'Slot posisi penuh';
      sub = 'Engine fokus mengelola ' + U.safe(d.capacity_used) + ' posisi; kandidat tetap dipantau.';
    } else if (executed > 0) {
      tone = 'ok'; title = executed + ' posisi baru dibuka pada scan terakhir';
      sub = (scan.executed_trades || []).map((t) => t.symbol + ' ' + (t.direction || '')).join(', ');
    } else if (scan.completed_at) {
      const dirs = eligible.map((r) => r.market + ' ' + r.direction).join(' & ') || 'tidak ada jalur';
      tone = eligible.length ? 'scan' : 'warn';
      title = eligible.length
        ? 'Aktif mencari setup · jalur terbuka: ' + dirs
        : 'Semua jalur entry ditahan oleh Macro Sentinel';
      const top = (d.rejection_funnel || [])[0];
      sub = passed > 0
        ? passed + ' kandidat lolos hard gate, tetapi belum mencapai konsensus eksekutif.'
        : top ? 'Penolak utama: ' + top.reason + ' (' + top.count + ' kandidat).'
        : 'Belum ada kandidat yang memenuhi kriteria.';
    }
    if (loop.is_scanning) sub = 'Sedang memindai… · ' + sub;
    if (banner) banner.dataset.tone = tone;
    U.setText('statusBannerTitle', title);
    U.setText('statusBannerSub', sub);

    U.setText('cycles', String(U.safe(loop.cycle_count)));
    U.setText('scanCount', String(U.safe(scan.candidates_scanned)));
    U.setText('gatesPassed', String(passed));
    const t = scan.timing || {};
    U.setText('cycleDuration', t.total_s != null ? U.num(t.total_s, 0) + ' s' : '—');
  }

  function overview(d) {
    statusBanner(d);
    U.flash('netPnl', d.total_net_pnl_usdt);
    U.flash('unrealized', d.unrealized_pnl_usdt);

    U.countTo('equity', d.equity_usdt, (v) => U.money(v) + ' <small>USDT</small>');
    U.countTo('netPnl', d.total_net_pnl_usdt,
      (v) => U.signed(v) + ' · ' + U.pct(d.total_net_pnl_pct));
    U.$('#netPnl').className = 'pnl-line ' + U.cls(d.total_net_pnl_usdt);

    U.countTo('cash', d.cash_usdt, (v) => U.money(v));
    U.countTo('allocated', d.allocated_margin_usdt, (v) => U.money(v));
    U.setText('capacityFoot', U.safe(d.capacity_used) + ' / ' + U.safe(d.capacity_max, 3) + ' slot terpakai');
    U.countTo('realized', d.realized_pnl_usdt, (v) => U.signed(v));
    U.$('#realized').className = 'stat-value ' + U.cls(d.realized_pnl_usdt);
    U.setText('feesFoot', 'Fee dibayar ' + U.money(d.total_fees_paid_usdt, 2));
    U.countTo('unrealized', d.unrealized_pnl_usdt, (v) => U.signed(v));
    U.$('#unrealized').className = 'stat-value ' + U.cls(d.unrealized_pnl_usdt);
    U.setText('unrealizedPct', U.pct(d.unrealized_pnl_pct) + ' dari alokasi');

    // Win rate vs the breakeven win rate of the actual payoff (not a vanity target).
    const ledger = U.safe(d.ledger_win_rate);
    const be = U.safe(d.breakeven_win_rate);
    U.countTo('winRate', ledger, (v) => U.num(v, 1) + '%');
    U.$('#winRate').className = 'metric-value ' + (be > 0 ? (ledger >= be ? 'positive' : 'negative') : '');
    U.setText('tradeRecord', U.safe(d.ledger_wins) + 'W · ' + U.safe(d.ledger_losses) + 'L · ' +
      U.safe(d.ledger_scratches) + ' scratch · n=' + U.safe(d.ledger_closed_trades));
    U.setProgress('winProgress', ledger);
    const mark = U.$('#breakevenMark');
    if (mark) { mark.style.left = Math.max(0, Math.min(100, be)) + '%'; mark.hidden = be <= 0; }
    U.setText('winTarget', 'Breakeven ' + U.num(be, 1) + '% · rolling-20 ' +
      U.num(d.rolling_win_rate_20, 1) + '% (n=' + U.safe(d.rolling_sample_size) + ')');

    U.setText('capacity', U.safe(d.capacity_used) + ' / ' + U.safe(d.capacity_max, 3));
    U.setProgress('capacityProgress', U.safe(d.capacity_used) / Math.max(1, U.safe(d.capacity_max, 3)) * 100);
    const g = d.quality_gates || {};
    U.setText('capacityCaption', 'Maks ' + U.safe(g.max_correlated_same_direction, 2) + ' searah · ' +
      U.num(g.max_position_size_pct, 1) + '% equity/posisi');

    U.countTo('profitFactor', d.profit_factor, (v) => U.num(v, 2));
    U.$('#profitFactor').className = 'metric-value ' + (U.safe(d.profit_factor) >= 1 ? 'positive' : 'negative');
    U.setText('expectancy', 'Expectancy ' + U.signed(d.expectancy_usdt, 2) + ' / trade');

    U.countTo('avgWin', d.avg_win_usdt, (v) => U.money(v, 2));
    U.setText('avgLoss', 'Avg loss ' + U.money(d.avg_loss_usdt, 2));

    periods(d);
    funnel(d);
  }

  function periods(d) {
    const p = d.periodic_performance || {};
    const labels = [['today', 'Hari ini'], ['this_week', '7 hari'], ['this_month', 'Bulan ini']];
    U.setHTML('periodic', labels.map(([key, label]) => {
      const x = p[key] || {};
      return '<div class="period-row"><div><div class="period-title">' + label + '</div>' +
        '<div class="period-foot">' + U.safe(x.trades) + ' trade · ' + U.safe(x.wins) + 'W/' + U.safe(x.losses) + 'L/' +
        U.safe(x.scratches) + 'S · win ' + U.num(x.win_rate, 1) + '%</div></div>' +
        '<div class="period-right"><div class="period-pnl ' + U.cls(x.net_pnl_usdt) + '">' + U.signed(x.net_pnl_usdt) + '</div>' +
        '<div class="period-foot">fee ' + U.money(x.fees_paid_usdt) + '</div></div></div>';
    }).join(''));
  }

  function funnel(d) {
    const rows = Array.isArray(d.rejection_funnel) ? d.rejection_funnel : [];
    const total = Math.max(1, U.safe((d.latest_scan || {}).candidates_scanned));
    U.setText('funnelMeta', rows.length ? U.safe(d.gates_passed_count) + ' / ' + total + ' kandidat lolos semua gate' : '—');
    U.setHTML('rejectionFunnel', rows.length
      ? rows.slice(0, 8).map((r) => {
        const pct = Math.min(100, U.safe(r.count) / total * 100);
        return '<div class="funnel-row"><span class="funnel-label" title="' + U.esc(r.reason) + '">' + U.esc(r.reason) + '</span>' +
          '<span class="funnel-bar"><i style="width:' + pct.toFixed(1) + '%"></i></span>' +
          '<b class="funnel-count">' + U.safe(r.count) + '</b></div>';
      }).join('')
      : '<p class="card-note">Belum ada data penolakan pada scan terakhir.</p>');
  }

  function macro(d) {
    const m = d.macro_health || {};
    U.setText('macroPrice', m.price ? U.money(m.price) : '—');
    U.setText('regimeName', U.title(m.regime || 'UNKNOWN'));
    const bad = m.circuit_breaker || m.safe_to_trade === false;
    const badge = U.$('#regimeBadge');
    badge.textContent = bad ? 'RISK GUARD' : 'SAFE';
    badge.className = 'regime-badge' + (bad ? ' risk' : '');
    U.setText('macroRsi', m.rsi != null ? U.num(m.rsi, 1) : '—');
    U.setText('macroEma', m.ema21 != null ? U.num(m.ema21, 0) : '—');
    U.setText('macroDrop', m.drop_4h_pct != null ? U.pct(m.drop_4h_pct) : '—');
    U.$('#macroDrop').className = U.cls(m.drop_4h_pct);
    U.setText('macroRationale', m.rationale || 'Menunggu evaluasi kondisi makro.');

    const guard = d.adaptive_guard || {};
    const chips = [
      '<span class="guard-chip">Loss streak <b>' + U.safe(guard.loss_streak) + '</b></span>',
      '<span class="guard-chip">Defensive step <b>' + U.safe(guard.steps) + '</b></span>',
      '<span class="guard-chip">Scan arah <b>' + U.esc(d.scan_direction_filter || '—') + '</b></span>',
      d.daily_loss_limit_hit
        ? '<span class="guard-chip alert">Batas rugi harian tercapai</span>'
        : '<span class="guard-chip">Batas harian aman</span>',
    ];
    U.setHTML('guardRow', chips.join(''));
    U.setHTML('quotes', (d.accepted_quotes || [])
      .map((q) => '<span class="quote-chip">' + U.esc(q) + '</span>').join(''));
  }

  function positions(d) {
    const items = window.AegisOperations.rows(d.open_positions);
    U.setText('positionMeta', items.length + ' aktif · ' + U.money(d.allocated_margin_usdt) + ' teralokasi');
    const root = U.$('#positions');
    if (!items.length) {
      root.innerHTML = '<article class="card empty-state"><div><div class="empty-orbit"></div>' +
        '<div class="empty-title">Tidak ada posisi terbuka</div>' +
        '<div class="empty-copy">Engine tetap memantau pasar dan kandidat baru (Spot Long &amp; Futures Short).</div></div></article>';
      return;
    }
    root.innerHTML = items.map((p) => {
      const direction = p.display_direction || p.direction || 'UNKNOWN';
      const isShort = direction === 'SHORT';
      const known = direction === 'SHORT' || direction === 'LONG';
      const badge = '<span class="side-badge ' + (known ? direction.toLowerCase() : 'unknown') + '">' + U.esc(known ? direction : 'ARAH N/A') + '</span>';
      const low = isShort ? (U.safe(p.take_profit_2) || U.safe(p.take_profit_1)) : U.safe(p.stop_loss_price);
      const high = isShort ? U.safe(p.stop_loss_price) : (U.safe(p.take_profit_2) || U.safe(p.take_profit_1));
      const cur = U.safe(p.current_price);
      const at = high > low
        ? (isShort
            ? Math.max(0, Math.min(100, (high - cur) / (high - low) * 100))
            : Math.max(0, Math.min(100, (cur - low) / (high - low) * 100)))
        : 50;
      const stateLabel = p.trailing_active ? 'Trailing aktif'
        : p.break_even_active ? 'Break-even terkunci'
        : p.tp1_hit ? 'TP1 terealisasi' : 'Stop terpasang';
      return '<article class="card position-card">' +
        '<div class="position-head"><div><div class="pair">' + U.esc(p.pair_display || p.symbol) + badge + '</div>' +
        '<div class="pair-sub">' + U.safe(p.holding_minutes) + ' mnt · ' + U.num(p.quantity, 4) + ' qty' +
        ' · ' + U.esc(p.display_market || p.market || 'Pasar N/A') + ' · ' + U.esc(d.mode === 'PAPER' ? 'SIMULASI' : 'LIVE') + '</div></div>' +
        '<div class="pos-pnl ' + U.cls(p.unrealized_pnl_usdt) + '">' + U.signed(p.unrealized_pnl_usdt, 2) +
        '<small>' + U.pct(p.unrealized_pnl_pct) + '</small></div></div>' +
        '<div class="price-strip">' +
        '<div class="price-cell"><span>Entry</span><strong>' + U.num(p.entry_price, 6) + '</strong></div>' +
        '<div class="price-cell"><span>Mark</span><strong>' + U.num(p.current_price, 6) + '</strong></div>' +
        '<div class="price-cell"><span>Ukuran</span><strong>' + U.money(p.position_usdt) + '</strong></div></div>' +
        '<div class="risk-track" role="img" aria-label="Posisi harga antara stop dan target"><i class="risk-marker" style="left:' + at + '%"></i></div>' +
        '<div class="position-foot"><span>SL ' + U.num(p.stop_loss_price, 6) + '</span><span>' +
        stateLabel + '</span><span>TP1 ' + U.num(p.take_profit_1, 6) + ' · TP2 ' + U.num(p.take_profit_2, 6) + '</span></div></article>';
    }).join('');
  }

  return { header, overview, macro, positions };
})();
