from typing import Dict, Any, List
import config
from config import (
    MAX_OPEN_POSITIONS,
    RISK_PER_TRADE_PCT,
    MAX_POSITION_SIZE_PCT,
    MIN_RISK_REWARD_RATIO,
    HARD_STOP_LOSS_DEFAULT_PCT,
    TARGET_TAKE_PROFIT_PCT,
    TRAILING_STOP_TRIGGER_PCT,
    TRAILING_STOP_DISTANCE_PCT
)


class RiskManagementAgent:
    """
    Risk & Capital Management Agent (The Veto Agent):
    Mandate: Guarantee capital preservation and positive expectancy.
    Calculates volatility-based stop loss, asymmetric risk-to-reward targets,
    and strict position sizing.
    """

    def __init__(self):
        self.name = "RiskManagementAgent"

    def evaluate_risk(
        self,
        symbol: str,
        current_price: float,
        atr: float,
        total_equity: float,
        open_positions: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        # 1. Concurrency Check
        if len(open_positions) >= MAX_OPEN_POSITIONS:
            return {
                "approved": False,
                "reason": f"Maximum open positions limit ({MAX_OPEN_POSITIONS}) reached."
            }

        # Check if symbol already traded
        for pos in open_positions:
            if pos.get("symbol") == symbol:
                return {
                    "approved": False,
                    "reason": f"Active position for {symbol} already exists."
                }

        # 2. Dynamic Stop Loss Calculation using ATR (1.2x ATR - Tighter for Win Rate)
        if atr and atr > 0:
            sl_distance = config.ADAPTIVE_ATR_MULTIPLIER * atr
            sl_price = current_price - sl_distance
            sl_pct = (sl_distance / current_price) * 100.0
        else:
            sl_pct = HARD_STOP_LOSS_DEFAULT_PCT
            sl_price = current_price * (1 - (sl_pct / 100.0))

        # Hard guardrail: Stop Loss must not exceed 3.5% (avoid high-drawdown trades)
        if sl_pct > 3.5:
            sl_pct = 3.5
            sl_price = current_price * (1 - 0.035)
        # And must not be lower than 0.8% (avoid getting stopped by normal noise)
        elif sl_pct < 0.8:
            sl_pct = 0.8
            sl_price = current_price * (1 - 0.008)

        # 3. Take Profit Targets (config-driven R multiples, fee-aware)
        sl_distance_abs = current_price - sl_price
        tp1_price = current_price + (config.TP1_R_MULTIPLE * sl_distance_abs)
        tp2_price = current_price + (config.TP2_R_MULTIPLE * sl_distance_abs)

        # Net R:R after round-trip fees (fees eat into reward and add to risk)
        roundtrip_fee_pct = config.EFFECTIVE_FEE_PCT * 2.0
        fee_cost_abs = current_price * (roundtrip_fee_pct / 100.0)
        net_reward = (tp2_price - current_price) - fee_cost_abs
        net_risk = sl_distance_abs + fee_cost_abs
        actual_rr_ratio = net_reward / net_risk if net_risk > 0 else 0.0

        if actual_rr_ratio < MIN_RISK_REWARD_RATIO:
            return {
                "approved": False,
                "reason": f"Net fee-adjusted Risk-Reward ratio {actual_rr_ratio:.2f} below minimum {MIN_RISK_REWARD_RATIO}"
            }

        # 4. Strict Position Sizing
        # Max risk amount in dollars = total_equity * (RISK_PER_TRADE_PCT / 100)
        risk_dollar_amount = total_equity * (RISK_PER_TRADE_PCT / 100.0)
        
        # Position size in tokens = risk_dollar / (price - sl)
        tokens_qty = risk_dollar_amount / (current_price - sl_price)
        position_cost_usdt = tokens_qty * current_price

        # Cap position cost to MAX_POSITION_SIZE_PCT (e.g. 25% of account)
        max_allowable_cost = total_equity * (MAX_POSITION_SIZE_PCT / 100.0)
        if position_cost_usdt > max_allowable_cost:
            position_cost_usdt = max_allowable_cost
            tokens_qty = position_cost_usdt / current_price

        # Minimum Binance trade size is usually 5-10 USDT
        if position_cost_usdt < 10.0:
            return {
                "approved": False,
                "reason": f"Calculated position size (${position_cost_usdt:.2f}) below minimum trade threshold ($10)"
            }

        return {
            "approved": True,
            "symbol": symbol,
            "entry_price": current_price,
            "atr": round(atr, 8) if atr else 0.0,
            "atr_pct": round((atr / current_price * 100.0), 4) if atr and current_price > 0 else 0.0,
            "stop_loss_price": round(sl_price, 6),
            "stop_loss_pct": round(sl_pct, 2),
            "take_profit_1": round(tp1_price, 6),
            "take_profit_2": round(tp2_price, 6),
            "risk_reward_ratio": round(actual_rr_ratio, 2),
            "position_usdt": round(position_cost_usdt, 2),
            "quantity": round(tokens_qty, 6),
            "trailing_trigger_pct": TRAILING_STOP_TRIGGER_PCT,
            "trailing_distance_pct": TRAILING_STOP_DISTANCE_PCT
        }
