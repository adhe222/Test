"""Tick-by-tick public market stream for OKX and Binance.

The engine used to price positions and candidates with REST snapshots every
few seconds. This module keeps a persistent public websocket per venue and
exposes the latest quote plus a short tick history, so the position guard and
the entry gates read a price that is milliseconds old instead of seconds old.

Design constraints:
  * stdlib + ``websockets`` only (Termux, Python 3.14, no pandas).
  * Never raises into the caller: a dead socket degrades to ``price() -> None``
    and every caller keeps its REST fallback.
  * One background thread owns the asyncio loop; all shared state is guarded
    by an RLock because the trading loop and the web watchdog read concurrently.
"""
from __future__ import annotations

import asyncio
import json
import os
import threading
import time
from collections import deque
from typing import Any, Dict, Iterable, List, Optional, Tuple

import config

try:  # pragma: no cover - exercised at runtime
    import websockets
except Exception:  # pragma: no cover
    websockets = None


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _norm_symbol(symbol: str) -> str:
    raw = str(symbol or "").upper().replace("/", "").replace("-", "")
    if raw.endswith("SWAP"):
        raw = raw[:-4]
    return raw


def _base_quote(symbol: str) -> str:
    raw = _norm_symbol(symbol)
    for quote in ("USDT", "USDC", "USD"):
        if raw.endswith(quote) and len(raw) > len(quote):
            return raw[: -len(quote)]
    return raw


class MarketStream:
    """Persistent tick stream with automatic reconnect and subscription diffing."""

    def __init__(self, exchange: Optional[str] = None):
        self.exchange = str(exchange or getattr(config, "EXCHANGE", "okx")).lower()
        self.enabled = _env_bool("MARKET_STREAM_ENABLED", True)
        self.stale_sec = float(os.getenv("MARKET_STREAM_STALE_SEC", "3.0"))
        self.max_symbols = int(os.getenv("MARKET_STREAM_MAX_SYMBOLS", "80"))
        self.reconcile_sec = float(os.getenv("MARKET_STREAM_RECONCILE_SEC", "2.0"))
        self.history_len = int(os.getenv("MARKET_STREAM_HISTORY", "600"))

        self._lock = threading.RLock()
        self._quotes: Dict[str, Dict[str, Any]] = {}
        self._history: Dict[str, deque] = {}
        self._desired: Dict[str, Tuple[str, str]] = {}
        self._inst_map: Dict[str, Tuple[str, str]] = {}
        self._subscribed: Dict[str, set] = {}
        self._tick_times: deque = deque(maxlen=4000)
        self._listeners = []
        self._last_trigger: Dict[str, float] = {}

        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._stop = threading.Event()
        self._connected: Dict[str, bool] = {}
        self._reconnects = 0
        self._messages = 0
        self._ticks = 0
        self._last_msg_ts = 0.0
        self._last_error = ""
        self._started_ts = 0.0

    # ------------------------------------------------------------------ names
    def _key(self, symbol: str, market: Optional[str]) -> str:
        return f"{str(market or 'SPOT').upper()}:{_norm_symbol(symbol)}"

    def _okx_inst(self, symbol: str, market: str) -> str:
        base = _base_quote(symbol)
        if str(market).upper() == "FUTURES":
            return f"{base}-USDT-SWAP"
        return f"{base}-USDT"

    def _binance_stream(self, symbol: str) -> str:
        return f"{_norm_symbol(symbol).lower()}@aggTrade"

    def _ws_url(self, market: str) -> str:
        if self.exchange == "binance":
            if str(market).upper() == "FUTURES":
                return "wss://fstream.binance.com/stream"
            return "wss://stream.binance.com:9443/stream"
        return "wss://ws.okx.com:8443/ws/v5/public"

    # --------------------------------------------------------------- lifecycle
    def start(self) -> bool:
        if not self.enabled or websockets is None or self._thread:
            return False
        self._started_ts = time.time()
        self._thread = threading.Thread(target=self._thread_main, name="market-stream", daemon=True)
        self._thread.start()
        return True

    def _thread_main(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._supervise())
        except Exception as exc:  # pragma: no cover - defensive
            self._last_error = f"{type(exc).__name__}: {exc}"
        finally:
            try:
                self._loop.close()
            except Exception:
                pass

    async def _supervise(self) -> None:
        markets = ["SPOT", "FUTURES"] if self.exchange != "okx" else ["SPOT", "FUTURES"]
        tasks = [asyncio.create_task(self._serve(market)) for market in markets]
        try:
            while not self._stop.is_set():
                await asyncio.sleep(0.5)
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------ subscriptions
    def ensure(self, symbols: Iterable[str], market: str = "SPOT") -> None:
        market = str(market or "SPOT").upper()
        with self._lock:
            for symbol in symbols or []:
                if not symbol:
                    continue
                key = self._key(symbol, market)
                if key in self._desired:
                    continue
                if len(self._desired) >= self.max_symbols:
                    oldest = next(iter(self._desired))
                    self._desired.pop(oldest, None)
                self._desired[key] = (_norm_symbol(symbol), market)

    def ensure_position(self, symbol: str, market: Optional[str]) -> None:
        self.ensure([symbol], "FUTURES" if str(market or "").upper() == "FUTURES" else "SPOT")

    def _desired_for(self, market: str) -> List[Tuple[str, str]]:
        with self._lock:
            return [v for v in self._desired.values() if v[1] == market]

    # ------------------------------------------------------------------ serve
    async def _serve(self, market: str) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                async with websockets.connect(
                    self._ws_url(market), ping_interval=20, ping_timeout=20,
                    close_timeout=5, max_queue=4096, open_timeout=12,
                ) as ws:
                    self._connected[market] = True
                    backoff = 1.0
                    await self._subscribe_all(ws, market)
                    ping_task = asyncio.create_task(self._app_ping(ws, market))
                    diff_task = asyncio.create_task(self._reconcile(ws, market))
                    try:
                        async for raw in ws:
                            self._handle(raw, market)
                    finally:
                        ping_task.cancel()
                        diff_task.cancel()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self._last_error = f"{market} {type(exc).__name__}: {exc}"
            finally:
                self._connected[market] = False
                self._subscribed.pop(market, None)
            if self._stop.is_set():
                break
            self._reconnects += 1
            await asyncio.sleep(backoff)
            backoff = min(backoff * 1.8, 30.0)

    async def _app_ping(self, ws, market: str) -> None:
        try:
            while not self._stop.is_set():
                await asyncio.sleep(20)
                if self.exchange != "binance":
                    await ws.send("ping")
        except asyncio.CancelledError:
            return
        except Exception:
            return

    async def _subscribe_all(self, ws, market: str) -> None:
        pairs = self._desired_for(market)
        if not pairs:
            return
        if self.exchange == "binance":
            params = [self._binance_stream(sym) for sym, _ in pairs]
            await ws.send(json.dumps({"method": "SUBSCRIBE", "params": params, "id": 1}))
            with self._lock:
                self._subscribed[market] = set(params)
                for sym, mk in pairs:
                    self._inst_map[self._binance_stream(sym)] = (sym, mk)
        else:
            args = [{"channel": "tickers", "instId": self._okx_inst(sym, mk)} for sym, mk in pairs]
            await ws.send(json.dumps({"op": "subscribe", "args": args}))
            with self._lock:
                self._subscribed[market] = {a["instId"] for a in args}
                for sym, mk in pairs:
                    self._inst_map[self._okx_inst(sym, mk)] = (sym, mk)

    async def _reconcile(self, ws, market: str) -> None:
        try:
            while not self._stop.is_set():
                await asyncio.sleep(self.reconcile_sec)
                pairs = self._desired_for(market)
                current = self._subscribed.get(market, set())
                if self.exchange == "binance":
                    wanted = {self._binance_stream(sym) for sym, _ in pairs}
                    add = wanted - current
                    drop = current - wanted
                    if add:
                        await ws.send(json.dumps({"method": "SUBSCRIBE", "params": sorted(add), "id": 2}))
                    if drop:
                        await ws.send(json.dumps({"method": "UNSUBSCRIBE", "params": sorted(drop), "id": 3}))
                    with self._lock:
                        self._subscribed[market] = wanted
                        for sym, mk in pairs:
                            self._inst_map[self._binance_stream(sym)] = (sym, mk)
                else:
                    wanted = {self._okx_inst(sym, mk) for sym, mk in pairs}
                    add = wanted - current
                    drop = current - wanted
                    if add:
                        await ws.send(json.dumps({"op": "subscribe", "args": [{"channel": "tickers", "instId": i} for i in sorted(add)]}))
                    if drop:
                        await ws.send(json.dumps({"op": "unsubscribe", "args": [{"channel": "tickers", "instId": i} for i in sorted(drop)]}))
                    with self._lock:
                        self._subscribed[market] = wanted
                        for sym, mk in pairs:
                            self._inst_map[self._okx_inst(sym, mk)] = (sym, mk)
        except asyncio.CancelledError:
            return
        except Exception as exc:
            self._last_error = f"reconcile {market}: {exc}"

    # ------------------------------------------------------------------ parse
    def _handle(self, raw: Any, market: str) -> None:
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        text = str(raw)
        if not text or text == "pong":
            return
        try:
            payload = json.loads(text)
        except Exception:
            return
        if self.exchange == "binance":
            self._handle_binance(payload, market)
        else:
            self._handle_okx(payload, market)

    def _handle_okx(self, payload: Dict[str, Any], market: str) -> None:
        data = payload.get("data")
        if not isinstance(data, list) or not data:
            return
        arg = payload.get("arg") or {}
        inst = str(arg.get("instId") or "")
        with self._lock:
            mapping = self._inst_map.get(inst)
        if not mapping:
            return
        row = data[0]
        try:
            price = float(row.get("last") or row.get("bidPx") or 0.0)
        except Exception:
            return
        if price <= 0:
            return
        self._store(mapping[0], mapping[1], price, row.get("bidPx"), row.get("askPx"),
                    row.get("ts"), row.get("vol24h"))

    def _handle_binance(self, payload: Dict[str, Any], market: str) -> None:
        stream = str(payload.get("stream") or "")
        data = payload.get("data") or {}
        with self._lock:
            mapping = self._inst_map.get(stream)
        if not mapping:
            symbol = data.get("s")
            if not symbol:
                return
            mapping = (_norm_symbol(symbol), market)
        try:
            price = float(data.get("p") or data.get("c") or 0.0)
        except Exception:
            return
        if price <= 0:
            return
        self._store(mapping[0], mapping[1], price, data.get("b"), data.get("a"),
                    data.get("T"), data.get("q"))

    def _store(self, symbol: str, market: str, price: float, bid, ask, ts, volume) -> None:
        now = time.time()
        quote = {
            "symbol": symbol,
            "market": market,
            "price": float(price),
            "bid": float(bid) if bid not in (None, "") else None,
            "ask": float(ask) if ask not in (None, "") else None,
            "exchange_ts": float(ts) / 1000.0 if ts and float(ts) > 1e11 else float(ts or 0.0),
            "recv_ts": now,
            "volume": volume,
            "source": f"{self.exchange}-ws",
        }
        key = self._key(symbol, market)
        with self._lock:
            self._quotes[key] = quote
            hist = self._history.get(key)
            if hist is None:
                hist = deque(maxlen=self.history_len)
                self._history[key] = hist
            hist.append((now, float(price)))
            self._ticks += 1
            self._messages += 1
            self._last_msg_ts = now
            self._tick_times.append(now)

        for listener in list(self._listeners):
            try:
                listener(quote)
            except Exception:
                pass

    # ------------------------------------------------------------------- reads
    def add_listener(self, fn) -> None:
        if fn not in self._listeners:
            self._listeners.append(fn)

    def movers(self, threshold_pct: float = 0.5, window_sec: float = 60.0,
               cooldown_sec: float = 45.0) -> List[str]:
        """Symbols whose real tick move over the window crossed the threshold."""
        now = time.time()
        out: List[str] = []
        with self._lock:
            for key, hist in self._history.items():
                if len(hist) < 2:
                    continue
                cutoff = now - window_sec
                past = None
                for ts, price in hist:
                    if ts >= cutoff:
                        past = price
                        break
                if not past:
                    continue
                last = hist[-1][1]
                change = ((last - past) / past) * 100.0
                if abs(change) >= threshold_pct and (now - self._last_trigger.get(key, 0.0)) >= cooldown_sec:
                    self._last_trigger[key] = now
                    out.append(key)
        return out

    def quote(self, symbol: str, market: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self._lock:
            keys = [self._key(symbol, market)] if market else [self._key(symbol, "FUTURES"), self._key(symbol, "SPOT")]
            for key in keys:
                quote = self._quotes.get(key)
                if not quote:
                    continue
                age = time.time() - float(quote.get("recv_ts") or 0.0)
                if age > self.stale_sec:
                    continue
                item = dict(quote)
                item["age_sec"] = round(age, 3)
                return item
        return None

    def price(self, symbol: str, market: Optional[str] = None, max_age: Optional[float] = None) -> Optional[float]:
        quote = self.quote(symbol, market)
        if not quote:
            return None
        if max_age is not None and quote.get("age_sec", 0.0) > max_age:
            return None
        return float(quote["price"])

    def velocity(self, symbol: str, market: Optional[str] = None, window_sec: float = 60.0) -> Optional[float]:
        """Percent move over the trailing window, from real ticks only."""
        with self._lock:
            keys = [self._key(symbol, market)] if market else [self._key(symbol, "FUTURES"), self._key(symbol, "SPOT")]
            for key in keys:
                hist = self._history.get(key)
                if not hist or len(hist) < 2:
                    continue
                cutoff = time.time() - window_sec
                past = None
                for ts, price in hist:
                    if ts >= cutoff:
                        past = price
                        break
                if past is None:
                    continue
                last = hist[-1][1]
                if past <= 0:
                    continue
                return round(((last - past) / past) * 100.0, 4)
        return None

    def tick_rate(self, window_sec: float = 5.0) -> float:
        now = time.time()
        with self._lock:
            recent = [ts for ts in self._tick_times if now - ts <= window_sec]
        return round(len(recent) / max(window_sec, 1e-6), 2)

    @property
    def healthy(self) -> bool:
        if not self._connected:
            return False
        return any(self._connected.values()) and (time.time() - self._last_msg_ts) <= max(self.stale_sec * 2, 8.0)

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            symbols = len(self._quotes)
            desired = len(self._desired)
            subscribed = sum(len(v) for v in self._subscribed.values())
            last_age = round(time.time() - self._last_msg_ts, 2) if self._last_msg_ts else None
            return {
                "enabled": self.enabled,
                "exchange": self.exchange,
                "connected": dict(self._connected),
                "healthy": self.healthy,
                "symbols_streaming": symbols,
                "symbols_desired": desired,
                "subscriptions": subscribed,
                "ticks": self._ticks,
                "messages": self._messages,
                "ticks_per_sec": self.tick_rate(),
                "last_message_age_sec": last_age,
                "reconnects": self._reconnects,
                "stale_sec": self.stale_sec,
                "last_error": self._last_error,
                "uptime_sec": round(time.time() - self._started_ts, 1) if self._started_ts else 0.0,
            }


market_stream = MarketStream()
