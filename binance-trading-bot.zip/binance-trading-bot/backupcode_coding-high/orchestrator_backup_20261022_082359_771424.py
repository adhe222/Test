from typing import Dict, Any, List
from datetime import datetime, timezone
from binance_api import BinanceClient
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.momentum import MomentumAnalystAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent, event_outcome
from agents.macro_sentinel import MacroMarketSentinel
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)
from agents.consciousness import consciousness_engine
import config


class TradingOrchestrator:
    def __init__(self):
        self.client = BinanceClient()
        self.llm = LLMClient()
        self.macro_sentinel = MacroMarketSentinel(self.client, self.llm)
        self.scanner = ScannerAgent(self.client)
        self.momentum_data_agent = MomentumAnalystAgent(self.client)
        self.orderbook_data_agent = OrderbookAgent(self.client)
        self.risk_data_agent = RiskManagementAgent()
        self.portfolio = PortfolioManagerAgent(self.client)

        self.narrative_spec = MarketNarrativeSpecialist(self.llm)
        self.price_action_spec = PriceActionSpecialist(self.llm)
        self.exhaustion_spec = MomentumExhaustionSpecialist(self.llm)
        self.microstructure_spec = MicrostructureSpecialist(self.llm)
        self.sentiment_spec = MarketSentimentSpecialist(self.llm)
        self.cro_spec = ChiefRiskOfficerSpecialist(self.llm)
        self.profit_spec = ProfitExtractionSpecialist(self.llm)
        self.executive_spec = ExecutiveStrategistSpecialist(self.llm)

    @staticmethod
    def _adverse_drift_pct(live_quote: float, signal_price: float, direction: str) -> float:
        """Signed drift: positive means the executable quote is worse than the signal."""
        if not signal_price:
            return 0.0
        if str(direction).upper() == "SHORT":
            return (float(signal_price) - float(live_quote)) / float(signal_price) * 100.0
        return (float(live_quote) - float(signal_price)) / float(signal_price) * 100.0

    @staticmethod
    def _signal_age_seconds(signal_generated_at: Any) -> float:
        if not signal_generated_at:
            return 0.0
        try:
            dt = datetime.fromisoformat(str(signal_generated_at))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())
        except (ValueError, TypeError):
            return 0.0

    def _refresh_execution_plan(
        self,
        symbol: str,
        direction: str,
        signal_price: Any,
        signal_generated_at: Any,
        atr: float,
        total_equity: float,
        open_positions: List[Dict[str, Any]],
        target_market: str,
        risk_scale: float,
        entry_metrics: Dict[str, Any],
    ):
        age = self._signal_age_seconds(signal_generated_at)
        max_age = float(getattr(config, "MAX_SIGNAL_AGE_SEC", 120))
        if max_age > 0 and age > max_age:
            return None, f"Execution-time stale signal: age {age:.0f}s > {max_age}s"
        try:
            fresh_ob = self.orderbook_data_agent.inspect_orderbook(
                symbol, direction=direction, use_cache=False
            )
        except Exception as exc:
            return None, f"Execution-time orderbook error: {type(exc).__name__}"
        if not fresh_ob.get("passed"):
            return None, f"Execution-time orderbook gate: {fresh_ob.get('reason', 'failed')}"
        quote_key = "best_ask" if direction == "LONG" else "best_bid"
        fresh_quote = fresh_ob.get(quote_key)
        if not isinstance(fresh_quote, (int, float)) or fresh_quote <= 0:
            return None, f"Execution-time stale signal: fresh {quote_key} unavailable"
        drift = self._adverse_drift_pct(fresh_quote, signal_price, direction)
        max_drift = float(getattr(config, "MAX_SIGNAL_DRIFT_PCT", 0.8))
        if drift > max_drift:
            return None, (
                f"Execution-time stale signal: fresh {quote_key} drifted adversely "
                f"{drift:.2f}% (> {max_drift}%)"
            )
        plan = self.risk_data_agent.evaluate_risk(
            symbol=symbol,
            current_price=fresh_quote,
            atr=atr,
            total_equity=total_equity,
            open_positions=open_positions,
            direction=direction,
            target_market=target_market,
            risk_scale=risk_scale,
        )
        if not plan.get("approved"):
            return None, f"Execution-time risk desk: {plan.get('reason', 'rejected')}"
        plan["price_source"] = (
            "FRESH_ORDERBOOK_BEST_ASK" if direction == "LONG" else "FRESH_ORDERBOOK_BEST_BID"
        )
        plan["signal_price"] = signal_price
        plan["signal_drift_pct"] = round(drift, 4)
        plan["entry_metrics"] = entry_metrics or {}
        return plan, None

    @staticmethod
    def _is_real_loss(event: Dict[str, Any]) -> bool:
        """A loss must clear the scratch band (PIT-015). Break-even scratches such
        as -0.0029 USDT are not losses and must not tighten gates or trigger
        symbol cooldowns."""
        outcome = event.get("outcome")
        if outcome:
            return outcome == "LOSS"
        pnl = float(event.get("pnl_usdt", 0.0))
        pnl_pct = abs(float(event.get("pnl_pct", 0.0) or 0.0))
        return pnl < 0 and pnl_pct > 0.05

    def _consecutive_losses(self) -> int:
        import json
        try:
            if not config.TRADE_LOG_FILE.exists():
                return 0
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
            streak = 0
            for event in reversed(events):
                if event.get("action") != "CLOSED":
                    continue
                if event.get("outcome") == "SCRATCH" or (
                    not event.get("outcome") and not self._is_real_loss(event)
                    and abs(float(event.get("pnl_pct", 0.0) or 0.0)) <= 0.05
                ):
                    continue  # scratches neither extend nor break a streak
                if self._is_real_loss(event):
                    streak += 1
                else:
                    break
            return streak
        except (OSError, ValueError, TypeError):
            return 0

    def _hours_since_last_close(self) -> float:
        import json
        try:
            if not config.TRADE_LOG_FILE.exists():
                return 0.0
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
            for event in reversed(events):
                if event.get("action") != "CLOSED":
                    continue
                ts = event.get("exit_time")
                if not ts:
                    return 0.0
                try:
                    dt = datetime.fromisoformat(ts)
                except (ValueError, TypeError):
                    return 0.0
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                return max(0.0, (now - dt).total_seconds() / 3600.0)
            return 0.0
        except (OSError, ValueError, TypeError):
            return 0.0

    def _adaptive_tightening(self) -> Dict[str, int]:
        streak = self._consecutive_losses()
        if not config.ADAPTIVE_GATES_ENABLED or streak < config.LOSS_STREAK_TIGHTEN_AFTER:
            return {"loss_streak": streak, "steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        steps = min(
            config.MAX_TIGHTEN_STEPS,
            1 + (streak - config.LOSS_STREAK_TIGHTEN_AFTER),
        )
        decay_hours = float(getattr(config, "TIGHTEN_STALE_DECAY_HOURS", 12.0))
        if decay_hours > 0:
            steps = max(0, steps - int(self._hours_since_last_close() // decay_hours))
        if steps <= 0:
            return {"loss_streak": streak, "steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        return {
            "loss_streak": streak,
            "steps": steps,
            "score_bonus": steps * config.LOSS_STREAK_SCORE_BONUS,
            "conviction_bonus": steps * config.LOSS_STREAK_CONVICTION_BONUS,
        }

    def _daily_loss_limit_hit(self) -> bool:
        perf = self.portfolio.get_periodic_performance().get("today", {})
        net = float(perf.get("net_pnl_usdt", 0.0))
        initial = float(self.portfolio.state.get("initial_capital", config.INITIAL_PAPER_BALANCE_USDT))
        return net < 0 and abs(net) >= initial * (config.DAILY_LOSS_LIMIT_PCT / 100.0)

    def _direction_performance_guard(self) -> Dict[str, Dict[str, Any]]:
        """Pause a direction whose recent realised expectancy is decisively negative.

        A paused direction is re-probed after a probation window with reduced
        risk, so the guard cannot deadlock the bot permanently.
        """
        directions = ("LONG", "SHORT")
        if not getattr(config, "DIRECTION_GUARD_ENABLED", True):
            return {
                d: {"allowed": True, "reason": "guard disabled", "win_rate": 0.0,
                    "net_pnl_usdt": 0.0, "sample": 0, "probe": False, "risk_scale": 1.0}
                for d in directions
            }
        try:
            history = self.portfolio.get_trade_history()
            if not isinstance(history, list):
                history = []
        except Exception:
            history = []
        portfolio_state = getattr(self.portfolio, "state", {})
        since = str(portfolio_state.get("counter_since") or "") if isinstance(portfolio_state, dict) else ""
        lookback = int(getattr(config, "DIRECTION_GUARD_LOOKBACK", 20))
        min_trades = int(getattr(config, "DIRECTION_GUARD_MIN_TRADES", 12))
        min_wr = float(getattr(config, "DIRECTION_GUARD_MIN_WIN_RATE", 30.0))
        probation_h = float(getattr(config, "DIRECTION_GUARD_PROBATION_HOURS", 6.0))
        probe_risk = float(getattr(config, "DIRECTION_GUARD_PROBE_RISK_MULT", 0.25))
        now = datetime.now(timezone.utc)
        result: Dict[str, Dict[str, Any]] = {}
        for direction in directions:
            rows = []
            for e in history:
                if not isinstance(e, dict) or e.get("action") != "CLOSED":
                    continue
                if since and str(e.get("exit_time", "")) <= since:
                    continue
                d = e.get("direction")
                if d is None:
                    d = "SHORT" if e.get("side") == "SELL" else ("LONG" if e.get("side") == "BUY" else None)
                if d == direction:
                    rows.append(e)
            recent = rows[-lookback:]
            sample = len(recent)
            if sample < min_trades:
                result[direction] = {
                    "allowed": True, "reason": "insufficient closed sample",
                    "win_rate": 0.0, "net_pnl_usdt": 0.0, "sample": sample,
                    "probe": False, "risk_scale": 1.0,
                }
                continue
            outcomes = [event_outcome(e) for e in recent]
            wins = outcomes.count("WIN")
            losses = outcomes.count("LOSS")
            decided = wins + losses
            win_rate = round((wins / decided) * 100.0, 1) if decided else 0.0
            net = round(sum(float(e.get("pnl_usdt", 0.0) or 0.0) for e in recent), 4)
            paused = win_rate < min_wr and net < 0.0
            if not paused:
                result[direction] = {
                    "allowed": True,
                    "reason": "rolling expectancy positive" if net >= 0.0 else "win rate above pause floor; net still negative",
                    "win_rate": win_rate, "net_pnl_usdt": net, "sample": sample,
                    "probe": False, "risk_scale": 1.0,
                }
                continue
            last_exit = max((str(e.get("exit_time", "")) for e in recent), default="")
            idle_hours = 0.0
            try:
                dt = datetime.fromisoformat(last_exit)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                idle_hours = max(0.0, (now - dt).total_seconds() / 3600.0)
            except (ValueError, TypeError):
                idle_hours = 0.0
            if idle_hours >= probation_h:
                result[direction] = {
                    "allowed": True,
                    "reason": f"probation probe after {idle_hours:.1f}h idle",
                    "win_rate": win_rate, "net_pnl_usdt": net, "sample": sample,
                    "probe": True, "risk_scale": probe_risk,
                }
            else:
                result[direction] = {
                    "allowed": False,
                    "reason": f"rolling {sample} trades: WR {win_rate:.1f}% / net {net:+.2f} USDT",
                    "win_rate": win_rate, "net_pnl_usdt": net, "sample": sample,
                    "probe": False, "risk_scale": 0.0,
                }
        return result

    def _symbols_in_cooldown(self) -> Dict[str, str]:
        blocked: Dict[str, str] = {}
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return blocked
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
        except (OSError, ValueError, TypeError):
            return blocked

        tf_minutes = {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240}
        bar_min = tf_minutes.get(config.KLINES_TIMEFRAME, 15)
        window_min = bar_min * config.SYMBOL_COOLDOWN_BARS
        now = datetime.now(timezone.utc)

        for event in reversed(events[-60:]):
            if event.get("action") != "CLOSED":
                continue
            if not self._is_real_loss(event):
                continue
            try:
                exited = datetime.fromisoformat(event["exit_time"])
            except (KeyError, ValueError):
                continue
            age_min = (now - exited).total_seconds() / 60.0
            if age_min < window_min:
                remaining = window_min - age_min
                blocked[event["symbol"]] = f"Cooldown after loss ({remaining:.0f}m left)"
        return blocked

    def _deterministic_specialist_report(self, spec, data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for m in spec.staff:
            r = m.evaluate(data)
            staff_reports.append({
                "staff_name": m.name,
                "role_title": m.role_title,
                "system_role": getattr(m, "system_role", ""),
                "verdict": r["verdict"],
                "conviction": r["conviction"],
                "rationale": r["rationale"],
                "signal": r["signal"]
            })
        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]
        verdict = "REJECT" if vetoes else "APPROVE"
        if not staff_reports:
            conv = 0
        elif vetoes:
            conv = min(s["conviction"] for s in staff_reports)
        else:
            conv = int(sum(s["conviction"] for s in staff_reports) / len(staff_reports))
        rat = f"Department Veto: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}" if vetoes else f"{spec.role_name} approved."

        return {
            "specialist": spec.role_name,
            "lead_title": spec.lead_title,
            "icon": spec.icon,
            "verdict": verdict,
            "conviction": conv,
            "rationale": rat,
            "engine": "Deterministic Engine (Learned Heuristics)",
            "engine_mode": "DETERMINISTIC_LEARNED",
            "ai_verdict": None,
            "staff_reports": staff_reports
        }

    def maybe_upgrade_agent_intelligence(self) -> Dict[str, Any]:
        try:
            trade_history = self.portfolio.get_trade_history()
            portfolio_state = self.portfolio.state
            return self.llm.upgrade_agent_intelligence(consciousness_engine, trade_history, portfolio_state)
        except Exception as e:
            print(f"[Consciousness] Intelligence upgrade skipped: {type(e).__name__}: {e}")
            return {"success": False, "mode": "SKIPPED"}

    def run_cycle(self) -> Dict[str, Any]:
        import time as _time
        _t0 = _time.monotonic()
        timing: Dict[str, float] = {}
        adaptive = self._adaptive_tightening()
        results = {
            "ai_status": self.llm.status_summary,
            "macro_health": {},
            "exit_events": [],
            "candidates_scanned": 0,
            "candidates_evaluated": [],
            "executed_trades": [],
            "portfolio_summary": {},
            "adaptive_guard": adaptive,
            "daily_loss_limit_hit": False,
        }

        exit_events = self.portfolio.update_and_monitor_positions()
        results["exit_events"] = exit_events

        if exit_events:
            for ev in exit_events:
                if float(ev.get("pnl_usdt", 0.0)) < 0:
                    consciousness_engine.record_trade_failure_and_learn(ev)
                else:
                    consciousness_engine.record_trade_success_and_reward(ev)
            self.maybe_upgrade_agent_intelligence()

        # Adaptive-ratchet staleness decay: learned thresholds relax toward the
        # foundation bases while the system is idle (hours since the LAST
        # closed outcome). A fresh loss above already re-armed full tightness,
        # so this can only run after the re-arm, never before it.
        try:
            _last_exit = ""
            for _t in self.portfolio.get_trade_history():
                if isinstance(_t, dict) and _t.get("action") == "CLOSED":
                    _et = str(_t.get("exit_time", ""))
                    if _et > _last_exit:
                        _last_exit = _et
            if _last_exit:
                _last_close = datetime.fromisoformat(_last_exit)
                if _last_close.tzinfo is None:
                    _last_close = _last_close.replace(tzinfo=timezone.utc)
                _hours_idle = (datetime.now(timezone.utc) - _last_close).total_seconds() / 3600.0
            else:
                _hours_idle = 24.0
            _decay = consciousness_engine.apply_staleness_decay(_hours_idle)
            results["staleness_decay"] = _decay
        except Exception as _exc:
            print(f"[STALENESS-DECAY] skipped: {_exc}")

        open_positions = self.portfolio.get_open_positions()
        current_equity = self.portfolio.get_equity()

        macro_health = self.macro_sentinel.evaluate_macro_health()
        results["macro_health"] = macro_health

        available_slots = config.MAX_OPEN_POSITIONS - len(open_positions)
        circuit_breaker_active = not macro_health.get("safe_to_trade", True)
        daily_limit_hit = self._daily_loss_limit_hit()
        results["daily_loss_limit_hit"] = daily_limit_hit
        cooldowns = self._symbols_in_cooldown()
        results["symbols_in_cooldown"] = cooldowns

        def _dir(pos: Dict[str, Any]) -> str:
            return "SHORT" if (pos.get("direction") == "SHORT" or pos.get("side") == "SELL") else "LONG"

        def _correlation_full(positions: List[Dict[str, Any]], direction: str) -> bool:
            # Correlated beta = same-direction exposure. A SHORT next to two
            # LONGs is a hedge; the old global count blocked it at slot 3.
            return sum(1 for p in positions if _dir(p) == direction) >= config.MAX_CORRELATED_POSITIONS

        # Spend the evaluation budget only on directions that can actually
        # execute. Live 2026-10-19: STRONG_BULLISH regime paused shorts, yet 23
        # of the top-40 slots were shorts, crowding out executable longs.
        direction_guard = self._direction_performance_guard()
        results["direction_guard"] = direction_guard
        longs_allowed = bool(macro_health.get("safe_for_longs", not circuit_breaker_active))
        shorts_allowed = bool(macro_health.get("safe_for_shorts", True))
        if not direction_guard.get("LONG", {}).get("allowed", True):
            longs_allowed = False
        if not direction_guard.get("SHORT", {}).get("allowed", True):
            shorts_allowed = False
        if longs_allowed and shorts_allowed:
            direction_filter = "ALL"
        elif longs_allowed:
            direction_filter = "LONG"
        elif shorts_allowed:
            direction_filter = "SHORT"
        else:
            direction_filter = "NONE"
        results["scan_direction_filter"] = direction_filter

        top_limit = getattr(config, "SCANNER_TOP_LIMIT", 20)
        candidates = self.scanner.scan_trending_pairs(top_limit=top_limit, direction_filter=direction_filter)
        results["candidates_scanned"] = len(candidates)

        # Market-data prefetch is read-only, so it runs in parallel (bounded to
        # stay far below Binance request-weight limits). Decisions, sizing and
        # execution below remain strictly sequential.
        def _base(sym: str) -> str:
            for q in config.ACCEPTED_QUOTE_ASSETS:
                if sym.endswith(q):
                    return sym[: -len(q)]
            return sym

        held = {pos["symbol"] for pos in open_positions}
        held_bases = {_base(s) for s in held}
        # Same coin on another quote (SOLUSDT vs SOLUSDC) = same exposure.
        # Statistically auto-banned symbols (portfolio manager, losing recent
        # history) are skipped before any market-data spend.
        try:
            banned_symbols = set(self.portfolio.get_banned_symbols() or [])
        except Exception:
            banned_symbols = set()
        if banned_symbols:
            results["autobanned_symbols_skipped"] = sorted(banned_symbols)
        to_eval = [c for c in candidates if c["symbol"] not in held and _base(c["symbol"]) not in held_bases and c["symbol"] not in banned_symbols]

        # Cluster guard: live 2026-10-20 14:52 UTC, seven SHORTs were opened in
        # one scan and five died together in the same 5-minute flush. No more
        # than MAX_ENTRIES_PER_DIRECTION_PER_CYCLE fresh entries per direction
        # may open per cycle; the rest stay on the watchlist.
        executed_this_cycle: Dict[str, int] = {"LONG": 0, "SHORT": 0}

        def _fetch(cand: Dict[str, Any]):
            d = cand.get("direction", "LONG")
            try:
                ob = self.orderbook_data_agent.inspect_orderbook(cand["symbol"], direction=d)
            except Exception as exc:
                ob = {"passed": False, "reason": f"Orderbook fetch error: {exc}"}
            try:
                mom = self.momentum_data_agent.analyze_symbol(
                    cand["symbol"], extra_score_required=adaptive["score_bonus"], direction=d, btc_context=macro_health
                )
            except Exception as exc:
                mom = {"passed": False, "score": 0, "gate_failures": [f"Market feed error: {exc}"]}
            return ob, mom

        timing["scan_s"] = round(_time.monotonic() - _t0, 2)
        from concurrent.futures import ThreadPoolExecutor
        prefetch: Dict[str, Any] = {}
        if to_eval:
            with ThreadPoolExecutor(max_workers=min(6, len(to_eval))) as pool:
                for cand, res in zip(to_eval, pool.map(_fetch, to_eval)):
                    prefetch[cand["symbol"]] = res
        timing["market_data_s"] = round(_time.monotonic() - _t0 - timing["scan_s"], 2)
        _t_delib = _time.monotonic()

        for candidate in to_eval:
            try:
                symbol = candidate["symbol"]
                direction = candidate.get("direction", "LONG")
                target_market = candidate.get("target_market", "SPOT" if direction == "LONG" else "FUTURES")

                if any(pos["symbol"] == symbol or _base(pos["symbol"]) == _base(symbol) for pos in open_positions):
                    continue

                ob_eval, mom_eval = prefetch[symbol]
                correlation_full = _correlation_full(open_positions, direction)
                guard_state = direction_guard.get(direction, {})
                risk_scale = (
                    getattr(config, "SELECTIVE_SHORT_RISK_MULT", 0.5)
                    if direction == "SHORT" and macro_health.get("selective_shorts") else 1.0
                ) * float(guard_state.get("risk_scale", 1.0) or 1.0)
                risk_scale = max(0.1, min(1.0, risk_scale))
                # Size and place stops from the executable side of the LIVE
                # book (LONG pays the ask, SHORT receives the bid). The last
                # closed 15m close was 0.3-1.8% away from the real market on
                # 2026-10-19 and silently shrank a 0.8% stop to ~0.45%.
                quote_key = "best_ask" if direction == "LONG" else "best_bid"
                live_quote = ob_eval.get(quote_key)
                signal_price = mom_eval.get("price")
                price_failures: List[str] = []
                if not (isinstance(live_quote, (int, float)) and live_quote > 0):
                    _ob_reason = ob_eval.get("reason") if isinstance(ob_eval, dict) else None
                    price_failures.append(
                        f"Live price unavailable ({_ob_reason or 'no executable orderbook quote'})"
                    )
                    live_quote = None
                elif isinstance(signal_price, (int, float)) and signal_price > 0:
                    drift_pct = self._adverse_drift_pct(live_quote, signal_price, direction)
                    max_drift = getattr(config, "MAX_SIGNAL_DRIFT_PCT", 0.8)
                    if drift_pct > max_drift:
                        price_failures.append(
                            f"Stale signal: live {quote_key} drifted adversely {drift_pct:.2f}% from analysed close (> {max_drift}%)"
                        )
                risk_eval = self.risk_data_agent.evaluate_risk(
                    symbol=symbol,
                    current_price=live_quote or 0.0,
                    atr=mom_eval.get("atr", 0.0),
                    total_equity=current_equity,
                    open_positions=open_positions,
                    direction=direction,
                    target_market=target_market,
                    risk_scale=risk_scale
                ) if live_quote is not None else {"approved": False, "reason": "Live price unavailable"}

                hard_gate_failures: List[str] = list(price_failures)
                if risk_eval.get("approved"):
                    risk_eval["price_source"] = "ORDERBOOK_BEST_ASK" if direction == "LONG" else "ORDERBOOK_BEST_BID"
                    risk_eval["signal_price"] = signal_price
                    # Snapshot of the REAL metrics at decision time: stored on
                    # the position and on the closing trade event, so the
                    # evolution loop audits what the entry actually looked like
                    # (the old audit fed it pnl/position as 'volume_change_pct').
                    risk_eval["entry_metrics"] = {
                        "rsi": mom_eval.get("rsi"),
                        "volume_surge": mom_eval.get("volume_surge"),
                        "imbalance": ob_eval.get("imbalance"),
                        "bid_depth_ratio": ob_eval.get("bid_depth_ratio"),
                        "spread_pct": ob_eval.get("spread_pct"),
                        "trend_efficiency": mom_eval.get("trend_efficiency"),
                        "atr_pct": mom_eval.get("atr_pct"),
                        "dist_from_ema21_pct": mom_eval.get("dist_from_ema21_pct"),
                    }

                if symbol in cooldowns:
                    hard_gate_failures.append(cooldowns[symbol])
                if config.REQUIRE_MOMENTUM_PASS and not mom_eval.get("passed", False):
                    hard_gate_failures.extend(
                        mom_eval.get("gate_failures") or [mom_eval.get("reason", "Momentum gate failed")]
                    )
                if config.REQUIRE_ORDERBOOK_PASS and not ob_eval.get("passed", False):
                    hard_gate_failures.append(
                        f"Orderbook gate: {ob_eval.get('reason', 'liquidity check failed')}"
                    )
                if ob_eval.get("passed"):
                    if direction == "LONG" and ob_eval.get("imbalance", 0.0) < config.MIN_ORDERBOOK_IMBALANCE:
                        hard_gate_failures.append(
                            f"Orderbook bid support weak (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                        )
                    elif direction == "SHORT" and ob_eval.get("imbalance", 0.0) > 0.40:
                        hard_gate_failures.append(
                            f"Heavy buyer absorption opposing short (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                        )
                if candidate.get("count_trades", 0) < config.MIN_TRADE_COUNT_24H:
                    hard_gate_failures.append(
                        f"Thin participation ({candidate.get('count_trades', 0):,} trades/24h < {config.MIN_TRADE_COUNT_24H:,})"
                    )
                if not risk_eval.get("approved"):
                    hard_gate_failures.append(f"Risk desk: {risk_eval.get('reason', 'risk plan rejected')}")

                if direction == "LONG" and not macro_health.get("safe_for_longs", not circuit_breaker_active):
                    hard_gate_failures.append(
                        "Macro Sentinel: " + (macro_health.get("long_block_reason") or "Bitcoin regime does not support altcoin longs")
                    )
                elif direction == "SHORT" and not macro_health.get("safe_for_shorts", True):
                    hard_gate_failures.append(
                        "Macro Sentinel: " + (macro_health.get("short_block_reason") or "Market regime not suitable for short entries")
                    )

                is_macro_blocked = (
                    not macro_health.get("safe_for_longs", not circuit_breaker_active)
                    if direction == "LONG"
                    else not macro_health.get("safe_for_shorts", True)
                )
                is_direction_blocked = not guard_state.get("allowed", True)
                if is_direction_blocked:
                    hard_gate_failures.append(
                        f"Direction performance guard: {guard_state.get('reason', 'paused')}"
                    )
                # Capacity/correlation/daily blocks are known BEFORE deliberation;
                # querying 8 LLM divisions for a trade that cannot execute cost
                # up to ~90s per candidate (live cycle measured 297s).
                execution_blocked = (
                    available_slots <= 0 or is_macro_blocked or is_direction_blocked
                    or daily_limit_hit or correlation_full
                )
                if not hard_gate_failures and not execution_blocked:
                    # Learned-threshold enforcement at the gate: every violation
                    # below is counted ONLY here (record_veto_enforced), because
                    # this is the site where a veto really blocks a candidate.
                    lesson_audits = (
                        ("Technical Price Action Division", {"candle": mom_eval.get("candle", {}), "volume_surge": mom_eval.get("volume_surge"), "direction": direction}),
                        ("Momentum Exhaustion Division", {"rsi": mom_eval.get("rsi", 50.0), "direction": direction}),
                        ("Order Book Microstructure Division", {"spread_pct": ob_eval.get("spread_pct", 0.0), "imbalance": ob_eval.get("imbalance"), "bid_depth_ratio": ob_eval.get("bid_depth_ratio"), "direction": direction}),
                        ("Volatility & Market Regime Division", {"trend_efficiency": mom_eval.get("trend_efficiency"), "atr_pct": mom_eval.get("atr_pct"), "direction": direction}),
                    )
                    for lesson_div, lesson_metrics in lesson_audits:
                        audit = consciousness_engine.audit_against_experience(lesson_div, lesson_metrics)
                        if audit and audit.get("violation") and audit.get("action") in ("VETO", "PENALTY_OR_VETO"):
                            hard_gate_failures.append(
                                f"Learned Lesson Veto ({audit.get('rule_id', '?')}): {audit.get('reason', '')}"
                            )
                            try:
                                consciousness_engine.record_veto_enforced(lesson_div, audit.get("rule_id", "?"))
                            except Exception:
                                pass
                gates_passed = len(hard_gate_failures) == 0
                # One AI touchpoint per candidate: divisions run deterministic, and
                # the ONLY LLM call is the executive synthesis review. Seven
                # division LLM calls per candidate opened the circuit breaker
                # 108x and produced 297s scan cycles (live log, 2026-10-19/20).
                rep_narrative = self._deterministic_specialist_report(self.narrative_spec, candidate)
                rep_pa = self._deterministic_specialist_report(self.price_action_spec, {"momentum_data": mom_eval})
                rep_exhaustion = self._deterministic_specialist_report(self.exhaustion_spec, {"momentum_data": mom_eval})
                rep_micro = self._deterministic_specialist_report(self.microstructure_spec, {"orderbook_data": {**ob_eval, "direction": direction}})
                rep_sentiment = self._deterministic_specialist_report(self.sentiment_spec, {"momentum_data": mom_eval, "ticker_data": candidate})
                rep_cro = self._deterministic_specialist_report(self.cro_spec, {"risk_plan": risk_eval})
                rep_profit = self._deterministic_specialist_report(self.profit_spec, {"risk_plan": risk_eval})

                all_specialist_reports = [
                    rep_narrative,
                    rep_pa,
                    rep_exhaustion,
                    rep_micro,
                    rep_sentiment,
                    rep_cro,
                    rep_profit
                ]

                if gates_passed and execution_blocked:
                    executive_verdict = {
                        "specialist": self.executive_spec.role_name,
                        "lead_title": self.executive_spec.lead_title,
                        "icon": self.executive_spec.icon,
                        "final_verdict": "WATCHLIST",
                        "consensus_conviction": 0,
                        "consensus_status": "WATCHLIST_ONLY",
                        "engine_mode": "DETERMINISTIC",
                        "summary": "Setup valid, but execution capacity/risk caps are active; tracked on watchlist.",
                        "direction": direction,
                        "target_market": target_market,
                        "staff_reports": []
                    }
                elif not gates_passed:
                    executive_verdict = {
                        "specialist": self.executive_spec.role_name,
                        "lead_title": self.executive_spec.lead_title,
                        "icon": self.executive_spec.icon,
                        "final_verdict": "REJECT",
                        "consensus_conviction": 0,
                        "consensus_status": "GATES_BLOCKED",
                        "engine_mode": "DETERMINISTIC",
                        "summary": f"Trade blocked by Quality Gates: {hard_gate_failures[0]}",
                        "direction": direction,
                        "target_market": target_market,
                        "staff_reports": []
                    }
                else:
                    executive_verdict = self.executive_spec.synthesize(
                        all_specialist_reports,
                        extra_conviction_required=adaptive["conviction_bonus"]
                    )
                    executive_verdict["direction"] = direction
                    executive_verdict["target_market"] = target_market
                    # NOTE: AI dissent is enforced inside synthesize itself —
                    # the single executive LLM review (LLM_SINGLE_REVIEW) can
                    # REJECT or penalize conviction below the bar there.

                can_execute = (
                    available_slots > 0
                    and not is_macro_blocked
                    and not is_direction_blocked
                    and not daily_limit_hit
                    and not correlation_full
                    and gates_passed
                    and executed_this_cycle.get(direction, 0) < int(getattr(config, "MAX_ENTRIES_PER_DIRECTION_PER_CYCLE", 2))
                )
                if available_slots <= 0:
                    execution_note = "CAPACITY_FULL_SURVEILLANCE"
                elif is_macro_blocked:
                    if direction == "LONG":
                        execution_note = "CIRCUIT_BREAKER_ACTIVE" if circuit_breaker_active else "BEARISH_REGIME_LONGS_PAUSED"
                    else:
                        execution_note = "MACRO_REGIME_SHORT_PAUSE"
                elif is_direction_blocked:
                    execution_note = f"DIRECTION_PERFORMANCE_PAUSE: {guard_state.get('reason', 'paused')}"
                elif daily_limit_hit:
                    execution_note = "DAILY_LOSS_LIMIT_PAUSE"
                elif correlation_full:
                    execution_note = f"CORRELATION_CAP_REACHED ({config.MAX_CORRELATED_POSITIONS} {direction} positions)"
                elif executed_this_cycle.get(direction, 0) >= int(getattr(config, "MAX_ENTRIES_PER_DIRECTION_PER_CYCLE", 2)):
                    execution_note = f"CYCLE_CLUSTER_CAP ({getattr(config, 'MAX_ENTRIES_PER_DIRECTION_PER_CYCLE', 2)} {direction} entries opened this cycle)"
                elif not gates_passed:
                    execution_note = f"QUALITY_GATE_BLOCKED: {hard_gate_failures[0]}"
                else:
                    execution_note = "READY_TO_EXECUTE"

                eval_record = {
                    "symbol": symbol,
                    "direction": direction,
                    "target_market": target_market,
                    "side": risk_eval.get("side", "BUY"),
                    "price": candidate["price"],
                    "price_change_24h": candidate["price_change_24h"],
                    "quote_volume_24h": candidate["quote_volume_24h"],
                    "technical_score": mom_eval.get("score", 0),
                    "min_score_required": mom_eval.get("min_score_required"),
                    "hard_gate_failures": hard_gate_failures,
                    "gates_passed": gates_passed,
                    "specialist_reports": all_specialist_reports,
                    "executive_verdict": executive_verdict,
                    "risk_plan": risk_eval,
                    "can_execute": can_execute,
                    "execution_note": execution_note
                }
                results["candidates_evaluated"].append(eval_record)

                if can_execute and executive_verdict["final_verdict"] == "APPROVE" and risk_eval.get("approved"):
                    execution_plan, execution_error = self._refresh_execution_plan(
                        symbol=symbol,
                        direction=direction,
                        signal_price=signal_price,
                        signal_generated_at=mom_eval.get("signal_generated_at"),
                        atr=mom_eval.get("atr", 0.0),
                        total_equity=current_equity,
                        open_positions=open_positions,
                        target_market=target_market,
                        risk_scale=risk_scale,
                        entry_metrics=risk_eval.get("entry_metrics"),
                    )
                    if execution_plan is None:
                        eval_record["can_execute"] = False
                        eval_record["execution_note"] = execution_error
                        results.setdefault("execution_rejections", []).append(
                            {"symbol": symbol, "reason": execution_error}
                        )
                    else:
                        success = self.portfolio.execute_trade(execution_plan)
                        if success:
                            eval_record["execution_plan"] = execution_plan
                            results["executed_trades"].append(eval_record)
                            executed_this_cycle[direction] = executed_this_cycle.get(direction, 0) + 1
                            open_positions = self.portfolio.get_open_positions()
                            available_slots = config.MAX_OPEN_POSITIONS - len(open_positions)

                if available_slots <= 0 and len(results["candidates_evaluated"]) >= 2:
                    break
            except Exception as e:
                print(f"[Orchestrator Warning] Candidate {candidate.get('symbol')} skipped ({type(e).__name__}): {e}")
                continue

        if available_slots <= 0:
            status = f"Capacity full ({config.MAX_OPEN_POSITIONS}/{config.MAX_OPEN_POSITIONS}) - Watchlist surveillance active"
        elif daily_limit_hit:
            status = f"Daily loss guard active (-{config.DAILY_LOSS_LIMIT_PCT}%) - entries paused, surveillance live"
        elif circuit_breaker_active:
            status = "Macro circuit breaker active - entries paused, surveillance live"
        elif not any(direction_guard.get(d, {}).get("allowed", True) for d in ("LONG", "SHORT")):
            status = "Direction performance guard active - all directions paused, surveillance live"
        elif adaptive["steps"] > 0:
            status = f"Active scanning (defensive mode: +{adaptive['score_bonus']} score / +{adaptive['conviction_bonus']}% conviction required)"
        else:
            status = "Active scanning"

        timing["deliberation_s"] = round(_time.monotonic() - _t_delib, 2)
        timing["total_s"] = round(_time.monotonic() - _t0, 2)
        results["timing"] = timing
        import re as _re
        funnel: Dict[str, int] = {}
        for rec in results["candidates_evaluated"]:
            for reason in set(_re.sub(r"\(.*?\)|[-+]?\d[\d.,]*%?x?", "", str(r)).strip(" :") for r in rec.get("hard_gate_failures", [])):
                funnel[reason] = funnel.get(reason, 0) + 1
        results["rejection_funnel"] = sorted(
            ({"reason": k, "count": v} for k, v in funnel.items()), key=lambda x: -x["count"]
        )[:12]
        results["gates_passed_count"] = sum(1 for rec in results["candidates_evaluated"] if rec.get("gates_passed"))

        results["portfolio_summary"] = {
            "equity_usdt": round(self.portfolio.get_equity(), 2),
            "cash_usdt": round(self.portfolio.state["cash_usdt"], 2),
            "open_positions": self.portfolio.get_open_positions(),
            "realized_pnl_usdt": round(self.portfolio.state.get("realized_pnl_usdt", 0.0), 4),
            "total_trades": self.portfolio.state.get("total_trades", 0),
            "winning_trades": self.portfolio.state.get("winning_trades", 0),
            "status": status
        }
        results["consciousness"] = consciousness_engine.get_ultra_context_summary()

        return results
    
    def autonomous_evolve(self):
        """Trigger autonomous self-evolution cycle (Opsi A implementation)."""
        from agents.consciousness import consciousness_engine
        from pathlib import Path
        import json
        
        print(f"[AUTO-EVOLVE] Starting autonomous evolution at {datetime.now(timezone.utc).isoformat()}...")
        
        # Step 1: Run comprehensive audit of all divisions against historical data
        try:
            result = self.audit_all_divisions()
            print(f"[AUTO-EVOLVE] Audit complete: {result.get('total_audits', 0)} audits run")
        except Exception as e:
            print(f"[AUTO-EVOLVE] Audit failed: {e}")
            raise
        
        # Step 2: Apply lessons learned & calibrated thresholds to consciousness engine
        try:
            conscious_data_path = config.DATA_DIR / "agent_consciousness.json"
            if conscious_data_path.exists():
                with open(conscious_data_path, 'r', encoding='utf-8') as f:
                    consciousness_data = json.load(f)
                
                # Do NOT add result['vetoes_enforced'] to the global counter:
                # those are LOSS trades whose entries would violate today's
                # learned gates (tightening candidates), not live vetoes. The
                # old += here double-counted every historical trade, 8x per
                # cycle, inflating total_vetoes_prevented (e.g. 2433 reported).
                consciousness_data['last_updated'] = datetime.now(timezone.utc).isoformat()
                consciousness_data['last_upgrade_mode'] = "AUTO_EVOLUTION"
                
                with open(conscious_data_path, 'w', encoding='utf-8') as f:
                    json.dump(consciousness_data, f, indent=2)
                
                print(f"[AUTO-EVOLVE] Consciousness updated: {consciousness_data['total_vetoes_prevented']} vetoes enforced, {consciousness_data['total_upgrades_performed']} weight updates")
            
            # Reload consciousness engine memory
            consciousness_engine.reload_memory()
            print("[AUTO-EVOLVE] Memory reloaded — learned constraints now active")
        except Exception as e:
            print(f"[AUTO-EVOLVE] Consciousness update failed: {e}")
            raise
        
        return {
            "status": "evolved",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "vetoes_enforced": result.get('vetoes_enforced', 0),
            "weight_updates": result.get('weight_updates', 0)
        }
    
    def audit_all_divisions(self) -> dict:
        """Audit divisions against trades closed SINCE the last evolution run.

        Metrics come from the entry_metrics snapshot stored when each position
        opened (real RSI / volume surge / imbalance / ATR at decision time).
        The previous implementation re-audited the same last-50 trades every
        cycle with constant fake metrics (pnl/position as 'volume_change_pct',
        missing RSI/imbalance keys), which inflated the global veto counter
        8x per cycle and could never teach anything new.
        """
        from agents.consciousness import consciousness_engine

        trade_history = self.portfolio.get_trade_history()
        if not trade_history:
            return {"success": True, "total_audits": 0, "vetoes_enforced": 0, "weight_updates": 0, "audited_trades": 0}

        watermark = consciousness_engine.get_evolution_watermark()
        last_exit_time = watermark.get("last_audited_exit_time")
        closed = [t for t in trade_history if isinstance(t, dict) and t.get("action") == "CLOSED"]
        pending = [
            t for t in closed
            if last_exit_time is None or str(t.get("exit_time", "")) > str(last_exit_time)
        ][-50:]

        total_audits = 0
        vetoes_enforced = 0
        last_processed_exit = last_exit_time

        for trade in pending:
            em = trade.get("entry_metrics") or {}
            direction = trade.get("direction")
            divisions_to_audit = [
                ("Technical Price Action Division", {"candle": em.get("candle", {}), "volume_surge": em.get("volume_surge"), "direction": direction}),
                ("Momentum Exhaustion Division", {"rsi": em.get("rsi", 50.0), "direction": direction}),
                ("Order Book Microstructure Division", {"spread_pct": em.get("spread_pct", 0.1), "imbalance": em.get("imbalance"), "bid_depth_ratio": em.get("bid_depth_ratio"), "direction": direction}),
                ("Volatility & Market Regime Division", {"trend_efficiency": em.get("trend_efficiency"), "atr_pct": em.get("atr_pct"), "direction": direction}),
            ]
            loss_with_violation = False
            for div_name, metrics in divisions_to_audit:
                try:
                    audit_result = consciousness_engine.audit_against_experience(div_name, metrics)
                    total_audits += 1
                    if audit_result and audit_result.get("violation") and trade.get("outcome") == "LOSS":
                        # This entry passed the gates yet still lost: its
                        # metrics are candidates for threshold tightening on
                        # the next learn cycle (reported, not double-counted
                        # into the global veto counter).
                        loss_with_violation = True
                except Exception as e:
                    print(f"[AUDIT] Failed to audit {div_name}: {e}")
            if loss_with_violation:
                vetoes_enforced += 1
            exit_t = str(trade.get("exit_time", ""))
            if exit_t > str(last_processed_exit or ""):
                last_processed_exit = exit_t

        if pending:
            consciousness_engine.set_evolution_watermark(
                last_processed_exit,
                int(watermark.get("audited_count", 0)) + len(pending),
            )

        return {
            "success": True,
            "total_audits": total_audits,
            "vetoes_enforced": vetoes_enforced,
            "weight_updates": 0,  # Weight updates happen separately via LLM upgrade
            "audited_trades": len(pending),
        }

