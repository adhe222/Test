/* Aegis Telemetry — Canvas 2D multi-agent deliberation flow.
 * Cubic bezier connectors + flowing particle packets, verdict colour coded:
 *   cyan = ingestion/scanning, emerald = approve, crimson = veto/reject.
 * devicePixelRatio aware, ResizeObserver driven, pauses on visibilitychange.
 */
window.AegisPipeline = (() => {
  'use strict';
  const U = window.AegisUtil;
  const readPalette = () => {
    const cs = getComputedStyle(document.documentElement);
    const v = (k, f) => (cs.getPropertyValue(k) || '').trim() || f;
    return { scan: v('--cyan', '#38bdf8'), approve: v('--green', '#34d399'), reject: v('--red', '#f87171'),
             node: v('--node-bg', 'rgba(8,18,32,.96)'), label: v('--text', '#e6edf7'), sub: v('--muted', '#93a3b8') };
  };
  let PALETTE = readPalette();
  const DIV_LABELS = ['Flow', 'Price Action', 'Momentum', 'Orderbook', 'Regime', 'Quant Risk', 'Profit Exit'];

  class Pipeline {
    constructor(canvas, tooltip) {
      this.c = canvas;
      this.ctx = canvas.getContext('2d');
      this.tip = tooltip;
      this.nodes = [];
      this.edges = [];
      this.data = null;
      this.frame = 0;
      this.w = 0;
      this.h = 0;
      this.running = !document.hidden;
      this.pinned = null;

      this.ro = new ResizeObserver(() => this.resize());
      this.ro.observe(canvas.parentElement);
      canvas.addEventListener('pointermove', (e) => { if (e.pointerType !== 'touch') this.pointer(e); });
      canvas.addEventListener('pointerleave', () => this.hide());
      canvas.addEventListener('pointerdown', (e) => this.pointer(e, true));
      document.addEventListener('visibilitychange', () => {
        this.running = !document.hidden;
        if (this.running) this.animate();
      });
      if (window.AegisTheme) {
        window.AegisTheme.onChange(() => { PALETTE = readPalette(); });
      }
      this.resize();
      this.animate();
    }

    setData(d) { this.data = d; this.build(); }

    resize() {
      // Measure the canvas itself (the parent has a 1px border, so parent-box
      // measurements overshoot by 2px and blur the backing store).
      let r = this.c.getBoundingClientRect();
      if (!r.width) r = this.c.parentElement.getBoundingClientRect();
      if (!r.width) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.c.width = Math.max(1, Math.round(r.width * dpr));
      this.c.height = Math.max(1, Math.round(r.height * dpr));
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.w = r.width; this.h = r.height;
      this.build();
    }

    state(v) {
      const s = String(v || '').toUpperCase();
      if (/REJECT|VETO|BLOCK|TRIPPED/.test(s)) return 'reject';
      if (/APPROVE|EXECUTED|SAFE/.test(s)) return 'approve';
      return 'scan';
    }

    node(label, sub, report) {
      return {
        label, sub,
        state: this.state(report && report.verdict),
        verdict: (report && report.verdict) || 'SCANNING',
        conviction: report && report.conviction,
        rationale: (report && report.rationale) || 'Live telemetry stream',
      };
    }

    build() {
      if (!this.w) return;
      const d = this.data || {};
      const scan = d.latest_scan || {};
      const cand = (scan.candidates_evaluated || [])[0];
      const reports = (cand && cand.specialist_reports) || [];
      const find = (frag) => reports.find((r) => String(r.specialist || '').toLowerCase().includes(frag));
      const mk = (l, s, r) => this.node(l, s, r);

      const ingest = [
        mk('Scanner', 'Market ingestion', {
          verdict: (d.autonomous_loop || {}).is_scanning ? 'SCANNING' : 'OBSERVING',
          rationale: U.safe(scan.candidates_scanned) + ' candidates scanned this cycle',
        }),
        mk('Momentum', 'Signal velocity', find('momentum')),
        mk('Orderbook', 'Microstructure', find('order book')),
        mk('Risk', 'Capital guard', find('quantitative risk')),
      ];

      const divs = DIV_LABELS.map((label, i) => mk(label, 'Division ' + (i + 1), reports[i]));

      const execReport = (cand && cand.executive_verdict) || null;
      const executive = mk('Executive', 'Final committee', execReport && {
        verdict: execReport.final_verdict,
        conviction: execReport.consensus_conviction,
        rationale: execReport.summary,
      });

      const executed = (scan.executed_trades || []).length > 0;
      const canExec = cand && cand.can_execute;
      const execution = mk('Execution', 'Order telemetry', {
        verdict: executed ? 'EXECUTED' : (executive.state === 'reject' ? 'BLOCKED' : canExec ? 'ARMED' : 'STANDBY'),
        rationale: executed
          ? 'Order forwarded to the portfolio engine'
          : (cand && cand.execution_note) || 'Awaiting an approved mandate',
      });

      this.nodes = ingest.concat(divs, [executive, execution]);
      this.layout(ingest, divs, executive, execution);

      this.edges = [];
      for (let i = 0; i < ingest.length - 1; i++) this.edges.push([ingest[i], ingest[i + 1]]);
      divs.forEach((n) => { this.edges.push([ingest[3], n]); this.edges.push([n, executive]); });
      this.edges.push([executive, execution]);
    }

    layout(ingest, divs, executive, execution) {
      this.vertical = this.w < 620;
      if (this.vertical) {
        const cx = this.w / 2;
        const ys = [55, 135, 215, 295];
        ingest.forEach((n, i) => Object.assign(n, { x: cx, y: ys[i], w: Math.min(140, this.w * .52), h: 42 }));
        const start = 385, gap = 58;
        divs.forEach((n, i) => Object.assign(n, {
          x: i % 2 ? this.w * .72 : this.w * .28,
          y: start + Math.floor(i / 2) * gap,
          w: Math.min(126, this.w * .42), h: 37,
        }));
        Object.assign(executive, { x: cx, y: start + 4 * gap + 20, w: Math.min(140, this.w * .52), h: 42 });
        Object.assign(execution, { x: cx, y: start + 4 * gap + 100, w: Math.min(140, this.w * .52), h: 42 });
      } else {
        const y = this.h / 2;
        const xs = [66, 206, 346, 486];
        ingest.forEach((n, i) => Object.assign(n, { x: xs[i], y, w: 110, h: 43 }));
        const colX = Math.min(664, this.w * .48);
        divs.forEach((n, i) => Object.assign(n, { x: colX, y: 46 + i * (this.h - 92) / 6, w: 122, h: 36 }));
        Object.assign(executive, { x: this.w - 258, y, w: 126, h: 43 });
        Object.assign(execution, { x: this.w - 86, y, w: 126, h: 43 });
      }
    }

    curve(a, b) {
      if (this.vertical) {
        const dy = (b.y - a.y) * .48;
        return [a.x, a.y + dy, b.x, b.y - dy];
      }
      const dx = (b.x - a.x) * .52;
      return [a.x + dx, a.y, b.x - dx, b.y];
    }

    pointOn(a, b, t) {
      const [c1x, c1y, c2x, c2y] = this.curve(a, b);
      const mt = 1 - t;
      const x = mt ** 3 * a.x + 3 * mt * mt * t * c1x + 3 * mt * t * t * c2x + t ** 3 * b.x;
      const y = mt ** 3 * a.y + 3 * mt * mt * t * c1y + 3 * mt * t * t * c2y + t ** 3 * b.y;
      return [x, y];
    }

    animate() {
      if (!this.running) return;
      this.draw();
      this.frame++;
      requestAnimationFrame(() => this.animate());
    }

    draw() {
      const x = this.ctx;
      if (!this.w) return;
      // Self-heal: if layout shifted materially after the last ResizeObserver
      // callback (scrollbar appearing, tab becoming visible), re-sync the backing
      // store. Tolerance is >2px so sub-pixel jitter cannot cause a resize loop,
      // and we keep drawing this frame instead of returning early.
      const rect = this.c.getBoundingClientRect();
      if (rect.width > 1 && Math.abs(rect.width - this.w) > 2) this.resize();
      if (!this.w) return;
      x.clearRect(0, 0, this.w, this.h);

      for (const [a, b] of this.edges) {
        const c = PALETTE[b.state] || PALETTE.scan;
        const [c1x, c1y, c2x, c2y] = this.curve(a, b);
        x.beginPath();
        x.moveTo(a.x, a.y);
        x.bezierCurveTo(c1x, c1y, c2x, c2y, b.x, b.y);
        x.strokeStyle = c + '38';
        x.lineWidth = 1.2;
        x.stroke();

        if (!U.reduced) {
          for (let p = 0; p < 2; p++) {
            const t = (this.frame * 0.004 + p * 0.51) % 1;
            const [px, py] = this.pointOn(a, b, t);
            x.beginPath();
            x.arc(px, py, 2.2, 0, Math.PI * 2);
            x.fillStyle = c;
            x.shadowColor = c;
            x.shadowBlur = 9;
            x.fill();
            x.shadowBlur = 0;
          }
        }
      }

      const small = this.w < 620;
      for (const n of this.nodes) {
        const c = PALETTE[n.state] || PALETTE.scan;
        x.fillStyle = PALETTE.node;
        x.strokeStyle = c + '6e';
        x.lineWidth = n === this.pinned ? 1.8 : 1;
        x.beginPath();
        x.roundRect(n.x - n.w / 2, n.y - n.h / 2, n.w, n.h, 9);
        x.fill();
        x.stroke();

        x.beginPath();
        x.arc(n.x - n.w / 2 + 11, n.y, 3, 0, Math.PI * 2);
        x.fillStyle = c;
        x.shadowColor = c;
        x.shadowBlur = 7;
        x.fill();
        x.shadowBlur = 0;

        x.textAlign = 'center';
        x.textBaseline = 'middle';
        x.fillStyle = PALETTE.label;
        x.font = '600 ' + (small ? 9 : 10) + 'px system-ui,sans-serif';
        x.fillText(n.label, n.x + 5, n.y - 5);
        x.fillStyle = PALETTE.sub;
        x.font = (small ? 8 : 8.5) + 'px system-ui,sans-serif';
        const meta = n.conviction != null ? n.verdict + ' · ' + U.safe(n.conviction) + '%' : n.verdict;
        x.fillText(meta, n.x + 5, n.y + 9);
      }
    }

    /* Hover on desktop, tap on mobile -> inspection tooltip with live verdict. */
    pointer(e, tap = false) {
      const r = this.c.getBoundingClientRect();
      const px = e.clientX - r.left;
      const py = e.clientY - r.top;
      const hit = this.nodes.find((n) =>
        Math.abs(px - n.x) <= n.w / 2 + 8 && Math.abs(py - n.y) <= n.h / 2 + 8);
      if (!hit) { this.hide(); return; }
      this.pinned = tap ? hit : null;
      this.tip.querySelector('.tooltip-title').textContent = hit.label + ' · ' + hit.sub;
      const meta = this.tip.querySelector('.tooltip-meta');
      meta.textContent = hit.conviction != null
        ? hit.verdict + ' · conviction ' + U.safe(hit.conviction) + '%'
        : hit.verdict;
      meta.style.color = PALETTE[hit.state] || PALETTE.scan;
      this.tip.querySelector('.tooltip-copy').textContent = hit.rationale;
      this.tip.classList.add('show');
      const tw = 240;
      this.tip.style.left = Math.max(8, Math.min(this.w - tw - 8, hit.x - tw / 2)) + 'px';
      this.tip.style.top = Math.max(8, hit.y - hit.h / 2 - 98) + 'px';
    }

    hide() { this.pinned = null; this.tip.classList.remove('show'); }
  }

  return { create: (canvas, tip) => new Pipeline(canvas, tip) };
})();
