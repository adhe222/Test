import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import config
from ai_engine import LLMClient
from agents.specialists import ExecutiveStrategistSpecialist
from agents.risk_manager import RiskManagementAgent
from orchestrator import TradingOrchestrator


def _research(status="OK", healthy=5):
    return {
        "status": status,
        "healthy_sources": healthy,
        "generated_at": "2026-10-22T02:00:00+00:00",
        "sources": [
            {"name": "binance_futures_funding", "ok": True, "latency_ms": 100.0},
            {"name": "binance_futures_open_interest", "ok": True, "latency_ms": 120.0},
        ],
        "funding": {"annualized_pct": -1.2},
        "open_interest": {"trend": "RISING"},
        "positioning": {"crowding": "BALANCED"},
        "taker_flow": {"pressure": "BUYERS"},
        "fear_greed": {"value": 55, "classification": "Neutral"},
        "news": {"symbol": [], "market": []},
        "bias": {"bias": "BULLISH", "score": 2, "flags": []},
    }


def _reports():
    return [
        {"specialist": "Narrative", "verdict": "REJECT", "conviction": 20, "rationale": "volume weak"},
        {"specialist": "PriceAction", "verdict": "REJECT", "conviction": 30, "rationale": "trend broken"},
        {"specialist": "Exhaustion", "verdict": "APPROVE", "conviction": 70, "rationale": "ok"},
        {"specialist": "Microstructure", "verdict": "REJECT", "conviction": 40, "rationale": "imbalance"},
        {"specialist": "Sentiment", "verdict": "APPROVE", "conviction": 60, "rationale": "ok"},
        {"specialist": "CRO", "verdict": "APPROVE", "conviction": 80, "rationale": "ok"},
        {"specialist": "Profit", "verdict": "APPROVE", "conviction": 75, "rationale": "ok"},
    ]


class FakeLLM:
    def __init__(self, result):
        self.result = result
        self.calls = 0
        self.last_context = None

    def query_specialist(self, specialist_role, system_instruction, context_data, fallback_fn):
        self.calls += 1
        self.last_context = context_data
        return dict(self.result)


class TestExecutiveAbsolute(unittest.TestCase):
    def setUp(self):
        self.patches = [
            patch.object(config, "AI_DECISION_AUTHORITY", "absolute"),
            patch.object(config, "AI_ABSOLUTE_MIN_CONVICTION", 60),
            patch.object(config, "AI_REQUIRE_EXTERNAL_RESEARCH", True),
            patch.object(config, "EXTERNAL_INTEL_MIN_SOURCES", 2),
        ]
        for p in self.patches:
            p.start()

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()

    def test_ai_can_override_deterministic_vetoes(self):
        llm = FakeLLM({
            "verdict": "APPROVE", "conviction": 82, "rationale": "external flow supports",
            "signal": "AI_APPROVE", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
        })
        result = ExecutiveStrategistSpecialist(llm).synthesize(
            _reports(), external_research=_research(), risk_plan={"approved": True, "symbol": "BTCUSDT"},
            strategy_failures=["Momentum gate failed"], direction="LONG",
        )
        self.assertEqual(result["final_verdict"], "APPROVE")
        self.assertEqual(result["consensus_status"], "AI_ABSOLUTE_OVERRIDE")
        self.assertEqual(result["decision_authority"], "absolute")
        self.assertEqual(llm.calls, 1)
        self.assertEqual(llm.last_context["decision_authority"], "absolute")

    def test_ai_reject_is_final(self):
        llm = FakeLLM({
            "verdict": "REJECT", "conviction": 70, "rationale": "news contradicts",
            "signal": "AI_REJECT", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
        })
        result = ExecutiveStrategistSpecialist(llm).synthesize(
            _reports(), external_research=_research(), risk_plan={"approved": True, "symbol": "BTCUSDT"},
            strategy_failures=[], direction="LONG",
        )
        self.assertEqual(result["final_verdict"], "REJECT")
        self.assertEqual(result["consensus_status"], "AI_ABSOLUTE_REJECT")

    def test_low_ai_conviction_is_rejected(self):
        llm = FakeLLM({
            "verdict": "APPROVE", "conviction": 45, "rationale": "weak",
            "signal": "AI_APPROVE", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
        })
        result = ExecutiveStrategistSpecialist(llm).synthesize(
            _reports(), external_research=_research(), risk_plan={"approved": True, "symbol": "BTCUSDT"},
            strategy_failures=[], direction="LONG",
        )
        self.assertEqual(result["final_verdict"], "REJECT")
        self.assertEqual(result["consensus_status"], "LOW_AI_CONVICTION")

    def test_degraded_external_research_blocks_approval(self):
        llm = FakeLLM({
            "verdict": "APPROVE", "conviction": 82, "rationale": "approve",
            "signal": "AI_APPROVE", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
        })
        result = ExecutiveStrategistSpecialist(llm).synthesize(
            _reports(), external_research=_research("DEGRADED", 1),
            risk_plan={"approved": True, "symbol": "BTCUSDT"}, strategy_failures=[], direction="LONG",
        )
        self.assertEqual(result["final_verdict"], "REJECT")
        self.assertEqual(result["consensus_status"], "EXTERNAL_RESEARCH_UNAVAILABLE")

    def test_ai_fallback_does_not_override_strategy_failures(self):
        llm = FakeLLM({
            "verdict": "REJECT", "conviction": 0, "rationale": "provider down",
            "signal": "AI_FALLBACK", "engine_mode": "DETERMINISTIC_FALLBACK", "is_fallback": True,
        })
        result = ExecutiveStrategistSpecialist(llm).synthesize(
            _reports(), external_research=_research(), risk_plan={"approved": True, "symbol": "BTCUSDT"},
            strategy_failures=["Momentum gate failed"], direction="LONG",
        )
        self.assertEqual(result["final_verdict"], "REJECT")
        self.assertEqual(result["consensus_status"], "AI_FALLBACK_DETERMINISTIC")

    def test_advisory_mode_keeps_deterministic_veto(self):
        with patch.object(config, "AI_DECISION_AUTHORITY", "advisory"):
            llm = FakeLLM({
                "verdict": "APPROVE", "conviction": 99, "rationale": "approve",
                "signal": "AI_APPROVE", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
            })
            result = ExecutiveStrategistSpecialist(llm).synthesize(_reports())
            self.assertEqual(result["final_verdict"], "REJECT")
            self.assertEqual(llm.calls, 0)


class TestLlmAbsoluteEngine(unittest.TestCase):
    def _client(self):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="test-model")
        client.client = MagicMock()
        content = json.dumps({
            "verdict": "APPROVE", "conviction": 78,
            "rationale": "funding and taker flow support", "signal": "AI_ABSOLUTE_TEST",
        })
        response = SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=content))])
        client.client.chat.completions.create.return_value = response
        return client

    def test_absolute_query_returns_ai_absolute_mode(self):
        client = self._client()
        with patch.object(config, "AI_DECISION_AUTHORITY", "absolute"), patch.object(config, "LLM_VETO_ONLY", False):
            result = client.query_specialist(
                "Executive", "Decide.", {"decision_authority": "absolute", "external_research": _research()},
                lambda ctx: {"verdict": "REJECT", "conviction": 0, "rationale": "baseline", "signal": "BASE"},
            )
            self.assertEqual(result["engine_mode"], "AI_ABSOLUTE")
            self.assertEqual(result["decision_authority"], "absolute")
            self.assertEqual(result["external_research_status"], "OK")
            self.assertEqual(result["ai_verdict"], "APPROVE")
            self.assertEqual(client.status_summary["decision_authority"], "absolute")

    def test_absolute_query_collects_streamed_json_chunks(self):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="test-model")
        client.client = MagicMock()
        payload = '{"verdict":"APPROVE","conviction":79,"rationale":"tick aligned","signal":"STREAM"}'
        chunks = [
            SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=part))])
            for part in (payload[:20], payload[20:55], payload[55:])
        ]
        client.client.chat.completions.create.return_value = iter(chunks)
        with patch.object(config, "AI_DECISION_AUTHORITY", "absolute"), patch.object(config, "LLM_VETO_ONLY", False):
            result = client.query_specialist(
                "Executive", "Decide.", {"external_research": _research()},
                lambda ctx: {"verdict": "REJECT", "conviction": 0, "rationale": "baseline", "signal": "BASE"},
            )
        self.assertEqual(result["engine_mode"], "AI_ABSOLUTE")
        self.assertEqual(result["signal"], "STREAM")
        self.assertEqual(client.status_summary["stream_requests"], 1)
        self.assertEqual(client.status_summary["stream_chunks"], 3)
        self.assertTrue(client.client.chat.completions.create.call_args.kwargs["stream"])

    def test_absolute_provider_failure_is_visible_fallback(self):
        client = self._client()
        error = RuntimeError("bad gateway")
        error.status_code = 502
        client.client.chat.completions.create.side_effect = error
        with patch.object(config, "AI_DECISION_AUTHORITY", "absolute"), patch.object(config, "LLM_VETO_ONLY", False):
            result = client.query_specialist(
                "Executive", "Decide.", {"decision_authority": "absolute", "external_research": _research()},
                lambda ctx: {"verdict": "REJECT", "conviction": 0, "rationale": "baseline", "signal": "BASE"},
            )
            self.assertTrue(result["is_fallback"])
            self.assertEqual(result["engine_mode"], "DETERMINISTIC_FALLBACK")
            self.assertEqual(result["decision_authority"], "absolute")
            self.assertEqual(result["external_research_status"], "OK")
            self.assertEqual(client.status_summary["last_error_kind"], "HTTP_502")


class TestOrchestratorAbsoluteOverride(unittest.TestCase):
    def _orch(self):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.llm = MagicMock(status_summary={})
        orch.portfolio = MagicMock()
        orch.portfolio.get_open_positions.return_value = []
        orch.portfolio.get_equity.return_value = 1000.0
        orch.portfolio.state = {"cash_usdt": 1000.0}
        orch.portfolio.update_and_monitor_positions.return_value = []
        orch.portfolio.get_periodic_performance.return_value = {"today": {"net_pnl_usdt": 0.0}}
        orch.portfolio.get_trade_history.return_value = []
        orch.portfolio.get_banned_symbols.return_value = []
        orch.portfolio.execute_trade.return_value = True
        orch.macro_sentinel = MagicMock()
        orch.macro_sentinel.evaluate_macro_health.return_value = {
            "safe_to_trade": True, "safe_for_longs": True, "safe_for_shorts": True,
        }
        orch.scanner = MagicMock()
        orch.scanner.scan_trending_pairs.return_value = [{
            "symbol": "AITESTUSDT", "direction": "LONG", "target_market": "SPOT",
            "price": 1.0, "price_change_24h": 3.0, "quote_volume_24h": 9e7, "count_trades": 300000,
        }]
        orch.orderbook_data_agent = MagicMock()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "imbalance": 0.0, "spread_pct": 0.01, "best_bid": 0.9999, "best_ask": 1.0,
        }
        orch.momentum_data_agent = MagicMock()
        orch.momentum_data_agent.analyze_symbol.return_value = {
            "passed": False, "score": 40, "gate_failures": ["Momentum score too low"],
            "price": 1.0, "atr": 0.01, "rsi": 50,
        }
        orch.risk_data_agent = RiskManagementAgent()
        for name in ("narrative_spec", "price_action_spec", "exhaustion_spec", "microstructure_spec",
                     "sentiment_spec", "cro_spec", "profit_spec"):
            spec = MagicMock(role_name=name, lead_title="", icon="", staff=[])
            setattr(orch, name, spec)
        orch.external_research = MagicMock()
        orch.external_research.collect.return_value = _research()
        orch.external_research.format_for_prompt.side_effect = lambda x: x
        fake = FakeLLM({
            "verdict": "APPROVE", "conviction": 84, "rationale": "external flow supports",
            "signal": "AI_APPROVE", "engine_mode": "AI_ABSOLUTE", "is_fallback": False,
        })
        orch.executive_spec = ExecutiveStrategistSpecialist(fake)
        return orch, fake

    def test_ai_absolute_can_override_strategy_gate_and_execute(self):
        orch, fake = self._orch()
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        self.enterContext(patch.object(config, "AI_DECISION_AUTHORITY", "absolute"))
        self.enterContext(patch.object(config, "AI_REQUIRE_EXTERNAL_RESEARCH", True))
        self.enterContext(patch.object(config, "EXTERNAL_INTEL_MIN_SOURCES", 2))
        with patch("orchestrator.consciousness_engine") as ce:
            ce.audit_against_experience.return_value = None
            ce.get_ultra_context_summary.return_value = {}
            result = orch.run_cycle()
        rec = result["candidates_evaluated"][0]
        self.assertTrue(rec["gates_passed"])
        self.assertTrue(rec["strategy_gate_failures"])
        self.assertEqual(rec["execution_note"], "EXECUTED")
        self.assertEqual(rec["executive_verdict"]["final_verdict"], "APPROVE")
        self.assertEqual(rec["executive_verdict"]["consensus_status"], "AI_ABSOLUTE_OVERRIDE")
        self.assertEqual(len(result["executed_trades"]), 1)
        self.assertEqual(fake.calls, 1)
        orch.portfolio.execute_trade.assert_called_once()

    def test_ai_absolute_fallback_blocks_strategy_override(self):
        orch, fake = self._orch()
        fake.result = {
            "verdict": "REJECT", "conviction": 0, "rationale": "provider down",
            "signal": "AI_FALLBACK", "engine_mode": "DETERMINISTIC_FALLBACK", "is_fallback": True,
        }
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        self.enterContext(patch.object(config, "AI_DECISION_AUTHORITY", "absolute"))
        self.enterContext(patch.object(config, "AI_REQUIRE_EXTERNAL_RESEARCH", True))
        self.enterContext(patch.object(config, "EXTERNAL_INTEL_MIN_SOURCES", 2))
        with patch("orchestrator.consciousness_engine") as ce:
            ce.audit_against_experience.return_value = None
            ce.get_ultra_context_summary.return_value = {}
            result = orch.run_cycle()
        rec = result["candidates_evaluated"][0]
        self.assertEqual(rec["executive_verdict"]["final_verdict"], "REJECT")
        self.assertEqual(rec["execution_note"], "AI_DECISION_AI_FALLBACK_DETERMINISTIC")
        self.assertEqual(len(result["executed_trades"]), 0)
        orch.portfolio.execute_trade.assert_not_called()


if __name__ == "__main__":
    unittest.main()
