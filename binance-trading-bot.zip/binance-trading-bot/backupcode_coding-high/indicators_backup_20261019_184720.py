from typing import List, Dict, Optional, Tuple, Any
import math
import time


def drop_forming_bar(klines: List[Dict[str, float]], now_ms: Optional[int] = None) -> List[Dict[str, float]]:
    """
    Return only CLOSED candles.

    Binance returns the in-progress candle as the last element. Its volume
    accumulates from zero across the interval and its close/high/low keep
    changing, so any confirmation signal computed on it (volume surge, candle
    body, EMA cross, RSI) depends on *when* the scan happened rather than on
    the market. Decisions must only ever use closed bars.
    """
    if not klines:
        return []
    if now_ms is None:
        now_ms = int(time.time() * 1000)
    last = klines[-1]
    close_time = last.get("close_time")
    # close_time is the last millisecond of the candle; it is still forming
    # while now <= close_time.
    if close_time is not None and now_ms <= int(close_time):
        return klines[:-1]
    return klines


def calculate_ema(prices: List[float], period: int) -> List[float]:
    """Calculate Exponential Moving Average (EMA) for a list of prices."""
    if not prices:
        return []
    k = 2 / (period + 1)
    ema_list = []
    # Initialize with simple moving average for the first period
    if len(prices) >= period:
        sma = sum(prices[:period]) / period
        ema = sma
        ema_list.append(ema)
        for price in prices[period:]:
            ema = (price * k) + (ema * (1 - k))
            ema_list.append(ema)
    else:
        # Fallback if prices length < period
        ema = sum(prices) / len(prices)
        for price in prices:
            ema = (price * k) + (ema * (1 - k))
            ema_list.append(ema)
    return ema_list


def calculate_rsi(closes: List[float], period: int = 14) -> Optional[float]:
    """Calculate Relative Strength Index (RSI)."""
    if len(closes) < period + 1:
        return 50.0
    
    gains = []
    losses = []
    for i in range(1, len(closes)):
        diff = closes[i] - closes[i - 1]
        gains.append(max(0.0, diff))
        losses.append(max(0.0, -diff))
    
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    
    if avg_loss == 0:
        return 100.0
    
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return float(rsi)


def calculate_atr(klines: List[Dict[str, float]], period: int = 14) -> float:
    """Calculate Average True Range (ATR)."""
    if not klines or len(klines) < 2:
        return 0.0
    
    atr_list = []
    for i in range(1, len(klines)):
        high = klines[i]["high"]
        low = klines[i]["low"]
        prev_close = klines[i - 1]["close"]
        tr = max(high - low, abs(high - prev_close), abs(low - prev_close))
        atr_list.append(tr)
    
    if not atr_list:
        return 0.0
    
    if len(atr_list) >= period:
        atr = sum(atr_list[:period]) / period
        for tr in atr_list[period:]:
            atr = (atr * (period - 1) + tr) / period
        return float(atr)
    else:
        return float(sum(atr_list) / len(atr_list))


def calculate_ema_and_metrics(klines: List[Dict[str, float]], timeframe: str = "15m") -> Dict[str, Any]:
    """Calculate EMA stack (9, 21, 50), RSI, and ATR for momentum analysis."""
    if len(klines) < 30:
        price = klines[-1]["close"] if klines else 100.0
        return {"ema9": price, "ema21": price, "ema50": price, "rsi": 50.0, "atr": price * 0.02, "score": 50}
    
    closes = [k["close"] for k in klines]
    
    # Calculate EMAs
    ema9_list = calculate_ema(closes, 9)
    ema21_list = calculate_ema(closes, 21)
    ema50_list = calculate_ema(closes, 50)
    
    ema9 = ema9_list[-1] if ema9_list else closes[-1]
    ema21 = ema21_list[-1] if ema21_list else closes[-1]
    ema50 = ema50_list[-1] if ema50_list else closes[-1]
    
    # Calculate RSI (14-period)
    rsi_val = calculate_rsi(closes, 14)
    rsi = rsi_val if rsi_val is not None else 50.0
    
    # Calculate ATR (14-period)
    atr = calculate_atr(klines, 14)
    price = closes[-1]
    if atr <= 0:
        atr = price * 0.02
    
    # Trend alignment score (0-100)
    score = 0
    if price > ema9 > ema21 > ema50:
        score = 100  # Perfect bullish alignment
    elif price > ema21 and ema9 > ema21:
        score = 75   # Moderate bullish
    elif price < ema9 < ema21 < ema50:
        score = 20   # Bearish
    else:
        score = 50   # Neutral/choppy
    
    # RSI adjustment for win rate optimization
    if 52 <= rsi <= 68:
        score += 10
    elif rsi > 74 or rsi < 42:
        score -= 20
    
    return {
        "ema9": ema9,
        "ema21": ema21,
        "ema50": ema50,
        "rsi": rsi,
        "atr": atr,
        "score": min(100, max(0, score))
    }


def calculate_volume_surge(klines: List[Dict[str, float]], period: int = 20) -> float:
    """Calculate ratio of recent volume compared to moving average volume."""
    if len(klines) < period + 1:
        return 1.0

    recent_vol = klines[-1]["volume"]
    past_volumes = [k["volume"] for k in klines[-period - 1: -1]]
    if not past_volumes:
        return 1.0
    avg_vol = sum(past_volumes) / len(past_volumes)
    if avg_vol <= 0:
        return 1.0
    return recent_vol / avg_vol


def calculate_candle_metrics(kline: Dict[str, float]) -> Dict[str, float]:
    """Calculate candle strength metrics (body percentage, upper/lower wick)."""
    high = kline["high"]
    low = kline["low"]
    open_p = kline["open"]
    close = kline["close"]
    candle_range = high - low

    if candle_range <= 0:
        return {"body_pct": 0.0, "is_bullish": False, "close_ratio": 0.5}

    body = abs(close - open_p)
    body_pct = (body / candle_range) * 100.0
    is_bullish = close >= open_p
    close_ratio = (close - low) / candle_range

    return {
        "body_pct": body_pct,
        "is_bullish": is_bullish,
        "close_ratio": close_ratio
    }
