/* Aegis Telemetry — equity curve.
 * Chart.js via CDN when reachable; otherwise a hand-rolled Canvas 2D sparkline.
 * Never throws: the rest of the dashboard must survive a blocked CDN.
 */
window.AegisChart = (() => {
  'use strict';
  const U = window.AegisUtil;
  let chart = null;
  let useFallback = false;
  let lastData = null;

  function palette() {
    const cs = getComputedStyle(document.documentElement);
    const v = (k) => (cs.getPropertyValue(k) || '').trim();
    const hex = v('--cyan') || '#38bdf8';
    const rgba = (a) => {
      const h = hex.replace('#', '');
      const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
      return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
    };
    return { accent: hex, areaTop: rgba(.24), areaBottom: rgba(0), tick: v('--muted') || '#64748b',
             grid: v('--line-weak') || 'rgba(148,180,213,.08)', tipBg: v('--panel-2') || '#111d33',
             tipBorder: v('--line-strong') || 'rgba(125,211,252,.25)', tipTitle: v('--muted') || '#8193aa',
             tipBody: v('--text') || '#e6edf7' };
  }

  function render(d) {
    lastData = d;
    const hist = d.equity_history || [];
    const labels = hist.map((h) => h.time || '');
    const values = hist.map((h) => U.safe(h.equity));
    U.setText('chartRange', values.length
      ? U.money(values[0]) + ' → ' + U.money(values[values.length - 1])
      : 'No samples');

    if (!values.length) { fallback([], []); return; }

    if (!useFallback && window.Chart) {
      try { chartjs(labels, values); return; }
      catch (err) {
        console.warn('Chart.js render failed, using canvas fallback:', err && err.message);
        useFallback = true;
        chart = null;
      }
    }
    fallback(labels, values);
  }

  function chartjs(labels, values) {
    const el = U.$('#equityChart');
    const p = palette();
    if (!chart) {
      const ctx = el.getContext('2d');
      const grad = ctx.createLinearGradient(0, 0, 0, 250);
      grad.addColorStop(0, p.areaTop);
      grad.addColorStop(1, p.areaBottom);
      chart = new window.Chart(ctx, {
        type: 'line',
        data: { labels, datasets: [{
          data: values, borderColor: p.accent, backgroundColor: grad, fill: true,
          borderWidth: 2, pointRadius: 0, pointHoverRadius: 3, tension: .34,
        }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          animation: U.reduced ? false : { duration: 420 },
          interaction: { intersect: false, mode: 'index' },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: p.tipBg, borderColor: p.tipBorder, borderWidth: 1,
              titleColor: p.tipTitle, bodyColor: p.tipBody, displayColors: false,
              callbacks: { label: (c) => U.money(c.parsed.y) },
            },
          },
          scales: {
            x: { grid: { display: false }, ticks: { color: p.tick, maxTicksLimit: 6, font: { size: 9 } } },
            y: { position: 'right', grid: { color: p.grid },
                 ticks: { color: p.tick, maxTicksLimit: 5, font: { size: 9 },
                          callback: (v) => '$' + Number(v).toLocaleString() } },
          },
        },
      });
    } else {
      chart.data.labels = labels;
      chart.data.datasets[0].data = values;
      chart.update('none');
    }
    U.$('#chartFallback').style.display = 'none';
  }

  function fallback(labels, values) {
    const c = U.$('#equityChart');
    const note = U.$('#chartFallback');
    if (!c) return;
    const rect = c.getBoundingClientRect();
    if (!rect.width) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.width = Math.max(1, Math.round(rect.width * dpr));
    c.height = Math.max(1, Math.round(rect.height * dpr));
    const x = c.getContext('2d');
    x.setTransform(dpr, 0, 0, dpr, 0, 0);
    x.clearRect(0, 0, rect.width, rect.height);

    const p = palette();
    x.strokeStyle = p.grid;
    x.lineWidth = 1;
    for (let i = 1; i < 5; i++) {
      const y = i * rect.height / 5;
      x.beginPath(); x.moveTo(0, y); x.lineTo(rect.width, y); x.stroke();
    }

    if (values.length < 2) { note.style.display = 'flex'; note.textContent = 'Menunggu sampel equity…'; return; }

    const min = Math.min.apply(null, values);
    const max = Math.max.apply(null, values);
    const range = Math.max(1e-9, max - min);
    const pt = (i) => [8 + i * (rect.width - 16) / (values.length - 1),
                       10 + (max - values[i]) * (rect.height - 24) / range];

    x.beginPath();
    values.forEach((_, i) => { const [px, py] = pt(i); i ? x.lineTo(px, py) : x.moveTo(px, py); });
    const grad = x.createLinearGradient(0, 0, 0, rect.height);
    grad.addColorStop(0, p.areaTop);
    grad.addColorStop(1, p.areaBottom);
    x.strokeStyle = p.accent;
    x.lineWidth = 2;
    x.stroke();
    x.lineTo(rect.width - 8, rect.height);
    x.lineTo(8, rect.height);
    x.closePath();
    x.fillStyle = grad;
    x.fill();

    note.style.display = 'none';
  }

  /* Called if the CDN script never arrives. */
  function forceFallback() { useFallback = true; chart = null; }

  if (window.AegisTheme) {
    window.AegisTheme.onChange(() => {
      if (chart) { chart.destroy(); chart = null; }
      if (lastData) render(lastData);
    });
  }

  return { render, forceFallback };
})();
