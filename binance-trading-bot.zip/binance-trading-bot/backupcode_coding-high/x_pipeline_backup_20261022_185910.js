(function () {
  'use strict';

  const U = window.AegisUtil;

  const STAGES = [
    { id: 'scan', label: 'Scanner', icon: 'radar' },
    { id: 'book', label: 'Orderbook', icon: 'layers' },
    { id: 'momentum', label: 'Momentum', icon: 'chart' },
    { id: 'research', label: 'Research', icon: 'globe' },
    { id: 'risk', label: 'Risk Guard', icon: 'shield' },
    { id: 'portfolio', label: 'Portfolio', icon: 'wallet' },
    { id: 'execution', label: 'Execution', icon: 'bolt' }
  ];

  const nodes = STAGES.map((stage) => Object.assign({}, stage, { status: 'IDLE', note: '' }));
  let hovered = -1;
  let rafId = 0;
  let running = false;
  let lastFrame = 0;
  let t0 = 0;
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const stageStatus = (d) => {
    const raw = d && (d.agents || d.agent_status || d.agent_consciousness);
    const list = Array.isArray(raw) ? raw
      : raw && typeof raw === 'object'
        ? Object.keys(raw).map((k) => (typeof raw[k] === 'object' && raw[k] ? Object.assign({ name: k }, raw[k]) : { name: k, status: raw[k] }))
        : [];
    const find = (keys) => list.find((a) => {
      const text = `${a.name || ''} ${a.role || ''} ${a.id || ''}`.toLowerCase();
      return keys.some((k) => text.includes(k));
    });
    const map = {
      scan: find(['scan']),
      book: find(['order book', 'orderbook', 'microstructure', 'order']),
      momentum: find(['moment', 'trend', 'exhaustion']),
      research: find(['research', 'intel', 'news', 'narrative', 'flow']),
      risk: find(['risk', 'guard', 'veto', 'capital']),
      portfolio: find(['portfolio', 'alloc', 'profit extraction', 'exit']),
      execution: find(['exec', 'router', 'judge', 'committee'])
    };
    nodes.forEach((node) => {
      const agent = map[node.id];
      if (agent) {
        node.status = String(agent.status || agent.verdict || (Number(agent.total_audits) > 0 ? 'ACTIVE' : 'IDLE')).toUpperCase();
        node.note = String(agent.message || agent.reason || agent.summary || agent.consciousness_focus || '').slice(0, 120);
      } else {
        node.status = 'IDLE';
        node.note = 'Belum ada laporan agen';
      }
    });
    const loop = d && d.autonomous_loop;
    if (loop && loop.running === false) nodes.forEach((n) => { if (n.status === 'IDLE') n.note = 'Mesin dalam mode jeda'; });
  };

  const tone = (status) => {
    const s = String(status || '').toUpperCase();
    if (/APPROVE|OK|PASS|READY|GO|RUNNING|DONE/.test(s)) return 'ok';
    if (/VETO|BLOCK|REJECT|FAIL|DENY|HALT/.test(s)) return 'bad';
    if (/WAIT|PAUSE|HOLD|PENDING|COOLDOWN|SCAN/.test(s)) return 'warn';
    return 'idle';
  };

  const colors = () => {
    const css = getComputedStyle(document.documentElement);
    const v = (name, fb) => css.getPropertyValue(name).trim() || fb;
    return {
      ok: v('--teal', '#2dd4bf'),
      bad: v('--rose', '#fb7185'),
      warn: v('--amber', '#f5b544'),
      idle: v('--muted-2', '#66788f'),
      cyan: v('--cyan', '#22d3ee'),
      grid: v('--hairline', 'rgba(120,180,235,.14)'),
      node: v('--node-bg', 'rgba(10,18,32,.94)'),
      ink: v('--ink', '#e8f0fb'),
      muted: v('--muted', '#7e90a8')
    };
  };

  const layout = (w, h) => {
    const cols = w < 620 ? 2 : w < 900 ? 3 : 4;
    const rows = Math.ceil(nodes.length / cols);
    const padX = 22;
    const padY = 26;
    const cellW = (w - padX * 2) / cols;
    const cellH = (h - padY * 2) / rows;
    return nodes.map((node, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const cx = padX + cellW * col + cellW / 2;
      const cy = padY + cellH * row + cellH / 2;
      return { node, cx, cy, w: Math.min(cellW - 16, 132), h: Math.min(cellH - 16, 54), index: i, cols, rows };
    });
  };

  const draw = (now) => {
    const canvas = document.getElementById('pipelineCanvas');
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(280, Math.floor(rect.width));
    const h = Math.max(180, Math.floor(rect.height || (w < 620 ? 300 : 220)));
    if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const C = colors();
    const boxes = layout(w, h);

    ctx.lineWidth = 1.4;
    boxes.forEach((box, i) => {
      if (i === 0) return;
      const prev = boxes[i - 1];
      const sameRow = Math.floor(i / box.cols) === Math.floor((i - 1) / prev.cols);
      const x1 = sameRow ? prev.cx + prev.w / 2 : prev.cx;
      const y1 = sameRow ? prev.cy : prev.cy + prev.h / 2;
      const x2 = sameRow ? box.cx - box.w / 2 : box.cx;
      const y2 = sameRow ? box.cy : box.cy - box.h / 2;
      const active = tone(nodes[i - 1].status) !== 'idle';
      ctx.strokeStyle = active ? C.cyan : C.grid;
      ctx.globalAlpha = active ? 0.55 : 0.4;
      ctx.setLineDash([5, 6]);
      ctx.lineDashOffset = reduceMotion ? 0 : -((now * 0.02) % 22);
      ctx.beginPath();
      if (sameRow) {
        ctx.moveTo(x1, y1);
        ctx.bezierCurveTo(x1 + 18, y1, x2 - 18, y2, x2, y2);
      } else {
        ctx.moveTo(x1, y1);
        ctx.bezierCurveTo(x1, y1 + 22, x2, y2 - 22, x2, y2);
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    });

    boxes.forEach((box) => {
      const node = box.node;
      const t = tone(node.status);
      const color = C[t] || C.idle;
      const x = box.cx - box.w / 2;
      const y = box.cy - box.h / 2;
      const isHover = box.index === hovered;
      ctx.fillStyle = C.node;
      ctx.strokeStyle = isHover ? C.cyan : color;
      ctx.globalAlpha = isHover ? 1 : 0.85;
      ctx.lineWidth = isHover ? 2 : 1.2;
      const r = 12;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, box.w, box.h, r);
      else ctx.rect(x, y, box.w, box.h);
      ctx.fill();
      ctx.stroke();
      ctx.globalAlpha = 1;

      if (t !== 'idle' && !reduceMotion) {
        const pulse = 0.5 + 0.5 * Math.sin(now * 0.002 + box.index);
        ctx.globalAlpha = 0.1 + pulse * 0.12;
        ctx.fillStyle = color;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x - 2, y - 2, box.w + 4, box.h + 4, r + 2);
        else ctx.rect(x - 2, y - 2, box.w + 4, box.h + 4);
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      ctx.beginPath();
      ctx.arc(x + 16, box.cy, 4, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();

      ctx.fillStyle = C.ink;
      ctx.font = '600 11.5px Inter, system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(node.label, x + 26, box.cy - 2);

      ctx.fillStyle = C.muted;
      ctx.font = '10px "JetBrains Mono", monospace';
      const statusText = String(node.status || 'IDLE').slice(0, 18);
      ctx.fillText(statusText, x + 26, box.cy + 12);
    });

    const legend = document.getElementById('pipelineLegend');
    if (legend && !legend.dataset.bound) {
      legend.dataset.bound = '1';
      legend.innerHTML = ['ok', 'warn', 'bad', 'idle'].map((k) => {
        const label = k === 'ok' ? 'Lolos' : k === 'warn' ? 'Ditahan' : k === 'bad' ? 'Veto' : 'Idle';
        return `<span><i style="background:${C[k]}"></i>${label}</span>`;
      }).join('');
    }
  };

  const loop = (now) => {
    if (!running) return;
    rafId = requestAnimationFrame(loop);
    if (now - lastFrame < 1000 / 30) return;
    lastFrame = now;
    draw(now);
  };

  const start = () => {
    if (running || reduceMotion) return;
    running = true;
    rafId = requestAnimationFrame(loop);
  };

  const stop = () => {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
  };

  const bindHover = () => {
    const canvas = document.getElementById('pipelineCanvas');
    const tooltip = document.getElementById('pipelineTooltip');
    if (!canvas || canvas.dataset.bound === '1') return;
    canvas.dataset.bound = '1';
    const hit = (clientX, clientY) => {
      const rect = canvas.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      const boxes = layout(rect.width, rect.height);
      return boxes.find((b) => Math.abs(x - b.cx) <= b.w / 2 && Math.abs(y - b.cy) <= b.h / 2);
    };
    const show = (box) => {
      if (!tooltip || !box) return;
      tooltip.innerHTML = `<strong>${U.esc(box.node.label)}</strong>`
        + `<div class="tt-row">status ${U.esc(box.node.status)}</div>`
        + `<div class="tt-row">${U.esc(box.node.note || '—')}</div>`;
      tooltip.style.left = `${Math.min(Math.max(box.cx - 60, 8), canvas.clientWidth - 200)}px`;
      tooltip.style.top = `${box.cy + box.h / 2 + 6}px`;
      tooltip.classList.add('show');
    };
    canvas.addEventListener('mousemove', (e) => {
      const box = hit(e.clientX, e.clientY);
      hovered = box ? box.index : -1;
      if (box) show(box);
      else if (tooltip) tooltip.classList.remove('show');
      if (reduceMotion) draw(performance.now());
    });
    canvas.addEventListener('mouseleave', () => {
      hovered = -1;
      if (tooltip) tooltip.classList.remove('show');
      if (reduceMotion) draw(performance.now());
    });
    canvas.addEventListener('click', (e) => {
      const box = hit(e.clientX, e.clientY);
      if (box) show(box);
    });
  };

  const render = (d) => {
    stageStatus(d || {});
    bindHover();
    draw(performance.now());
    if (!reduceMotion) start();
  };

  let resizeTimer = 0;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => draw(performance.now()), 150);
  }, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else if (!reduceMotion) start();
  });

  window.AegisPipeline = { render, stop, start };
})();
