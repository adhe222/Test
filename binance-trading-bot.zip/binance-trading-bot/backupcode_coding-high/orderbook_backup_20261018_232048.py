from typing import Dict, Any
from config import MAX_ALLOWABLE_SPREAD_PCT


class OrderbookAgent:
    """
    Order Book & Liquidity Inspector Agent:
    Validates bid/ask spreads to eliminate slippage drag and measures
    order book volume imbalance (buyers vs sellers) in the immediate depth.
    """

    def __init__(self, binance_client):
        self.client = binance_client
        self.name = "OrderbookAgent"

    def inspect_orderbook(self, symbol: str) -> Dict[str, Any]:
        try:
            depth = self.client.get_orderbook(symbol, limit=20)
        except Exception as e:
            return {
                "symbol": symbol,
                "passed": False,
                "reason": f"Orderbook fetch error: {e}"
            }
        bids = depth.get("bids", [])
        asks = depth.get("asks", [])

        if not bids or not asks:
            return {
                "symbol": symbol,
                "passed": False,
                "reason": "Empty orderbook received"
            }

        best_bid = bids[0][0]
        best_ask = asks[0][0]

        if best_bid <= 0:
            return {"symbol": symbol, "passed": False, "reason": "Invalid bid price"}

        spread_pct = ((best_ask - best_bid) / best_bid) * 100.0

        # Slippage Guard: veto if spread is too wide
        if spread_pct > MAX_ALLOWABLE_SPREAD_PCT:
            return {
                "symbol": symbol,
                "passed": False,
                "spread_pct": spread_pct,
                "reason": f"Wide spread ({spread_pct:.3f}%) exceeds safety threshold ({MAX_ALLOWABLE_SPREAD_PCT}%)"
            }

        # Calculate depth volume within top 15 tiers
        bid_depth_usd = sum(p * q for p, q in bids[:15])
        ask_depth_usd = sum(p * q for p, q in asks[:15])
        total_depth = bid_depth_usd + ask_depth_usd

        imbalance = 0.0
        if total_depth > 0:
            imbalance = (bid_depth_usd - ask_depth_usd) / total_depth

        # Imbalance check: if sellers dominate heavily (< -0.35), caution/rejection
        if imbalance < -0.35:
            return {
                "symbol": symbol,
                "passed": False,
                "spread_pct": spread_pct,
                "bid_depth_usd": bid_depth_usd,
                "ask_depth_usd": ask_depth_usd,
                "imbalance": imbalance,
                "reason": f"Orderbook sell wall dominant (imbalance {imbalance:.2f})"
            }

        return {
            "symbol": symbol,
            "passed": True,
            "best_bid": best_bid,
            "best_ask": best_ask,
            "spread_pct": spread_pct,
            "bid_depth_usd": bid_depth_usd,
            "ask_depth_usd": ask_depth_usd,
            "imbalance": imbalance,
            "reason": f"Tight spread ({spread_pct:.3f}%), positive liquidity support"
        }
