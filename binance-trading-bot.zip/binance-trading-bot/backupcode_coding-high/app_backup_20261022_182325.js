/* Aegis Telemetry — app controller: polling, tabs, service worker.
 * Read-only: this file issues GET /api/status only. No control endpoints.
 */
(() => {
  'use strict';
  const U = window.AegisUtil;
  const V = window.AegisViews;
  const V2 = window.AegisViews2;
  const C = window.AegisChart;

  const POLL_MS = 2000;
  let lastGood = null;
  let pipeline = null;
  let timer = null;

  function paint(d) {
    V.header(d);
    V.overview(d);
    V.macro(d);
    V.positions(d);
    window.AegisOperations.render(d);
    V2.agents(d);
    V2.history(d);
    V2.footer(d);
    C.render(d);
    if (pipeline) pipeline.setData(d);
  }

  /* Poll loop: network failure = reconnecting; render failure = keep connected. */
  async function poll() {
    try {
      const res = await fetch('/api/status', { cache: 'no-store', headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      lastGood = data;
      const conn = U.$('#connection');
      if (conn) conn.className = 'connection-pill connected';
      U.setText('connectionText', 'Terhubung');
      try {
        paint(data);
      } catch (renderErr) {
        console.error('Telemetry render error:', renderErr);
        U.setText('connectionText', 'Terhubung (render error)');
      }
    } catch (err) {
      console.warn('Telemetry reconnecting:', err && err.message);
      const conn = U.$('#connection');
      if (conn) conn.className = 'connection-pill reconnecting';
      U.setText('connectionText', 'Reconnecting');
      U.setText('updatedAt', lastGood ? 'Last-good data retained' : 'Waiting for first response');
      window.AegisOperations.stale(true);
    } finally {
      clearTimeout(timer);
      timer = setTimeout(poll, POLL_MS);
    }
  }

  const TABS = ['summary', 'market', 'positions', 'agents', 'history'];

  function activate(name, focus) {
    if (!TABS.includes(name)) name = 'summary';
    U.$$('.tab').forEach((b) => {
      const on = b.dataset.tab === name;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
      if (on && focus) b.focus();
    });
    U.$$('.view').forEach((v) => v.classList.toggle('active', v.dataset.view === name));
    if (location.hash !== '#' + name) history.replaceState(null, '', '#' + name);
    window.scrollTo({ top: 0, behavior: U.reduced ? 'auto' : 'smooth' });
    // Canvases sized while display:none need a re-measure once visible.
    if (name === 'agents' && pipeline) pipeline.resize();
    if (name === 'summary' && lastGood) C.render(lastGood);
  }

  function initTabs() {
    const tabs = U.$$('.tab');
    tabs.forEach((btn, i) => {
      btn.addEventListener('click', () => activate(btn.dataset.tab));
      // WAI-ARIA tabs: arrow keys move between tabs.
      btn.addEventListener('keydown', (e) => {
        const step = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
        if (e.key === 'Home') { e.preventDefault(); activate(tabs[0].dataset.tab, true); }
        else if (e.key === 'End') { e.preventDefault(); activate(tabs[tabs.length - 1].dataset.tab, true); }
        else if (step) { e.preventDefault(); activate(tabs[(i + step + tabs.length) % tabs.length].dataset.tab, true); }
      });
    });
    window.addEventListener('hashchange', () => activate(location.hash.slice(1)));
    activate(location.hash.slice(1) || 'summary');
  }

  function initTheme() {
    const btn = U.$('#themeToggle');
    const sync = () => {
      if (btn) btn.setAttribute('aria-pressed', String(window.AegisTheme.current() === 'light'));
    };
    if (btn) btn.addEventListener('click', () => window.AegisTheme.toggle());
    if (window.AegisTheme) window.AegisTheme.onChange(() => {
      sync();
      if (pipeline) pipeline.resize();
    });
    sync();
  }

  function init() {
    try {
      pipeline = window.AegisPipeline.create(U.$('#pipelineCanvas'), U.$('#pipelineTooltip'));
    } catch (err) {
      console.warn('Pipeline canvas unavailable:', err && err.message);
    }
    initTabs();
    initTheme();
    poll();

    // If the Chart.js CDN is blocked, switch the equity curve to the local renderer.
    setTimeout(() => {
      if (!window.Chart) {
        C.forceFallback();
        if (lastGood) C.render(lastGood);
      }
    }, 2500);

    window.addEventListener('resize', () => { if (lastGood) C.render(lastGood); }, { passive: true });

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .catch((err) => console.warn('Service worker unavailable:', err && err.message));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
