from urllib.parse import urlsplit

import config


def _rows(value):
    if isinstance(value, dict):
        value = value.get("items", [])
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def current_run_closed_events(events, run_trade_count):
    closed = [event for event in events if isinstance(event, dict) and event.get("action") == "CLOSED"]
    if isinstance(run_trade_count, int) and not isinstance(run_trade_count, bool) and run_trade_count >= 0:
        return closed[-run_trade_count:] if run_trade_count else []
    return closed


def describe_market_record(record, direction_hint=None):
    result = dict(record)
    direction = str(record.get("direction", "")).upper()
    if direction not in ("LONG", "SHORT"):
        direction = {"BUY": "LONG", "SHORT": "SHORT"}.get(str(record.get("action", "")).upper(), "UNKNOWN")
    if direction == "UNKNOWN" and direction_hint in ("LONG", "SHORT"):
        direction = direction_hint
    market = str(record.get("market") or record.get("target_market") or "").upper()
    source = "RECORDED"
    if market not in ("SPOT", "FUTURES"):
        market = {"LONG": "SPOT", "SHORT": "FUTURES"}.get(direction, "UNKNOWN")
        source = "DIRECTION" if market != "UNKNOWN" else "UNKNOWN"
    result.update(display_direction=direction, display_market=market, market_source=source)
    return result


def _capabilities():
    exchange = str(getattr(config, "EXCHANGE", "binance") or "binance").lower()
    spot = bool(getattr(config, "ENABLE_SPOT_LONGS", True))
    futures = bool(getattr(config, "ENABLE_FUTURES_SHORTS", True))
    if exchange == "okx":
        spot = spot and bool(getattr(config, "OKX_SPOT_ENABLED", True))
        futures = futures and bool(getattr(config, "OKX_FUTURES_ENABLED", True))
    return {"exchange": exchange, "spot": spot, "futures": futures}


def _dns_route_label():
    try:
        import dns_route

        routing = dns_route.active_routing()
        return "DOH" if routing.suffixes else "SYSTEM"
    except Exception:
        return "SYSTEM"


def build_market_operations(mode, ledger_mode, scan, positions, macro, loop, data_endpoint):
    mode = str(mode).upper()
    scan = scan if isinstance(scan, dict) else {}
    macro = macro if isinstance(macro, dict) else {}
    loop = loop if isinstance(loop, dict) else {}
    caps = _capabilities()
    positions = [describe_market_record(row) for row in _rows(positions)]
    candidates = [describe_market_record(row) for row in _rows(scan.get("candidates_evaluated"))]
    executed = _rows(scan.get("executed_trades"))
    executed_symbols = {row.get("symbol") for row in executed if row.get("symbol")}
    daily_paused = scan.get("daily_loss_limit_hit") is True
    capacity_full = config.MAX_OPEN_POSITIONS > 0 and len(positions) >= config.MAX_OPEN_POSITIONS
    mode_known = mode in ("PAPER", "LIVE")
    direction_guard = scan.get("direction_guard") if isinstance(scan.get("direction_guard"), dict) else {}
    routes = []
    for direction, market, enabled, macro_key in (
        ("LONG", "SPOT", caps["spot"], "safe_to_trade"),
        ("SHORT", "FUTURES", caps["futures"], "safe_for_shorts"),
    ):
        permission = macro.get(macro_key) if macro.get("regime") != "FALLBACK_NORMAL" else None
        guard_state = direction_guard.get(direction) if isinstance(direction_guard.get(direction), dict) else {}
        own = [row for row in candidates if row["display_direction"] == direction]
        status, reason = "WAITING_SETUP", "Izin makro terbuka; menunggu setup, risk gate dan persetujuan eksekutif."
        if not enabled:
            status, reason = "DISABLED", "Jalur dinonaktifkan dalam konfigurasi bot."
        elif not mode_known:
            status, reason = "UNSUPPORTED", "Mode runtime tidak dikenali; status eksekusi belum dapat dikonfirmasi."
        elif daily_paused:
            status, reason = "DAILY_PAUSED", "Batas rugi harian tercapai; entry dihentikan, posisi tetap dipantau."
        elif capacity_full:
            status, reason = "CAPACITY_FULL", "Slot posisi penuh; pemantauan dan evaluasi kandidat tetap berjalan."
        elif guard_state and not guard_state.get("allowed", True):
            status, reason = "PERFORMANCE_PAUSED", (
                f"Direction performance guard menahan entry {direction}: "
                f"{guard_state.get('reason', 'rolling expectancy negatif')}."
            )
        elif permission is False:
            status, reason = "MACRO_PAUSED", "Macro Sentinel menahan entry arah ini" + (
                f": {macro.get('short_block_reason')}." if direction == "SHORT" and macro.get("short_block_reason") else "."
            )
        elif permission is not True:
            status, reason = "WAITING_DATA", "Menunggu evaluasi makro yang valid."
        elif direction == "SHORT" and macro.get("selective_shorts"):
            status, reason = "SELECTIVE", (
                "BTC bullish: SHORT hanya untuk aset yang lemah sendiri (struktur 1h+4h bearish, "
                "tertinggal dari BTC) dengan risiko 50%."
            )
        routes.append({
            "direction": direction,
            "market": market,
            "configured": bool(enabled),
            "execution": "SIMULATION" if mode == "PAPER" else (f"{market}_ORDER_PATH" if mode == "LIVE" else "UNSUPPORTED"),
            "status": status,
            "reason": reason,
            "macro_permission": "ALLOWED" if permission is True else "PAUSED" if permission is False else "UNKNOWN",
            "direction_guard": guard_state,
            "entry_eligible": status in ("WAITING_SETUP", "SELECTIVE"),
            "candidate_count": len(own),
            "quality_pass_count": sum(row.get("gates_passed") is True for row in own),
            "position_count": sum(row["display_direction"] == direction for row in positions),
            "executed_count": sum(str(row.get("direction", "")).upper() == direction for row in executed),
        })
    audit = []
    for row in candidates:
        blockers = row.get("hard_gate_failures")
        blockers = [str(reason) for reason in blockers] if isinstance(blockers, list) else []
        route = next((item for item in routes if item["direction"] == row["display_direction"]), None)
        if route and not route["entry_eligible"]:
            blockers.insert(0, route["reason"])
        note = row.get("execution_note")
        if note and note != "READY_TO_EXECUTE":
            blockers.append(str(note))
        verdict = row.get("executive_verdict")
        verdict = verdict if isinstance(verdict, dict) else {}
        final_verdict = verdict.get("final_verdict", "UNKNOWN")
        if row.get("symbol") in executed_symbols:
            status = "EXECUTED"
        elif row.get("gates_passed") is not True or blockers:
            status = "BLOCKED"
        else:
            status = "AWAITING_APPROVAL"
        audit.append({
            "symbol": row.get("symbol", "UNKNOWN"),
            "direction": row["display_direction"],
            "market": row["display_market"],
            "status": status,
            "technical_score": row.get("technical_score"),
            "gates_passed": row.get("gates_passed") is True,
            "executive_verdict": final_verdict,
            "blockers": list(dict.fromkeys(blockers)),
        })
    try:
        host = urlsplit(str(data_endpoint)).hostname or "UNKNOWN"
    except ValueError:
        host = "UNKNOWN"
    routing_rows = [
        row.get("market_decision")
        for row in _rows(scan.get("candidates_evaluated"))
        if isinstance(row.get("market_decision"), dict)
    ]
    routing_summary = {
        "enabled": bool(getattr(config, "AUTO_MARKET_ROUTING", True)),
        "spot_count": sum(1 for row in routing_rows if row.get("market") == "SPOT"),
        "futures_count": sum(1 for row in routing_rows if row.get("market") == "FUTURES"),
        "decisions": [
            {
                "symbol": row.get("symbol"),
                "direction": row.get("direction"),
                "market": row.get("market"),
                "leverage": row.get("leverage"),
                "funding_pct": row.get("funding_pct"),
                "net_edge_spot_pct": row.get("net_edge_spot_pct"),
                "net_edge_futures_pct": row.get("net_edge_futures_pct"),
                "reason": row.get("reason"),
            }
            for row in routing_rows
        ][:8],
    }
    activity = "SCANNING" if loop.get("is_scanning") is True else "MONITORING" if positions else "WAITING_SETUP" if candidates else "WARMING_UP"
    return {
        "mode": mode if mode_known else "UNKNOWN",
        "exchange": config.EXCHANGE_LABEL,
        "ledger_mode": str(ledger_mode).upper(),
        "mode_mismatch": mode != str(ledger_mode).upper(),
        "exchange_orders_enabled": mode == "LIVE",
        "execution_notice": "Simulasi PAPER. Tidak ada order yang dikirim ke exchange." if mode == "PAPER" else "LIVE: jalur order SPOT (LONG) dan FUTURES (SHORT) tersedia; konektivitas dan fill tidak dibuktikan oleh dashboard." if mode == "LIVE" else "Mode runtime tidak dikenali. Eksekusi order belum dapat dikonfirmasi.",
        "spot_live_supported": bool(caps["spot"]),
        "futures_live_supported": bool(caps["futures"]),
        "data_market": "+".join(
            name for name, ok in (("SPOT", caps["spot"]), ("FUTURES", caps["futures"])) if ok
        ) or "DISABLED",
        "data_host": host,
        "dns_route": _dns_route_label(),
        "data_notice": "Harga, candle dan orderbook mengikuti market posisi: SPOT untuk LONG, FUTURES/SWAP untuk SHORT, pada exchange aktif.",
        "futures_notice": "SHORT memakai kontrak Futures/SWAP di mode LIVE; di PAPER disimulasikan tanpa leverage/likuidasi. Funding tidak dibukukan ke P&L.",
        "configured_leverage": config.FUTURES_DEFAULT_LEVERAGE,
        "auto_market_routing": bool(getattr(config, "AUTO_MARKET_ROUTING", True)),
        "market_routing": routing_summary,
        "leverage_applied": any(
            float(row.get("leverage") or 1.0) > 1.0 and str(row.get("market") or "").upper() == "FUTURES"
            for row in positions
        ),
        "timeframes": [config.KLINES_TIMEFRAME, config.TREND_TIMEFRAME_1, config.TREND_TIMEFRAME_2, config.LTF_TIMEFRAME],
        "activity": activity,
        "snapshot_at": scan.get("completed_at"),
        "last_updated": scan.get("last_updated"),
        "evaluated_count": len(candidates),
        "executed_count": len(executed),
        "position_count": len(positions),
        "routes": routes,
        "candidates": audit,
    }
