from typing import List, Dict, Optional, Tuple
import math


def calculate_ema_and_metrics(klines: List[Dict[str, float]], timeframe: str = "15m") -> Dict[str, Any]:
    """Calculate EMA stack (9, 21, 50), RSI, and ATR for momentum analysis."""
    if len(klines) < 60:
        return {"ema9": 0, "ema21": 0, "ema50": 0, "rsi": 50, "atr": 0, "score": 0}
    
    closes = [k["close"] for k in klines]
    highs = [k["high"] for k in klines]
    lows = [k["low"] for k in klines]
    
    # Calculate EMAs
    ema9_list = calculate_ema(closes, 9)
    ema21_list = calculate_ema(closes, 21)
    ema50_list = calculate_ema(closes, 50)
    
    ema9 = ema9_list[-1] if ema9_list else 0
    ema21 = ema21_list[-1] if ema21_list else 0
    ema50 = ema50_list[-1] if ema50_list else 0
    
    # Calculate RSI (14-period)
    rsi_val = calculate_rsi(closes, 14)
    rsi = rsi_val if rsi_val is not None else 50
    
    # Calculate ATR (14-period) - Tighter multiplier applied in risk manager
    atr_list = []
    for i in range(1, len(klines)):
        high = highs[i]
        low = lows[i]
        prev_close = closes[i - 1]
        tr = max(high - low, abs(high - prev_close), abs(low - prev_close))
        atr_list.append(tr)
    
    atr = None
    if len(atr_list) >= 14:
        atr = sum(atr_list[:14]) / 14
        for tr in atr_list[14:]:
            atr = (atr * 13 + tr) / 14
    
    # Trend alignment score (0-100)
    price = klines[-1]["close"]
    score = 0
    if ema9 > 0 and ema21 > 0 and ema50 > 0:
        if price > ema9 > ema21 > ema50:
            score = 100  # Perfect bullish alignment
        elif price > ema21 and ema9 > ema21:
            score = 75   # Moderate bullish
        elif price < ema9 < ema21 < ema50:
            score = 20   # Bearish
        else:
            score = 50   # Neutral/choppy
    
    # RSI adjustment
    if 50 <= rsi <= 68:
        score += 10
    elif rsi > 75 or rsi < 42:
        score -= 15
    
    return {
        "ema9": ema9,
        "ema21": ema21,
        "ema50": ema50,
        "rsi": rsi,
        "atr": atr if atr else (price * 0.02),  # Fallback 2% ATR
        "score": min(100, max(0, score))
    }


def calculate_volume_surge(klines: List[Dict[str, float]], period: int = 20) -> float:
    """Calculate ratio of recent volume compared to moving average volume."""
    if len(klines) < period + 1:
        return 1.0

    recent_vol = klines[-1]["volume"]
    # 20-period volume before current candle
    past_volumes = [k["volume"] for k in klines[-period - 1: -1]]
    if not past_volumes:
        return 1.0
    avg_vol = sum(past_volumes) / len(past_volumes)
    if avg_vol <= 0:
        return 1.0
    return recent_vol / avg_vol


def calculate_candle_metrics(kline: Dict[str, float]) -> Dict[str, float]:
    """Calculate candle strength metrics (body percentage, upper/lower wick)."""
    high = kline["high"]
    low = kline["low"]
    open_p = kline["open"]
    close = kline["close"]
    candle_range = high - low

    if candle_range <= 0:
        return {"body_pct": 0.0, "is_bullish": False, "close_ratio": 0.5}

    body = abs(close - open_p)
    body_pct = (body / candle_range) * 100.0
    is_bullish = close >= open_p
    close_ratio = (close - low) / candle_range

    return {
        "body_pct": body_pct,
        "is_bullish": is_bullish,
        "close_ratio": close_ratio
    }
