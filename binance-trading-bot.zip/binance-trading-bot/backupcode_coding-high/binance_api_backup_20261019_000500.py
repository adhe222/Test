import time
import hmac
import hashlib
from urllib.parse import urlencode
from typing import Dict, List, Optional, Any
import requests

from config import BINANCE_API_URL, BINANCE_API_KEY, BINANCE_API_SECRET

DEFAULT_ENDPOINTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com"
]


class BinanceClient:
    def __init__(self, base_url: str = BINANCE_API_URL, api_key: str = BINANCE_API_KEY, api_secret: str = BINANCE_API_SECRET):
        primary = base_url.rstrip("/") if base_url else "https://data-api.binance.vision"
        endpoints = [primary]
        for ep in DEFAULT_ENDPOINTS:
            if ep not in endpoints:
                endpoints.append(ep)
        self.endpoints = endpoints
        self.active_base_url = primary
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        if self.api_key:
            self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    def _sign_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request_with_fallback(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 4.0) -> requests.Response:
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}{path}"
            try:
                resp = self.session.request(method, url, params=params, timeout=timeout)
                resp.raise_for_status()
                self.active_base_url = base
                return resp
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint")

    def get_24hr_tickers(self) -> List[Dict[str, Any]]:
        resp = self._request_with_fallback("GET", "/api/v3/ticker/24hr", timeout=6.0)
        return resp.json()

    def get_price(self, symbol: str) -> float:
        resp = self._request_with_fallback("GET", "/api/v3/ticker/price", params={"symbol": symbol}, timeout=4.0)
        data = resp.json()
        return float(data["price"])

    def get_klines(self, symbol: str, interval: str = "15m", limit: int = 100) -> List[Dict[str, Any]]:
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        resp = self._request_with_fallback("GET", "/api/v3/klines", params=params, timeout=5.0)
        raw_klines = resp.json()

        klines = []
        for k in raw_klines:
            klines.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "quote_volume": float(k[7]),
                "trades": int(k[8])
            })
        return klines

    def get_orderbook(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        params = {"symbol": symbol, "limit": limit}
        resp = self._request_with_fallback("GET", "/api/v3/depth", params=params, timeout=4.0)
        data = resp.json()
        bids = [[float(p), float(q)] for p, q in data.get("bids", [])]
        asks = [[float(p), float(q)] for p, q in data.get("asks", [])]
        return {"bids": bids, "asks": asks}

    def get_account_info(self) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for private account endpoints.")
        params = self._sign_params({})
        resp = self._request_with_fallback("GET", "/api/v3/account", params=params, timeout=6.0)
        return resp.json()

    def place_order(self, symbol: str, side: str, order_type: str = "MARKET",
                    quantity: Optional[float] = None, quote_order_qty: Optional[float] = None) -> Dict[str, Any]:
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper()
        }
        if quantity is not None:
            params["quantity"] = f"{quantity:.6f}"
        elif quote_order_qty is not None:
            params["quoteOrderQty"] = f"{quote_order_qty:.2f}"
        else:
            raise ValueError("Either quantity or quote_order_qty must be provided.")

        params = self._sign_params(params)
        ordered = [self.active_base_url] + [ep for ep in self.endpoints if ep != self.active_base_url]
        last_exc = None
        for base in ordered:
            url = f"{base}/api/v3/order"
            try:
                resp = self.session.post(url, params=params, timeout=6.0)
                resp.raise_for_status()
                self.active_base_url = base
                return resp.json()
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as exc:
                last_exc = exc
                continue
        if last_exc:
            raise last_exc
        raise RuntimeError("No available Binance API endpoint for placing order")
