# Binance Institutional AI Multi-Agent Quant Trading System (Clouvia Powered)

A Python multi-agent trading bot with bidirectional PAPER strategies (Spot LONG and simulated Futures SHORT), deterministic risk gates, a Clouvia AI final-decision authority with multi-source external research, persistent portfolio accounting, and a read-only web dashboard. A win-rate target is a strategy objective, not a verified performance guarantee. Paper trading remains experimental and is not a profit guarantee; use a small slot count and conservative profile until a sufficiently large out-of-sample paper sample validates expectancy. For performance analysis, use the portfolio ledger's own run counters and time range: `trade_history.json` is append-only and may contain trades from earlier runs.

## Risk Controls Updated After Paper Ledger Review

- The local `.env` currently sets `TRADING_PROFILE=aggressive` (the code default is `balanced`). The aggressive preset lowers entry score/conviction thresholds and allows more slots; explicit environment variables still override the preset.
- The BTC macro sentinel separately exposes `safe_for_longs` and `safe_for_shorts`: it pauses new altcoin LONG entries when BTC is below EMA50 in a bearish EMA21/EMA50 structure, without disabling all markets or short candidates. Severe panic remains governed by the existing circuit breaker.
- Default stop distance is 1.5 x ATR, with a 1.0% floor and 3.5% ceiling; TP1 is 1.0R and TP2 is 4.0R. TP1 banks 50% and simultaneously moves the stop to a fee-aware break-even (0.60% cushion, or round-trip fees + paper slippage + 0.10%, whichever is larger). The runner trailing stop is floored at that break-even price. Stagnant micro-profit salvage waits 240 minutes and requires at least +1.0% net.
- The local `.env` explicitly sets a maximum of 3 concurrent positions in the same direction. Without an override, the cap is derived from the configured total slots (for the code-default 3 slots, the cap is 2). This is a concurrency limit, not a profitability control.
- Paper stop and trailing exits account for price gaps by filling at the observed market price when it is worse than the stop threshold. A stop is not a guarantee of a capped loss in a gap or illiquid market.
- Dashboard win-rate, profit-factor, expectancy, and exit-reason metrics are scoped to the latest portfolio run count, while the trade-history view remains append-only. This prevents earlier runs from inflating current-run performance metrics.
- These are risk controls, not demonstrated alpha. Historical ledger replay and a small sample are not predictive evidence; do not enable real orders on this basis.

## Momentum Profit Integrity (2026-10-22)

The paper ledger exposed a structural exit inconsistency, not a market-prediction problem. Of 123 closed trades: 49 `STOP_LOSS_HIT` realised -95.23 USDT, 27 `BREAK_EVEN_STOP_EXIT` realised +6.79 USDT but 20 of those had never reached TP1 and collectively lost -4.33 USDT, while 19 `TRAILING_STOP_EXIT` realised +72.78 USDT and 2 `TP2` realised +23.10 USDT. The old rules armed break-even at +1R but waited for TP1 at +1.5R; price frequently reached +1R, the stop moved to a 0.45% cushion that did not cover fees plus slippage, then reversed. Those exits were labelled break-even while realising small losses.

Changes in this repair:
- TP1 now triggers at +1R and banks 50% at the same moment the stop moves to break-even, so the partial and the protection are one event rather than two competing rules.
- Break-even is fee-aware: `max(0.60%, round-trip fee + paper slippage + 0.10%)`. The trailing stop can never sit below the break-even stop after TP1.
- Pyramiding is opt-in and disabled by default (`ENABLE_PYRAMIDING=false`). When enabled, it requires TP1 already banked, trailing active, no exit already pending, and the add's maximum stop risk plus fee to be fully covered by the realised TP1 profit. An add at TP2 or at a live stop/trail is skipped because it would close immediately and pay a pointless fee.
- Position monitoring uses a 3-second price cache (was 10 seconds) so the 3-second watchdog does not act on a stale quote.
- `MAX_SIGNAL_DRIFT_PCT` (default 0.8%) rejects a signal only when the executable order-book quote has drifted **adversely** from the analysed close; a favorable gap is not treated as a chase.
- Execution is re-quoted after the LLM review: the order book is fetched with cache bypass, adverse drift is re-checked, and the risk plan (entry, stop, TP1/TP2, quantity) is recomputed from the fresh executable quote. A signal older than `MAX_SIGNAL_AGE_SEC` (default 120s) or a fresh quote beyond the drift limit is rejected instead of booking a stale entry.
- Klines cache TTL is capped at the newest bar's time-to-close, and each bar carries an `is_closed` marker captured at fetch time. A mid-bar snapshot can no longer be re-used after that bar closes and be mistaken for a final candle by volume, RSI, EMA or candle-body gates.
- A failed or empty 5m LTF feed is now a hard gate failure. The old `except: pass` let entries through without the micro-trigger confirmation.
- Trade-log dedupe is keyed by `(symbol, action, entry_time)`, so a repeated close for the same entry cannot be appended twice even if the second event carries a different exit timestamp.
- Paper counters are reconstructed from `CLOSED`, `PARTIAL_TP1_TAKEN` and `PYRAMID_ADD` events. `gross_realized_pnl_usdt = realized_pnl_usdt + total_fees_paid_usdt` is enforced on every load, and `cash_reconciliation` reports any persisted-cash mismatch instead of silently presenting a stale balance. The daily/weekly/monthly report and the direction guard both respect `counter_since`, so legacy trades from before a reset cannot inflate current-run metrics. The existing paper book was scoped to the verified `2026-10-20T03:15:55Z` reset boundary (source: `.zsh_history:595`); `trade_history.json` remains append-only and was not rewritten.
- Direction performance guard: after at least 12 closed trades in the last 20 for a direction (scoped to the current run via `counter_since`), a win rate below 30% with negative net PnL pauses new entries in that direction. After 6 hours without a close it allows one probation probe at 0.25x risk, preventing a permanent deadlock. On the current paper ledger this would pause LONG (last 20: 25.0% WR, -2.25 USDT) and keep SHORT (50.0% WR, -2.96 USDT). The dashboard route status is `PERFORMANCE_PAUSED` with the guard reason, not a generic "waiting setup" label. The sample is small; this is a risk control, not proof of alpha.
- Empty `OPENAI_MODEL` now falls back to `coding-high`; `OPENAI_BASE_URL` is read through config. The previous empty model made every AI review fail into deterministic fallback while `configured` still reported true. Provider failures (including HTTP 402 exhausted credits, 429 and 5xx) are now surfaced as `engine_mode=DETERMINISTIC_FALLBACK` with `last_error_kind`; `Retry-After` is honoured by the circuit breaker, so a degraded AI path is visible instead of silently labelled active.

These are risk and accounting repairs. They do not guarantee profit, and the paper sample is too small for an out-of-sample performance claim. Real orders remain disabled unless the operator explicitly configures live keys and accepts the documented limitations.

## AI Absolute Decision Authority & External Research (2026-10-22)

`AI_DECISION_AUTHORITY` controls how the Clouvia review binds:
- `advisory` (legacy): AI dissent only penalises conviction.
- `veto`: AI may reject a deterministic approval.
- `absolute` (currently active in `.env`): the executive AI is the final approver. It may override deterministic strategy gates — momentum score, order-book imbalance, and learned-lesson vetoes — when the external dossier and risk/reward justify it.

Hard risk rails are never delegated to the LLM: live-price/data freshness, spread/liquidity, risk-desk approval, stop-loss and position sizing, daily loss limit, capacity/correlation caps, symbol cooldowns, and the macro circuit breaker still reject before or independently of the AI. `AI_ABSOLUTE_MIN_CONVICTION` (default 60) is a floor; an AI `APPROVE` below it is converted to `REJECT`.

Every absolute review receives a timestamped external dossier from `market_intel.py`:
- Binance Futures funding rate, mark/index price, next funding time.
- Open-interest history (1h change and trend).
- Global long/short account ratio and crowding.
- Taker buy/sell flow and pressure.
- Alternative.me Fear & Greed index.
- CoinDesk and Cointelegraph RSS headlines, with symbol-matched and market-wide sections.

`EXTERNAL_INTEL_MIN_SOURCES` (default 2) and `AI_REQUIRE_EXTERNAL_RESEARCH=true` mean an AI approval is rejected when the dossier is `DEGRADED` or has too few healthy sources. The dossier is cached for `EXTERNAL_INTEL_TTL_SEC` (180s), fetched for at most `AI_RESEARCH_MAX_CANDIDATES` (3) candidates per cycle, and every source failure is reported per-source instead of being hidden.

If the AI provider is unavailable, `query_specialist` returns `engine_mode=DETERMINISTIC_FALLBACK` with `last_error_kind`, and the absolute path falls back to deterministic consensus **but never overrides strategy failures**. This prevents a provider outage from silently becoming an unvetted aggressive entry. `status_summary` exposes `decision_authority` and `external_research_status`; the CLI and dashboard show both. The active model is exactly the model in `.env` (`OPENAI_MODEL`/`CLOUVIA_MODEL`); the current value is `glm5.3-thinking-agentic`. Provider failures remain visible as `DETERMINISTIC_FALLBACK` with `last_error_kind` and never silently become an AI approval.

`cash_reconciliation` is now recomputed on every portfolio save, not only on load. Opening a position previously left a stale `OK` reconciliation while `cash_usdt` had already been reduced by the new position cost.

## AI Self-Evolution: Autonomous Local Intelligence Upgrade (2026-10-22)

The AI is not limited to approving trades. It also upgrades the local intelligence state in `data/agent_consciousness.json`:
- **Triggers**: after every closed trade (`TRADE_CLOSE`) and on the autonomous scheduler (`SCHEDULED_6H`, configurable via `EVOLUTION_INTERVAL_SEC`, default 21600s). Startup runs one cycle before the dashboard starts.
- **Dossier**: recent closed trades with entry metrics, per-direction and per-exit-reason performance, audit summary, current thresholds/weights/rules, portfolio state, and BTC market context from the external-research agent.
- **Output contract**: strict JSON with `calibrated_thresholds`, `dynamic_weights`, and `new_rules`. Each new rule must carry a `machine_check` predicate: metric, operator, threshold, direction, and action.
- **Real enforcement**: machine rules are evaluated first on the executable path (`audit_against_experience` -> `orchestrator.run_cycle`). A `VETO`/`PENALTY_OR_VETO` blocks the candidate and increments the rule's `times_applied`; a `CAUTION` is recorded but does not block. Free-text-only rules are stored as advisory and never counted as enforced.
- **Validation**: thresholds and weights are clamped to sane bounds; unsupported keys are dropped; duplicate machine signatures are rejected; semantically inverted rules (for example vetoing SHORT for low bid depth, which is actually favorable for shorts) are rejected.
- **Persistence**: AI-calibrated thresholds are marked `ai_locked` and are not relaxed by the loss-ratchet staleness decay. A fresh loss explicitly clears that lock for the affected key so live risk protection can take over.
- **Telemetry**: `last_upgrade` records timestamp, trigger, model, version, diagnosis, changed threshold/weight keys, applied counts, and rejected-rule counts. The CLI shows `Last AI Upgrade`; `/api/status` exposes `last_upgrade`, `machine_rule_count`, and `ai_intelligence_level`.
- **Failure behavior**: provider failure falls back to deterministic evolution with `DETERMINISTIC_AUTONOMOUS_FALLBACK`; it never silently claims an AI upgrade. `--no-autonomous-evolve` disables the scheduler.

Empirical startup run: 9 thresholds, 2 weights, and 5 machine rules applied, persisted, and then read back by `audit_against_experience` (for example `AI-VOL-SURGE-001` fired on `volume_surge 1.50 < 1.80`). Subsequent scheduled runs applied further rules without duplicating exact signatures.

## Unlimited Capacity Mode (2026-10-22)

The operator can remove artificial slot caps without disabling risk controls:
- `MAX_OPEN_POSITIONS=0` means unlimited total positions.
- `MAX_CORRELATED_POSITIONS=0` means unlimited same-direction positions.
- `MAX_ENTRIES_PER_DIRECTION_PER_CYCLE=0` means no per-cycle cluster cap.
- `MAX_TOTAL_ALLOCATION_PCT=100` allows the book to use all free cash.
- Spot LONG and Futures SHORT are both enabled (`ENABLE_SPOT_LONGS=true`, `ENABLE_FUTURES_SHORTS=true`).

Unlimited capacity is not unlimited leverage. The natural limits remain: one position per symbol, `MAX_POSITION_SIZE_PCT` per position (currently 15% of equity), available `cash_usdt`, risk per trade, stop loss, daily loss limit, liquidity/spread gates, macro circuit breaker, and AI absolute approval. The portfolio manager rejects an entry when cash is insufficient for the position plus fee.

Implementation details: `0` is the unlimited sentinel in `config.apply_position_slots`, the risk manager skips its slot check, the orchestrator treats available slots as effectively infinite, correlation and per-cycle caps are bypassed, and the dashboard renders `3 / ∞` with "Tanpa batas searah". Tests cover the zero-slot sentinel, the risk agent approving with many open positions, and dashboard capacity rendering.

## Dashboard Reconnect Fix & Telemetry Payload (2026-10-22)

The dashboard was showing `Reconnecting` every 2s even though `/api/status` returned HTTP 200. Root cause was a JavaScript scope error: `capMax` was declared inside `statusBanner()` but used inside `overview()`, so every poll threw `ReferenceError` during `paint()` and the catch block mislabeled it as a network failure.

Fixes:
- Declare `capMax` inside `overview()`; add a Node regression test that renders the summary with `capacity_max=0`.
- Separate fetch failures from render failures: only network/HTTP errors show `Reconnecting`; a render exception logs `Telemetry render error` and keeps the connection pill connected.
- Compact `/api/status`: keep full `specialist_reports`/`executive_verdict` only for the top candidate; subsequent candidates keep summary fields. Live payload dropped from ~794 KB to ~189 KB per 2s poll.
- Asset cache bumped to `pro-9` / `aegis-shell-v13-theme`.

## Trading Profile (Entry Strictness Presets)

`TRADING_PROFILE` in `.env` selects a preset for entry strictness: `conservative`, `balanced` (code default), or `aggressive` (currently active in `.env`). Explicit env knobs (e.g. `MIN_TECHNICAL_SCORE`, `RISK_PER_TRADE_PCT`) always win over the preset. Safety rails — macro circuit breaker, symbol cooldowns, daily loss limit, capacity caps — stay active in every profile. `config.apply_trading_profile()` applies the preset at import; `config.TRADING_PROFILE` reports the active one (printed on every CLI startup).

## Position Slots (Free User Capacity Control)

Concurrent open-position capacity is user-controlled, in priority order:
1. CLI flags: `--slots N`, `--max-same-direction N`, `--position-size-pct P`.
2. Env / `.env`: `MAX_OPEN_POSITIONS` (1-20, validated against `MAX_SLOTS_LIMIT`).
3. First-run prompt: when `MAX_OPEN_POSITIONS` is absent from the environment and stdin is a TTY, the bot asks once, persists the choice into `.env`, and never asks again.

`config.apply_position_slots()` derives `MAX_CORRELATED_POSITIONS` (default min(3, ceil(2/3 of slots))) and `MAX_POSITION_SIZE_PCT` (default min(25, 90/slots)) unless explicitly set. The prompt is skipped automatically on non-interactive runs (no TTY) and in tests.

## Self-Evolution Enforcement (Fixed)

Previous behavior: learned thresholds and RCA rules were written to `data/agent_consciousness.json` but never enforced — division weights fed the Executive Committee (except the Momentum division, whose lookup key mismatched and always defaulted to 1.0), while `audit_against_experience` ran only on the deterministic fallback path with mismatched metric keys (empirical proof: 6207 audits, 0 vetoes enforced). Now:
- Learned lessons (RSI ceiling `EXH-001`, upper-wick `PA-001`, learned volume-surge floor) and calibrated thresholds are audited on the executable deliberation path in `orchestrator.run_cycle` before LLM queries; a violation appends a `Learned Lesson Veto` hard-gate failure.
- Break-even scratches (outcome `SCRATCH` or |pnl_pct| <= 0.05 without outcome) no longer count as learnable losses or rewardable wins.
- Double-learning removed: `orchestrator.run_cycle` is the single learning entry point per exit event (the duplicate call in `portfolio_manager` was removed).
- `apply_ai_upgrade` clamps LLM-proposed weights to [0.5, 2.0] and thresholds to per-key sane bounds; non-numeric values are dropped.
- A corrupt `agent_consciousness.json` is preserved as `.corrupt-<ts>` before reinitialization (no more silent wipe of learned state).
- The Momentum division's learned weight now actually biases the weighted conviction synthesis (role name aligned with the memory key).
- The founder volume-surge floor (1.10x) only vetoes when the threshold was actually learned (deviates from founder default); momentum.py's config gates are unchanged.

## Adaptive Ratchet Staleness Decay (Anti-Deadlock)

Live 2026-10-21: after a loss cluster the deterministic evolution ratcheted `min_volume_surge` to its 1.30 cap while the best market candidate produced only 0.75x — 265 scan cycles, 0 executions, and no path back (wins only raise weights, never relax thresholds). The ratchet was a structural deadlock. Now (`agents/consciousness.py`, `orchestrator.run_cycle`):
- Every scan cycle computes `hours_idle` since the LAST closed outcome and calls `apply_staleness_decay(hours_idle)`: learned thresholds relax linearly from their `ratchet_anchor` (value at the last tightening write) toward the foundation bases, in discrete steps (default one step per 0.5h, full relax after 12h idle; env `THRESHOLD_STALENESS_DECAY_HOURS` / `THRESHOLD_STALENESS_DECAY_STEP_HOURS`).
- A fresh LOSS re-arms to full tightness instantly (`record_trade_failure_and_learn` -> `rearm_thresholds`) BEFORE the incremental +0.02 tightening, so decay only accrues while the system is idle and live protection is never weakened.
- Hard risk gates (daily loss limit, position sizing, stop-loss) are untouched by decay.
- Effective thresholds (the decayed values) are what `audit_against_experience` enforces, and `staleness_decay` (last application: hours idle, fraction, relaxed keys) is surfaced in `get_ultra_context_summary` telemetry.
- Unit tests: `tests/test_staleness_decay.py` (ratchet saturation, interpolation, idempotence, re-arm on loss, win no-rearm, reload persistence, AI-upgrade anchor).

## Loss Cooldown Bypass (2026-10-22)

The post-loss symbol cooldown (`SYMBOL_COOLDOWN_BARS`, default 3 bars) is now a SOFT gate instead of a blanket ban (`orchestrator._cooldown_bypass_decision`):
- A candidate that just lost is allowed to re-enter immediately ONLY when the fresh setup is demonstrably stronger than the normal entry bar: momentum gate passed, technical score >= `min_score_required + SYMBOL_COOLDOWN_BYPASS_SCORE_MARGIN` (default 30), orderbook gate passed with imbalance confirming the trade direction (`>= +0.05` for LONG, `<= -0.05` for SHORT), HTF confluence intact when available, and fewer than `SYMBOL_COOLDOWN_BYPASS_MAX_RECENT_LOSSES` (default 2) real losses on that symbol within `SYMBOL_COOLDOWN_BYPASS_LOOKBACK_HOURS` (default 6h).
- Weak or marginal setups keep the full cooling window; the veto text now reads `Cooldown after loss (...m left) — bypass denied: <reason>`.
- A symbol that keeps bleeding is never bypassed: two real losses inside the lookback window lock it until the window expires.
- `SYMBOL_COOLDOWN_BYPASS_ENABLED=false` restores the old hard cooldown. `SYMBOL_COOLDOWN_BYPASS_RISK_MULT` scales position risk on a bypass (default 1.0 = full size).
- Telemetry: `symbols_in_cooldown` still lists every cooling symbol; allowed bypasses appear in cycle result `cooldown_bypasses` and on each candidate record as `cooldown_bypass` (`allowed`, `reason`, `score`, `imbalance`, `recent_losses`).
- Tests: `tests/test_aggressiveness_fixes.py::TestLossCooldownBypass` plus end-to-end `test_strong_setup_reenters_after_loss_cooldown` / `test_weak_setup_still_respects_loss_cooldown`.

## Security Notes

`WEB_HOST` now defaults to `127.0.0.1` (previously `0.0.0.0`, which exposed the unauthenticated dashboard to the whole LAN). Set `WEB_HOST=0.0.0.0` explicitly only behind a trusted network or reverse proxy with auth. `/api/status` no longer leaks the upstream LLM base URL or provider name (masked in `web_dashboard`; keys remain visible only in local CLI output). `GET /`, `/api/status`, and `/api/health` are registered via `api_route(methods=["GET", "HEAD"])` so `curl -I` probes and uptime monitors work (`@app.get` alone returns `405 Method Not Allowed` for HEAD in this FastAPI/Starlette build).

## Theme System (dark + light)

The dashboard ships a dual-theme design system driven entirely by CSS custom properties. Default is the dark identity; a light theme is one click away via the sun/moon toggle in the header (`#themeToggle`).

- `static/css/base.css` defines every color as a semantic token in `:root` (dark) and overrides them under `html[data-theme="light"]` — surfaces, hairlines, text tiers, semantic accents, header/tabbar/tooltip/canvas-node backgrounds.
- An inline script in `<head>` reads `localStorage("aegis-theme")` **before** stylesheets load, sets `data-theme`, and syncs `meta[name=theme-color]` — zero FOUC, choice persists across reloads.
- `chart.js` and `pipeline.js` read tokens via `getComputedStyle` and rebuild their canvases on theme change (`AegisTheme.onChange`), so the equity curve and deliberation flow recolor instantly.
- All light-theme text pairs pass WCAG 2.2 AA (body >= 4.5:1): text 17.3:1, muted 5.5:1, tertiary 5.4:1, cyan accent 5.9:1, green 5.5:1, red 6.5:1, amber 7.1:1.
- Asset cache version is `v=pro-8` (HTML + `sw.js` shell list, service worker `aegis-shell-v12-theme`) so PWA clients pick up the telemetry/UI changes without stale-cache artifacts.

## Market Operations Dashboard

The first panel on Overview, **Apa yang sedang dijalankan?**, now reports:

- Actual runtime execution mode (PAPER/LIVE), separately from persisted ledger mode; a mismatch is explicitly flagged.
- Always-visible **SPOT LONG** and **FUTURES SHORT** routes, including enabled configuration, macro permission, daily-risk/capacity pauses, candidate counts, quality passes and open-position counts.
- Current scanning/monitoring activity, timestamp of the last completed scan, candidate evaluation and entry counts. The displayed interval is the pause **between** scans, not the total scan duration.
- Per-candidate market, direction, actual gate rejection reasons and execution state. Quality approval is not presented as an executed order. Additional candidates use an expandable native disclosure.
- Public market-data host without credentials, Spot data provenance, analysis timeframes and Futures simulation limitations.
- Stale-data warning on disconnection while retaining last-good information. The service worker caches shell assets only; API telemetry is never cached.
- Explicit market/direction labels on positions and history. Ambiguous legacy closes display **ARAH N/A / Pasar tidak tercatat**, never an invented LONG or SHORT. Labels inferred from explicit direction are marked as such; persisted records are not modified.

### Execution boundaries

PAPER simulates both strategies without sending orders. Prices, candles and depth come from Binance **Spot** endpoints, also for SHORT simulation. The simulated SHORT P&L is `(entry - current) * quantity`; configured Futures leverage is not applied, and real Futures margin, liquidation, funding settlement and contract availability are not modeled.

The implemented live order client uses `/api/v3/order` (**Spot**). There is no Futures order, leverage-setting or position-mode implementation. The dashboard marks Futures LIVE as **not supported**, not as an available exchange route. This status is observational only: it does not add a backend execution interlock or certify existing LIVE safety. Do not enable LIVE SHORT without implementing and verifying Futures routing and risk controls. No LIVE order or exchange connectivity test is performed by dashboard rendering.

`dashboard_telemetry.py` builds read-only summaries; `web_dashboard.py` adds `market_operations` to `GET /api/status`. `static/js/operations.js` and `static/css/operations.css` render the panel. `main.py` publishes scan start/completion state and timezone-aware timestamps and binds the dashboard before the first CLI scan. This fixes the former silent `timezone` name error that left cycle telemetry stale.

Open http://localhost:8080 and refresh once after deployment so the updated PWA shell is loaded.

---

## 🏛️ All-Weather Hybrid Architecture (Spot Longs + Futures Shorts)

The system automatically detects macro market regimes and operates bidirectionally:

### 1. Spot Long Execution (Bullish Breakouts)
- Triggered when Bitcoin and candidate assets exhibit bullish momentum and trend alignment.
- Targets clean breakouts with high buyer absorption, rising volume, and safe distance above EMA21.
- Take Profit ladders execute at +2R and +4R above entry price with trailing stop trailing behind peak gains.

### 2. Futures Short Simulation (Bearish Breakdowns)
- Triggered when candidate assets show breakdown structure (Price < EMA9 < EMA21 < EMA50).
- When BTC is in a severe selloff, the Macro Sentinel circuit breaker pauses altcoin longs; a non-panic bearish EMA21/EMA50 structure also pauses longs without globally halting selective shorts. Shorting still requires independent bearish candidate confirmation.
- Mathematical Inverted Risk & PnL:
  * Simulated unrealized PnL: `(Entry Price - Current Price) * Quantity` (no applied leverage)
  * Dynamic Stop Loss placed **above** entry price: `Entry Price + (1.5 * ATR)`
  * Multi-stage Take Profit placed **below** entry price: TP1 at 2.0R, TP2 at 4.0R
  * Trailing stop tracks downward price progression (`lowest_price`), moving stop loss down as profit deepens.
  * Early break-even protection activates at +1R (the same event as TP1) with a fee-aware cushion of at least 0.60%.

---

## Direction-Aware Entry Gate Repair

- `agents/momentum.py` scores 1h and 4h confirmation in the requested direction. Bearish SHORT setups receive points for price below EMA21/EMA50 and a mirrored 4h RSI corridor of 28–52; bullish LONG scoring is unchanged.
- Both higher-timeframe feeds must contain sufficient closed candles. Missing 1h or 4h data blocks entry instead of silently treating partial confirmation as complete.
- SHORT entries cannot combine a bullish higher-timeframe trend with bearish confirmation from another timeframe. Conflicting higher-timeframe structure remains a hard veto.
- `agents/orderbook.py` accepts `direction="LONG"` by default and `direction="SHORT"` explicitly. Sell-side depth imbalance below -0.35 vetoes LONG, not SHORT; buyer absorption above +0.40 vetoes SHORT. Spread limits remain common to both directions.
- `orchestrator.py` forwards candidate direction to the upstream orderbook check, as well as the momentum, risk, and specialist stages.
- Macro regime authorization, position limits, RSI entry limits, volume confirmation, stops, and the executive approval requirement remain enforced. The repair removes contradictory gates; it does not force orders or guarantee immediate entries.
- `tests/test_directional_gates.py` covers valid mirrored LONG/SHORT fixtures, opposing and missing HTF data, liquidity direction, spread protection, and direction propagation. Fixtures are synthetic test data, not historical or live performance evidence.
- The SHORT portfolio lifecycle test uses temporary portfolio and trade-history files. Verification must also use `BOT_DATA_DIR` to isolate consciousness and other persistent state from the running bot.
- SHORT simulation uses the configured market-data feed. A passing paper test does not verify live Futures routing, order execution, or profitability.

## 🏛️ System Reliability & Gridlock Elimination Engine

The system is engineered to solve scanning deadlocks, upstream timeouts, and geographical ISP blocks (such as Indonesian TrustPositif filters on `api.binance.com`).

### Key Reliability Enhancements:
1. **Multi-Endpoint Failover Layer (`binance_api.py`)**:
   - Primary data gateway points to `https://data-api.binance.vision` (unblocked, low-latency institutional Binance Cloud endpoint).
   - Seamless failover across cluster mirrors: `api.binance.com`, `api1.binance.com`, `api2.binance.com`, `api3.binance.com`, `api4.binance.com`, and `api-gcp.binance.com`.
2. **Deterministic Short-Circuit Evaluation (`orchestrator.py`)**:
   - Candidates that do not meet strict technical baselines are evaluated deterministically in sub-millisecond timeframes (0.05 ms).
   - Prevents cascading sequential LLM latency and eliminates scan freezes.
   - Qualified breakout and breakdown candidates trigger parallel deliberation across all specialist divisions via Python `ThreadPoolExecutor`.
3. **Calibrated Momentum & Trend Gates (`agents/momentum.py` & `config.py`)**:
   - Volume surge evaluated across a 3-bar rolling window (>= 1.1x) to catch sustained momentum continuation.
   - Dynamic Trend Efficiency threshold calibrated to realistic crypto volatility (>= 0.12).
   - Long RSI momentum corridor: 45.0 - 74.0.
   - Short RSI momentum corridor: 26.0 - 55.0.
   - 24h Quote Volume threshold calibrated to $2,000,000 USDT (expanding the liquid asset pool across 130+ pairs).
   - Top candidate evaluation quota scaled to 15 assets per cycle (`SCANNER_TOP_LIMIT = 15`).
4. **Adaptive Circuit Breaker (`ai_engine.py`)**:
   - 45.0s per-request timeout with automatic circuit breaker if upstream AI endpoints experience transient network degradation.
5. **Reasoning-Model JSON Resilience (`ai_engine.py`)**:
   - Token budget sized for thinking models: `LLM_MAX_TOKENS` (default 1500, meta-quant calibration uses >= 2000) prevents "Unterminated string" truncation errors that permanently opened the circuit breaker and froze the bot in deterministic-only mode.
   - Multi-stage defensive parser `_parse_json`: strips markdown fences and `−think−`-style reasoning blocks, removes trailing commas, then scans every balanced `{...}` candidate until one yields a valid JSON object (immune to brace-shaped noise in reasoning prose). Truncated output still fails closed to the deterministic fallback.
6. **Adaptive Loss-Streak Guard with Staleness Decay (`orchestrator.py`)**:
   - Consecutive losses tighten technical score and conviction thresholds stepwise (up to `MAX_TIGHTEN_STEPS`), but steps now decay 1 per `TIGHTEN_STALE_DECAY_HOURS` (default 4h) since the last closed trade. Without the decay a cold loss streak locked the executive conviction bar above every candidate forever (deadlock: no trades -> no wins -> no relaxation). A fresh loss re-arms the full guard immediately; hard risk gates (daily loss limit, sizing, stops) are unaffected by the decay.
7. **Single-Instance Discipline (`main.py`)**:
   - Running `main.py --port N` without `--web` silently starts a FULL second scan loop (AUTO-MODE); two loops double the 7-parallel LLM bursts past the router's 10-concurrent cap (HTTP 429 -> permanent circuit open) and race `portfolio.json`. Always verify with `ps -ef | grep main.py` that exactly one loop runs.

---

## 🧠 Ultra-Context AI Engine & Autonomous Sub-Agent Evolution

The system features an autonomous reinforcement and meta-quant intelligence loop:
1. **Dual-Brain Operational Architecture**:
   - **Online Mode (AI Meta-Quant Active)**: The Clouvia LLM acts as the Chief Intelligence Officer. It analyzes recent trade outcomes (wins, losses, scratches, fees) and automatically upgrades dynamic weights, calibrated thresholds, and empirical rules in `agent_consciousness.json`.
   - **Offline / Circuit-Open Mode (100% Deterministic Mastery)**: If the LLM is down, erroring, or timed out, the 8 divisions and 24 sub-agents execute autonomously using their latest upgraded weights and learned thresholds.
2. **Continuous Self-Evolution ("Semakin Lama Semakin Cerdas")**:
   - Trade outcomes trigger immediate learning:
     * On Loss: Conducts Root Cause Analysis (RCA), appends an immutable preventive rule to `agent_consciousness.json`, tightens risk filters (+3% weight on Risk Division), and prevents repeating identical mistakes.
     * On Win: Rewards high-conviction divisions (+0.02 dynamic weight) and adjusts profit extraction ladders.
   - Even in 100% offline mode, the deterministic evolution engine autonomously adapts parameters from live market feedback.

---

## 👑 Corporate Quant Hierarchy: 8 Divisions & 24 Specialized Sub-Agents (32 AI Roles)

To guarantee institutional-grade precision, every division lead is supported by 3 dedicated employee sub-agents who conduct granular quantitative audits:

### Division 1: Market Flow & Narrative (🌐)
Lead: Head of Flow Strategy
- Sub-Agent 1.1: Volume Velocity Analyst (Audits 24h quote volume magnitude vs institutional threshold)
- Sub-Agent 1.2: Smart Money Tracker (Evaluates average trade size & whale block order footprint)
- Sub-Agent 1.3: Trend Corridor Sentinel (Ensures 24h price gains/drops remain inside safe corridor)

### Division 2: Technical Price Action (📈)
Lead: Head Quantitative Chartist
- Sub-Agent 2.1: EMA Trend Alignment Quant (Audits multi-timeframe 1h and 4h EMA 9/21/50 stack and slope)
- Sub-Agent 2.2: Candle Geometry Analyst (Measures close ratio near candle peak & wick rejection)
- Sub-Agent 2.3: Volume Surge Auditor (Validates 3-bar rolling volume surge >= 1.1x)

### Division 3: Momentum & Exhaustion (⚡)
Lead: Head Momentum Auditor
- Sub-Agent 3.1: RSI Velocity Auditor (Audits prime acceleration zone: 45-74 for Longs, 26-55 for Shorts)
- Sub-Agent 3.2: Overbought/Oversold Divergence Guard (Enforces absolute VETO to prevent buying tops or shorting bottoms)
- Sub-Agent 3.3: Mean Reversion Quant (Audits price distance from EMA21 to prevent rubber-band snap)

### Division 4: Order Book Microstructure (🔬)
Lead: Head Market Maker & Liquidity Quant
- Sub-Agent 4.1: Spread & Slippage Guard (Enforces strict spread <= 0.20% to eliminate friction)
- Sub-Agent 4.2: Depth Imbalance Quant (Measures top bid depth vs ask depth wall absorption)
- Sub-Agent 4.3: Order Book Wall Scanner (Detects heavy opposing walls that could cap progression)

### Division 5: Volatility & Market Regime (📡)
Lead: Head Volatility & Regime Analyst
- Sub-Agent 5.1: ATR Volatility Engineer (Measures ATR volatility expansion vs dead chop)
- Sub-Agent 5.2: Trade Velocity Scout (Audits 24h count of trades for active participation)
- Sub-Agent 5.3: Market Noise Filter (Detects low-participation spoofing and wash trading)

### Division 6: Quantitative Risk & Capital (🛡️) - VETO AUTHORITY
Lead: Chief Risk Officer (Holds Absolute Veto)
- Sub-Agent 6.1: Position Sizing Auditor (Enforces 2% max portfolio risk per trade, max 25% single-asset cap)
- Sub-Agent 6.2: Stop Loss Engineer (Calculates ATR 1.5x volatility stop price, 1.0% floor)
- Sub-Agent 6.3: Risk-to-Reward Calculator (Enforces minimum 1:2.0 R:R mathematical positive expectancy)

### Division 7: Profit Extraction & Tactical Exits (🎯)
Lead: Head Profit Extraction Strategist
- Sub-Agent 7.1: Take Profit Architect (Designs 2-stage harvest: TP1 at 50% partial out + break-even lock)
- Sub-Agent 7.2: Trailing Stop Specialist (Arms Dynamic ATR Trailing Stop: scales distance dynamically based on ATR volatility, e.g. 0.8% - 3.5%, trailing 1.8x - 4.5% triggers)
- Sub-Agent 7.3: Fee & Friction Auditor (Guarantees net profitability accounting for Binance round-trip fee)

### Division 8: Executive Investment Committee (👑)
Lead: Managing Director & Executive Judge
- Sub-Agent 8.1: Department Consensus Auditor (Tallies votes, detects any department veto)
- Sub-Agent 8.2: Conviction Weight Synthesizer (Aggregates division scores into firm-wide conviction >= 75%)
- Sub-Agent 8.3: Order Execution Commander (Formulates trade thesis and authorizes execution ticket)

---

## 💎 Senior Trader Quantitative Enhancements

1. **Dynamic ATR Trailing Stop**: Replaces static 1.2% trailing with volatility-scaled trailing distance ($1.0 \times \text{ATR}$ as percentage of price, bounded between 0.8% and 3.5%). Low-volatility majors get tighter trails to lock profit, while high-beta alts get breathing room.
2. **Anti-Short Squeeze Guard**: Protects against capitulation traps and short squeezes by inspecting funding rate crowding ($< -0.03\%$), selling climax exhaustion (RSI $< 27.0$ combined with $> 4.5\%$ stretch below EMA21), and buyer order book absorption walls ($> +30\%$).
3. **Alpha Relative Strength vs Bitcoin**: Compares 4-hour performance of candidates against Bitcoin's benchmark. Rejects LONGs that lag BTC by $> 1.5\%$ (negative alpha), and rejects SHORTs that resist Bitcoin dumps by $> 1.5\%$ (positive alpha).
4. **Multi-Timeframe (MTF) Fast Trigger**: Augments the 15m trend structure with 5m candlestick confirmation (`drop_forming_bar`) to filter out false wicks and sudden intraday rejection bars before execution.
5. **Configurable Outbound Proxy Gateway**: `BinanceClient` supports `BINANCE_PROXY_URL` or standard proxy environment variables for HTTP connectivity. Proxy configuration and optional funding-data requests do not implement or prove live Futures order routing.

---

## ⚡ Clouvia AI Configuration

The bot interfaces with **Clouvia AI Router** (`https://router.clouvia.id/v1`) via the OpenAI Python SDK.

### Environment Setup (`.env`):
```env
TRADING_MODE=paper
INITIAL_PAPER_BALANCE=1000.0

BINANCE_API_URL=https://data-api.binance.vision
BINANCE_API_KEY=[REDACTED]
BINANCE_API_SECRET=[REDACTED]

OPENAI_BASE_URL=https://router.clouvia.id/v1
OPENAI_API_KEY=[REDACTED]
OPENAI_MODEL=<model-yang-ada-di-.env>
CLOUVIA_MODEL=<model-yang-ada-di-.env>

MIN_VOLUME_USDT=2000000
```

---

## 🚀 Usage & Commands

### 1. Execute a Single Instant Diagnostic Scan:
```bash
python3 main.py --scan
```

### 2. Run the Autonomous Live Trading Engine:
```bash
python3 main.py
```
Or customize scan intervals and launch web surveillance simultaneously:
```bash
python3 main.py --run --interval 10 --web
```

### 3. Launch Web Surveillance Dashboard:
```bash
python3 -m uvicorn web_dashboard:app --host 0.0.0.0 --port 8080
```
Open `http://localhost:8080` in your browser.

---

## 🧪 Test Suite & Empirical Verification

Run the comprehensive unit test suite with an isolated state directory:
```bash
BOT_DATA_DIR="$(mktemp -d "$TMPDIR/binance-bot-tests.XXXXXX")" TRADING_MODE=paper python3 -m unittest discover -s tests -v
```
The Python suite currently contains 202 tests, including regression coverage for fee-aware TP1/break-even exits, gross/fee/realized parity after reload, house-money pyramiding, direction performance probation, live-close retry safety, scratch-loss guards, AI-upgrade clamping, corrupt-state preservation, learned-threshold enforcement, Momentum weight readback, trading-profile presets, directional macro gates, paper stop gap-fill pricing, current-run dashboard analytics, AI absolute override/fallback, external-research parsing/caching, AI self-evolution (machine-rule enforcement, dedupe, semantic rejection, AI-threshold persistence), dashboard unlimited-capacity rendering, and cash-reconciliation refresh. Browser view regressions use Node's built-in runner (7 tests, no npm dependencies):
```bash
node --test tests/test_dashboard_views.cjs
```
The 6 JavaScript tests cover both visible routes, HTML escaping, malformed rows and dates, reconnect behavior, expandable candidate persistence and unavailable telemetry. Fixtures do not send orders. Portfolio fixtures initialize a numeric price before entry to keep equity snapshots deterministic across second boundaries.

For strict unchanged-file hash verification, pause the autonomous runner first; otherwise legitimate background equity/consciousness writes can change hashes during an isolated test run. Never reset or overwrite the live portfolio to make a test pass. No package manifest or SQL database is present; application state is held in the JSON files under `BOT_DATA_DIR`.

## Autonomous Self-Evolution

The CLI registers `--autonomous-evolve` as `store_true` with a default of `True`, so the flag is currently redundant. There is no `--no-autonomous-evolve` option. The scheduler is intended to run an immediate cycle followed by six-hour intervals, but startup output must be checked because the scheduler can fail during initialization; do not assume an evolution cycle completed solely from the configured interval. Verify resulting counters in `/api/status` before relying on learned thresholds.
