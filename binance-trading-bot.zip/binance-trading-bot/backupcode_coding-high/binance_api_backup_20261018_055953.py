import time
import hmac
import hashlib
from urllib.parse import urlencode
from typing import Dict, List, Optional, Any
import requests

from config import BINANCE_API_URL, BINANCE_API_KEY, BINANCE_API_SECRET


class BinanceClient:
    def __init__(self, base_url: str = BINANCE_API_URL, api_key: str = BINANCE_API_KEY, api_secret: str = BINANCE_API_SECRET):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        if self.api_key:
            self.session.headers.update({"X-MBX-APIKEY": self.api_key})

    def _sign_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def get_24hr_tickers(self) -> List[Dict[str, Any]]:
        """Fetch 24hr ticker price change statistics for all pairs."""
        url = f"{self.base_url}/api/v3/ticker/24hr"
        resp = self.session.get(url, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def get_price(self, symbol: str) -> float:
        """Fetch latest price for a symbol."""
        url = f"{self.base_url}/api/v3/ticker/price"
        resp = self.session.get(url, params={"symbol": symbol}, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return float(data["price"])

    def get_klines(self, symbol: str, interval: str = "15m", limit: int = 100) -> List[Dict[str, Any]]:
        """
        Fetch OHLCV klines.
        Returns list of dicts: [open_time, open, high, low, close, volume, close_time, quote_volume, trades, ...]
        """
        url = f"{self.base_url}/api/v3/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        resp = self.session.get(url, params=params, timeout=10)
        resp.raise_for_status()
        raw_klines = resp.json()

        klines = []
        for k in raw_klines:
            klines.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": int(k[6]),
                "quote_volume": float(k[7]),
                "trades": int(k[8])
            })
        return klines

    def get_orderbook(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        """Fetch order book depth."""
        url = f"{self.base_url}/api/v3/depth"
        params = {"symbol": symbol, "limit": limit}
        resp = self.session.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        bids = [[float(p), float(q)] for p, q in data.get("bids", [])]
        asks = [[float(p), float(q)] for p, q in data.get("asks", [])]
        return {"bids": bids, "asks": asks}

    def get_account_info(self) -> Dict[str, Any]:
        """Fetch account balances (requires API key & secret)."""
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for private account endpoints.")
        url = f"{self.base_url}/api/v3/account"
        params = self._sign_params({})
        resp = self.session.get(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def place_order(self, symbol: str, side: str, order_type: str = "MARKET",
                    quantity: Optional[float] = None, quote_order_qty: Optional[float] = None) -> Dict[str, Any]:
        """Place live order (requires API key & secret)."""
        if not self.api_key or not self.api_secret:
            raise ValueError("API Key and Secret are required for trading.")
        url = f"{self.base_url}/api/v3/order"
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper()
        }
        if quantity is not None:
            params["quantity"] = f"{quantity:.6f}"
        elif quote_order_qty is not None:
            params["quoteOrderQty"] = f"{quote_order_qty:.2f}"
        else:
            raise ValueError("Either quantity or quote_order_qty must be provided.")

        params = self._sign_params(params)
        resp = self.session.post(url, params=params, timeout=10)
        resp.raise_for_status()
        return resp.json()
