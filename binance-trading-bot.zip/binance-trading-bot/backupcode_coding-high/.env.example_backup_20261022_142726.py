# ==============================================================================
# BINANCE QUANT MULTI-AGENT BOT - CONFIGURATION & CREDENTIALS
# ==============================================================================

# 1. Operational Mode:
# 'paper' = Simulated paper trading with REAL live Binance ticker/depth data ($1,000 USDT balance)
# 'live'  = Real execution on Binance Spot (requires valid API key & secret with Spot trading permission)
TRADING_MODE=paper

# 2. Binance API Credentials:
# Dapatkan di: Binance -> Profile -> API Management -> Create API Key
# Cukup centang 'Enable Reading' & 'Enable Spot & Margin Trading'. JANGAN centang 'Enable Withdrawals'!
BINANCE_API_KEY=[REDACTED_SECRET:ENV_VAR]
# - Clouvia Router (Indonesia): https://router.clouvia.id/v1 (Model: coding-high, claude-sonnet-5-thinking-agentic)
# - OpenAI Resmi: https://api.openai.com/v1 (Model: gpt-4o-mini, gpt-4o)
# - DeepSeek: https://api.deepseek.com/v1 (Model: deepseek-chat)
# - Ollama Local: http://localhost:11434/v1 (Model: llama3, mistral)
CLOUVIA_API_KEY=[REDACTED_SECRET:ENV_VAR]
OPENAI_API_KEY=
OPENAI_BASE_URL=https://router.clouvia.id/v1
OPENAI_MODEL=coding-high
LLM_TEMPERATURE=0.3

# 4. Capital & Risk Configuration (Optional Overrides):
INITIAL_PAPER_BALANCE=1000.0
MIN_VOLUME_USDT=3000000
MIN_CHANGE_PCT=0.5
MAX_CHANGE_PCT=55.0
ESTIMATED_FEE_PCT=0.10
BNB_FEE_DISCOUNT=false

TRADING_PROFILE=balanced
# MAX_OPEN_POSITIONS: jumlah slot posisi terbuka (1-20). Kosongkan agar bot menanyakannya sekali saat pertama dijalankan.
# TRADING_PROFILE: conservative | balanced | aggressive (preset ketatitas entry; env eksplisit selalu menang atas preset).
