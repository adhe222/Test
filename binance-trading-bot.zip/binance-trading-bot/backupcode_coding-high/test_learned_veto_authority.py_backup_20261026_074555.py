import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from orchestrator import TradingOrchestrator


class LearnedVetoAuthorityCase(unittest.TestCase):
    def _orchestrator(self):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.llm = MagicMock(status_summary={})
        orch.portfolio = MagicMock()
        orch.portfolio.get_open_positions.return_value = []
        orch.portfolio.get_equity.return_value = 1000.0
        orch.portfolio.state = {"cash_usdt": 500.0}
        orch.portfolio.update_and_monitor_positions.return_value = []
        orch.portfolio.get_periodic_performance.return_value = {"today": {"net_pnl_usdt": 0.0}}
        orch.portfolio.execute_trade.return_value = True
        orch.macro_sentinel = MagicMock()
        orch.macro_sentinel.evaluate_macro_health.return_value = {"safe_to_trade": True, "safe_for_shorts": True}
        orch.scanner = MagicMock()
        orch.scanner.scan_trending_pairs.return_value = [
            {"symbol": "NEWUSDT", "direction": "SHORT", "target_market": "FUTURES", "price": 10.0,
             "price_change_24h": -5.0, "quote_volume_24h": 9e7, "count_trades": 200000},
        ]
        orch.orderbook_data_agent = MagicMock()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "imbalance": 0.0, "spread_pct": 0.01,
            "best_bid": 9.99, "best_ask": 10.01,
        }
        orch.momentum_data_agent = MagicMock()
        orch.momentum_data_agent.analyze_symbol.return_value = {
            "passed": True, "score": 120, "price": 10.0, "atr": 0.1, "rsi": 40,
        }
        orch.risk_data_agent = MagicMock()
        orch.risk_data_agent.evaluate_risk.return_value = {"approved": True, "side": "SELL", "position_usdt": 100}
        for name in ("narrative_spec", "price_action_spec", "exhaustion_spec", "microstructure_spec",
                     "sentiment_spec", "cro_spec", "profit_spec"):
            spec = MagicMock(role_name=name, lead_title="", icon="", staff=[])
            spec.analyze.return_value = {"specialist": name, "verdict": "APPROVE", "conviction": 90, "rationale": ""}
            setattr(orch, name, spec)
        orch.executive_spec = MagicMock(role_name="exec", lead_title="", icon="")
        orch.executive_spec.synthesize.return_value = {"final_verdict": "APPROVE", "consensus_conviction": 90}
        return orch

    def _run(self, audit_result):
        orch = self._orchestrator()
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        self.enterContext(patch.object(config, "MAX_OPEN_POSITIONS", 6))
        self.enterContext(patch.object(config, "AI_DECISION_AUTHORITY", "absolute"))
        with patch("orchestrator.consciousness_engine") as ce:
            ce.audit_against_experience.return_value = audit_result
            ce.get_ultra_context_summary.return_value = {}
            result = orch.run_cycle()
        return orch, result

    def test_learned_veto_blocks_a_candidate_even_under_absolute_ai_authority(self):
        orch, result = self._run({
            "violation": True,
            "rule_id": "PA-VOL-LEARNED",
            "action": "PENALTY_OR_VETO",
            "reason": "Volume surge (1.17x < learned floor 2.00x).",
        })
        rec = result["candidates_evaluated"][0]
        self.assertFalse(rec["can_execute"], rec["execution_note"])
        self.assertIn("Learned Lesson Veto", rec["execution_note"])
        self.assertEqual(result["executed_trades"], [])
        orch.portfolio.execute_trade.assert_not_called()

    def test_clean_candidate_still_executes_under_absolute_ai_authority(self):
        orch, result = self._run(None)
        rec = result["candidates_evaluated"][0]
        self.assertTrue(rec["can_execute"], rec["execution_note"])
        self.assertEqual(len(result["executed_trades"]), 1)
        orch.portfolio.execute_trade.assert_called_once()


if __name__ == "__main__":
    unittest.main()
