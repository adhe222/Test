import json
import os
import time
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional

import config
from config import DATA_DIR

CONSCIOUSNESS_FILE = DATA_DIR / "agent_consciousness.json"


class AgentConsciousnessEngine:
    def __init__(self, file_path: Optional[Path] = None):
        self.file_path = file_path or CONSCIOUSNESS_FILE
        self.memory = self._load_memory()

    def _default_memory(self) -> Dict[str, Any]:
        return {
            "version": "2.2.0-ULTRA",
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "total_mistakes_analyzed": 0,
            "total_vetoes_prevented": 0,
            "total_upgrades_performed": 0,
            "ai_intelligence_level": "2.2.0-ULTRA",
            "last_upgrade_mode": "INITIALIZED",
            "divisions": {
                "Market Flow & Narrative Division": {
                    "icon": "🌐",
                    "consciousness_focus": "Detecting institutional whale volume and sustainable velocity corridors.",
                    "total_audits": 0,
                    "dynamic_weight": 1.0,
                    "calibrated_thresholds": {
                        "min_volume_usdt": 3000000.0,
                        "min_change_pct": 0.5,
                        "max_change_pct": 55.0
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "FLOW-001",
                            "rule": "Never approve an asset if 24h quote volume is less than $3M or if trading is purely retail-skewed.",
                            "origin": "Foundation Quant Rule: Prevents illiquid slippage traps.",
                            "times_applied": 0
                        }
                    ]
                },
                "Technical Price Action Division": {
                    "icon": "📈",
                    "consciousness_focus": "Validating multi-EMA trend structure and rejecting heavy upper wick traps.",
                    "total_audits": 0,
                    "dynamic_weight": 1.15,
                    "calibrated_thresholds": {
                        "max_upper_wick_ratio": 0.35,
                        "min_close_ratio": 0.50,
                        "min_volume_surge": 1.10
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "PA-001",
                            "rule": "Reject breakouts where upper wick rejection is > 35% of total candle height, even if price is above EMA9.",
                            "origin": "RCA from SOLUSDT stop-out: Upper wick indicated aggressive seller dumping at local resistance.",
                            "times_applied": 0
                        },
                        {
                            "rule_id": "PA-002",
                            "rule": "Require price to be above EMA21 on 15m; never attempt counter-trend bottom fishing.",
                            "origin": "Trend continuation mandate: Prevents catching falling knives.",
                            "times_applied": 0
                        }
                    ]
                },
                "Momentum Exhaustion Division": {
                    "icon": "⚡",
                    "consciousness_focus": "Protecting against buying blow-off tops and momentum exhaustion.",
                    "total_audits": 0,
                    "dynamic_weight": 1.10,
                    "calibrated_thresholds": {
                        "min_rsi": 45.0,
                        "max_rsi": 74.0,
                        "max_ema21_distance_pct": 5.0
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "EXH-001",
                            "rule": "Absolute Veto when 15m RSI exceeds 74.0, regardless of how bullish price action looks.",
                            "origin": "Overbought protection rule: Overextended RSI has high probability of mean reversion dip.",
                            "times_applied": 0
                        }
                    ]
                },
                "Order Book Microstructure Division": {
                    "icon": "🔬",
                    "consciousness_focus": "Guarding against bid/ask spread slippage and phantom order book sell walls.",
                    "total_audits": 0,
                    "dynamic_weight": 1.05,
                    "calibrated_thresholds": {
                        "max_spread_pct": 0.20,
                        "min_imbalance": 0.05
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "MICRO-001",
                            "rule": "Reject trades when spread exceeds 0.20% or when orderbook depth imbalance is below 0.05.",
                            "origin": "Microstructure slippage audit: High spread instantly erodes expected value.",
                            "times_applied": 0
                        }
                    ]
                },
                "Volatility & Market Regime Division": {
                    "icon": "📡",
                    "consciousness_focus": "Ensuring trade setups possess authentic ATR volatility expansion and healthy trend efficiency.",
                    "total_audits": 0,
                    "dynamic_weight": 1.0,
                    "calibrated_thresholds": {
                        "min_trend_efficiency": 0.12,
                        "min_atr_pct": 0.80
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "REG-001",
                            "rule": "Disallow entry if trend efficiency is below 0.12 or ATR volatility is flatlined (< 0.8%) to avoid capital stagnation.",
                            "origin": "Capital efficiency rule: Low efficiency chop ties up margin with negative carry.",
                            "times_applied": 0
                        }
                    ]
                },
                "Quantitative Risk & Capital Division": {
                    "icon": "🛡️",
                    "consciousness_focus": "Enforcing 2% equity risk ceiling and mandatory asymmetric 1:2.0+ R:R ratio.",
                    "total_audits": 0,
                    "dynamic_weight": 1.25,
                    "calibrated_thresholds": {
                        "max_risk_pct": 2.0,
                        "min_risk_reward": 2.0,
                        "stop_loss_atr_mult": 1.20
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "RISK-001",
                            "rule": "Never deploy more than 25% of equity per position; always enforce minimum 1:2.0 risk-reward ratio.",
                            "origin": "Capital survival rule: Consecutive losses must not create catastrophic drawdowns.",
                            "times_applied": 0
                        }
                    ]
                },
                "Profit Extraction & Tactical Exits Division": {
                    "icon": "🎯",
                    "consciousness_focus": "Harvesting 50% at TP1, activating proactive break-even, and trailing profits.",
                    "total_audits": 0,
                    "dynamic_weight": 1.10,
                    "calibrated_thresholds": {
                        "early_break_even_pct": 1.50,
                        "tp1_harvest_pct": 50.0,
                        "trailing_trigger_pct": 2.20,
                        "trailing_distance_pct": 1.20
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "EXIT-001",
                            "rule": "Immediately move Stop Loss to Break-Even (+0.2% fee cushion) once gain reaches +1.50%.",
                            "origin": "Zero-Loss Rule: A trade that reaches +1.50% must never turn into a negative trade.",
                            "times_applied": 0
                        }
                    ]
                },
                "Executive Investment Committee & Judge": {
                    "icon": "👑",
                    "consciousness_focus": "Synthesizing consensus across all divisions and enforcing unanimous non-veto.",
                    "total_audits": 0,
                    "dynamic_weight": 1.0,
                    "calibrated_thresholds": {
                        "min_conviction": 75,
                        "unanimous_required": True
                    },
                    "lessons_learned": [
                        {
                            "rule_id": "EXEC-001",
                            "rule": "Unanimous non-veto required: a single risk or microstructure veto halts execution.",
                            "origin": "Hedge fund governance mandate: Prevents aggressive divisions from overruling risk.",
                            "times_applied": 0
                        }
                    ]
                }
            }
        }

    def _load_memory(self) -> Dict[str, Any]:
        if self.file_path.exists():
            try:
                with open(self.file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    default_mem = self._default_memory()
                    for k in ["version", "total_mistakes_analyzed", "total_vetoes_prevented", "total_upgrades_performed", "ai_intelligence_level", "last_upgrade_mode"]:
                        if k not in data:
                            data[k] = default_mem[k]
                    for div_k, div_v in default_mem["divisions"].items():
                        if div_k not in data.get("divisions", {}):
                            data.setdefault("divisions", {})[div_k] = div_v
                        else:
                            for thresh_k, thresh_v in div_v["calibrated_thresholds"].items():
                                data["divisions"][div_k].setdefault("calibrated_thresholds", {})
                                if thresh_k not in data["divisions"][div_k]["calibrated_thresholds"]:
                                    data["divisions"][div_k]["calibrated_thresholds"][thresh_k] = thresh_v
                            if "dynamic_weight" not in data["divisions"][div_k]:
                                data["divisions"][div_k]["dynamic_weight"] = div_v["dynamic_weight"]
                    return data
            except Exception as e:
                corrupt_backup = self.file_path.with_name(
                    f"{self.file_path.name}.corrupt-{int(time.time())}"
                )
                try:
                    self.file_path.replace(corrupt_backup)
                except Exception:
                    corrupt_backup = None
                suffix = f" Corrupt state preserved at {corrupt_backup}." if corrupt_backup else ""
                print(
                    f"[Consciousness] Failed to load {self.file_path} ({type(e).__name__}: {e}); "
                    f"reinitializing foundation memory.{suffix}"
                )
        mem = self._default_memory()
        self._save_memory(mem)
        return mem

    def _save_memory(self, memory: Dict[str, Any]):
        memory["last_updated"] = datetime.now(timezone.utc).isoformat()
        temp_file = self.file_path.with_name(f"{self.file_path.name}.{os.getpid()}_{threading.get_ident()}_{time.time_ns()}.tmp")
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(memory, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            temp_file.replace(self.file_path)
        except Exception:
            if temp_file.exists():
                try:
                    temp_file.unlink()
                except Exception:
                    pass
            raise

    def get_threshold(self, division_name: str, key: str, default_val: Any) -> Any:
        div = self.memory.get("divisions", {}).get(division_name, {})
        return div.get("calibrated_thresholds", {}).get(key, default_val)

    def get_weight(self, division_name: str, default_val: float = 1.0) -> float:
        div = self.memory.get("divisions", {}).get(division_name, {})
        return float(div.get("dynamic_weight", default_val))

    def get_division_lessons(self, division_name: str) -> List[Dict[str, Any]]:
        div = self.memory.get("divisions", {}).get(division_name, {})
        return div.get("lessons_learned", [])

    def audit_against_experience(self, division_name: str, metrics: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        div_data = self.memory.get("divisions", {}).get(division_name)
        if not div_data:
            return None

        div_data["total_audits"] = div_data.get("total_audits", 0) + 1

        if division_name == "Technical Price Action Division":
            candle = metrics.get("candle", {})
            vol_surge = metrics.get("volume_surge")
            if vol_surge is not None:
                founder_floor = 1.10
                min_vol = self.get_threshold(division_name, "min_volume_surge", founder_floor)
                if abs(min_vol - founder_floor) > 1e-9 and float(vol_surge) < min_vol:
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": "PA-VOL-LEARNED",
                        "rule": f"Learned volume surge floor {min_vol:.2f}x after documented losses.",
                        "action": "PENALTY_OR_VETO",
                        "reason": f"[Learned Threshold Applied]: Volume surge ({float(vol_surge):.2f}x < learned floor {min_vol:.2f}x). Breakout momentum not confirmed."
                    }
            max_upper_wick = self.get_threshold(division_name, "max_upper_wick_ratio", 0.35)
            if candle.get("is_bullish") and candle.get("upper_wick_ratio", 0.0) > max_upper_wick:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "PA-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "PENALTY_OR_VETO",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: Upper wick ({candle.get('upper_wick_ratio', 0.0):.2f} > {max_upper_wick:.2f}) rejected. Avoiding fakeout loss."
                    }

        elif division_name == "Momentum Exhaustion Division":
            rsi = metrics.get("rsi", 50.0)
            max_rsi = self.get_threshold(division_name, "max_rsi", 74.0)
            if rsi > max_rsi:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "EXH-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "VETO",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: RSI ({rsi:.1f}) exceeds {max_rsi:.1f} limit. Preventing top-buying mistake."
                    }

        elif division_name == "Order Book Microstructure Division":
            spread = metrics.get("spread_pct", 0.0)
            max_spread = self.get_threshold(division_name, "max_spread_pct", 0.20)
            if spread > max_spread:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "MICRO-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "CAUTION",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: Spread ({spread:.3f}% > {max_spread:.2f}%) danger zone. Slippage drag warning."
                    }

        return None

    def record_trade_failure_and_learn(self, trade_event: Dict[str, Any]):
        symbol = trade_event.get("symbol", "UNKNOWN")
        reason = trade_event.get("reason", "")
        pnl = float(trade_event.get("pnl_usdt", 0.0))

        outcome = trade_event.get("outcome")
        if outcome == "SCRATCH":
            return
        if outcome and outcome != "LOSS":
            return
        if not outcome:
            pnl_pct = abs(float(trade_event.get("pnl_pct", 0.0) or 0.0))
            if not (pnl < 0 and pnl_pct > 0.05):
                return
        if pnl >= 0:
            return

        self.memory["total_mistakes_analyzed"] += 1
        pa_div = self.memory["divisions"].get("Technical Price Action Division", {})
        rule_num = len(pa_div.get("lessons_learned", [])) + 1
        new_rule_id = f"RCA-{symbol[:3]}-{rule_num:03d}"

        new_lesson = {
            "rule_id": new_rule_id,
            "rule": f"Strengthen entry validation on {symbol}: require deeper bid depth support and minimum 1h EMA21 confirmation before entering.",
            "origin": f"RCA from {symbol} {reason} (PnL: ${pnl:.4f}) on {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}",
            "times_applied": 0
        }

        if "lessons_learned" in pa_div:
            pa_div["lessons_learned"].append(new_lesson)

        self.evolve_heuristics_deterministically([trade_event])
        self._save_memory(self.memory)

    def record_trade_success_and_reward(self, trade_event: Dict[str, Any]):
        pnl = float(trade_event.get("pnl_usdt", 0.0))
        outcome = trade_event.get("outcome")
        if outcome == "SCRATCH":
            return
        if outcome and outcome != "WIN":
            return
        if not outcome:
            pnl_pct = abs(float(trade_event.get("pnl_pct", 0.0) or 0.0))
            if not (pnl > 0 and pnl_pct > 0.05):
                return
        if pnl <= 0:
            return
        for div_name in ["Technical Price Action Division", "Momentum Exhaustion Division", "Profit Extraction & Tactical Exits Division"]:
            div = self.memory["divisions"].get(div_name)
            if div:
                cur_w = div.get("dynamic_weight", 1.0)
                div["dynamic_weight"] = min(1.40, round(cur_w + 0.02, 3))
        self._save_memory(self.memory)

    def apply_ai_upgrade(self, upgrade_data: Dict[str, Any]):
        new_ver = upgrade_data.get("upgrade_version", "2.3.0-ULTRA")
        self.memory["ai_intelligence_level"] = new_ver
        self.memory["last_upgrade_mode"] = "AI_ULTRA_CONTEXT"
        self.memory["total_upgrades_performed"] = self.memory.get("total_upgrades_performed", 0) + 1

        THRESHOLD_BOUNDS = {
            "min_rsi": (20.0, 80.0), "max_rsi": (55.0, 80.0),
            "min_volume_surge": (0.5, 2.0), "max_upper_wick_ratio": (0.1, 0.6),
            "min_close_ratio": (0.2, 0.9), "max_spread_pct": (0.01, 1.0),
            "min_imbalance": (-0.9, 0.9), "min_trend_efficiency": (0.0, 0.5),
            "min_atr_pct": (0.0, 10.0), "min_volume_usdt": (500000.0, 100000000.0),
            "min_change_pct": (0.0, 10.0), "max_change_pct": (5.0, 100.0),
        }

        def _clamp(value, low, high):
            try:
                num = float(value)
            except (TypeError, ValueError):
                return None
            if num != num:
                return None
            return min(high, max(low, num))

        calibrated = upgrade_data.get("calibrated_thresholds", {})
        if isinstance(calibrated, dict):
            for div_name, thresholds in calibrated.items():
                if div_name in self.memory["divisions"] and isinstance(thresholds, dict):
                    self.memory["divisions"][div_name].setdefault("calibrated_thresholds", {})
                    for k, v in thresholds.items():
                        bounds = THRESHOLD_BOUNDS.get(k)
                        clamped = _clamp(v, *bounds) if bounds else None
                        if clamped is not None:
                            self.memory["divisions"][div_name]["calibrated_thresholds"][k] = clamped

        weights = upgrade_data.get("dynamic_weights", {})
        if isinstance(weights, dict):
            for div_name, w in weights.items():
                if div_name in self.memory["divisions"]:
                    clamped = _clamp(w, 0.5, 2.0)
                    if clamped is not None:
                        self.memory["divisions"][div_name]["dynamic_weight"] = round(clamped, 3)

        new_rules = upgrade_data.get("new_rules", [])
        for rule in new_rules:
            div_name = rule.get("division")
            if div_name in self.memory["divisions"]:
                existing_ids = {r.get("rule_id") for r in self.memory["divisions"][div_name].get("lessons_learned", [])}
                if rule.get("rule_id") not in existing_ids:
                    self.memory["divisions"][div_name].setdefault("lessons_learned", []).append({
                        "rule_id": rule.get("rule_id", f"AI-{div_name[:3]}-01"),
                        "rule": rule.get("rule", ""),
                        "origin": rule.get("origin", "Ultra-Context AI Meta-Optimization"),
                        "times_applied": 0
                    })

        self._save_memory(self.memory)

    def evolve_heuristics_deterministically(self, trade_events: List[Dict[str, Any]]):
        self.memory["total_upgrades_performed"] = self.memory.get("total_upgrades_performed", 0) + 1
        self.memory["last_upgrade_mode"] = "DETERMINISTIC_AUTONOMOUS"

        for tr in trade_events:
            pnl = float(tr.get("pnl_usdt", 0.0))
            if pnl < 0:
                risk_div = self.memory["divisions"].get("Quantitative Risk & Capital Division")
                if risk_div:
                    risk_div["dynamic_weight"] = min(1.50, round(risk_div.get("dynamic_weight", 1.25) + 0.03, 3))
                pa_div = self.memory["divisions"].get("Technical Price Action Division")
                if pa_div:
                    thresh = pa_div.setdefault("calibrated_thresholds", {})
                    thresh["min_volume_surge"] = min(1.30, round(thresh.get("min_volume_surge", 1.10) + 0.02, 3))
                exh_div = self.memory["divisions"].get("Momentum Exhaustion Division")
                if exh_div:
                    thresh = exh_div.setdefault("calibrated_thresholds", {})
                    thresh["max_rsi"] = max(70.0, round(thresh.get("max_rsi", 74.0) - 0.5, 1))
            elif pnl > 0:
                self.record_trade_success_and_reward(tr)

        self._save_memory(self.memory)

    def get_ultra_context_summary(self) -> Dict[str, Any]:
        return {
            "ai_intelligence_level": self.memory.get("ai_intelligence_level", "2.2.0-ULTRA"),
            "total_mistakes_analyzed": self.memory.get("total_mistakes_analyzed", 0),
            "total_vetoes_prevented": self.memory.get("total_vetoes_prevented", 0),
            "total_upgrades_performed": self.memory.get("total_upgrades_performed", 0),
            "last_upgrade_mode": self.memory.get("last_upgrade_mode", "UNKNOWN"),
            "divisions": {
                name: {
                    "weight": div.get("dynamic_weight", 1.0),
                    "thresholds": div.get("calibrated_thresholds", {}),
                    "learned_rules_count": len(div.get("lessons_learned", [])),
                    "audits": div.get("total_audits", 0)
                }
                for name, div in self.memory.get("divisions", {}).items()
            }
        }


consciousness_engine = AgentConsciousnessEngine()
