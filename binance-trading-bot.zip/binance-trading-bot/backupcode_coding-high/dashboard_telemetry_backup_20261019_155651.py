from urllib.parse import urlsplit

import config


def _rows(value):
    if isinstance(value, dict):
        value = value.get("items", [])
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def describe_market_record(record, direction_hint=None):
    result = dict(record)
    direction = str(record.get("direction", "")).upper()
    if direction not in ("LONG", "SHORT"):
        direction = {"BUY": "LONG", "SHORT": "SHORT"}.get(str(record.get("action", "")).upper(), "UNKNOWN")
    if direction == "UNKNOWN" and direction_hint in ("LONG", "SHORT"):
        direction = direction_hint
    market = str(record.get("market") or record.get("target_market") or "").upper()
    source = "RECORDED"
    if market not in ("SPOT", "FUTURES"):
        market = {"LONG": "SPOT", "SHORT": "FUTURES"}.get(direction, "UNKNOWN")
        source = "DIRECTION" if market != "UNKNOWN" else "UNKNOWN"
    result.update(display_direction=direction, display_market=market, market_source=source)
    return result


def build_market_operations(mode, ledger_mode, scan, positions, macro, loop, data_endpoint):
    mode = str(mode).upper()
    scan = scan if isinstance(scan, dict) else {}
    macro = macro if isinstance(macro, dict) else {}
    loop = loop if isinstance(loop, dict) else {}
    positions = [describe_market_record(row) for row in _rows(positions)]
    candidates = [describe_market_record(row) for row in _rows(scan.get("candidates_evaluated"))]
    executed = _rows(scan.get("executed_trades"))
    executed_symbols = {row.get("symbol") for row in executed if row.get("symbol")}
    daily_paused = scan.get("daily_loss_limit_hit") is True
    capacity_full = len(positions) >= config.MAX_OPEN_POSITIONS
    mode_known = mode in ("PAPER", "LIVE")
    routes = []
    for direction, market, enabled, macro_key in (
        ("LONG", "SPOT", config.ENABLE_SPOT_LONGS, "safe_to_trade"),
        ("SHORT", "FUTURES", config.ENABLE_FUTURES_SHORTS, "safe_for_shorts"),
    ):
        permission = macro.get(macro_key) if macro.get("regime") != "FALLBACK_NORMAL" else None
        own = [row for row in candidates if row["display_direction"] == direction]
        status, reason = "WAITING_SETUP", "Izin makro terbuka; menunggu setup, risk gate dan persetujuan eksekutif."
        if not enabled:
            status, reason = "DISABLED", "Jalur dinonaktifkan dalam konfigurasi bot."
        elif not mode_known:
            status, reason = "UNSUPPORTED", "Mode runtime tidak dikenali; status eksekusi belum dapat dikonfirmasi."
        elif mode == "LIVE" and market == "FUTURES":
            status, reason = "UNSUPPORTED", "Routing order Futures LIVE belum tersedia; kode order saat ini memakai endpoint Spot."
        elif daily_paused:
            status, reason = "DAILY_PAUSED", "Batas rugi harian tercapai; entry dihentikan, posisi tetap dipantau."
        elif capacity_full:
            status, reason = "CAPACITY_FULL", "Slot posisi penuh; pemantauan dan evaluasi kandidat tetap berjalan."
        elif permission is False:
            status, reason = "MACRO_PAUSED", "Macro Sentinel belum mengizinkan entry arah ini."
        elif permission is not True:
            status, reason = "WAITING_DATA", "Menunggu evaluasi makro yang valid."
        routes.append({
            "direction": direction,
            "market": market,
            "configured": bool(enabled),
            "execution": "SIMULATION" if mode == "PAPER" else ("SPOT_ORDER_PATH" if market == "SPOT" and mode == "LIVE" else "UNSUPPORTED"),
            "status": status,
            "reason": reason,
            "macro_permission": "ALLOWED" if permission is True else "PAUSED" if permission is False else "UNKNOWN",
            "entry_eligible": status == "WAITING_SETUP",
            "candidate_count": len(own),
            "quality_pass_count": sum(row.get("gates_passed") is True for row in own),
            "position_count": sum(row["display_direction"] == direction for row in positions),
            "executed_count": sum(str(row.get("direction", "")).upper() == direction for row in executed),
        })
    audit = []
    for row in candidates:
        blockers = row.get("hard_gate_failures")
        blockers = [str(reason) for reason in blockers] if isinstance(blockers, list) else []
        route = next((item for item in routes if item["direction"] == row["display_direction"]), None)
        if route and not route["entry_eligible"]:
            blockers.insert(0, route["reason"])
        note = row.get("execution_note")
        if note and note != "READY_TO_EXECUTE":
            blockers.append(str(note))
        verdict = row.get("executive_verdict")
        verdict = verdict if isinstance(verdict, dict) else {}
        final_verdict = verdict.get("final_verdict", "UNKNOWN")
        if row.get("symbol") in executed_symbols:
            status = "EXECUTED"
        elif row.get("gates_passed") is not True or blockers:
            status = "BLOCKED"
        else:
            status = "AWAITING_APPROVAL"
        audit.append({
            "symbol": row.get("symbol", "UNKNOWN"),
            "direction": row["display_direction"],
            "market": row["display_market"],
            "status": status,
            "technical_score": row.get("technical_score"),
            "gates_passed": row.get("gates_passed") is True,
            "executive_verdict": final_verdict,
            "blockers": list(dict.fromkeys(blockers)),
        })
    try:
        host = urlsplit(str(data_endpoint)).hostname or "UNKNOWN"
    except ValueError:
        host = "UNKNOWN"
    activity = "SCANNING" if loop.get("is_scanning") is True else "MONITORING" if positions else "WAITING_SETUP" if candidates else "WARMING_UP"
    return {
        "mode": mode if mode_known else "UNKNOWN",
        "ledger_mode": str(ledger_mode).upper(),
        "mode_mismatch": mode != str(ledger_mode).upper(),
        "exchange_orders_enabled": mode == "LIVE",
        "execution_notice": "Simulasi PAPER. Tidak ada order yang dikirim ke exchange." if mode == "PAPER" else "LIVE: jalur order Spot tersedia; konektivitas dan fill tidak dibuktikan oleh dashboard. Futures LIVE belum didukung." if mode == "LIVE" else "Mode runtime tidak dikenali. Eksekusi order belum dapat dikonfirmasi.",
        "futures_live_supported": False,
        "data_market": "SPOT",
        "data_host": host,
        "data_notice": "Harga, candle dan orderbook memakai data Spot Binance, termasuk untuk simulasi SHORT; bukan harga kontrak Futures.",
        "futures_notice": "SHORT disimulasikan tanpa leverage, margin atau likuidasi Futures. Funding tidak dibukukan ke P&L.",
        "configured_leverage": config.FUTURES_DEFAULT_LEVERAGE,
        "leverage_applied": False,
        "timeframes": [config.KLINES_TIMEFRAME, config.TREND_TIMEFRAME_1, config.TREND_TIMEFRAME_2, config.LTF_TIMEFRAME],
        "activity": activity,
        "snapshot_at": scan.get("completed_at"),
        "last_updated": scan.get("last_updated"),
        "evaluated_count": len(candidates),
        "executed_count": len(executed),
        "position_count": len(positions),
        "routes": routes,
        "candidates": audit,
    }
