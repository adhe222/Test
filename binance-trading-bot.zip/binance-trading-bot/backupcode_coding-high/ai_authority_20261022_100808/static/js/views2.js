/* Aegis Telemetry — Agents, quality gates and History renderers */
window.AegisViews2 = (() => {
  'use strict';
  const U = window.AegisUtil;

  function agents(d) {
    const minds = d.agent_consciousness || {};
    const scan = d.latest_scan || {};
    const cand = (scan.candidates_evaluated || [])[0];
    const reports = (cand && cand.specialist_reports) || [];
    const byName = new Map(reports.map((r) => [r.specialist, r]));

    U.setHTML('agents', Object.keys(minds).map((name) => {
      const a = minds[name] || {};
      const r = byName.get(name);
      const verdict = (r && r.verdict) || 'OBSERVING';
      const tone = /REJECT|VETO/.test(verdict) ? 'negative' : /APPROVE/.test(verdict) ? 'positive' : '';
      const conv = r && r.conviction != null ? ' · ' + U.safe(r.conviction) + '%' : '';
      return '<article class="card agent-card"><div class="agent-head">' +
        '<div class="agent-icon">' + U.esc(a.icon || '◈') + '</div><div>' +
        '<div class="agent-name">' + U.esc(name.replace(' Division', '')) + '</div>' +
        '<div class="agent-state ' + tone + '">' + U.esc(verdict) + conv + '</div></div></div>' +
        '<div class="agent-focus">' + U.esc((r && r.rationale) || a.consciousness_focus ||
          'Passive market surveillance') + '</div>' +
        '<div class="agent-audits">' + U.safe(a.total_audits) + ' audits · ' +
        ((a.lessons_learned || []).length) + ' retained rules</div></article>';
    }).join(''));

    const dirBadge = cand && cand.direction
      ? (' <span class="side-badge ' + cand.direction.toLowerCase() + '">' + cand.direction + '</span>')
      : '';
    U.setHTML('pipelineSymbol', cand
      ? U.esc(cand.symbol) + dirBadge + ' · ' + reports.length + ' division reports'
      : 'Menunggu kandidat');

    renderGates(cand, d);
  }

  function renderGates(cand, d) {
    if (!cand) {
      U.setHTML('gateBody', '<div class="card-note">Belum ada kandidat yang dievaluasi pada siklus ini.</div>');
      U.setText('gateSymbol', '—');
      return;
    }
    const dirBadge = cand.direction
      ? (' <span class="side-badge ' + cand.direction.toLowerCase() + '">' + cand.direction + '</span>')
      : '';
    U.setHTML('gateSymbol', U.esc(cand.symbol || '—') + dirBadge);
    const score = U.safe(cand.technical_score);
    const need = U.safe(cand.min_score_required);
    const passed = cand.gates_passed === true;
    const fails = cand.hard_gate_failures || [];

    let html = '<div class="gate-score"><b class="' + (score >= need ? 'positive' : 'negative') + '">' +
      U.num(score, 1) + '</b><span>technical score · minimum ' + U.num(need, 1) + ' required</span></div>';

    if (fails.length) {
      html += '<div class="gate-list">' + fails.map((f) =>
        '<div class="gate-fail"><i>✕</i><span>' + U.esc(f) + '</span></div>').join('') + '</div>';
    } else if (passed) {
      html += '<div class="gate-list"><div class="gate-pass">✓ Semua hard gate terlewati — menunggu mandat eksekutif.</div></div>';
    } else {
      html += '<div class="gate-list"><div class="gate-fail"><i>✕</i><span>' +
        U.esc(cand.execution_note || 'Setup belum memenuhi ambang kualitas.') + '</span></div></div>';
    }

    const gates = d.quality_gates || {};
    const chips = Object.keys(gates).map((k) =>
      '<span class="breakdown-chip">' + U.esc(U.title(k)) + ' <b>' + U.esc(String(gates[k])) + '</b></span>');
    if (chips.length) html += '<div class="breakdown">' + chips.join('') + '</div>';
    U.setHTML('gateBody', html);
  }

  function history(d) {
    U.setHTML('qualityStrip',
      '<div class="quality-cell"><span>Win rate</span><strong class="' +
        (U.safe(d.ledger_win_rate) >= U.safe(d.breakeven_win_rate) ? 'positive' : 'negative') + '">' +
        U.num(d.ledger_win_rate, 1) + '%</strong><small>breakeven ' + U.num(d.breakeven_win_rate, 1) + '%</small></div>' +
      '<div class="quality-cell"><span>Trade tertutup</span><strong>' + U.safe(d.ledger_closed_trades) + '</strong><small>' +
        U.safe(d.ledger_wins) + 'W · ' + U.safe(d.ledger_losses) + 'L · ' + U.safe(d.ledger_scratches) + 'S</small></div>' +
      '<div class="quality-cell"><span>Profit factor</span><strong class="' +
        (U.safe(d.profit_factor) >= 1 ? 'positive' : 'negative') + '">' + U.num(d.profit_factor, 2) + '</strong><small>gross win / gross loss</small></div>' +
      '<div class="quality-cell"><span>Net ledger</span><strong class="' + U.cls(d.ledger_net_pnl_usdt) + '">' +
        U.signed(d.ledger_net_pnl_usdt, 2) + '</strong><small>expectancy ' + U.signed(d.expectancy_usdt, 2) + '</small></div>');

    const breakdown = d.exit_reason_breakdown || {};
    const keys = Object.keys(breakdown).sort((a, b) => breakdown[b] - breakdown[a]);
    U.setHTML('exitBreakdown', keys.length
      ? keys.map((k) => '<span class="breakdown-chip">' + U.esc(U.title(k)) + ' <b>' +
          U.esc(String(breakdown[k])) + '</b></span>').join('')
      : '<span class="card-note">Belum ada data alasan exit.</span>');

    const rows = window.AegisOperations.rows(d.trade_history);
    U.setText('historyMeta', rows.length + ' event terbaru');
    const outcomeOf = (t) => {
      if (t.action !== 'CLOSED') return { label: 'PARSIAL', cls: 'partial' };
      const o = t.outcome || (Math.abs(U.safe(t.pnl_pct)) <= 0.05 ? 'SCRATCH' : U.safe(t.pnl_usdt) > 0 ? 'WIN' : 'LOSS');
      return { label: o, cls: o.toLowerCase() };
    };
    U.setHTML('tradeBody', rows.length ? rows.map((t) => {
      const direction = t.display_direction || t.direction || 'UNKNOWN';
      const known = direction === 'SHORT' || direction === 'LONG';
      const badge = ' <span class="side-badge ' + (known ? direction.toLowerCase() : 'unknown') + '">' + U.esc(known ? direction : 'N/A') + '</span>';
      const market = t.display_market || t.market || 'UNKNOWN';
      const marketLabel = market === 'UNKNOWN' ? 'Pasar tidak tercatat' : market + (t.market_source === 'DIRECTION' ? ' · dari arah' : '');
      const out = outcomeOf(t);
      return '<tr><td class="trade-symbol">' + U.esc(t.symbol) + badge + '<small class="trade-market-note">' + U.esc(marketLabel) + '</small></td>' +
        '<td>' + (t.action === 'CLOSED' ? 'Tutup' : 'TP1 parsial') + '</td>' +
        '<td class="num mono">' + (t.entry_price != null ? U.num(t.entry_price, 6) : '—') + '</td>' +
        '<td class="num mono">' + (t.exit_price != null ? U.num(t.exit_price, 6) : '—') + '</td>' +
        '<td class="num mono ' + U.cls(t.pnl_usdt) + '">' + U.signed(t.pnl_usdt, 2) + '</td>' +
        '<td class="num mono ' + U.cls(t.pnl_pct) + '">' + U.pct(t.pnl_pct) + '</td>' +
        '<td><span class="outcome-pill ' + out.cls + '">' + out.label + '</span></td>' +
        '<td class="reason" title="' + U.esc(t.reason) + '">' + U.esc(U.title(t.reason || t.action || '—')) + '</td>' +
        '<td class="mono nowrap">' + U.formatTime(t.exit_time) + '</td></tr>';
    }).join('')
      : '<tr><td colspan="9" class="empty-row">Belum ada transaksi tertutup.</td></tr>');
  }

  function footer(d) {
    const ai = d.ai_status || {};
    const health = ai.circuit_open || ai.last_error_kind ? 'fallback: ' + (ai.last_error_kind || 'circuit open') :
      String(ai.engine_mode || '').startsWith('AI_') ? 'last review verified' : 'not yet verified';
    U.setText('modelInfo', (ai.provider || 'AI engine') + ' · ' + (ai.model || 'deterministic fallback') + ' · ' + health +
      ' · ' + U.safe(d.total_mistakes_analyzed) + ' lessons · ' +
      U.safe(d.total_vetoes_prevented) + ' vetoes prevented');
  }

  return { agents, history, footer };
})();
