import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from agents.portfolio_manager import PortfolioManagerAgent
from ai_engine import LLMClient
from orchestrator import TradingOrchestrator


def _plan(direction="LONG"):
    short = direction == "SHORT"
    return {
        "symbol": "FIXUSDT",
        "direction": direction,
        "target_market": "FUTURES" if short else "SPOT",
        "side": "SELL" if short else "BUY",
        "position_usdt": 100.0,
        "quantity": 1.0,
        "entry_price": 100.0,
        "stop_loss_price": 103.0 if short else 97.0,
        "stop_loss_pct": 3.0,
        "take_profit_1": 97.0 if short else 103.0,
        "take_profit_2": 88.0 if short else 112.0,
        "trailing_trigger_pct": 3.0,
        "trailing_distance_pct": 1.0,
        "entry_atr_pct": 1.0,
        "atr": 1.0,
    }


class TestFeeAwareExits(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", self.tmp / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", self.tmp / "trades.json"))
        self.client = MagicMock()
        self.client.get_price.return_value = 100.0
        self.portfolio = PortfolioManagerAgent(self.client, mode="paper")
        self.portfolio.reset_portfolio(1000.0)

    def test_tp1_banks_half_and_locks_fee_aware_break_even(self):
        self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
        self.client.get_price.return_value = 103.0
        events = self.portfolio.update_and_monitor_positions()
        self.assertEqual(events[0]["action"], "PARTIAL_TP1_TAKEN")
        pos = self.portfolio.state["open_positions"][0]
        self.assertTrue(pos["tp1_hit"])
        self.assertTrue(pos["break_even_active"])
        self.assertGreater(pos["partial_pnl_realized"], 0.0)
        self.assertGreaterEqual(pos["stop_loss_price"], 100.0 * (1.0 + config.BREAK_EVEN_BUFFER_PCT / 100.0))
        self.assertGreaterEqual(pos["trailing_stop_price"], pos["stop_loss_price"])

    def test_break_even_exit_after_tp1_is_net_positive(self):
        self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
        self.client.get_price.return_value = 103.0
        self.portfolio.update_and_monitor_positions()
        self.client.get_price.return_value = 100.4
        events = self.portfolio.update_and_monitor_positions()
        closed = [e for e in events if e["action"] == "CLOSED"]
        self.assertEqual(len(closed), 1)
        self.assertGreater(closed[0]["pnl_usdt"], 0.0, closed[0])

    def test_duplicate_close_for_same_entry_is_not_logged_twice(self):
        self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
        self.client.get_price.return_value = 103.0
        self.portfolio.update_and_monitor_positions()
        self.client.get_price.return_value = 100.4
        self.portfolio.update_and_monitor_positions()
        before = len(self.portfolio.get_trade_history())
        closed = [e for e in self.portfolio.get_trade_history() if e["action"] == "CLOSED"][0]
        duplicate = dict(closed)
        duplicate["exit_time"] = "2026-10-22T00:00:00+00:00"
        self.portfolio._log_trade(duplicate)
        self.assertEqual(len(self.portfolio.get_trade_history()), before)

    def test_reload_recomputes_gross_and_fees_with_parity(self):
        self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
        self.client.get_price.return_value = 103.0
        self.portfolio.update_and_monitor_positions()
        self.client.get_price.return_value = 112.0
        self.portfolio.update_and_monitor_positions()
        reloaded = PortfolioManagerAgent(self.client, mode="paper")
        state = reloaded.state
        self.assertAlmostEqual(
            state["gross_realized_pnl_usdt"] - state["total_fees_paid_usdt"],
            state["realized_pnl_usdt"],
            places=3,
        )
        self.assertEqual(state["cash_reconciliation"]["status"], "OK")

    def test_reload_counts_open_partial_profit(self):
        self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
        self.client.get_price.return_value = 103.0
        self.portfolio.update_and_monitor_positions()
        reloaded = PortfolioManagerAgent(self.client, mode="paper")
        state = reloaded.state
        self.assertGreater(state.get("open_partial_pnl_usdt", 0.0), 0.0)
        self.assertGreater(state["realized_pnl_usdt"], 0.0)
        self.assertAlmostEqual(
            state["gross_realized_pnl_usdt"] - state["total_fees_paid_usdt"],
            state["realized_pnl_usdt"],
            places=3,
        )

    def test_periodic_performance_respects_run_boundary(self):
        now = datetime.now(timezone.utc)
        legacy_ts = (now - timedelta(hours=1)).isoformat()
        recent_ts = now.isoformat()
        events = [
            {"symbol": "OLDUSDT", "action": "CLOSED", "outcome": "LOSS", "pnl_usdt": -100.0,
             "pnl_pct": -10.0, "exit_time": legacy_ts, "fee_paid_usdt": 0.1, "gross_pnl_usdt": -99.9},
            {"symbol": "NEWUSDT", "action": "CLOSED", "outcome": "WIN", "pnl_usdt": 5.0,
             "pnl_pct": 1.0, "exit_time": recent_ts, "fee_paid_usdt": 0.1, "gross_pnl_usdt": 5.1},
        ]
        (self.tmp / "trades.json").write_text(json.dumps(events))
        self.portfolio.state["counter_since"] = (now - timedelta(minutes=30)).isoformat()
        today = self.portfolio.get_periodic_performance()["today"]
        self.assertEqual(today["trades"], 1)
        self.assertEqual(today["wins"], 1)
        self.assertAlmostEqual(today["net_pnl_usdt"], 5.0, places=2)

    def test_pyramid_add_is_house_money_and_fee_is_reconciled(self):
        with patch.object(config, "ENABLE_PYRAMIDING", True):
            self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
            self.client.get_price.return_value = 103.0
            self.portfolio.update_and_monitor_positions()
            self.client.get_price.return_value = 104.5
            self.portfolio.update_and_monitor_positions()
        pos = self.portfolio.state["open_positions"][0]
        self.assertEqual(pos.get("pyramids_added"), 1)
        events = self.portfolio.get_trade_history()
        adds = [e for e in events if e.get("action") == "PYRAMID_ADD"]
        self.assertEqual(len(adds), 1)
        self.assertGreater(adds[0].get("fee_paid_usdt", 0.0), 0.0)
        reloaded = PortfolioManagerAgent(self.client, mode="paper")
        state = reloaded.state
        self.assertAlmostEqual(
            state["gross_realized_pnl_usdt"] - state["total_fees_paid_usdt"],
            state["realized_pnl_usdt"],
            places=3,
        )

    def test_pyramid_does_not_add_when_tp2_is_already_reached(self):
        with patch.object(config, "ENABLE_PYRAMIDING", True):
            self.assertTrue(self.portfolio.execute_trade(_plan("LONG")))
            self.client.get_price.return_value = 103.0
            self.portfolio.update_and_monitor_positions()
            self.client.get_price.return_value = 112.0
            events = self.portfolio.update_and_monitor_positions()
        self.assertEqual([e for e in events if e.get("action") == "PYRAMID_ADD"], [])
        self.assertEqual(self.portfolio.state["open_positions"], [])


class TestLiveOrderFailureKeepsPosition(unittest.TestCase):
    def test_failed_live_close_is_retried_not_booked(self):
        tmp = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", tmp / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", tmp / "trades.json"))
        client = MagicMock()
        client.get_price.return_value = 100.0
        portfolio = PortfolioManagerAgent(client, mode="paper")
        portfolio.reset_portfolio(1000.0)
        self.assertTrue(portfolio.execute_trade(_plan("LONG")))
        portfolio.mode = "live"
        client.place_order.side_effect = RuntimeError("exchange down")
        client.get_price.return_value = 96.0
        events = portfolio.update_and_monitor_positions()
        self.assertEqual(events, [])
        self.assertEqual(len(portfolio.state["open_positions"]), 1)

    def test_failed_live_close_all_keeps_position(self):
        tmp = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", tmp / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", tmp / "trades.json"))
        client = MagicMock()
        client.get_price.return_value = 100.0
        portfolio = PortfolioManagerAgent(client, mode="paper")
        portfolio.reset_portfolio(1000.0)
        self.assertTrue(portfolio.execute_trade(_plan("LONG")))
        portfolio.mode = "live"
        client.place_order.side_effect = RuntimeError("exchange down")
        closed = portfolio.close_all_positions(reason="TEST")
        self.assertEqual(closed, [])
        self.assertEqual(len(portfolio.state["open_positions"]), 1)


class TestDirectionPerformanceGuard(unittest.TestCase):
    def _history(self, direction, outcome, pnl, count, hours_ago):
        ts = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
        return [
            {
                "symbol": f"T{i}USDT",
                "direction": direction,
                "action": "CLOSED",
                "outcome": outcome,
                "pnl_usdt": pnl,
                "pnl_pct": 1.0 if pnl > 0 else -1.0,
                "exit_time": ts,
            }
            for i in range(count)
        ]

    def _guard(self, history):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.portfolio = MagicMock()
        orch.portfolio.get_trade_history.return_value = history
        return orch._direction_performance_guard()

    def test_negative_direction_is_paused(self):
        history = self._history("LONG", "LOSS", -1.0, 20, 0.5) + self._history("SHORT", "WIN", 1.0, 20, 0.5)
        guard = self._guard(history)
        self.assertFalse(guard["LONG"]["allowed"])
        self.assertTrue(guard["SHORT"]["allowed"])
        self.assertIn("WR", guard["LONG"]["reason"])

    def test_paused_direction_gets_probation_probe(self):
        history = self._history("LONG", "LOSS", -1.0, 20, config.DIRECTION_GUARD_PROBATION_HOURS + 1.0)
        guard = self._guard(history)
        self.assertTrue(guard["LONG"]["allowed"])
        self.assertTrue(guard["LONG"]["probe"])
        self.assertEqual(guard["LONG"]["risk_scale"], config.DIRECTION_GUARD_PROBE_RISK_MULT)


class TestAdverseDrift(unittest.TestCase):
    def test_favorable_long_gap_is_not_adverse(self):
        self.assertLess(TradingOrchestrator._adverse_drift_pct(99.0, 100.0, "LONG"), 0.0)
        self.assertGreater(TradingOrchestrator._adverse_drift_pct(101.0, 100.0, "LONG"), 0.0)

    def test_favorable_short_gap_is_not_adverse(self):
        self.assertLess(TradingOrchestrator._adverse_drift_pct(101.0, 100.0, "SHORT"), 0.0)
        self.assertGreater(TradingOrchestrator._adverse_drift_pct(99.0, 100.0, "SHORT"), 0.0)


class TestExecutionRequote(unittest.TestCase):
    def _orch(self):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.orderbook_data_agent = MagicMock()
        orch.risk_data_agent = MagicMock()
        return orch

    def _args(self, **overrides):
        values = {
            "symbol": "FIXUSDT",
            "direction": "LONG",
            "signal_price": 100.0,
            "signal_generated_at": datetime.now(timezone.utc).isoformat(),
            "atr": 1.0,
            "total_equity": 1000.0,
            "open_positions": [],
            "target_market": "SPOT",
            "risk_scale": 1.0,
            "entry_metrics": {"rsi": 60.0},
        }
        values.update(overrides)
        return values

    def test_adverse_fresh_quote_blocks_execution(self):
        orch = self._orch()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "best_ask": 103.0, "best_bid": 102.9,
        }
        plan, error = orch._refresh_execution_plan(**self._args())
        self.assertIsNone(plan)
        self.assertIn("drifted adversely", error)
        orch.risk_data_agent.evaluate_risk.assert_not_called()
        orch.orderbook_data_agent.inspect_orderbook.assert_called_once_with(
            "FIXUSDT", direction="LONG", use_cache=False
        )

    def test_fresh_quote_recomputes_risk_plan(self):
        orch = self._orch()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "best_ask": 100.2, "best_bid": 100.1,
        }
        orch.risk_data_agent.evaluate_risk.return_value = {
            "approved": True, "entry_price": 100.2, "stop_loss_price": 98.2,
        }
        plan, error = orch._refresh_execution_plan(**self._args())
        self.assertIsNone(error)
        self.assertEqual(plan["entry_price"], 100.2)
        self.assertEqual(plan["price_source"], "FRESH_ORDERBOOK_BEST_ASK")
        self.assertAlmostEqual(plan["signal_drift_pct"], 0.2, places=3)
        self.assertEqual(plan["entry_metrics"], {"rsi": 60.0})
        self.assertEqual(
            orch.risk_data_agent.evaluate_risk.call_args.kwargs["current_price"], 100.2
        )

    def test_stale_signal_age_blocks_before_requote(self):
        orch = self._orch()
        stale = (datetime.now(timezone.utc) - timedelta(seconds=300)).isoformat()
        plan, error = orch._refresh_execution_plan(**self._args(signal_generated_at=stale))
        self.assertIsNone(plan)
        self.assertIn("age", error)
        orch.orderbook_data_agent.inspect_orderbook.assert_not_called()


class TestLlmConfiguration(unittest.TestCase):
    def test_empty_model_env_falls_back_to_a_real_model(self):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="")
        summary = client.status_summary
        self.assertTrue(summary["model"])
        self.assertTrue(summary["configured"])
        self.assertEqual(summary["base_url"], "http://127.0.0.1:9/v1")

    def test_config_base_url_and_model_are_not_blank(self):
        self.assertTrue(config.OPENAI_MODEL)
        self.assertTrue(config.OPENAI_BASE_URL.startswith("http"))

    def test_provider_failure_is_marked_as_fallback(self):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="test-model")
        client.client = MagicMock()
        error = RuntimeError("bad gateway")
        error.status_code = 502
        client.client.chat.completions.create.side_effect = error
        result = client.query_specialist(
            "Probe", "Return JSON only.", {"symbol": "BTCUSDT"},
            lambda data: {"verdict": "REJECT", "conviction": 0, "rationale": "fallback", "signal": "PROBE"},
        )
        self.assertEqual(result["engine_mode"], "DETERMINISTIC_FALLBACK")
        self.assertTrue(result["is_fallback"])
        self.assertEqual(result["fallback_reason"], "HTTP_502")
        status = client.status_summary
        self.assertEqual(status["engine_mode"], "DETERMINISTIC_FALLBACK")
        self.assertEqual(status["last_error_kind"], "HTTP_502")
        self.assertTrue(status["circuit_open"])
        self.assertGreater(status["retry_after_sec"], 0)


if __name__ == "__main__":
    unittest.main()
