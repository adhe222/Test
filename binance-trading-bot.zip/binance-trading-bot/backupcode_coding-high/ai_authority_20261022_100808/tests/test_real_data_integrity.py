"""Real-data integrity: no synthetic values may drive decisions or telemetry.

Each test asserts a behaviour observed broken on live Binance data on
2026-10-19 (stale 15m entry price, fabricated indicator/macro/depth defaults).
Network clients are stubbed only because tests must not hit the exchange;
the code under test is the real production code.
"""
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from indicators import calculate_ema_and_metrics


class TestIndicatorsNeverFabricate(unittest.TestCase):
    def test_insufficient_history_returns_invalid_not_synthetic(self):
        bars = [{"open": 1.0, "high": 1.1, "low": 0.9, "close": 1.0, "volume": 1.0} for _ in range(10)]
        m = calculate_ema_and_metrics(bars)
        self.assertFalse(m.get("valid", True))
        self.assertIsNone(m["ema21"])
        self.assertIsNone(m["atr"])
        self.assertIsNone(m["rsi"])

    def test_empty_history_has_no_dummy_price(self):
        m = calculate_ema_and_metrics([])
        self.assertFalse(m.get("valid", True))
        self.assertIsNone(m["ema9"])

    def test_zero_range_bars_do_not_invent_atr(self):
        bars = [{"open": 5.0, "high": 5.0, "low": 5.0, "close": 5.0, "volume": 1.0} for _ in range(60)]
        m = calculate_ema_and_metrics(bars)
        self.assertIsNone(m["atr"], "flat feed must not yield a fabricated 2% ATR")


class TestMacroFailClosed(unittest.TestCase):
    def test_api_error_pauses_entries_instead_of_assuming_safe(self):
        from agents.macro_sentinel import MacroMarketSentinel
        client = MagicMock()
        client.get_klines.side_effect = OSError("network down")
        status = MacroMarketSentinel(client).evaluate_macro_health()
        self.assertFalse(status["safe_to_trade"])
        self.assertFalse(status["safe_for_shorts"])
        self.assertEqual(status["regime"], "DATA_UNAVAILABLE")
        self.assertIsNone(status["rsi"])
        self.assertIsNone(status["price"])

    def test_insufficient_btc_history_pauses_entries(self):
        from agents.macro_sentinel import MacroMarketSentinel
        client = MagicMock()
        client.get_klines.return_value = [{"open": 1, "high": 1, "low": 1, "close": 1, "volume": 1}] * 10
        status = MacroMarketSentinel(client).evaluate_macro_health()
        self.assertFalse(status["safe_to_trade"])
        self.assertFalse(status["safe_for_shorts"])
        self.assertEqual(status["regime"], "DATA_UNAVAILABLE")


class TestOrderbookDepthNotInvented(unittest.TestCase):
    def test_missing_depth_rejects(self):
        from agents.specialists import ResistanceWallStaff
        staff = ResistanceWallStaff(MagicMock())
        res = staff.evaluate({"orderbook_data": {"direction": "LONG"}})
        self.assertEqual(res["verdict"], "REJECT")


class TestEntryUsesExecutablePrice(unittest.TestCase):
    """Live 2026-10-19: entries booked at the last CLOSED 15m close. SUIUSDC was
    booked at 1.0116 while the real market was 1.0081, shrinking the effective
    stop from 0.80% to ~0.45%; five LONGs stopped out within minutes."""

    def _orch(self, direction, close_price, bid, ask):
        from orchestrator import TradingOrchestrator
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.llm = MagicMock(status_summary={})
        orch.portfolio = MagicMock()
        orch.portfolio.get_open_positions.return_value = []
        orch.portfolio.get_equity.return_value = 1000.0
        orch.portfolio.state = {"cash_usdt": 1000.0}
        orch.portfolio.update_and_monitor_positions.return_value = []
        orch.portfolio.get_periodic_performance.return_value = {"today": {"net_pnl_usdt": 0.0}}
        orch.portfolio.execute_trade.return_value = True
        orch.macro_sentinel = MagicMock()
        orch.macro_sentinel.evaluate_macro_health.return_value = {"safe_to_trade": True, "safe_for_shorts": True}
        orch.scanner = MagicMock()
        orch.scanner.scan_trending_pairs.return_value = [{
            "symbol": "REALUSDT", "direction": direction, "target_market": "SPOT" if direction == "LONG" else "FUTURES",
            "price": close_price, "price_change_24h": 3.0, "quote_volume_24h": 9e7, "count_trades": 300000}]
        orch.orderbook_data_agent = MagicMock()
        orch.orderbook_data_agent.inspect_orderbook.return_value = {
            "passed": True, "imbalance": 0.0, "spread_pct": 0.01, "best_bid": bid, "best_ask": ask}
        orch.momentum_data_agent = MagicMock()
        orch.momentum_data_agent.analyze_symbol.return_value = {
            "passed": True, "score": 150, "price": close_price, "live_price": ask, "atr": close_price * 0.01, "rsi": 60}
        from agents.risk_manager import RiskManagementAgent
        orch.risk_data_agent = RiskManagementAgent()
        for name in ("narrative_spec", "price_action_spec", "exhaustion_spec", "microstructure_spec",
                     "sentiment_spec", "cro_spec", "profit_spec"):
            spec = MagicMock(role_name=name, lead_title="", icon="", staff=[])
            spec.analyze.return_value = {"specialist": name, "verdict": "APPROVE", "conviction": 90, "rationale": ""}
            setattr(orch, name, spec)
        orch.executive_spec = MagicMock(role_name="exec", lead_title="", icon="")
        orch.executive_spec.synthesize.return_value = {"final_verdict": "APPROVE", "consensus_conviction": 90}
        return orch

    def _run(self, orch):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        with patch("orchestrator.consciousness_engine") as ce:
            ce.audit_against_experience.return_value = None
            ce.get_ultra_context_summary.return_value = {}
            return orch.run_cycle()

    def test_long_plan_priced_at_best_ask_not_stale_close(self):
        orch = self._orch("LONG", close_price=1.0116, bid=1.0080, ask=1.0081)
        result = self._run(orch)
        plan = result["candidates_evaluated"][0]["risk_plan"]
        self.assertAlmostEqual(plan["entry_price"], 1.0081, places=6)
        self.assertLess(plan["stop_loss_price"], 1.0081)
        self.assertEqual(plan.get("price_source"), "FRESH_ORDERBOOK_BEST_ASK")

    def test_short_plan_priced_at_best_bid(self):
        orch = self._orch("SHORT", close_price=0.05820, bid=0.05810, ask=0.05812)
        result = self._run(orch)
        plan = result["candidates_evaluated"][0]["risk_plan"]
        self.assertAlmostEqual(plan["entry_price"], 0.05810, places=6)
        self.assertGreater(plan["stop_loss_price"], 0.05810)
        self.assertEqual(plan.get("price_source"), "FRESH_ORDERBOOK_BEST_BID")

    def test_signal_too_far_from_live_market_is_rejected(self):
        # live ask 3% above the analysed close = chasing a move the signal never saw
        orch = self._orch("LONG", close_price=1.0, bid=1.0299, ask=1.03)
        result = self._run(orch)
        rec = result["candidates_evaluated"][0]
        self.assertFalse(rec["gates_passed"])
        self.assertTrue(any("Stale signal" in f for f in rec["hard_gate_failures"]))
        orch.portfolio.execute_trade.assert_not_called()

    def test_no_live_quote_means_no_trade(self):
        orch = self._orch("LONG", close_price=1.0, bid=None, ask=None)
        orch.momentum_data_agent.analyze_symbol.return_value["live_price"] = None
        result = self._run(orch)
        rec = result["candidates_evaluated"][0]
        self.assertFalse(rec["gates_passed"])
        self.assertTrue(any("live price unavailable" in f.lower() for f in rec["hard_gate_failures"]))


class TestEquityNeverUsesCostAsMarketValue(unittest.TestCase):
    def test_price_failure_is_flagged_not_hidden(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", directory / "p.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "t.json"))
        client = MagicMock(); client.get_price.return_value = 100.0
        pm = PortfolioManagerAgent(client, mode="paper"); pm.reset_portfolio(1000.0)
        pm.execute_trade({"symbol": "REALUSDT", "direction": "LONG", "side": "BUY", "position_usdt": 100.0,
                          "quantity": 1.0, "entry_price": 100.0, "stop_loss_price": 99.0, "stop_loss_pct": 1.0,
                          "take_profit_1": 110.0, "take_profit_2": 120.0,
                          "trailing_trigger_pct": 2.0, "trailing_distance_pct": 1.0})
        client.get_price.side_effect = OSError("feed down")
        pm.get_equity()
        self.assertEqual(pm.last_equity_stale_symbols, ["REALUSDT"])


if __name__ == "__main__":
    unittest.main()


class TestKlinesCacheFreshness(unittest.TestCase):
    def test_cache_never_outlives_a_forming_bar(self):
        from binance_api import BinanceClient
        client = BinanceClient(base_url="https://example.invalid", api_key="", api_secret="")
        now_ms = int(time.time() * 1000)
        close_time = now_ms + 30_000
        raw = [[now_ms - 900_000, "1", "1.1", "0.9", "1", "5", close_time, "5", 10, "0", "0", "0"]]
        response = MagicMock()
        response.json.return_value = raw
        client._request_with_fallback = MagicMock(return_value=response)
        client.get_klines("FIXUSDT", interval="15m", limit=100)
        expiry, _ = client._cache["klines:FIXUSDT:15m:100"]
        self.assertLessEqual(expiry, time.time() + 31.0)
