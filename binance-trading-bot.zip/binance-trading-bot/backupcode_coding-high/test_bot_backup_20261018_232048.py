import unittest
from unittest.mock import MagicMock

from indicators import (
    calculate_ema,
    calculate_rsi,
    calculate_atr,
    calculate_volume_surge,
    calculate_candle_metrics
)
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent
from agents.macro_sentinel import MacroMarketSentinel
from agents.momentum import MomentumAnalystAgent
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)


class TestIndicators(unittest.TestCase):
    def test_ema(self):
        prices = [10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0]
        ema = calculate_ema(prices, 5)
        self.assertGreater(len(ema), 0)
        self.assertAlmostEqual(ema[0], 12.0)

    def test_rsi(self):
        prices = [10.0 + i for i in range(25)]
        rsi = calculate_rsi(prices, 14)
        self.assertIsNotNone(rsi)
        self.assertGreater(rsi, 90.0)

    def test_atr(self):
        klines = [
            {"high": 105.0, "low": 95.0, "close": 100.0} for _ in range(20)
        ]
        atr = calculate_atr(klines, 14)
        self.assertIsNotNone(atr)
        self.assertAlmostEqual(atr, 10.0, places=1)

    def test_candle_metrics(self):
        kline = {"open": 100.0, "high": 110.0, "low": 98.0, "close": 109.0}
        metrics = calculate_candle_metrics(kline)
        self.assertTrue(metrics["is_bullish"])
        self.assertGreater(metrics["close_ratio"], 0.8)


class TestAgents(unittest.TestCase):
    def test_scanner_symbol_filtering(self):
        mock_client = MagicMock()
        scanner = ScannerAgent(mock_client)
        self.assertTrue(scanner.is_valid_symbol("BTCUSDT"))
        self.assertTrue(scanner.is_valid_symbol("SOLUSDT"))
        self.assertTrue(scanner.is_valid_symbol("BTCFDUSD"))
        self.assertTrue(scanner.is_valid_symbol("ETHUSDC"))
        self.assertFalse(scanner.is_valid_symbol("BTCTRY"))
        self.assertFalse(scanner.is_valid_symbol("USDCUSDT"))
        self.assertFalse(scanner.is_valid_symbol("BTCUPUSDT"))

    def test_orderbook_veto_on_wide_spread(self):
        mock_client = MagicMock()
        mock_client.get_orderbook.return_value = {
            "bids": [[100.0, 10.0]],
            "asks": [[101.0, 10.0]]
        }
        ob_agent = OrderbookAgent(mock_client)
        res = ob_agent.inspect_orderbook("TESTUSDT")
        self.assertFalse(res["passed"])
        self.assertIn("Wide spread", res["reason"])

    def test_risk_management_sizing_and_targets(self):
        import config
        risk_agent = RiskManagementAgent()
        total_equity = 1000.0
        current_price = 100.0
        atr = 1.0

        res = risk_agent.evaluate_risk(
            symbol="ETHUSDT",
            current_price=current_price,
            atr=atr,
            total_equity=total_equity,
            open_positions=[]
        )
        self.assertTrue(res["approved"], res.get("reason"))
        self.assertEqual(res["stop_loss_pct"], round(config.ADAPTIVE_ATR_MULTIPLIER * atr, 2))
        # Reported R:R is NET of round-trip fees, so it must clear the configured floor
        self.assertGreaterEqual(res["risk_reward_ratio"], config.MIN_RISK_REWARD_RATIO)
        # ...and stay below the gross multiple, proving fees are actually deducted
        self.assertLess(res["risk_reward_ratio"], config.TP2_R_MULTIPLE)
        self.assertLessEqual(res["position_usdt"], 250.0)

        # TP targets must follow the configured R multiples
        sl_dist = current_price - res["stop_loss_price"]
        self.assertAlmostEqual(
            res["take_profit_1"], current_price + config.TP1_R_MULTIPLE * sl_dist, places=4
        )
        self.assertAlmostEqual(
            res["take_profit_2"], current_price + config.TP2_R_MULTIPLE * sl_dist, places=4
        )

    def test_risk_management_veto_on_capacity(self):
        risk_agent = RiskManagementAgent()
        open_pos = [{"symbol": "A"}, {"symbol": "B"}, {"symbol": "C"}]
        res = risk_agent.evaluate_risk("D", 100.0, 1.0, 1000.0, open_pos)
        self.assertFalse(res["approved"])
        self.assertIn("Maximum open positions limit", res["reason"])

    def test_portfolio_execution_and_stop_loss(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio.json"
            temp_log_file = Path(tmp_dir) / "test_trades.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "SOLUSDT",
                    "entry_price": 100.0,
                    "quantity": 1.0,
                    "position_usdt": 100.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0,
                    "take_profit_2": 105.0,
                    "trailing_trigger_pct": 2.5,
                    "trailing_distance_pct": 1.2
                }

                bought = portfolio.execute_buy(plan)
                self.assertTrue(bought)
                self.assertEqual(len(portfolio.get_open_positions()), 1)

                mock_client.get_price.return_value = 97.0
                with unittest.mock.patch("agents.consciousness.consciousness_engine.record_trade_failure_and_learn") as mock_learn:
                    actions = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions), 1)
                self.assertEqual(actions[0]["reason"], "STOP_LOSS_HIT")
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                self.assertLess(portfolio.state["cash_usdt"], 1000.0)
                self.assertGreater(portfolio.state["total_fees_paid_usdt"], 0.0)
                self.assertIn("fee_paid_usdt", actions[0])
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log

    def test_partial_tp1_and_break_even_lock(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio_tp1.json"
            temp_log_file = Path(tmp_dir) / "test_trades_tp1.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "SOLUSDT",
                    "entry_price": 100.0,
                    "quantity": 2.0,
                    "position_usdt": 200.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 102.0,
                    "take_profit_2": 106.0,
                    "trailing_trigger_pct": 5.0,
                    "trailing_distance_pct": 1.2
                }

                bought = portfolio.execute_buy(plan)
                self.assertTrue(bought)

                # Price hits TP1 (102.2) without activating trailing stop (> 5.0%)
                mock_client.get_price.return_value = 102.2
                actions = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions), 1)
                self.assertEqual(actions[0]["action"], "PARTIAL_TP1_TAKEN")
                
                pos = portfolio.get_open_positions()[0]
                self.assertTrue(pos["tp1_hit"])
                self.assertTrue(pos["break_even_active"])
                expected_remaining = 2.0 * (1 - config.FASTER_TP1_RATIO)
                self.assertAlmostEqual(pos["quantity"], expected_remaining, places=6)
                self.assertGreaterEqual(
                    pos["stop_loss_price"], 100.0 * (1 + config.BREAK_EVEN_BUFFER_PCT / 100.0) - 1e-6
                )

                # Price now dumps back to 100.1 (hitting Break-Even SL)
                mock_client.get_price.return_value = 100.1
                actions_exit = portfolio.update_and_monitor_positions()
                self.assertEqual(len(actions_exit), 1)
                self.assertEqual(actions_exit[0]["reason"], "TRAILING_STOP_EXIT")
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                # Overall portfolio should be NET POSITIVE because 50% was closed at +2.2%!
                self.assertGreater(portfolio.state["cash_usdt"], 1000.0)
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log

    def test_momentum_hard_gates_use_real_htf_confirmation(self):
        """Regression: HTF used to silently fail due to missing imports and except/pass."""
        from unittest.mock import patch
        from agents.momentum import MomentumAnalystAgent

        mock_client = MagicMock()
        # Trending data: a choppy flat series would (correctly) be rejected by the
        # regime filter, so the mock must represent a real directional move.
        bullish_klines = [
            {"open": 100.0 + i * 0.5, "high": 101.0 + i * 0.5, "low": 99.5 + i * 0.5,
             "close": 100.8 + i * 0.5, "volume": 150.0, "quote_volume": 1000.0, "trades": 100}
            for i in range(100)
        ]
        htf_1h = [
            {"close": 100.0 + i, "open": 99.0 + i, "high": 101.0 + i, "low": 98.0 + i, "volume": 100.0}
            for i in range(60)
        ]
        htf_4h = [
            {"close": 100.0 + i, "open": 99.0 + i, "high": 101.0 + i, "low": 98.0 + i, "volume": 100.0}
            for i in range(40)
        ]
        mock_client.get_klines.side_effect = [bullish_klines, htf_1h, htf_4h]

        last_close = bullish_klines[-1]["close"]
        metrics = {
            "ema9": last_close - 0.5, "ema21": last_close - 1.5, "ema50": last_close - 3.0,
            "rsi": 60.0, "atr": 1.0, "score": 85,
        }
        with patch("agents.momentum.calculate_ema_and_metrics", return_value=metrics), \
             patch("agents.momentum.calculate_volume_surge", return_value=1.5), \
             patch("agents.momentum.calculate_candle_metrics", return_value={"is_bullish": True, "close_ratio": 0.8, "body_pct": 60}), \
             patch("agents.momentum.calculate_rsi", return_value=60.0), \
             patch("agents.momentum.calculate_ema",
                   side_effect=lambda prices, period: [prices[-1] * (0.97 if period == 21 else 0.94)]):
            result = MomentumAnalystAgent(mock_client).analyze_symbol("TESTUSDT")

        self.assertTrue(result["passed"], result.get("gate_failures"))
        self.assertTrue(result["htf_available"])
        self.assertGreaterEqual(result["htf_score"], 8)
        self.assertEqual(result["gate_failures"], [])

    def test_momentum_rejects_when_htf_unavailable(self):
        from unittest.mock import patch
        from agents.momentum import MomentumAnalystAgent

        mock_client = MagicMock()
        primary = [
            {"open": 100.0, "high": 102.0, "low": 99.5, "close": 101.5, "volume": 150.0}
            for _ in range(100)
        ]
        mock_client.get_klines.side_effect = [primary, RuntimeError("HTF feed down")]
        metrics = {"ema9": 100.5, "ema21": 99.5, "ema50": 97.0, "rsi": 60.0, "atr": 1.0, "score": 90}
        with patch("agents.momentum.calculate_ema_and_metrics", return_value=metrics), \
             patch("agents.momentum.calculate_volume_surge", return_value=1.6), \
             patch("agents.momentum.calculate_candle_metrics", return_value={"is_bullish": True, "close_ratio": 0.8, "body_pct": 60}):
            result = MomentumAnalystAgent(mock_client).analyze_symbol("TESTUSDT")

        self.assertFalse(result["passed"])
        self.assertTrue(any("unavailable" in reason.lower() for reason in result["gate_failures"]))

    def test_micro_profit_salvage_banks_aged_winner(self):
        import tempfile
        from pathlib import Path
        from datetime import datetime, timezone, timedelta
        import config

        mock_client = MagicMock()
        mock_client.get_price.return_value = 100.0
        with tempfile.TemporaryDirectory() as tmp_dir:
            orig_port, orig_log = config.PORTFOLIO_FILE, config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = Path(tmp_dir) / "portfolio.json"
            config.TRADE_LOG_FILE = Path(tmp_dir) / "trades.json"
            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)
                plan = {
                    "symbol": "SOLUSDT", "entry_price": 100.0, "quantity": 2.0,
                    "position_usdt": 200.0, "stop_loss_price": 98.0, "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0, "take_profit_2": 106.0,
                    "trailing_trigger_pct": config.TRAILING_STOP_TRIGGER_PCT,
                    "trailing_distance_pct": config.TRAILING_STOP_DISTANCE_PCT,
                }
                self.assertTrue(portfolio.execute_buy(plan))
                portfolio.state["open_positions"][0]["entry_time"] = (
                    datetime.now(timezone.utc) - timedelta(minutes=config.MICRO_PROFIT_SALVAGE_AFTER_MIN + 5)
                ).isoformat()
                mock_client.get_price.return_value = 100.8
                actions = portfolio.update_and_monitor_positions()
                self.assertEqual(actions[0]["reason"], "MICRO_PROFIT_SALVAGE_EXIT")
                self.assertGreater(actions[0]["pnl_usdt"], 0)
                self.assertEqual(portfolio.state["winning_trades"], 1)
            finally:
                config.PORTFOLIO_FILE, config.TRADE_LOG_FILE = orig_port, orig_log

    def test_state_isolation_respects_config_override(self):
        """Regression: agent used stale `from config import PORTFOLIO_FILE`, so test
        overrides were ignored and tests wrote into the LIVE production state."""
        import tempfile, json
        from pathlib import Path
        import config

        mock_client = MagicMock()
        live_portfolio = config.PORTFOLIO_FILE
        live_before = live_portfolio.read_bytes() if live_portfolio.exists() else None

        with tempfile.TemporaryDirectory() as tmp_dir:
            orig_port, orig_log = config.PORTFOLIO_FILE, config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = Path(tmp_dir) / "iso_portfolio.json"
            config.TRADE_LOG_FILE = Path(tmp_dir) / "iso_trades.json"
            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(777.0)
                self.assertTrue(config.PORTFOLIO_FILE.exists())
                written = json.loads(config.PORTFOLIO_FILE.read_text())
                self.assertEqual(written["initial_capital"], 777.0)
            finally:
                config.PORTFOLIO_FILE, config.TRADE_LOG_FILE = orig_port, orig_log

        # The live state file must be byte-identical (never touched by the test)
        live_after = live_portfolio.read_bytes() if live_portfolio.exists() else None
        self.assertEqual(live_before, live_after, "test run mutated the live portfolio state file")

    def test_macro_market_sentinel(self):
        mock_client = MagicMock()
        # Normal upward BTC klines
        normal_klines = [
            {"open": 60000.0 + i*10, "high": 60050.0 + i*10, "low": 59950.0 + i*10, "close": 60020.0 + i*10, "volume": 100.0}
            for i in range(60)
        ]
        mock_client.get_klines.return_value = normal_klines
        sentinel = MacroMarketSentinel(mock_client)
        status = sentinel.evaluate_macro_health()
        self.assertTrue(status["safe_to_trade"])
        self.assertFalse(status["circuit_breaker"])

        # Dumping BTC klines (Drop from 65k to 55k)
        dumping_klines = [
            {"open": 65000.0 - i*200, "high": 65100.0 - i*200, "low": 64800.0 - i*200, "close": 64900.0 - i*200, "volume": 500.0}
            for i in range(60)
        ]
        mock_client.get_klines.return_value = dumping_klines
        status_dump = sentinel.evaluate_macro_health()
        self.assertFalse(status_dump["safe_to_trade"])
        self.assertTrue(status_dump["circuit_breaker"])


class TestSpecialistAgents(unittest.TestCase):
    def setUp(self):
        self.llm = LLMClient(api_key="", base_url="")

    def test_narrative_specialist(self):
        spec = MarketNarrativeSpecialist(self.llm)
        report = spec.analyze({
            "symbol": "SOLUSDT",
            "price_change_24h": 8.5,
            "quote_volume_24h": 25_000_000.0
        })
        self.assertEqual(report["verdict"], "APPROVE")
        self.assertGreaterEqual(report["conviction"], 65)

    def test_price_action_specialist(self):
        spec = PriceActionSpecialist(self.llm)
        report = spec.analyze({
            "momentum_data": {
                "score": 85,
                "rsi": 62.0,
                "volume_surge": 1.6,
                "reasons": ["Price > EMA9 > EMA21"]
            }
        })
        self.assertEqual(report["verdict"], "APPROVE")
        self.assertGreaterEqual(report["conviction"], 70)
        self.assertEqual(len(report["staff_reports"]), 3)

    def test_rsi_exhaustion_specialist(self):
        spec = MomentumExhaustionSpecialist(self.llm)
        # Healthy zone
        rep_ok = spec.analyze({"momentum_data": {"rsi": 60.0}})
        self.assertEqual(rep_ok["verdict"], "APPROVE")

        # Overbought exhaustion veto
        rep_veto = spec.analyze({"momentum_data": {"rsi": 82.0}})
        self.assertEqual(rep_veto["verdict"], "REJECT")
        self.assertIn("overbought", rep_veto["rationale"].lower())

    def test_sentiment_regime_specialist(self):
        spec = MarketSentimentSpecialist(self.llm)
        report = spec.analyze({
            "momentum_data": {"atr": 0.05},
            "ticker_data": {"count_trades": 60_000}
        })
        self.assertEqual(report["verdict"], "APPROVE")

    def test_profit_extraction_specialist(self):
        spec = ProfitExtractionSpecialist(self.llm)
        report = spec.analyze({
            "risk_plan": {
                "take_profit_1": 103.0,
                "take_profit_2": 106.0,
                "trailing_trigger_pct": 2.5,
                "trailing_distance_pct": 1.2
            }
        })
        self.assertEqual(report["verdict"], "APPROVE")

    def test_cro_veto_power(self):
        spec = ChiefRiskOfficerSpecialist(self.llm)
        report = spec.analyze({
            "risk_plan": {"approved": False, "reason": "R:R ratio below 2.0"}
        })
        self.assertEqual(report["verdict"], "REJECT")
        self.assertIn("VETO", report["rationale"])

    def test_executive_consensus_synthesis(self):
        exec_spec = ExecutiveStrategistSpecialist(self.llm)
        approved_reports = [
            {"specialist": "Narrative", "verdict": "APPROVE", "conviction": 80},
            {"specialist": "PriceAction", "verdict": "APPROVE", "conviction": 85},
            {"specialist": "Exhaustion", "verdict": "APPROVE", "conviction": 90},
            {"specialist": "Microstructure", "verdict": "APPROVE", "conviction": 75},
            {"specialist": "Sentiment", "verdict": "APPROVE", "conviction": 80},
            {"specialist": "CRO", "verdict": "APPROVE", "conviction": 90},
            {"specialist": "Profit", "verdict": "APPROVE", "conviction": 90}
        ]
        consensus = exec_spec.synthesize(approved_reports)
        self.assertEqual(consensus["final_verdict"], "APPROVE")
        self.assertGreaterEqual(consensus["consensus_conviction"], 70)

        # One veto triggers rejection
        vetoed_reports = list(approved_reports)
        vetoed_reports[5] = {"specialist": "CRO", "verdict": "REJECT", "rationale": "High drawdown"}
        rejected_consensus = exec_spec.synthesize(vetoed_reports)
        self.assertEqual(rejected_consensus["final_verdict"], "REJECT")

    def test_close_all_positions_and_periodic_perf(self):
        import tempfile
        from pathlib import Path
        mock_client = MagicMock()
        mock_client.get_price.return_value = 105.0

        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_portfolio_file = Path(tmp_dir) / "test_portfolio.json"
            temp_log_file = Path(tmp_dir) / "test_trades.json"
            
            import config
            orig_port = config.PORTFOLIO_FILE
            orig_log = config.TRADE_LOG_FILE
            config.PORTFOLIO_FILE = temp_portfolio_file
            config.TRADE_LOG_FILE = temp_log_file

            try:
                portfolio = PortfolioManagerAgent(mock_client, mode="paper")
                portfolio.reset_portfolio(1000.0)

                plan = {
                    "symbol": "BTCUSDT",
                    "entry_price": 100.0,
                    "quantity": 2.0,
                    "position_usdt": 200.0,
                    "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0,
                    "take_profit_1": 103.0,
                    "take_profit_2": 108.0,
                    "trailing_trigger_pct": 2.5,
                    "trailing_distance_pct": 1.2
                }
                portfolio.execute_buy(plan)
                self.assertEqual(len(portfolio.get_open_positions()), 1)

                # Test emergency close all positions
                closed = portfolio.close_all_positions(reason="BOT_SHUTDOWN_LIQUIDATION")
                self.assertEqual(len(closed), 1)
                self.assertEqual(len(portfolio.get_open_positions()), 0)
                self.assertEqual(closed[0]["reason"], "BOT_SHUTDOWN_LIQUIDATION")

                # Test periodic performance report
                perf = portfolio.get_periodic_performance()
                self.assertIn("today", perf)
                self.assertIn("this_week", perf)
                self.assertIn("this_month", perf)
                self.assertEqual(perf["today"]["trades"], 1)
                self.assertGreater(perf["today"]["wins"], 0)
            finally:
                config.PORTFOLIO_FILE = orig_port
                config.TRADE_LOG_FILE = orig_log

    def test_ultra_context_consciousness_evolution(self):
        import tempfile
        from pathlib import Path
        from agents.consciousness import AgentConsciousnessEngine

        with tempfile.TemporaryDirectory() as tmp_dir:
            test_file = Path(tmp_dir) / "test_consciousness.json"
            engine = AgentConsciousnessEngine(file_path=test_file)
            self.assertEqual(engine.memory["version"], "2.2.0-ULTRA")

            initial_risk_weight = engine.get_weight("Quantitative Risk & Capital Division")
            engine.evolve_heuristics_deterministically([{"symbol": "BTCUSDT", "pnl_usdt": -5.0}])
            self.assertGreater(engine.memory["total_upgrades_performed"], 0)
            self.assertEqual(engine.memory["last_upgrade_mode"], "DETERMINISTIC_AUTONOMOUS")
            self.assertGreaterEqual(engine.get_weight("Quantitative Risk & Capital Division"), initial_risk_weight)

            upgrade_payload = {
                "upgrade_version": "2.4.0-ULTRA",
                "executive_diagnosis": "Testing AI meta upgrade",
                "calibrated_thresholds": {
                    "Technical Price Action Division": {"min_volume_surge": 1.25}
                },
                "dynamic_weights": {
                    "Technical Price Action Division": 1.35
                },
                "new_rules": [
                    {
                        "division": "Technical Price Action Division",
                        "rule_id": "PA-TEST-01",
                        "rule": "Avoid entering during macro consolidation",
                        "origin": "AI Test Upgrade"
                    }
                ]
            }
            engine.apply_ai_upgrade(upgrade_payload)
            self.assertEqual(engine.memory["ai_intelligence_level"], "2.4.0-ULTRA")
            self.assertEqual(engine.get_weight("Technical Price Action Division"), 1.35)
            self.assertEqual(engine.get_threshold("Technical Price Action Division", "min_volume_surge", 1.0), 1.25)
            summary = engine.get_ultra_context_summary()
            self.assertIn("divisions", summary)

    def test_bi_directional_scanner_short_and_long(self):
        mock_client = MagicMock()
        mock_client.get_24hr_tickers.return_value = [
            {
                "symbol": "SOLUSDT",
                "lastPrice": "100.0",
                "priceChangePercent": "5.5",
                "quoteVolume": "10000000.0",
                "highPrice": "105.0",
                "lowPrice": "95.0",
                "count": 50000
            },
            {
                "symbol": "ETHUSDT",
                "lastPrice": "2000.0",
                "priceChangePercent": "-4.2",
                "quoteVolume": "15000000.0",
                "highPrice": "2100.0",
                "lowPrice": "1980.0",
                "count": 60000
            }
        ]
        scanner = ScannerAgent(mock_client)
        candidates = scanner.scan_trending_pairs(top_limit=10)
        self.assertEqual(len(candidates), 2)
        symbols = {c["symbol"]: c for c in candidates}
        self.assertEqual(symbols["SOLUSDT"]["direction"], "LONG")
        self.assertEqual(symbols["SOLUSDT"]["target_market"], "SPOT")
        self.assertEqual(symbols["ETHUSDT"]["direction"], "SHORT")
        self.assertEqual(symbols["ETHUSDT"]["target_market"], "FUTURES")

    def test_short_position_execution_and_trailing_pnl(self):
        mock_client = MagicMock()
        mock_client.get_price.return_value = 100.0
        portfolio = PortfolioManagerAgent(mock_client, mode="paper")
        portfolio.reset_portfolio(1000.0)

        plan = {
            "symbol": "BTCUSDT",
            "direction": "SHORT",
            "target_market": "FUTURES",
            "side": "SELL",
            "position_usdt": 100.0,
            "quantity": 1.0,
            "entry_price": 100.0,
            "stop_loss_price": 103.0,
            "stop_loss_pct": 3.0,
            "take_profit_1": 96.0,
            "take_profit_2": 92.0,
            "trailing_trigger_pct": 2.0,
            "trailing_distance_pct": 1.0
        }
        success = portfolio.execute_trade(plan)
        self.assertTrue(success)
        self.assertEqual(len(portfolio.get_open_positions()), 1)
        pos = portfolio.get_open_positions()[0]
        self.assertEqual(pos["direction"], "SHORT")
        self.assertEqual(pos["side"], "SELL")

        mock_client.get_price.return_value = 95.0
        actions = portfolio.update_and_monitor_positions()
        self.assertGreater(len(actions), 0)
        self.assertEqual(actions[0]["action"], "PARTIAL_TP1_TAKEN")
        self.assertGreater(actions[0]["pnl_usdt"], 0)

        mock_client.get_price.return_value = 91.0
        close_actions = portfolio.update_and_monitor_positions()
        self.assertGreater(len(close_actions), 0)
        self.assertEqual(close_actions[0]["action"], "CLOSED")
        self.assertEqual(close_actions[0]["reason"], "TAKE_PROFIT_2_HIT")
        self.assertGreater(close_actions[0]["pnl_usdt"], 0)
        self.assertEqual(len(portfolio.get_open_positions()), 0)

    def test_dynamic_atr_trailing_stop_calculation(self):
        risk_agent = RiskManagementAgent()
        plan = risk_agent.evaluate_risk(
            symbol="SOLUSDT",
            current_price=100.0,
            atr=2.5,
            total_equity=1000.0,
            open_positions=[],
            direction="LONG"
        )
        self.assertTrue(plan["approved"])
        self.assertEqual(plan["trailing_distance_pct"], 2.5)
        self.assertGreaterEqual(plan["trailing_trigger_pct"], 4.5)

    def test_anti_short_squeeze_guard(self):
        mock_client = MagicMock()
        mock_client.get_funding_rate.return_value = -0.05
        klines = [
            {"open": 100.0, "high": 101.0, "low": 98.0, "close": 99.0, "volume": 1000.0}
            for _ in range(60)
        ]
        mock_client.get_klines.return_value = klines
        mom_agent = MomentumAnalystAgent(mock_client)
        res = mom_agent.analyze_symbol("ETHUSDT", direction="SHORT")
        self.assertFalse(res["passed"])
        fail_str = " ".join(res.get("gate_failures", []))
        self.assertIn("Anti-Squeeze Guard", fail_str)

    def test_alpha_relative_strength_filter(self):
        mock_client = MagicMock()
        mock_client.get_funding_rate.return_value = 0.01
        klines = [
            {"open": 100.0, "high": 101.0, "low": 98.0, "close": 90.0, "volume": 1000.0}
            for _ in range(60)
        ]
        mock_client.get_klines.return_value = klines
        mom_agent = MomentumAnalystAgent(mock_client)
        btc_context = {"drop_4h_pct": 2.0}
        res = mom_agent.analyze_symbol("DOGEUSDT", direction="LONG", btc_context=btc_context)
        self.assertFalse(res["passed"])
        fail_str = " ".join(res.get("gate_failures", []))
        self.assertIn("Negative Alpha vs Bitcoin", fail_str)


if __name__ == "__main__":
    unittest.main()
