# Binance Institutional AI Multi-Agent Quant Trading System (Clouvia Powered)

A Python multi-agent trading bot with bidirectional PAPER strategies (Spot LONG and simulated Futures SHORT), deterministic risk gates, a Clouvia AI final-decision authority with multi-source external research, persistent portfolio accounting, and a read-only web dashboard. A win-rate target is a strategy objective, not a verified performance guarantee. Paper trading remains experimental and is not a profit guarantee; use a small slot count and conservative profile until a sufficiently large out-of-sample paper sample validates expectancy. For performance analysis, use the portfolio ledger's own run counters and time range: `trade_history.json` is append-only and may contain trades from earlier runs.

## Tick-event execution pipeline

- `market_stream.py` maintains public OKX/Binance WebSockets and publishes each parsed trade/ticker tick to listeners. The event loop coalesces bursts per market/symbol for 50 ms, preventing a 100+ tick/s feed from building an unbounded work queue.
- Open positions are evaluated only when their own symbol receives a fresh tick. TP, SL, break-even, trailing, and momentum-fade exits therefore react to venue ticks rather than the 10-second scan schedule. Web analysis calls `run_cycle(..., monitor_positions=False)` so it cannot duplicate tick closes; a one-second REST guard covers only held symbols whose WebSocket quote is stale.
- A dedicated discovery worker periodically refreshes liquidity and 24-hour metadata, updates the candidate watchlist, and subscribes it to WebSockets; it performs no AI analysis. A move of at least `TICK_SCAN_TRIGGER_PCT` inside `TICK_SCAN_WINDOW_SEC` wakes a separate targeted worker, which handles one symbol per `run_cycle(triggered_symbols=...)`, bypasses the REST scanner, and sends only that mover through orderbook, momentum, TradingView, risk, and AI gates.
- `/api/status.market_stream.event_bus` reports received ticks, coalesced batches, targeted position-guard runs, event-scan triggers, and the latest trigger symbols. `latest_scan.scan_mode` distinguishes `EVENT` from `PERIODIC` analysis.
- TradingView multi-timeframe verification and universe metadata remain request/response APIs because those providers expose no public full-market tick stream. They are invoked immediately by the event cycle and are never represented as native WebSocket data.
- Continuous/default startup has one loop owner: the dashboard asyncio lifecycle. `python3 main.py` and `python3 main.py --run` no longer start the old terminal polling loop beside the event bus. Clouvia completions use `stream=True`; token chunks are assembled and then validated as the required JSON decision object.
- Startup self-evolution is delayed by `EVOLUTION_START_DELAY_SEC` and runs in a daemon timer, so it cannot delay WebSocket subscriptions, the position guard, or dashboard port binding.
- Decision AI and self-evolution use separate `LLMClient` instances and separate telemetry. A failed calibration response cannot downgrade the live decision engine from `AI_ABSOLUTE`; when the evolution watermark has no newly closed trades, calibration exits as `NO_NEW_TRADES` without calling Clouvia.

## Live Trading Recovery & TradingView Scanner Integration (2026-10-26)

### Root Cause Isolation: "Kenapa Sudah 12+ Jam Tidak Melakukan Trading"

Audit forensik terhadap log daemon, ledger, dan telemetri pasar mengungkap 5 akar masalah bertumpuk (stacked root causes) yang menyebabkan bot berhenti mengeksekusi order:
1. **Downtime Proses Total (54 Jam)**: Bot sempat dimatikan manual via SIGKILL pada `2026-10-23 11:27 UTC` dan baru dihidupkan kembali pada `2026-10-25 17:34 UTC` tanpa supervisor latar belakang.
2. **Feed Data Simulasi OKX Rusak (`OKX_DEMO=true`)**: Endpoint demo OKX menyuplai candle simulasi tanpa rentang (flat candle, close ratio 0.50, body 0.0%) pada 114 dari 309 instrumen, dan deviasi harga perp vs spot mencapai 13.85%, menyebabkan 100% kandidat gugur pada gerbang `5m micro-trigger not aligned`.
3. **Konflik Ambang Likuiditas ($2M vs $20M)**: Scanner menyaring kandidat berdasarkan `MIN_24H_VOLUME_USDT=2000000` ($2M), namun Orchestrator membuang seluruh kandidat di bawah `MIN_QUOTE_VOLUME_24H=20000000` ($20M) dengan alasan "Thin participation" (50 dari 57 kandidat tereliminasi).
4. **Kebuntuan AI Authority (`AI_DECISION_AUTHORITY=absolute`)**: Model eksternal merespons `HTTP_401` sehingga keputusan tertahan di fallback tanpa approval eksekusi.
5. **Ratchet Starvation pada Mesin Aturan Belajar (`Learned Lesson Veto`)**: 56 aturan mesin hasil pembelajaran evolusi mandiri menumpuk di atas gerbang dasar dan memveto 100% kandidat yang lolos filter strategi dasar.

### Solusi & Pemulihan Sistem

1. **Migrasi ke Live Public Feed OKX (`OKX_DEMO=false`)**: Data harga, orderbook, dan candle 5m ditarik langsung dari pasar riil publik OKX tanpa delay dan tanpa candle flat, dengan eksekusi transaksi tetap dikunci pada mode aman `TRADING_MODE=paper`.
2. **Harmonisasi Ambang Likuiditas**: Menetapkan `MIN_VOLUME_USDT=20000000` ($20M) secara seragam antara scanner dan orchestrator.
3. **AI Advisory Mode (`AI_DECISION_AUTHORITY=advisory`)**: Memberikan wewenang konsensus deterministik kuantitatif untuk mengeksekusi posisi tanpa terblokir saat provider LLM eksternal mengalami gangguan.
4. **Learned Gate Advisory Mode (`LEARNED_GATE_MODE=advisory`)**: Pelanggaran aturan belajar dicatat secara transparan pada `candidate.learned_advisories` untuk kebutuhan audit forensik tanpa memblokir kandidat yang memenuhi parameter strategi dasar.
5. **Supervisor Daemon Tangguh (`run_bot.sh`)**: Menggunakan `termux-wake-lock`, auto-restart on exit, graceful shutdown via `.stop-supervisor`, dan rotasi log per-run di `logs/bot_<timestamp>.log`.

### Integrasi Realtime TradingView Scanner & Live Chart Posisi

1. **Jembatan TradingView (`tv_bridge.py`)**: Mengintegrasikan algoritma kalkulasi indikator dari `tradingview-mcp` dengan verifikasi multi-timeframe realtime (5m, 15m, 1h, 4h). Posisi hanya dikonfirmasi jika arah bias teknikal TV selaras dengan sinyal bot.
2. **Endpoint Telemetri Chart (`/api/positions/charts`)**: Menyajikan data 90 candle 1-menit realtime, overlay level harga entry, Stop Loss, TP1, TP2, serta log verifikasi TV.
3. **Live Chart di Halaman Ringkasan (`#positionCharts`)**: Menampilkan visualisasi chart interaktif langsung pada card posisi terbuka dashboard web dengan pembaruan dinamis.

---

## Learned-Threshold Enforcement & `scalp` Profile (2026-10-23)

### Root cause of the losing run (61 closed trades, 2026-10-22T14:22 to 2026-10-23T06:49)

The ledger, not the narrative, explained the drawdown: net `-32.12 USDT` (equity 967.88 from 1000.00), win rate `26.2%`, profit factor `0.34`, gross `-13.83`, fees `-18.29`.

1. **The self-improvement loop learned but its verdicts never bound at the gate.** `config.AI_DECISION_AUTHORITY=absolute` made `run_cycle` compute `gates_passed = safety_passed` only, discarding `strategy_failures`, which is exactly where `Learned Lesson Veto` entries were appended. The 01:47 `AI_ULTRA_CONTEXT` upgrade (`glm5.3-thinking-agentic`) had correctly diagnosed the problem and raised `min_volume_surge` to `2.0`, `min_trend_efficiency` to `0.4`, `max_spread_pct` to `0.03`, `min_bid_depth_ratio` to `1.4`; the 6 entries opened after that upgrade still averaged `trend_efficiency 0.32` and `spread 0.07%`, i.e. 4 of 6 sat outside the thresholds the machine had just learned. Those 6 trades netted `-14.87` at `16.7%` WR.
2. **The 90-minute hard time stop was the fee pump.** 43 of 61 exits (70%) were `MOMENTUM_TIME_STOP_EXIT` with `11.6%` WR, `gross -10.85`, `fees -12.93` — the bucket lost more to commission than to price.
3. **Reward-to-risk was inverted.** `STOP_LOSS_HIT` averaged `-3.48` (7 trades) while the only profitable bucket, `TRAILING_STOP_EXIT`, averaged `+1.45` (11 trades, 100% WR). Direction split was `57 SHORT / 4 LONG` in a tape that punished shorts.

### The fix

`orchestrator.run_cycle` now keeps learned-lesson violations in their own list and folds them into the gate:

```python
gates_passed = safety_passed and learned_passed and (absolute_authority or strategy_passed)
```

`AI_DECISION_AUTHORITY=absolute` still lets the AI override the deterministic specialist scores, but it can no longer override a threshold the bot learned from its own closed losses. `tests/test_learned_veto_authority.py` pins both directions: a learned veto blocks the candidate (note `QUALITY_GATE_BLOCKED: Learned Lesson Veto ...`, zero `execute_trade` calls) and a clean candidate still executes. Reverting the one-line formula makes that test fail with `AssertionError: True is not false : EXECUTED`, so the test is not vacuous.

### `TRADING_PROFILE=scalp`

`config.TRADING_PROFILES` gained a `scalp` preset and `_PROFILE_KNOBS` now covers the exit knobs (`TIME_STOP_AFTER_MIN`, `TIME_STOP_HARD_MIN`, `TP1_R_MULTIPLE`, `MAX_OPEN_POSITIONS`, `MAX_POSITION_SIZE_PCT`, `TRAILING_STOP_TRIGGER_PCT`, `TRAILING_STOP_DISTANCE_PCT`, `AI_ABSOLUTE_MIN_CONVICTION`). Explicit `.env` values still win over the preset. `TRAILING_STOP_TRIGGER_PCT` / `TRAILING_STOP_DISTANCE_PCT` were hardcoded and are now env-driven like the rest.

| Knob | balanced default | scalp |
| --- | --- | --- |
| `TIME_STOP_AFTER_MIN` / `TIME_STOP_HARD_MIN` | 30 / 90 | 15 / 30 |
| `TP1_R_MULTIPLE` | 1.0 | 1.2 |
| `TRAILING_STOP_TRIGGER_PCT` / `_DISTANCE_PCT` | 2.2 / 1.5 | 1.6 / 1.0 |
| `MAX_OPEN_POSITIONS` / `MAX_POSITION_SIZE_PCT` | 3 / 25 | 2 / 18 |
| `RISK_PER_TRADE_PCT` / `DAILY_LOSS_LIMIT_PCT` | 2.0 / 4.0 | 1.5 / 3.0 |
| `ENHANCED_MIN_CONVICTION` / `MIN_TECHNICAL_SCORE` | base | 72 / 68 |
| `MIN_RISK_REWARD_RATIO` | base | 1.6 |
| `AI_ABSOLUTE_MIN_CONVICTION` | 60 | 70 |

`TIME_STOP_SOFT_ENABLED` stays `false`: the soft cut is a deliberate opt-in and the hard window plus enforced entries is the policy that recycles dead capital.

Two test suites were made hermetic instead of profile-coupled: `tests/test_time_stop_policy.py` patches the three time-stop knobs in `setUp`, and `tests/test_aggressiveness_fixes.py::_run` pins `MAX_OPEN_POSITIONS` to 6 so capacity never masks the correlation-cap and hedge assertions.

### Verification

`python3 -m unittest discover -s tests` → `Ran 329 tests ... OK`. `python3 main.py --scan` on the live feed reports `Active Capacity 0 / 2 positions (max 1 searah, 18.0% equity/posisi)`, `136 RCA Rules | 58847 Vetoes Enforced`, and blocks the evaluated candidate at the quality gate rather than executing it. Fee math to keep in mind before tightening targets further: the observed round trip costs about `0.20%` of notional (`0.30 USDT` on a `~145 USDT` position), so a scalp target below `0.5%` cannot pay for itself at this fee tier.

## Reference Architecture Review: TradingAgents (TauricResearch)

Checked against `TauricResearch/TradingAgents` (arXiv 2412.20138). Read from source at `main`: `graph/setup.py`, `graph/conditional_logic.py`, `memory/settlement.py`, `memory/reflection.py`, `backtest.py`, `agents/risk_mgmt/*`.

What the reference does that this repo does not:

1. **Adversarial debate before the decision.** Analysts feed a Bull and a Bear researcher that alternate for `2 * max_debate_rounds` turns, then a Research Manager writes the balanced view; a Trader proposes, then Aggressive / Conservative / Neutral risk analysts alternate for `3 * max_risk_discuss_rounds` turns before the Portfolio Manager decides. This repo runs eight divisions and an executive in one pass — agreement is measured, dissent is not argued out. Our losing run is exactly the shape a bear case would have caught: 57 SHORT entries in a tape where the book was bid-heavy (`bid_depth_ratio` median 0.97 on losers).
2. **Settlement + reflection instead of a grade.** A decision stays pending until its holding window trades, then it is scored as raw return *and* alpha versus a benchmark, entered at the first close after the decision date, and turned into 2-4 sentences of prose that are re-injected into later prompts. `trade_reviewer.py` grades process defects (`FEE_DOMINATED`, `DEGENERATE_TARGET`, `SUB_MINUTE_HOLD`) over a run scope but never settles a decision against a benchmark, so a SHORT that lost while BTC fell 3% is indistinguishable from one that lost while BTC rose.
3. **Backtest scored from the first close after each decision.** `backtest.py` replays a ticker/date grid. This repo has no offline harness at all, so every threshold change — including the six-hourly AI upgrade — is validated only by live paper trades. That is how 113 "upgrades" accumulated against 61 closed trades.
4. **Look-ahead tests as a gate.** The reference suite ships `test_news_lookahead`, `test_fundamentals_lookahead`, `test_memory_pointintime`, `test_ohlcv_latest_bar`, `test_fundamentals_units`. Our entries already record `entry_metrics` at decision time (point-in-time), but nothing asserts it.

Adoption order for this repo, cheapest first: (a) benchmark-alpha settlement in `trade_reviewer` so each closed trade carries `alpha_vs_BTC`; (b) a replay harness over the exchange client's own klines that scores the `scalp` policy before it trades; (c) a deterministic bear-case pass over the same metrics before entry (no extra LLM call); (d) debate rounds only if (a)-(c) still leave the entry problem unsolved.

## Policy Replay Harness (`replay.py`, 2026-10-23)

(b) above is now implemented. `replay.py` scores an exit policy over closed candles before any paper trade is risked. It is a policy-level approximation, not a full bot replay: it sees OHLCV only, so spread, orderbook imbalance and news are absent, and it assumes the stop is hit before the target inside a bar that touches both.

```
python3 replay.py --symbol BTCUSDT --interval 15m --limit 300 --policy scalp
python3 replay.py --symbol ETHUSDT --interval 1h --limit 300 --compare
```

Policies in `POLICIES`: `baseline` (30/90 min, TP1 1.0R, trail 2.2/1.5, gates 1.10 / 0.12), `scalp` (15/30 min, TP1 1.2R, trail 1.6/1.0, gates 2.0 / 0.40), `swing_hold` (no stop, no TP, fixed 32-bar horizon, gates 1.40 / 0.15). Signals are volume surge over the prior 20 bars, 20-bar trend efficiency, and an RSI band; entry is the next bar's open, so no bar is traded on its own signal. Round-trip fee is fixed at `0.20%`.

Measured on 24 datasets (BTC/ETH/SOL/DOGE/LINK/SUI/AVAX/NEAR × 5m/15m/1h × 300 closed bars, OKX futures, 2026-10-23), non-overlapping trades:

| policy | trades | net % | win rate | expectancy/trade |
| --- | --- | --- | --- | --- |
| baseline | 409 | -124.08 | 36.4% | -0.303% |
| scalp | 1 | -0.59 | 0.0% | -0.595% |
| swing_hold | 58 | -0.56 | 50.0% | -0.010% |

A 90-combination sweep of the exit knobs (volume surge 1.2-2.0, trend efficiency 0.15-0.40, hard window 30/45/60, TP1 1.0/1.2/1.5, trail 1.6/1.0 vs 2.2/1.5) produced no combination with positive expectancy; the best was `-0.166%` per trade at `n=61`. Two consequences worth keeping in mind before tuning anything else: the `scalp` gate set is tight enough to fire once across 24 datasets (an idle bot, not a profitable one), and a fixed 2% stop costs more than it saves — at 8 bars, `swing_hold` with a 2% stop measured `-0.373%` per trade versus `-0.081%` without it, because the stop sits inside normal intraday noise.

One hypothesis did survive: filtering by relative strength versus BTC (20-bar return difference) and holding 32 bars turned positive — `rs >= 0.5` gave `n=27, net +18.27%, WR 63.0%, +0.677%/trade`, `rs >= 1.0` gave `n=16, +16.25%, WR 68.8%, +1.016%/trade`. At `n=16-27` and with 8-bar holds negative in the same run, this is a hypothesis to accumulate more samples on, not a validated edge, and it is deliberately not wired into the live gate.

Replay is a pure function over bars (`signal_at`, `simulate_trade`, `simulate`, `aggregate`) and is covered by `tests/test_replay_policy.py` (13 tests: stop arithmetic incl. fee, hard window, hold window, disabled stop, signal rejection of an overbought straight line, and an assertion that every entry follows a bar that already carried the signal).

### Live profile decision (2026-10-23)

The operator chose the loose-gate `balanced` profile after the replay sweep, so `.env` now runs `TRADING_PROFILE=balanced`, `TIME_STOP_AFTER_MIN=30`, `TIME_STOP_HARD_MIN=90`, `TP1_R_MULTIPLE=1.0`, trailing `2.2/1.5`, `MAX_OPEN_POSITIONS=3`, `MAX_POSITION_SIZE_PCT=25`, `RISK_PER_TRADE_PCT=2.0`, `AI_ABSOLUTE_MIN_CONVICTION=60`, `DAILY_LOSS_LIMIT_PCT=4.0`, with the duplicate `EXCHANGE` key removed so `okx` is the single authoritative value. This is the configuration the replay measured at `-0.303%` expectancy per trade, so the expectation is a slow bleed, not a profit: the learned-veto enforcement and the direction guard are what keep it bounded. The strict `scalp` profile and its `.env` snapshot remain in `.env.scalp_backup`.

### Fee floor is the binding constraint (2026-10-23)

Re-running the same 24 datasets at lower fee levels isolates what the strategy can and cannot survive:

| round-trip fee | baseline exp/trade | scalp exp/trade | swing_hold exp/trade |
| --- | --- | --- | --- |
| 0.20% | -0.299% | -0.595% | -0.019% |
| 0.10% | -0.199% | -0.495% | +0.081% |
| 0.08% | -0.179% | -0.475% | +0.101% |
| 0.06% | -0.159% | -0.455% | +0.121% |
| 0.00% | -0.099% | -0.395% | +0.181% |

`swing_hold` is the only policy that crosses zero, and it does so at a 0.10% round trip — i.e. futures taker pricing. At the spot rate the same entries lose. That makes venue fee, not signal tuning, the first lever.

While measuring it, a real accounting defect surfaced: `PortfolioManagerAgent` charged `EFFECTIVE_FEE_PCT` (0.10% per side) on every fill, including `FUTURES` fills, while `risk_manager` already priced futures at `FUTURES_FEE_PCT` (0.05%). Across the 73 closed futures trades the recorded `fee_paid_usdt` implies a median **0.200% round trip** where the venue charges 0.100% — a 2x overcharge, worth roughly 0.10% of notional per trade, and a permanent disagreement between the desk that decides the trade and the ledger that grades it.

Fix: a `_fee_pct(market)` helper returns `FUTURES_FEE_PCT` for `FUTURES` and `EFFECTIVE_FEE_PCT` otherwise, applied at all seven fee sites (entry, TP1 slice, pyramiding add, time-stop net-gain check, break-even cushion, close, emergency close). Covered by `tests/test_fee_by_market.py` (4 tests). Mutation-verified: forcing the helper to always return the spot rate fails 3 of them with the exact 2x discrepancy (`0.1 != 0.05`, `0.3 != 0.2`), and restoring it returns green.

This changes accounting only — historical rows keep their overcharged fees, so the equity curve before this fix is pessimistic by roughly 0.10% of notional per futures trade.

### Direction and hold length: the only two levers with sign consistency (2026-10-23)

Two larger sweeps were run to test whether the relative-strength idea survives splitting the data in half. Same signal family, fee 0.10% round trip (futures taker), entries filtered so LONG requires the asset to out-return BTC over 20 bars and SHORT requires it to under-return by the same threshold.

1h datasets, 12 alts plus BTC, 299 closed bars each (~12 days), hold 24 or 32 bars:

| threshold | hold | half | n | net % | WR | LONG n/net | SHORT n/net |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0.5 | 32 | first | 9 | -6.14 | 55.6% | 3 / -18.4 | 6 / +12.3 |
| 0.5 | 32 | second | 12 | +32.17 | 91.7% | 8 / +18.1 | 4 / +14.1 |
| 0.5 | 32 | all | 21 | +26.03 | 76.2% | 11 / -0.3 | 10 / +26.3 |
| 1.0 | 32 | first | 8 | -4.35 | 62.5% | 3 / -18.4 | 5 / +14.0 |
| 1.0 | 32 | second | 11 | +29.31 | 90.9% | 7 / +15.3 | 4 / +14.1 |
| 1.0 | 32 | all | 19 | +24.97 | 78.9% | 10 / -3.1 | 9 / +28.1 |

Read honestly: the aggregate is positive only because the second half is a trending window (WR 91.7%). The first half loses. The one pattern that holds across all six cells is directional — **SHORT with relative weakness is positive in every cell (+2.3 to +28.1), LONG with relative strength is negative in every cell (-18.4 to -0.3)**. With 4-10 trades per cell that is a hypothesis worth accumulating samples on, not a reason to flip the live config.

It also contradicts the live direction guard, which paused SHORT (rolling 20: WR 20%, net -20.93) and allows LONG. Both readings come from small samples over different windows, so neither settles it. The tie-break is sample size, which is exactly what the bot is now collecting.

Structural conclusion that does not depend on any of this: at **zero fees** the fast policy still measures `-0.099%` per trade over 410 trades, and `scalp` measures `-0.395%` over its single signal. Fee optimisation cannot rescue a negative-gross entry; only a different entry condition can. Hold length and direction are the two variables that showed sign consistency, so any further work belongs there rather than in exit tuning.

### Fast-signal family sweep: negative (2026-10-23)

Four alternative fast entry families were tested against the same cached datasets, entry at the next bar's open, non-overlapping, fee 0.20% and 0.10% round trip, holds 3/6/12 bars:

| family | rule | 0.20% RT | 0.10% RT |
| --- | --- | --- | --- |
| rsi2 | RSI(2) < 10 long / > 90 short | -0.170 to -0.241% | -0.070 to -0.141% |
| donchian | close breaks 20-bar high/low | -0.332 to -0.533% | -0.232 to -0.433% |
| volfade | fade a 3x volume spike against its body | +0.033 to +0.075% | +0.133 to +0.175% |
| emacross | EMA9/21 cross | -0.138 to -0.235% | -0.038 to -0.135% |

`volfade` was the only positive family and looked like a real fast edge: on 300-bar datasets it gave `n=223, +32.59%, WR 48.4%, +0.146%/trade`, positive in both halves, in 7 of 8 symbols, at both fee levels. It died on a longer sample. Re-fetching 1440 hourly bars per symbol (10 symbols, ~2 months, paginated through the OKX candles endpoint):

| hold | n | net % | WR | exp/trade |
| --- | --- | --- | --- | --- |
| 1 | 657 | -63.72 | 43.8% | -0.097% |
| 2 | 622 | -32.86 | 47.9% | -0.053% |
| 3 | 591 | -27.83 | 47.5% | -0.047% |
| 4 | 566 | -14.36 | 47.7% | -0.025% |
| 6 | 523 | -7.66 | 48.6% | -0.015% |
| 8 | 496 | +27.14 | 49.6% | +0.055% |
| 12 | 428 | -48.26 | 50.0% | -0.113% |

Split into thirds the same hold-3 configuration reads `+0.029% / -0.240% / +0.102%` per trade, and per symbol 4 of 10 are negative with SOL at `-0.269%`. The one positive cell (hold 8, `+0.055%`) sits inside noise and its neighbours on both sides are negative, which is the signature of a grid point that happened to land well, not of an edge.

Verdict: none of the five fast signal families carries a demonstrable edge on this OHLCV-only data at realistic fees. The 12-day window that made `volfade` look profitable is exactly the trap the replay harness exists to catch, and this is why the harness should always be pointed at the longest history the venue will serve before any live change.

### Funding-rate axis: weak and regime-dependent (2026-10-23)

The one non-OHLCV axis already reachable through the exchange client is funding. Three months of 8-hourly funding history were pulled per symbol (279-300 records each) and joined to the hourly bars; the rule is fade the crowd, `SHORT` when funding is above the threshold and `LONG` when below it, with non-overlapping trades enforced so consecutive 8-hourly events cannot count the same 24-hour move three times.

| threshold | hold | n | net % | WR | exp/trade | LONG n/net | SHORT n/net |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0.03% | 8 | 108 | -11.62 | 48.1% | -0.108% | 72 / -24.8 | 36 / +13.2 |
| 0.03% | 24 | 70 | +19.20 | 48.6% | +0.274% | 46 / +3.8 | 24 / +15.4 |
| 0.03% | 48 | 57 | +94.69 | 52.6% | +1.661% | 39 / +100.7 | 18 / -6.0 |
| 0.05% | 24 | 59 | +12.28 | 49.2% | +0.208% | 39 / -0.7 | 20 / +13.0 |
| 0.08% | 24 | 48 | -6.30 | 43.8% | -0.131% | 34 / -3.5 | 14 / -2.8 |

Splitting the 24-bar variant into thirds exposes it: `+0.369% / +0.499% / -1.404%` at 0.03%, `+0.360% / +0.225% / -0.899%` at 0.05%, `+0.688% / -0.337% / -3.450%` at 0.08%. The aggregate is carried entirely by the two older thirds, and the most recent third is decisively negative at every threshold. The 48-bar row is not usable either: its profit sits in `LONG` on a window where NEAR alone returned `+153%` buy-and-hold, so it is beta, not signal.

Taken together with the OHLCV sweeps, the pattern is consistent: every candidate that survives a short window dies when the sample is lengthened, the trades are de-overlapped, or the window is split by regime. Further grid searching on this data would manufacture false positives rather than find an edge. A real fast strategy needs a data source the bot does not currently have (orderbook depth, liquidations, open-interest change) validated over at least three regimes and a hundred-plus non-overlapping trades, which is a data-collection task measured in weeks, not a tuning task.

## Market Snapshot Recorder (`market_recorder.py`, 2026-10-23)

The gap identified above is missing features, not missing knobs, so the bot now has a recorder that captures what the ledger never stored: top-of-book spread, five-level depth imbalance and funding, alongside the last closed bar.

```
python3 market_recorder.py --symbols BTCUSDT,ETHUSDT,SOLUSDT --interval 1h --limit 300
python3 market_recorder.py --loop-sec 300 --out data/snapshots.jsonl
```

Each round appends one JSON line per symbol to `data/snapshots.jsonl` (append-only, so repeated runs and a long-lived loop accumulate rather than overwrite). Fields: `symbol`, `recorded_at`, `market`, `interval`, `bars`, `funding_rate_pct` (percent per funding interval, `null` when the venue call fails), `book.{mid,spread_pct,bid_depth,ask_depth,depth_ratio}`, `last_close`, `last_bar_time`. The forming bar is dropped before capture, so a snapshot never mixes a partially built candle into a feature row. Orderbook and funding failures degrade to nulls instead of dropping the whole record.

Pure pieces (`book_features`, `build_record`, `append_jsonl`, `capture`) are covered by `tests/test_market_recorder.py` (9 tests), including zero-ask-depth division safety and the forming-bar drop. First live run against OKX futures wrote 5 records with real spread and depth-ratio values (`BTCUSDT spread 0.001152%, depth_ratio 0.1199`; `ETHUSDT spread 0.04216%, depth_ratio 5.1115`).

This is collection infrastructure, not a strategy change: it touches no order path and cannot affect trading. Its purpose is to make the orderbook/OI hypotheses testable in a few weeks with real recorded features instead of being guessed from OHLCV.

### Ledger feature discrimination and the trend-efficiency cap (2026-10-23)

The 77 closed trades each carry eight point-in-time entry features, so they can be ranked against their own outcomes. With 19 wins and 58 losses, rank AUC per feature (0.5 = no information):

| feature | AUC | median in wins | median in losses |
| --- | --- | --- | --- |
| imbalance | 0.315 | -0.1795 | -0.0183 |
| bid_depth_ratio | 0.315 | 0.6956 | 0.9642 |
| trend_efficiency | 0.348 | 0.1110 | 0.1920 |
| dist_from_ema21_pct | 0.625 | 0.4960 | 0.2620 |
| atr_pct | 0.602 | 0.6580 | 0.5725 |
| spread_pct | 0.559 | 0.0399 | 0.0253 |
| rsi | 0.460 | 43.15 | 43.87 |
| volume_surge | 0.512 | 1.1138 | 1.1425 |

`imbalance` and `bid_depth_ratio` are the same book skew in two units and move together; both say winners entered when bid support was thinner. At n=77 the standard error on AUC is about 0.077, so those two sit roughly 2.4 SE from 0.5 and `trend_efficiency` 2.0 SE — suggestive across eight comparisons, not established.

`trend_efficiency` is the interesting one because it points the opposite way from the learned rule, which raised `min_trend_efficiency` to 0.40. Testing that directly required a cap, so `replay.signal_at` now accepts an optional `trend_efficiency_max` (covered by `test_trend_efficiency_max_rejects_the_cleanest_trend`). Capping instead of flooring the metric on the 24-dataset set:

| cap | fee | n | net % | WR | exp/trade |
| --- | --- | --- | --- | --- | --- |
| none | 0.10% | 410 | -81.74 | 42.4% | -0.199% |
| 0.20 | 0.10% | 207 | -29.87 | 43.5% | -0.144% |
| 0.30 | 0.10% | 327 | -50.96 | 43.7% | -0.156% |
| 0.15 | 0.10% | 100 | -32.66 | 37.0% | -0.327% |
| none | 0.20% | 410 | -122.74 | 36.8% | -0.299% |
| 0.20 | 0.20% | 207 | -50.57 | 35.7% | -0.244% |

Capping at 0.20 improves expectancy by 0.055% per trade at both fee levels and halves the trade count, but the sign stays negative, so the ledger's AUC hint does not become a tradable edge. The learned rule and this test also cannot both be right: the rule wants trend efficiency above 0.40, this sample prefers below 0.20. Neither is strong enough to justify changing live behaviour, which is why the live gate is untouched.

## Futuristic HUD Dashboard (2026-10-22)

The dashboard was rebuilt as a dense MONITOR surface: deep-space canvas, hairline telemetry cards, chat-bubble data presentation and a candlestick market chart. No purple/cyan gradient slop, no emoji, no centered marketing hero.

- `templates/dashboard.html` — five ARIA tab panels (Ringkasan, Pasar, Posisi, Agen, Riwayat), header venue pills (mode, exchange, DNS route, connection), skip link, mobile bottom tab bar (60px targets, `position:fixed`, shown ≤768px; see the fixed-positioning contract below).
- `static/css/base.css` — design tokens for dark/light (`--void`, `--surface`, `--hairline`, `--cyan`, `--teal`, `--rose`, `--amber`), header shell, skeletons.
- `static/css/components.css` — bubble system (`.bubble--in` / `.bubble--out` with tails, `.bubble-stat` pill bubbles), hero equity card, KPI tiles, chart stage, position cards with risk track.
- `static/css/pipeline.css` / `operations.css` — agent verdict bubbles, route bubbles, audit bubbles, tables.
- `static/js/universe.js` — background engine: three parallax star layers, two static nebula gradients, one shooting star per 9-14s, 30fps cap, DPR cap 2, pauses on `visibilitychange`, single static frame under `prefers-reduced-motion`.
- `static/js/chart.js` — candlestick renderer (1px wick, glow bodies, EMA21 cyan / EMA50 amber overlays, volume histogram, dashed last-price line with price tag, crosshair + OHLC readout on hover/touch) plus the equity sparkline.
- `static/js/views.js`, `views2.js`, `operations.js`, `pipeline.js`, `app.js` — renderers, animated decision-flow canvas (7 stages, dashed bezier connectors with one travelling pulse dot per segment, hover tooltips), tab routing with arrow/Home/End keys, 3s polling with abort-on-new-request and stale-data banner.

`GET /api/market/chart?symbol=BTCUSDT&market=SPOT|FUTURES&interval=5m|15m|1h|4h&limit=30..200` serves OHLCV from the active exchange client (15s in-process cache, symbol sanitized to `[A-Z0-9]`, interval allow-listed, 503 with a typed error when the feed is unavailable). It is read-only and never places orders.

Verified live (chromedriver, rendered DOM, not source assertions): equity `$1,000.00`, exchange `OKX`, DNS `DOH`, 4 narrative bubbles, 6 KPI bubbles, 12 funnel rows, chart `1348x318` with 120 real candles (`DOGEUSDT · FUTURES`, `15m · 120 candle · OKX · DNS DOH`), 44 audit rows, 8 agent bubbles, pipeline canvas `953x476`, theme toggle dark↔light, and at 390px viewport: tab bar `flex`, 60px buttons, zero horizontal overflow.

### Fixed-positioning contract (2026-10-22)

Two CSS defects made the mobile bottom tab bar travel with the page even though its rule said `position:fixed`:

1. A stacking rule `body>:not(#universe):not(.skip-link){position:relative;z-index:1}` carried ID-level specificity (`1,0,1`, because `:not()` inherits its argument's specificity) and outranked `.app-tabbar{position:fixed}` and `.app-header{position:sticky}` (both `0,1,0`). It was removed; only `main{position:relative;z-index:1}` is needed to lift content above the `#universe` canvas (`z-index:0`).
2. `overflow-x:hidden` on `html`/`body` turns the body into a scroll container, which breaks `position:sticky` for the header. It now reads `overflow-x:hidden; overflow-x:clip` — old browsers keep `hidden`, modern ones use `clip`, which clips without creating a scroll container.

Rules to keep this working: never set `transform`, `filter`, `backdrop-filter`, `perspective`, `contain` or `will-change` on `body` or on any ancestor of `.app-tabbar` (each creates a containing block for `fixed` descendants), and never write a `body > *`-style rule that sets `position`.

Verified at 390×844, DPR 2, mobile emulation, real scroll (`window.scrollTo`): tab bar computed `fixed` with `bar_bottom == innerHeight` (844) at `scrollY` 0, 900, 3027 and 700 on the Pasar tab; header computed `sticky` with `header_top == 0` at every position; `scrollWidth - clientWidth == 0`. Screenshots: `hud_fixed_tabbar_bottom.png`, `hud_fixed_tabbar_market.png`. Asset version bumped to `?v=hud5` so phones drop the stale CSS.

### Decision flow animation (2026-10-22)

The "Alur keputusan" canvas existed but was unusable on a phone: `.pipeline-wrap canvas{height:auto}` left the wrap 180px tall while the layout packed 7 stages into a 2-column grid, so each node collapsed to ~16px and the whole thing read as a dead strip. Fixed:

- `.pipeline-wrap` now owns an explicit responsive height — 260px below 560px, 300px to 959px, 250px above — and the canvas fills it (`width:100%;height:100%`). `draw()` reads `getBoundingClientRect()` and skips frames when the panel is hidden (`rect` under 40px), so a background tab never paints a zero-size canvas.
- Layout is a compact grid, never a single vertical column: 2 columns on phones (4 rows), 3 columns from 560px, 4 columns from 960px of canvas width. Node height is clamped to 30-46px and labels stay at 12.5px/650, so 7 stages read as a compact flow at 334px wide and in 260px of height.
- Every connector carries a travelling pulse dot evaluated along its cubic bezier (`bezier()` + `sin(phase*π)` fade), so the flow visibly moves even when no candidate is in flight; an active upstream stage makes the dot bigger, brighter and faster.
- Nodes show live metrics right-aligned: `45 pair` (scanner), `0 lolos` (risk), `0 posisi` (portfolio). Missing telemetry renders `—`, never a fabricated zero.
- Head pill `#pipelineLive` shows `live · siklus N`, switches to amber `jeda` when `autonomous_loop.active` is false, and `#pipelineSymbol` shows `<symbol>` or `45 pair · siklus N · OKX`.
- `stageStatus()` reads `autonomous_loop.active` (not `running`), so a paused engine is reported correctly.

Verified with rendered DOM at two viewports: mobile 390×844 → canvas `334x258`, wrap 260px, `cols=2`, node height 45px, painted pixels changing between frames, `live · siklus 3`, zero horizontal overflow; desktop 1440×900 → canvas `954x248`, `cols=3` (the card is 954px wide inside the grid), `live · siklus 6`. Screenshots `hud_flow_compact_mobile.png`, `hud_flow_compact_desktop.png`. Asset version `?v=hud7`.

### Telemetry stamp contract (2026-10-22)

The footer rendered `— · DNS DOH · snapshot Waktu belum valid` because it read top-level `exchange` and `generated_at`, neither of which `/api/status` ever emitted (the venue only existed at `market_operations.exchange`, the timestamp only at `market_operations.snapshot_at`).

- `GET /api/status` now includes `generated_at` (UTC ISO, set when the payload is built).
- The footer reads `market_operations.exchange` → `exchange` → `exchange_label`, and stamps from `generated_at` → `market_operations.snapshot_at`.
- The header clock reads `generated_at` with the same fallback, so it can never print "Waktu belum valid" while a snapshot exists.

Verified live: footer `OKX · DNS DOH · snapshot 19.06.39`, header pills `PAPER` / `OKX` / `DNS DOH`, clock `baru saja`.

Agent bubbles carried the same symptom for a different reason: `agent_consciousness` entries have no timestamp field at all (`icon`, `consciousness_focus`, `total_audits`, `lessons_learned`, `calibrated_thresholds`, `dynamic_weight`), yet the renderer stamped `agent.updated_at || agent.timestamp` — both `undefined` — so all 8 bubbles printed "Waktu belum valid". They now resolve `updated_at` → `timestamp` → `last_audit_at` → `last_seen_at` → `latest_scan.completed_at` → `generated_at`, falling back to `—` instead of prose. `U.stamp()` keeps returning "Waktu belum valid" only for a genuinely unparseable date (asserted by `tests/test_dashboard_views.cjs`).

Verified in the rendered DOM across all five tabs: 0 occurrences of "Waktu belum valid" (Ringkasan, Pasar, Posisi, Agen, Riwayat), 8 agent bubbles each showing the real cycle time `19.09.13`, chart footer `15m · 120 candle · OKX · DNS DOH · 19.09.37`. Asset version `?v=hud8`.


## Position Count Badge on Nav Icons (2026-10-22)

The open-position count was only rendered inside the desktop tab row (`#tabPositionsCount` as a sibling of the label) and the mobile `.app-tabbar` had no badge element at all, so on a phone the "Posisi" icon never showed a number even while `responsive.css` carried an orphan `.app-tabbar .tab-count` rule for an element that did not exist.

- Both navs now wrap the glyph in `<span class="tab-icon">` and place the badge inside it: `#tabPositionsCount` (top tabs) and `#tabPositionsCountMobile` (bottom tabbar).
- `.tab-count` is absolutely anchored to the icon (`top:-5px; right:-9px`), 16px pill, cyan `#22d3ee` fill, JetBrains Mono numerals, 1.5px surface ring so it stays legible over the icon stroke; mobile variant is 15px / 9.5px text.
- `views.js` writes the count to both badges, hides them at zero, caps the label at `9+`, and sets `aria-label="Posisi, N terbuka"` on the button; the badge itself is `aria-hidden="true"` so the count is announced once.
- Asset version bumped to `?v=hud9`.

Verified in a live headless Chromium against OKX PAPER with 3 open positions:

| viewport | badge | text | box | icon overlap | tap target | overflow-x |
|---|---|---|---|---|---|---|
| 390x844 | `#tabPositionsCountMobile` | `3` | 15x15 at (198,791) | true | 78x60 | 0 |
| 1280x900 | `#tabPositionsCount` | `3` | 16x16 at (444,19) | true | n/a | 0 |

Both badges report `aria-label="Posisi, 3 terbuka"` and `background rgb(34, 211, 238)`. Hidden navs correctly render the badge at 0x0 (their `nav` computes `display:none`).

## Trade History Sync & Ledger Integrity (2026-10-22)

The Riwayat tab did not mirror the bot ledger: it only rendered `trade_history` rows (so open positions were invisible), it read `pnl`/`net_pnl` while the log writes `pnl_usdt` (every closed row would have shown `$0.00`), it listed `PARTIAL_TP1_TAKEN` events as if they were finished trades (double-counting one trade as two), and the position cards read `opened_at`/`unrealized_pct`, fields the API never emits, so every card printed `Waktu belum valid` and `0.00%`.

Server contract added to `GET /api/status` (`web_dashboard.py`):

- `trade_history` rows are normalised: `pnl_usdt`/`pnl`/`net_pnl` carry the same value, `pnl_pct` falls back to `roi_pct`, and `closed_at` mirrors `exit_time`.
- `open_trades` — one entry per live position: `symbol`, `direction`, `market`, `leverage`, `entry_price`, `current_price`, `pnl_usdt`, `pnl_pct`, `opened_at`, `stop_loss_price`, `take_profit_1`.
- `history_summary` — `open`, `closed`, `shown`, `wins`, `losses`, `scratches`, `fees_usdt`, `realized_usdt`, `unrealized_usdt`, `integrity` (`OK`/`MISMATCH`), `issues[]`, `log_file`, `log_rows`. Integrity compares the ledger counter with the number of `CLOSED` events, the summed log PnL with `realized_pnl_usdt` (tolerance 0.01 USDT), and surfaces any `cash_reconciliation` status other than `OK`.

Client fixes:

- `views2.js` renders an integrity strip (`role="status"`, teal dot for `OK`, rose plus an issue list for `MISMATCH`), an open-positions table above the closed table, and filters the closed table to `action === "CLOSED"` so partial take-profits are not counted as trades. Field resolution is `pnl_usdt → pnl → net_pnl` and `direction → display_direction → side`.
- `views.js` position cards resolve `unrealized_pnl_usdt → unrealized_pnl → pnl`, `unrealized_pct → unrealized_pnl_pct → pnl_pct`, and `opened_at → entry_time → timestamp`, so PnL, ROI and the timestamp always come from the same snapshot.
- Asset version bumped to `?v=hud12`.

Verified headless against OKX PAPER, 19 assertions per viewport, **0 failures**:

| viewport | equity | cash | realized | unrealized | net PnL | cards | open rows | closed rows | badge |
|---|---|---|---|---|---|---|---|---|---|
| 1280x900 | `$999.87` | `$99.32` | `-$0.30` | `+$1.07` | `+$0.77` | 6 | 6 | 1 | 6 |
| 390x844 | `$999.15` | `$99.32` | `-$0.30` | `+$0.35` | `+$0.05` | 6 | 6 | 1 | 6 |

Both viewports report `historyMeta = "6 terbuka · 1 tertutup"`, `history-integrity ok`, and zero occurrences of `NaN`, `undefined`, `Infinity` or `Waktu belum valid` anywhere in the DOM. Python suite `Ran 252 tests … OK`, Node view suite `7/7 pass`.

## Automatic SPOT/FUTURES Routing (2026-10-22)

The bot no longer hard-maps `LONG → SPOT` and `SHORT → FUTURES`. `market_router.py` scores both venues per candidate and the orchestrator executes the winner.

Decision rules (`MarketRouter.choose`):

- **SHORT → FUTURES, always.** Spot cannot short. If futures is unavailable or disabled for the symbol the candidate is vetoed with `Short requires FUTURES but futures is unavailable`.
- **LONG, both venues available → net-edge comparison.** Score = `expected_move_pct − round-trip fee − funding cost` with a futures liquidation-risk premium (`FUTURES_LIQUIDATION_RISK_PCT`, 0.05%) subtracted, because a leveraged venue carries tail risk spot does not.
  - `expected_move_pct = stop_pct × TP1_R_MULTIPLE`, where `stop_pct = clamp(ATR% × ADAPTIVE_ATR_MULTIPLIER, ROUTER_STOP_FLOOR_PCT, ROUTER_STOP_CAP_PCT)`.
  - `funding cost = funding_rate × 100 × FUNDING_HOLD_PERIODS`; a negative rate is a credit to the chosen side.
  - Fees: spot `EFFECTIVE_FEE_PCT`, futures `FUTURES_FEE_PCT` (0.05% one-way default).
- **LONG switches to FUTURES** when spot is missing, when funding pays the long (`funding_pct ≤ −FUNDING_CREDIT_EDGE_PCT`), when the risk-adjusted futures edge beats spot by more than `AUTO_MARKET_SWITCH_MARGIN_PCT`, or when `FUTURES_MARGIN_ENABLED=true` and leverage frees margin the account does not have.
- **LONG defaults to SPOT** otherwise: no funding, no liquidation.
- **Leverage** is derived, never guessed: `min(FUTURES_AUTO_LEVERAGE_MAX, 100 / (FUTURES_LIQUIDATION_BUFFER_MULT × stop_pct))`, so liquidation distance always stays at least `FUTURES_LIQUIDATION_BUFFER_MULT` times the stop distance.

Wiring:

- `agents/scanner.py` no longer pins `target_market` for LONG (`None` = router decides) and keeps `markets` per ticker so futures-only symbols still produce LONG candidates.
- `orchestrator.run_cycle` calls the router after market data prefetch, fetches the funding rate once per candidate, stores `market_decision` on the candidate and on every `eval_record`.
- `_refresh_execution_plan` re-quotes and re-sizes with the same `leverage`/`market_decision`, so the executed position records the routed venue, leverage and margin instead of silently falling back to 1x.
- `agents/risk_manager.py` charges the futures fee on futures plans and returns `leverage`/`margin_usdt`.
- `agents/portfolio_manager.py` stores `leverage` and `market_decision` on the position.
- `market_operations` telemetry exposes `auto_market_routing`, `market_routing` (spot/futures counts + up to 8 decisions with reason, funding and net edges) and `leverage_applied`.

Env keys: `AUTO_MARKET_ROUTING` (true), `FUTURES_AUTO_LEVERAGE_MAX` (3.0), `FUTURES_LIQUIDATION_BUFFER_MULT` (3.0), `FUTURES_LIQUIDATION_RISK_PCT` (0.05), `FUTURES_FEE_PCT` (0.05), `FUNDING_HOLD_PERIODS` (3), `FUNDING_CREDIT_EDGE_PCT` (0.005), `AUTO_MARKET_SWITCH_MARGIN_PCT` (0.02), `ROUTER_STOP_FLOOR_PCT` (1.0), `ROUTER_STOP_CAP_PCT` (3.5), `FUTURES_MARGIN_ENABLED` (false).

Paper ledger stays notional-based: cash is debited by full notional and `leverage`/`margin_usdt` are recorded for live routing and telemetry, so `cash_reconciliation` invariants are unchanged. `FUTURES_MARGIN_ENABLED` is the opt-in switch for margin-based sizing.

Verified live (OKX PAPER, cycle 1-2): `auto_market_routing: True`, 45/45 candidates routed `FUTURES` (macro circuit breaker suspended longs, so every candidate was SHORT), leverage 3.0 with 33.33% liquidation distance, and two SHORT entries executed (`INJUSDT` 8.145, `ETHUSDT` 2402.0, $150 notional each). Tests: 252 Python OK, 7 Node OK, including 14 router tests and a regression test proving `_refresh_execution_plan` propagates `leverage=3.0` into the plan.

## Why No Position Opened (2026-10-22)

The bot ran 17+ cycles on OKX PAPER with `gates_passed = 0` and zero positions. Two real defects were found and fixed; a third factor is environmental.

**Defect 1 — OKX tickers reported a fake trade count.** `okx_api.get_24hr_tickers()` emitted `"count": 0` for every symbol because OKX's `/api/v5/market/ticker` has no trade-count field. `agents/scanner.py` mapped that to `count_trades = 0`, and the participation gate in `orchestrator.run_cycle` rejected **45 of 45 candidates** with `Thin participation (0 trades/24h < 20,000)` — including BTCUSDT and ETHUSDT.

- `okx_api.py` no longer emits `count`; `scanner.py` maps a missing count to `None` instead of `0`.
- The gate is venue-aware: when `count_trades is None` it applies `config.MIN_QUOTE_VOLUME_24H` (20M USDT/24h) instead of the trade-count floor; Binance keeps the real count gate.
- `agents/specialists.py` treats an unknown count as unknown: no wash-trading veto on `trades < 1_000`, and the Smart Money tracker reports a volume-only signal instead of "$0 average trade size".
- Verified: `gates_passed` went `0 → 20` of 45 in the next cycle, `safety_pass 20/45`.

**Defect 2 — self-evolved machine rules stacked into impossible thresholds.** 32 enforced `AI-*` rules accumulated, six of them for `volume_surge` (floors 1.6, 1.8, 1.9, 2.0, 2.1, 2.2) and three for `trend_efficiency` (0.15, 0.25, 0.30) while `config` itself asks for 0.95 and 0.12. Because `audit_against_experience` returns the first hit, the strictest rule effectively vetoed almost everything (`volume_surge 0.84 < 2.0000`).

- `MACHINE_RULE_METRICS` bounds tightened: `volume_surge (0.5, 1.5)`, `trend_efficiency (0.0, 0.25)`, `spread_pct (0.0, 0.5)`, `bid_depth_ratio (0.0, 3.0)`, `atr_pct (0.0, 3.0)`.
- `_load_memory()` re-clamps every stored `machine_check.threshold` into those bounds, so the existing file was repaired on load.
- `audit_against_experience()` now evaluates the newest rule only per `(metric, direction, operator, action)`, so learned rules supersede instead of pile up.
- Verified on disk after restart: `volume_surge thresholds=[1.5]`, `trend_efficiency thresholds=[0.15, 0.25]`.

The rejection funnel also stopped stripping digits (`5m micro-trigger not aligned` instead of `m micro-trigger not aligned`).

**Remaining, legitimate blockers (not bugs).** After the fixes, 0 of 45 candidates had an empty strategy-failure list, which is what the deterministic executive path requires to approve while the LLM is down:

- Macro circuit breaker active: BTC RSI 29.2 < 42 → `safe_for_longs: false`, `safe_for_shorts: true`, so only SHORT is eligible.
- 41/45 fail the 5m micro-trigger gate (5m candle does not confirm the short).
- 20/45 fail the learned `volume_surge >= 1.5` veto in a quiet tape (0.2-1.0x surge).
- 13/45 fail `trend_efficiency >= 0.25` (choppy regime).
- LLM provider returns `HTTP_401`, `circuit_open: true`, `decision_authority: absolute`, so the executive layer runs `DETERMINISTIC_FALLBACK`, which approves only when strategy failures are empty, consensus holds, conviction clears the bar and external research is healthy.

Tests after all edits: 238 Python OK, 7 Node OK. Backups under `backupcode_coding-high/` for `okx_api.py`, `config.py`, `agents/scanner.py`, `agents/specialists.py`, `agents/consciousness.py`, `orchestrator.py` and `data/agent_consciousness.json`.


## DNS Poisoning Bypass via DoH (2026-10-22)

Both venues appeared "dead" while the API code was correct. Root cause: the ISP resolves `okx.com`, `binance.com`, `api.binance.com` and `fapi.binance.com` to the sinkhole `115.178.182.58`, which blackholes traffic (curl exit 28). A direct hit on the real Cloudflare edge (`--resolve www.okx.com:443:104.18.42.1`) returned HTTP 200, proving the failure was DNS, not the client.

`dns_route.py` installs an in-process DNS-over-HTTPS resolver (Cloudflare, Google, Quad9; TTL cache 600s, endpoint rotation) by patching `urllib3.util.connection.create_connection` only for the configured suffixes, so TLS SNI and certificate validation stay intact — no hardcoded IPs. `ensure_routing()` is called from the Binance and OKX client constructors.

| Env key | Default | Meaning |
|---|---|---|
| `DOH_ROUTING_ENABLED` | `true` | Install the DoH resolver in-process |
| `DOH_ROUTED_HOSTS` | `okx.com,binance.com` | Suffix allow-list for DoH resolution |
| `DOH_CACHE_TTL_SEC` | `600` | Resolver cache TTL |
| `FUTURES_ENDPOINT_COOLDOWN_SEC` | `300` | Per-endpoint futures health cooldown |
| `FUTURES_FEED_BACKOFF_SEC` | `180` | Fail-fast window after a futures feed error |

`dashboard_telemetry.py` reports the active route as `dns_route` (`DOH`/`SYSTEM`) so the HUD shows which path data actually took.

The DoH patch is process-global but only installed on first call, so every module that makes its own HTTP calls must install it. `ExternalResearchAgent.__init__` now calls `ensure_routing()` before building its `requests.Session`; previously it inherited the patch only if an exchange client happened to be constructed first, which silently degraded funding rate, open interest, long/short ratio and taker flow to `null` (`status: PARTIAL`) in any process that built the research agent first. Verified after the fix: both venues report 7/7 healthy sources with real values (Binance funding -0.002%/8h, OI 7.64B USDT, LSR 1.81 LONG_CROWDED, taker 1.18 BUYERS; OKX funding +0.0066%/8h, OI 3.33B USDT, LSR 1.94 LONG_CROWDED, taker 0.73 SELLERS). OKX `mark_price`/`index_price` stay `0.0` because `/api/v5/public/funding-rate` does not return them; the funding rate itself is correct.

## Risk Controls Updated After Paper Ledger Review

- The local `.env` currently sets `TRADING_PROFILE=aggressive` (the code default is `balanced`). The aggressive preset lowers entry score/conviction thresholds and allows more slots; explicit environment variables still override the preset.
- The BTC macro sentinel separately exposes `safe_for_longs` and `safe_for_shorts`: it pauses new altcoin LONG entries when BTC is below EMA50 in a bearish EMA21/EMA50 structure, without disabling all markets or short candidates. Severe panic remains governed by the existing circuit breaker.
- Default stop distance is 1.5 x ATR, with a 1.0% floor and 3.5% ceiling; TP1 is 1.0R and TP2 is 4.0R. TP1 banks 50% and simultaneously moves the stop to a fee-aware break-even (0.60% cushion, or round-trip fees + paper slippage + 0.10%, whichever is larger). The runner trailing stop is floored at that break-even price. Stagnant micro-profit salvage waits 240 minutes and requires at least +1.0% net.
- The local `.env` explicitly sets a maximum of 3 concurrent positions in the same direction. Without an override, the cap is derived from the configured total slots (for the code-default 3 slots, the cap is 2). This is a concurrency limit, not a profitability control.
- Paper stop and trailing exits account for price gaps by filling at the observed market price when it is worse than the stop threshold. A stop is not a guarantee of a capped loss in a gap or illiquid market.
- Dashboard win-rate, profit-factor, expectancy, and exit-reason metrics are scoped to the latest portfolio run count, while the trade-history view remains append-only. This prevents earlier runs from inflating current-run performance metrics.
- These are risk controls, not demonstrated alpha. Historical ledger replay and a small sample are not predictive evidence; do not enable real orders on this basis.

## Sub-Cent Price Precision & Fee-Floor Guard (2026-10-22)

A ledger review of the current paper run (11 closed trades, 1 win / 10 losses, net -6.53 USDT, fees 3.45 USDT) isolated one structural defect, not a market-prediction failure:

- `agents/risk_manager.py` rounded stop-loss, TP1 and TP2 to a fixed 6 decimals. For an asset priced at `0.000005` (SHIBUSDT) a 4R short target computed to `0.0000048` and rounded back onto the entry. The bracket became `TP2 == entry`, so the first price tick satisfied `current_p <= take_profit_2` and the position closed two seconds after entry as `TAKE_PROFIT_2_HIT` with `gross_pnl_usdt = 0.0` and `pnl_usdt = -0.30` — a pure fee loss booked as a take-profit. Two of the eleven losses were exactly this event.
- The same rounding could collapse a stop onto the entry, producing an instant stop-out on any penny asset.

Fixes:

- `round_price()` / `price_decimals()` round to `PRICE_SIG_DIGITS` (default 8) significant digits instead of a fixed 6 decimals, so sub-cent levels keep their resolution.
- The risk desk now fails closed when the bracket is not strictly ordered (`SL > entry > TP1 > TP2` for shorts, mirrored for longs) or when any adjacent gap is below `MIN_TARGET_GAP_PCT` (default 0.05%).
- `PortfolioManagerAgent._degenerate_bracket()` re-validates the same invariant at execution time, before cash is committed or a live order is placed.
- The exit loop requires `abs(entry - TP2) >= MIN_TARGET_GAP_PCT` before it may report `TAKE_PROFIT_2_HIT`, so a legacy position with a collapsed target can no longer close itself as a winner.
- TP1 must clear fees: `MIN_TP1_NET_FEE_MULT` (default 1.0) rejects a plan whose TP1 net of round-trip fees is below one fee leg, so no target is fee-sized.

Regression tests: `tests/test_price_precision.py` (8 tests) covers penny-asset brackets both directions, high-price ordering, the fee floor and the execution-time guard.

## Grok (xAI) Social & Narrative Intel (2026-10-22, optional)

`grok_intel.py` adds an optional social/narrative layer to the external dossier: `GrokIntelAgent` calls an xAI-compatible chat endpoint with live search enabled (`search_parameters.sources = [x, news]`), and returns `sentiment_score` (-100..100), `narrative_strength`, `crowd_positioning`, `confidence`, `summary`, `catalysts` and `risks`.

- Without `XAI_API_KEY`/`GROK_API_KEY` the agent reports `status=DISABLED` and makes zero network calls; the bot behaves exactly as before.
- It degrades instead of raising: a non-JSON answer, a transport error or a provider rejection becomes `status=DEGRADED` with the error text, and the failure is reported per-source in `market_intel.ExternalResearchAgent.collect()`.
- If the provider rejects `search_parameters`, the call is retried once without live search and the result is marked `live_search=false`.
- Responses are untrusted input: control characters are stripped, numeric fields clamped, list fields capped at 3 items and the summary truncated to `GROK_MAX_CHARS` (600).
- Cost control: per-symbol TTL cache (`GROK_TTL_SEC`, 600s), a global minimum interval between calls (`GROK_MIN_INTERVAL_SEC`, 45s) and a hard timeout (`GROK_TIMEOUT_SEC`, 20s).
- Config: `GROK_ENABLED`, `XAI_API_KEY`/`GROK_API_KEY`, `GROK_BASE_URL`, `GROK_MODEL`, `GROK_LIVE_SEARCH`, `GROK_TIMEOUT_SEC`, `GROK_TTL_SEC`, `GROK_MIN_INTERVAL_SEC`, `GROK_MAX_CHARS`. Documented in `.env.example`.

Regression tests: `tests/test_grok_intel.py` (10 tests) covers disabled mode, JSON/fenced-JSON parsing, clamping, sanitisation, cache reuse, live-search fallback and degradation on upstream errors.

## Trade Reviewer Journal: Process vs Outcome (2026-10-22)

`trade_reviewer.py` grades every closed trade in the current run on two separate axes — process (did the trade obey the rules and is the recorded data trustworthy?) and outcome (net PnL) — then appends each review to `data/review_journal.json` (append-only, capped at the last 200 reviews).

- Defect flags: `DEGENERATE_TARGET` (take-profit booked with zero gross), `FEE_ONLY_LOSS` (flat gross, negative net), `FEE_DOMINATED` (the loss is entirely fees), `SUB_MINUTE_HOLD`, `MISSING_TIMESTAMPS`, `MISSING_EXIT_REASON`, `MISSING_DIRECTION`.
- Aggregations: net/avg/win-rate/fees per exit reason, per direction, and the five worst symbols; plus profit factor, payoff ratio, expectancy per trade and fee share of gross profit.
- Verdict ladder: `SAMPLE_TOO_SMALL` (<20 closed trades), `NEGATIVE_EDGE` (PF < 1.0), `FEE_BREAK_EVEN` (1.0 ≤ PF < 1.3), `POSITIVE_EDGE`.
- Run scoping follows `portfolio.counter_since`, so trades from earlier runs can neither flatter nor poison the review.
- CLI: `python3 trade_reviewer.py`. Read-only API: `GET /api/review` (503 with a typed error when the ledger is unreadable).

First run against the current paper ledger (11 closed since `2026-10-22T07:21:30Z`): net -6.53 USDT, gross -5.20, fees 3.45, win rate 9.09% (1W/10L), profit factor 0.196, expectancy -0.594 USDT/trade, process-clean 63.64%, verdict `SAMPLE_TOO_SMALL`. Leaks ranked: `MOMENTUM_TIME_STOP_EXIT` n=7 net -4.42, `STOP_LOSS_HIT` n=1 net -3.10, `TAKE_PROFIT_2_HIT` n=2 net -0.60 (both degenerate targets), `TRAILING_STOP_EXIT` n=1 net +1.59. Flags: FEE_DOMINATED 4, DEGENERATE_TARGET 2, FEE_ONLY_LOSS 2, SUB_MINUTE_HOLD 2.

For contrast, the previous run (130 closed, scoped from its own boundary) produced 35.4% win rate, profit factor 1.04, gross +48.74 USDT against 43.76 USDT of fees — 90% of the gross edge consumed by fees. That run is the honest baseline: the strategy is roughly break-even before costs, so any change in trade frequency, target size or venue fee materially moves the result. Neither sample is large enough for an out-of-sample claim.

Regression tests: `tests/test_trade_reviewer.py` (7 tests) covers defect detection, run scoping, profit factor/fee share math, worst-reason ranking, journal append/cap and empty-ledger handling.

## Approval Gate for Live Orders (2026-10-22)

Live mode no longer executes on its own. With `REQUIRE_APPROVAL_TICKET=true` (default), a signal that passes every deterministic gate and the AI council becomes a ticket in `data/approval_queue.json` instead of an order, and the candidate is marked `AWAITING_APPROVAL`.

- The ticket carries symbol, direction, market, entry, SL, TP1/TP2, quantity, notional, RR, ATR, leverage, conviction, the executive rationale and the entry-metrics snapshot.
- Approval re-quotes before spending money: `POST /api/approvals/{id}/approve` calls `orchestrator.execute_approved_ticket()`, which rebuilds the plan from a fresh order book (adverse-drift check against the ticket entry price) and only then hands it to the portfolio.
- Consumption is atomic and single-use: `APPROVED → CONSUMED` on execution, and replaying a consumed ticket is refused. States: `PENDING`, `APPROVED`, `REJECTED`, `EXPIRED`, `CONSUMED`.
- `PortfolioManagerAgent` refuses any live entry that has no approved ticket, before cash is committed or an order is placed. Paper mode is unchanged (no ticket needed).
- TTL `APPROVAL_TICKET_TTL_SEC` (900s); queue cap `APPROVAL_MAX_PENDING` (20, the oldest pending expires on overflow).
- API authorisation for the mutating endpoints: `APPROVAL_API_TOKEN` (passed as `?token=`) when set, otherwise loopback client addresses only; anything else gets 403. `GET /api/approvals` lists pending plus history.

Regression tests: `tests/test_approval_queue.py` (14 tests) covers ticket lifecycle, mismatch and replay rejection, expiry, overflow, sanitisation, and the live execution gate with a mocked exchange client.

## Daily Brief Routine (2026-10-22)

`daily_brief.py` renders one page from the ledger, the reviewer verdict, the open book and the approval queue: book equity (cash + allocated, explicitly not mark-to-market), run net/fees/win rate/PF, verdict, process-clean percentage, worst leak, and a deterministic action list.

- CLI: `python3 daily_brief.py` (add `--save` to append to `data/daily_brief.json`, capped at the last 60). Read-only API: `GET /api/brief`.
- Actions are derived from numbers only: sample below the floor, profit factor under 1.0, fee share above 60% of gross, an exit reason with n ≥ 3 and negative net, defect flags, and tickets waiting for a decision.
- Scheduling (Termux cron): `0 8 * * * cd /storage/emulated/0/binance-trading-bot && python3 daily_brief.py --save >> logs/brief.log 2>&1`

Regression tests: `tests/test_daily_brief.py` (6 tests) covers equity composition, verdict/action generation, fee-share and degenerate-target actions, pending tickets and journal persistence.

## Playbook Library (2026-10-22)

`playbook_library.py` groups the closed trades of the current run by a setup fingerprint — direction plus RSI bucket, trend-efficiency bucket, ATR% bucket and volume-surge bucket — and reports trades/wins/net/avg/win rate/PF per fingerprint, plus direction totals and the symbols involved.

- Advisory only: no gate, score, size or veto reads it, and the payload says so (`advisory_only: true`). It exists to show which setups actually paid, not to authorise entries.
- `min_sample` (5) marks a fingerprint as `sample_ok: false` below the threshold so small buckets cannot be mistaken for evidence.
- Read-only API: `GET /api/playbooks`.

Regression tests: `tests/test_playbook_library.py` (7 tests) covers bucket fingerprints, grouping, exact/direction/none lookup, run scoping and the small-sample flag.

## Audit Tab on the HUD (2026-10-22)

The dashboard now surfaces the governance layer instead of leaving it API-only. A sixth tab
(`data-tab="audit"`, reachable at `#audit` on desktop and in the mobile tab bar) renders four
read-only endpoints plus the two approval decisions.

- Verdict card: reviewer verdict pill (`SAMPLE_TOO_SMALL`, `NEGATIVE_EDGE`, `FEE_BREAK_EVEN`,
  `POSITIVE_EDGE`) with closed trades, net, gross, fees, win rate, profit factor, expectancy and
  payoff for the active run.
- Mandatory actions: the brief's deterministic action list, rendered verbatim so the HUD and the
  CLI never disagree.
- Approval queue: pending tickets with symbol, side, market, entry, stop, TP1/TP2, notional, R:R,
  rationale and expiry countdown. Approving is a two-step action — the first click arms the button
  for six seconds, the second click sends `POST /api/approvals/{id}/approve`; reject is single-step.
  History shows the last six decisions with the deciding actor.
- Leak table: net, win rate and fees per exit reason. Playbook table: fingerprints sorted by net,
  capped at eight rows, each row flagged `sampel kecil` while `sample_ok` is false.
- Defect card: reviewer defect counters and the single largest leak.

Refresh policy: data loads on tab activation and then every 15s only while the tab is visible; the
header refresh button also refreshes audit when that tab is active. Assets are
`static/js/audit.js` and `static/css/audit.css`, both cache-busted with `?v=hud13`.

An empty approval queue in paper mode is correct behaviour: only live entries become tickets.
Approval POSTs are same-origin without a token, so they succeed only from loopback unless
`APPROVAL_API_TOKEN` is set; the panel prints the 403 reason instead of failing silently.

Regression tests: `tests/test_dashboard_audit.py` (9 tests) asserts the tab and panel exist in both
navigations, every element id referenced by `audit.js` exists in the template, the four GET and two
POST routes are served, tab activation wires `activate()`/`deactivate()`, approve stays two-step,
and no emoji leaks into the audit assets.

## Time-Stop Policy: Fee-Aware Soft Cut + Hard Window (2026-10-22)

The 30-minute momentum time stop used to fire on any trade that had not reached +0.3% once the
15m EMA9 flipped against it. Measured on the live paper ledger, that rule was the dominant exit
(10 of 15 closes) and every one of those exits paid a 0.30 USDT round-trip fee on a trade whose
gross PnL averaged -0.17%: the strategy was booking the exchange fee as a loss, not a market loss.

Reconstruction of 1-minute candles for the same trades showed the structural mismatch:

- Average maximum favourable excursion before the cut: 0.33% (best 0.69%). None of the ten ever
  reached 1%.
- TP1 sits at 1R, and R is the ATR-derived stop (floor 1%, cap 3.5%), so TP1 needs a 1-3.5% move —
  unreachable inside a 30-minute window. Break-even arming also sits at 1R, so nothing protected
  the 0.25-0.69% gains that did appear.
- After the cut, 6 of 10 trades continued in the position's favour by 0.45-1.55% (NEAR 1.55%,
  ACT 1.49%, SUI 1.34%, BTC 0.90%): the exit was early, not wrong about the direction.

The policy is now two-stage:

- Soft window (`TIME_STOP_AFTER_MIN`, 30 min): cuts only when the exit would book a real loss after
  fees, i.e. `net_gain_pct <= TIME_STOP_MIN_NET_GAIN_PCT` (-0.10%), and the EMA9 has flipped. A flat
  or green trade is no longer donated to the exchange as pure fee drag.
- Hard window (`TIME_STOP_HARD_MIN`, 90 min): recycles capital from a trade still under
  `TIME_STOP_MIN_GAIN_PCT` (0.3%) regardless of the EMA state.

Measured again on the run that started 2026-10-22T14:07Z (35 closes, new price precision and the
two-stage policy active), the split was unambiguous:

- `MOMENTUM_TIME_STOP_EXIT`: 26 trades, net -13.14 USDT, 3.9% win rate, 7.85 USDT of fees.
- `TRAILING_STOP_EXIT`: 9 trades, net +11.99 USDT, 100% win rate, average +1.33 USDT.

Inside the time-stop bucket, the 20 soft cuts under 60 minutes accounted for -11.86 USDT, while the
6 hard cuts at 90 minutes only cost -1.28 USDT. Replaying the 20 soft-cut trades on 5-minute candles
and holding them to minute 90 (no stop simulation, so an upper bound) closed +14.21 USDT instead of
-11.86, a +26.07 USDT swing; no trade's worst excursion exceeded 2.3%, so a 3.5% stop would not have
fired. The 30-minute EMA9 flip was noise, not confirmation.

The soft stage is therefore **off by default** (`TIME_STOP_SOFT_ENABLED=false`). The hard 90-minute
window, the stagnation timeout and the micro-profit salvage stay active. Set
`TIME_STOP_SOFT_ENABLED=true` only to re-arm the early cut for a deliberate experiment.

Stagnation timeout (`MAX_HOLD_HOURS_STAGNANT`, 8h) and the micro-profit salvage (240 min) remain as
backstops behind both stages.

Regression tests: `tests/test_time_stop_policy.py` (7 tests) covers the spared flat trade, the cut on
a real loss after fees, the hard-window recycle, the quiet gap between windows, configurability of
the hard window, and that the EMA flip is still required for the soft stage.

## Scan Gate, Policy Epoch & Threshold Drift Bound (2026-10-22)

Live symptom: the loop printed "Cycle finished in 0.09s" with zero candidates and no positions for
hours. `market_operations.scan_direction_filter` was `NONE`: SPOT LONG was macro-blocked
(`safe_for_longs=false`, BTC below EMA50) and FUTURES SHORT was paused by the direction guard, so
`scan_trending_pairs` was called with a filter that matches nothing and returned an empty list. The
HUD still showed SPOT LONG as `WAITING_SETUP`, because the route builder read `safe_to_trade` instead
of `safe_for_longs` for LONG — the display disagreed with the execution gate.

Three repairs:

- `dashboard_telemetry` now derives the LONG route from `safe_for_longs` (falling back to
  `safe_to_trade` only when the field is absent), so a macro block shows as `MACRO_PAUSED`.
- `DIRECTION_GUARD_SINCE` is a policy epoch: the rolling guard only counts trades closed after it,
  because outcomes produced by the removed 30-minute soft cut do not measure the current exit policy.
  The guard still needs `DIRECTION_GUARD_MIN_TRADES` closed trades before it can pause a direction.
- `CONSCIOUSNESS_MAX_THRESHOLD_DRIFT` bounds how far a learned threshold may move from its foundation
  base (default 2.0 = at most twice as strict; 0 disables the bound). Auto-evolution had ratcheted
  `min_trend_efficiency` from 0.12 to 0.36 and `max_spread_pct` from 0.2 to 0.06, which vetoed almost
  every candidate in a choppy tape regardless of setup quality.

After the restart the filter became `SHORT`, 50 candidates were evaluated in the first cycle, and one
SHORT (CROUSDT) executed with a valid bracket. Regression tests: `tests/test_consciousness_drift.py`
(5 tests), the LONG-route case in `tests/test_dashboard_telemetry.py`, and the guard epoch case in
`tests/test_profit_guard.py`.

## Momentum Profit Integrity (2026-10-22)

The paper ledger exposed a structural exit inconsistency, not a market-prediction problem. Of 123 closed trades: 49 `STOP_LOSS_HIT` realised -95.23 USDT, 27 `BREAK_EVEN_STOP_EXIT` realised +6.79 USDT but 20 of those had never reached TP1 and collectively lost -4.33 USDT, while 19 `TRAILING_STOP_EXIT` realised +72.78 USDT and 2 `TP2` realised +23.10 USDT. The old rules armed break-even at +1R but waited for TP1 at +1.5R; price frequently reached +1R, the stop moved to a 0.45% cushion that did not cover fees plus slippage, then reversed. Those exits were labelled break-even while realising small losses.

Changes in this repair:
- TP1 now triggers at +1R and banks 50% at the same moment the stop moves to break-even, so the partial and the protection are one event rather than two competing rules.
- Break-even is fee-aware: `max(0.60%, round-trip fee + paper slippage + 0.10%)`. The trailing stop can never sit below the break-even stop after TP1.
- Pyramiding is opt-in and disabled by default (`ENABLE_PYRAMIDING=false`). When enabled, it requires TP1 already banked, trailing active, no exit already pending, and the add's maximum stop risk plus fee to be fully covered by the realised TP1 profit. An add at TP2 or at a live stop/trail is skipped because it would close immediately and pay a pointless fee.
- Position monitoring uses a 3-second price cache (was 10 seconds) so the 3-second watchdog does not act on a stale quote.
- `MAX_SIGNAL_DRIFT_PCT` (default 0.8%) rejects a signal only when the executable order-book quote has drifted **adversely** from the analysed close; a favorable gap is not treated as a chase.
- Execution is re-quoted after the LLM review: the order book is fetched with cache bypass, adverse drift is re-checked, and the risk plan (entry, stop, TP1/TP2, quantity) is recomputed from the fresh executable quote. A signal older than `MAX_SIGNAL_AGE_SEC` (default 120s) or a fresh quote beyond the drift limit is rejected instead of booking a stale entry.
- Klines cache TTL is capped at the newest bar's time-to-close, and each bar carries an `is_closed` marker captured at fetch time. A mid-bar snapshot can no longer be re-used after that bar closes and be mistaken for a final candle by volume, RSI, EMA or candle-body gates.
- A failed or empty 5m LTF feed is now a hard gate failure. The old `except: pass` let entries through without the micro-trigger confirmation.
- Trade-log dedupe is keyed by `(symbol, action, entry_time)`, so a repeated close for the same entry cannot be appended twice even if the second event carries a different exit timestamp.
- Paper counters are reconstructed from `CLOSED`, `PARTIAL_TP1_TAKEN` and `PYRAMID_ADD` events. `gross_realized_pnl_usdt = realized_pnl_usdt + total_fees_paid_usdt` is enforced on every load, and `cash_reconciliation` reports any persisted-cash mismatch instead of silently presenting a stale balance. The daily/weekly/monthly report and the direction guard both respect `counter_since`, so legacy trades from before a reset cannot inflate current-run metrics. The existing paper book was scoped to the verified `2026-10-20T03:15:55Z` reset boundary (source: `.zsh_history:595`); `trade_history.json` remains append-only and was not rewritten.
- Direction performance guard: after at least 12 closed trades in the last 20 for a direction (scoped to the current run via `counter_since`), a win rate below 30% with negative net PnL pauses new entries in that direction. After 6 hours without a close it allows one probation probe at 0.25x risk, preventing a permanent deadlock. On the current paper ledger this would pause LONG (last 20: 25.0% WR, -2.25 USDT) and keep SHORT (50.0% WR, -2.96 USDT). The dashboard route status is `PERFORMANCE_PAUSED` with the guard reason, not a generic "waiting setup" label. The sample is small; this is a risk control, not proof of alpha.
- Empty `OPENAI_MODEL` now falls back to `coding-high`; `OPENAI_BASE_URL` is read through config. The previous empty model made every AI review fail into deterministic fallback while `configured` still reported true. Provider failures (including HTTP 402 exhausted credits, 429 and 5xx) are now surfaced as `engine_mode=DETERMINISTIC_FALLBACK` with `last_error_kind`; `Retry-After` is honoured by the circuit breaker, so a degraded AI path is visible instead of silently labelled active.

These are risk and accounting repairs. They do not guarantee profit, and the paper sample is too small for an out-of-sample performance claim. Real orders remain disabled unless the operator explicitly configures live keys and accepts the documented limitations.

## AI Absolute Decision Authority & External Research (2026-10-22)

`AI_DECISION_AUTHORITY` controls how the Clouvia review binds:
- `advisory` (legacy): AI dissent only penalises conviction.
- `veto`: AI may reject a deterministic approval.
- `absolute` (currently active in `.env`): the executive AI is the final approver. It may override deterministic strategy gates — momentum score, order-book imbalance, and learned-lesson vetoes — when the external dossier and risk/reward justify it.

Hard risk rails are never delegated to the LLM: live-price/data freshness, spread/liquidity, risk-desk approval, stop-loss and position sizing, daily loss limit, capacity/correlation caps, symbol cooldowns, and the macro circuit breaker still reject before or independently of the AI. `AI_ABSOLUTE_MIN_CONVICTION` (default 60) is a floor; an AI `APPROVE` below it is converted to `REJECT`.

Every absolute review receives a timestamped external dossier from `market_intel.py`:
- Binance Futures funding rate, mark/index price, next funding time.
- Open-interest history (1h change and trend).
- Global long/short account ratio and crowding.
- Taker buy/sell flow and pressure.
- Alternative.me Fear & Greed index.
- CoinDesk and Cointelegraph RSS headlines, with symbol-matched and market-wide sections.

`EXTERNAL_INTEL_MIN_SOURCES` (default 2) and `AI_REQUIRE_EXTERNAL_RESEARCH=true` mean an AI approval is rejected when the dossier is `DEGRADED` or has too few healthy sources. The dossier is cached for `EXTERNAL_INTEL_TTL_SEC` (180s), fetched for at most `AI_RESEARCH_MAX_CANDIDATES` (3) candidates per cycle, and every source failure is reported per-source instead of being hidden.

If the AI provider is unavailable, `query_specialist` returns `engine_mode=DETERMINISTIC_FALLBACK` with `last_error_kind`, and the absolute path falls back to deterministic consensus **but never overrides strategy failures**. This prevents a provider outage from silently becoming an unvetted aggressive entry. `status_summary` exposes `decision_authority` and `external_research_status`; the CLI and dashboard show both. The active model is exactly the model in `.env` (`OPENAI_MODEL`/`CLOUVIA_MODEL`); the current value is `glm5.3-thinking-agentic`. Provider failures remain visible as `DETERMINISTIC_FALLBACK` with `last_error_kind` and never silently become an AI approval.

`cash_reconciliation` is now recomputed on every portfolio save, not only on load. Opening a position previously left a stale `OK` reconciliation while `cash_usdt` had already been reduced by the new position cost.

## AI Self-Evolution: Autonomous Local Intelligence Upgrade (2026-10-22)

The AI is not limited to approving trades. It also upgrades the local intelligence state in `data/agent_consciousness.json`:
- **Triggers**: after every closed trade (`TRADE_CLOSE`) and on the autonomous scheduler (`SCHEDULED_6H`, configurable via `EVOLUTION_INTERVAL_SEC`, default 21600s). Startup runs one cycle before the dashboard starts.
- **Dossier**: recent closed trades with entry metrics, per-direction and per-exit-reason performance, audit summary, current thresholds/weights/rules, portfolio state, and BTC market context from the external-research agent.
- **Output contract**: strict JSON with `calibrated_thresholds`, `dynamic_weights`, and `new_rules`. Each new rule must carry a `machine_check` predicate: metric, operator, threshold, direction, and action.
- **Real enforcement**: machine rules are evaluated first on the executable path (`audit_against_experience` -> `orchestrator.run_cycle`). A `VETO`/`PENALTY_OR_VETO` blocks the candidate and increments the rule's `times_applied`; a `CAUTION` is recorded but does not block. Free-text-only rules are stored as advisory and never counted as enforced.
- **Validation**: thresholds and weights are clamped to sane bounds; unsupported keys are dropped; duplicate machine signatures are rejected; semantically inverted rules (for example vetoing SHORT for low bid depth, which is actually favorable for shorts) are rejected.
- **Persistence**: AI-calibrated thresholds are marked `ai_locked` and are not relaxed by the loss-ratchet staleness decay. A fresh loss explicitly clears that lock for the affected key so live risk protection can take over.
- **Telemetry**: `last_upgrade` records timestamp, trigger, model, version, diagnosis, changed threshold/weight keys, applied counts, and rejected-rule counts. The CLI shows `Last AI Upgrade`; `/api/status` exposes `last_upgrade`, `machine_rule_count`, and `ai_intelligence_level`.
- **Failure behavior**: provider failure falls back to deterministic evolution with `DETERMINISTIC_AUTONOMOUS_FALLBACK`; it never silently claims an AI upgrade. `--no-autonomous-evolve` disables the scheduler.

Empirical startup run: 9 thresholds, 2 weights, and 5 machine rules applied, persisted, and then read back by `audit_against_experience` (for example `AI-VOL-SURGE-001` fired on `volume_surge 1.50 < 1.80`). Subsequent scheduled runs applied further rules without duplicating exact signatures.

## Unlimited Capacity Mode (2026-10-22)

The operator can remove artificial slot caps without disabling risk controls:
- `MAX_OPEN_POSITIONS=0` means unlimited total positions.
- `MAX_CORRELATED_POSITIONS=0` means unlimited same-direction positions.
- `MAX_ENTRIES_PER_DIRECTION_PER_CYCLE=0` means no per-cycle cluster cap.
- `MAX_TOTAL_ALLOCATION_PCT=100` allows the book to use all free cash.
- Spot LONG and Futures SHORT are both enabled (`ENABLE_SPOT_LONGS=true`, `ENABLE_FUTURES_SHORTS=true`).

Unlimited capacity is not unlimited leverage. The natural limits remain: one position per symbol, `MAX_POSITION_SIZE_PCT` per position (currently 15% of equity), available `cash_usdt`, risk per trade, stop loss, daily loss limit, liquidity/spread gates, macro circuit breaker, and AI absolute approval. The portfolio manager rejects an entry when cash is insufficient for the position plus fee.

Implementation details: `0` is the unlimited sentinel in `config.apply_position_slots`, the risk manager skips its slot check, the orchestrator treats available slots as effectively infinite, correlation and per-cycle caps are bypassed, and the dashboard renders `3 / ∞` with "Tanpa batas searah". Tests cover the zero-slot sentinel, the risk agent approving with many open positions, and dashboard capacity rendering.

## Dashboard Reconnect Fix & Telemetry Payload (2026-10-22)

The dashboard was showing `Reconnecting` every 2s even though `/api/status` returned HTTP 200. Root cause was a JavaScript scope error: `capMax` was declared inside `statusBanner()` but used inside `overview()`, so every poll threw `ReferenceError` during `paint()` and the catch block mislabeled it as a network failure.

Fixes:
- Declare `capMax` inside `overview()`; add a Node regression test that renders the summary with `capacity_max=0`.
- Separate fetch failures from render failures: only network/HTTP errors show `Reconnecting`; a render exception logs `Telemetry render error` and keeps the connection pill connected.
- Compact `/api/status`: keep full `specialist_reports`/`executive_verdict` only for the top candidate; subsequent candidates keep summary fields. Live payload dropped from ~794 KB to ~189 KB per 2s poll.
- Asset cache bumped to `pro-9` / `aegis-shell-v13-theme`.

## Trading Profile (Entry Strictness Presets)

`TRADING_PROFILE` in `.env` selects a preset for entry strictness: `conservative`, `balanced` (code default), or `aggressive` (currently active in `.env`). Explicit env knobs (e.g. `MIN_TECHNICAL_SCORE`, `RISK_PER_TRADE_PCT`) always win over the preset. Safety rails — macro circuit breaker, symbol cooldowns, daily loss limit, capacity caps — stay active in every profile. `config.apply_trading_profile()` applies the preset at import; `config.TRADING_PROFILE` reports the active one (printed on every CLI startup).

## Position Slots (Free User Capacity Control)

Concurrent open-position capacity is user-controlled, in priority order:
1. CLI flags: `--slots N`, `--max-same-direction N`, `--position-size-pct P`.
2. Env / `.env`: `MAX_OPEN_POSITIONS` (1-20, validated against `MAX_SLOTS_LIMIT`).
3. First-run prompt: when `MAX_OPEN_POSITIONS` is absent from the environment and stdin is a TTY, the bot asks once, persists the choice into `.env`, and never asks again.

`config.apply_position_slots()` derives `MAX_CORRELATED_POSITIONS` (default min(3, ceil(2/3 of slots))) and `MAX_POSITION_SIZE_PCT` (default min(25, 90/slots)) unless explicitly set. The prompt is skipped automatically on non-interactive runs (no TTY) and in tests.

## Self-Evolution Enforcement (Fixed)

Previous behavior: learned thresholds and RCA rules were written to `data/agent_consciousness.json` but never enforced — division weights fed the Executive Committee (except the Momentum division, whose lookup key mismatched and always defaulted to 1.0), while `audit_against_experience` ran only on the deterministic fallback path with mismatched metric keys (empirical proof: 6207 audits, 0 vetoes enforced). Now:
- Learned lessons (RSI ceiling `EXH-001`, upper-wick `PA-001`, learned volume-surge floor) and calibrated thresholds are audited on the executable deliberation path in `orchestrator.run_cycle` before LLM queries; a violation appends a `Learned Lesson Veto` hard-gate failure.
- Break-even scratches (outcome `SCRATCH` or |pnl_pct| <= 0.05 without outcome) no longer count as learnable losses or rewardable wins.
- Double-learning removed: `orchestrator.run_cycle` is the single learning entry point per exit event (the duplicate call in `portfolio_manager` was removed).
- `apply_ai_upgrade` clamps LLM-proposed weights to [0.5, 2.0] and thresholds to per-key sane bounds; non-numeric values are dropped.
- A corrupt `agent_consciousness.json` is preserved as `.corrupt-<ts>` before reinitialization (no more silent wipe of learned state).
- The Momentum division's learned weight now actually biases the weighted conviction synthesis (role name aligned with the memory key).
- The founder volume-surge floor (1.10x) only vetoes when the threshold was actually learned (deviates from founder default); momentum.py's config gates are unchanged.

## Adaptive Ratchet Staleness Decay (Anti-Deadlock)

Live 2026-10-21: after a loss cluster the deterministic evolution ratcheted `min_volume_surge` to its 1.30 cap while the best market candidate produced only 0.75x — 265 scan cycles, 0 executions, and no path back (wins only raise weights, never relax thresholds). The ratchet was a structural deadlock. Now (`agents/consciousness.py`, `orchestrator.run_cycle`):
- Every scan cycle computes `hours_idle` since the LAST closed outcome and calls `apply_staleness_decay(hours_idle)`: learned thresholds relax linearly from their `ratchet_anchor` (value at the last tightening write) toward the foundation bases, in discrete steps (default one step per 0.5h, full relax after 12h idle; env `THRESHOLD_STALENESS_DECAY_HOURS` / `THRESHOLD_STALENESS_DECAY_STEP_HOURS`).
- A fresh LOSS re-arms to full tightness instantly (`record_trade_failure_and_learn` -> `rearm_thresholds`) BEFORE the incremental +0.02 tightening, so decay only accrues while the system is idle and live protection is never weakened.
- Hard risk gates (daily loss limit, position sizing, stop-loss) are untouched by decay.
- Effective thresholds (the decayed values) are what `audit_against_experience` enforces, and `staleness_decay` (last application: hours idle, fraction, relaxed keys) is surfaced in `get_ultra_context_summary` telemetry.
- Unit tests: `tests/test_staleness_decay.py` (ratchet saturation, interpolation, idempotence, re-arm on loss, win no-rearm, reload persistence, AI-upgrade anchor).

## Loss Cooldown Bypass (2026-10-22)

The post-loss symbol cooldown (`SYMBOL_COOLDOWN_BARS`, default 3 bars) is now a SOFT gate instead of a blanket ban (`orchestrator._cooldown_bypass_decision`):
- A candidate that just lost is allowed to re-enter immediately ONLY when the fresh setup is demonstrably stronger than the normal entry bar: momentum gate passed, technical score >= `min_score_required + SYMBOL_COOLDOWN_BYPASS_SCORE_MARGIN` (default 30), orderbook gate passed with imbalance confirming the trade direction (`>= +0.05` for LONG, `<= -0.05` for SHORT), HTF confluence intact when available, and fewer than `SYMBOL_COOLDOWN_BYPASS_MAX_RECENT_LOSSES` (default 2) real losses on that symbol within `SYMBOL_COOLDOWN_BYPASS_LOOKBACK_HOURS` (default 6h).
- Weak or marginal setups keep the full cooling window; the veto text now reads `Cooldown after loss (...m left) — bypass denied: <reason>`.
- A symbol that keeps bleeding is never bypassed: two real losses inside the lookback window lock it until the window expires.
- `SYMBOL_COOLDOWN_BYPASS_ENABLED=false` restores the old hard cooldown. `SYMBOL_COOLDOWN_BYPASS_RISK_MULT` scales position risk on a bypass (default 1.0 = full size).
- Telemetry: `symbols_in_cooldown` still lists every cooling symbol; allowed bypasses appear in cycle result `cooldown_bypasses` and on each candidate record as `cooldown_bypass` (`allowed`, `reason`, `score`, `imbalance`, `recent_losses`).
- Tests: `tests/test_aggressiveness_fixes.py::TestLossCooldownBypass` plus end-to-end `test_strong_setup_reenters_after_loss_cooldown` / `test_weak_setup_still_respects_loss_cooldown`.

## Security Notes

`WEB_HOST` now defaults to `127.0.0.1` (previously `0.0.0.0`, which exposed the unauthenticated dashboard to the whole LAN). Set `WEB_HOST=0.0.0.0` explicitly only behind a trusted network or reverse proxy with auth. `/api/status` no longer leaks the upstream LLM base URL or provider name (masked in `web_dashboard`; keys remain visible only in local CLI output). `GET /`, `/api/status`, and `/api/health` are registered via `api_route(methods=["GET", "HEAD"])` so `curl -I` probes and uptime monitors work (`@app.get` alone returns `405 Method Not Allowed` for HEAD in this FastAPI/Starlette build).

## Theme System (dark + light)

The dashboard ships a dual-theme design system driven entirely by CSS custom properties. Default is the dark identity; a light theme is one click away via the sun/moon toggle in the header (`#themeToggle`).

- `static/css/base.css` defines every color as a semantic token in `:root` (dark) and overrides them under `html[data-theme="light"]` — surfaces, hairlines, text tiers, semantic accents, header/tabbar/tooltip/canvas-node backgrounds.
- An inline script in `<head>` reads `localStorage("aegis-theme")` **before** stylesheets load, sets `data-theme`, and syncs `meta[name=theme-color]` — zero FOUC, choice persists across reloads.
- `chart.js` and `pipeline.js` read tokens via `getComputedStyle` and rebuild their canvases on theme change (`AegisTheme.onChange`), so the equity curve and deliberation flow recolor instantly.
- All light-theme text pairs pass WCAG 2.2 AA (body >= 4.5:1): text 17.3:1, muted 5.5:1, tertiary 5.4:1, cyan accent 5.9:1, green 5.5:1, red 6.5:1, amber 7.1:1.
- Asset cache version is `v=pro-8` (HTML + `sw.js` shell list, service worker `aegis-shell-v12-theme`) so PWA clients pick up the telemetry/UI changes without stale-cache artifacts.

## Market Operations Dashboard

The first panel on Overview, **Apa yang sedang dijalankan?**, now reports:

- Actual runtime execution mode (PAPER/LIVE), separately from persisted ledger mode; a mismatch is explicitly flagged.
- Always-visible **SPOT LONG** and **FUTURES SHORT** routes, including enabled configuration, macro permission, daily-risk/capacity pauses, candidate counts, quality passes and open-position counts.
- Current scanning/monitoring activity, timestamp of the last completed scan, candidate evaluation and entry counts. The displayed interval is the pause **between** scans, not the total scan duration.
- Per-candidate market, direction, actual gate rejection reasons and execution state. Quality approval is not presented as an executed order. Additional candidates use an expandable native disclosure.
- Public market-data host without credentials, Spot data provenance, analysis timeframes and Futures simulation limitations.
- Venue capability flags (`spot_live_supported`, `futures_live_supported`) plus `data_market`, `data_host`, `dns_route` (`DOH`/`SYSTEM`) and `data_notice`, so the HUD states which venue serves the data instead of implying both are interchangeable.
- Market data is venue-aware: LONG routes read SPOT, SHORT routes read FUTURES/SWAP on the active exchange (`config.EXCHANGE`), so OKX and Binance are both first-class rather than Binance-shaped.
- Stale-data warning on disconnection while retaining last-good information. The service worker caches shell assets only; API telemetry is never cached.
- Explicit market/direction labels on positions and history. Ambiguous legacy closes display **ARAH N/A / Pasar tidak tercatat**, never an invented LONG or SHORT. Labels inferred from explicit direction are marked as such; persisted records are not modified.

### Execution boundaries

PAPER simulates both strategies without sending orders. Prices, candles and depth follow the route's venue: SPOT for LONG, FUTURES/SWAP for SHORT, on the exchange selected by `config.EXCHANGE` (Binance or OKX). The simulated SHORT P&L is `(entry - current) * quantity`; configured Futures leverage is not applied, and real Futures margin, liquidation, funding settlement and contract availability are not modeled.

Live order routing exists for SPOT (`/api/v3/order`) and for Binance Futures (`_futures_order`, with per-endpoint health tracking and a `FUTURES_ENDPOINT_COOLDOWN_SEC` cooldown so a dead endpoint fails fast instead of stalling the cycle); OKX orders go through the v5 signed client. This is code capability, not certification: no LIVE order or exchange connectivity test is performed by dashboard rendering, and LIVE remains off unless explicitly enabled. Verify Futures routing and risk controls on paper before enabling LIVE SHORT.

`dashboard_telemetry.py` builds read-only summaries; `web_dashboard.py` adds `market_operations` to `GET /api/status`. `static/js/operations.js` and `static/css/operations.css` render the panel. `main.py` publishes scan start/completion state and timezone-aware timestamps and binds the dashboard before the first CLI scan. This fixes the former silent `timezone` name error that left cycle telemetry stale.

Open http://localhost:8080 and refresh once after deployment so the updated PWA shell is loaded.

---

## 🏛️ All-Weather Hybrid Architecture (Spot Longs + Futures Shorts)

The system automatically detects macro market regimes and operates bidirectionally:

### 1. Spot Long Execution (Bullish Breakouts)
- Triggered when Bitcoin and candidate assets exhibit bullish momentum and trend alignment.
- Targets clean breakouts with high buyer absorption, rising volume, and safe distance above EMA21.
- Take Profit ladders execute at +2R and +4R above entry price with trailing stop trailing behind peak gains.

### 2. Futures Short Simulation (Bearish Breakdowns)
- Triggered when candidate assets show breakdown structure (Price < EMA9 < EMA21 < EMA50).
- When BTC is in a severe selloff, the Macro Sentinel circuit breaker pauses altcoin longs; a non-panic bearish EMA21/EMA50 structure also pauses longs without globally halting selective shorts. Shorting still requires independent bearish candidate confirmation.
- Mathematical Inverted Risk & PnL:
  * Simulated unrealized PnL: `(Entry Price - Current Price) * Quantity` (no applied leverage)
  * Dynamic Stop Loss placed **above** entry price: `Entry Price + (1.5 * ATR)`
  * Multi-stage Take Profit placed **below** entry price: TP1 at 2.0R, TP2 at 4.0R
  * Trailing stop tracks downward price progression (`lowest_price`), moving stop loss down as profit deepens.
  * Early break-even protection activates at +1R (the same event as TP1) with a fee-aware cushion of at least 0.60%.
- With `EXCHANGE=okx`, SHORT positions are executed on OKX USDT-margined perpetual swaps (real futures) instead of a simulated spot sell.

---

## OKX Spot + Futures Exchange Support (2026-10-22)

`EXCHANGE=okx` switches the whole stack from Binance to OKX without touching the agent logic. Both markets are first-class:

| Direction | OKX instrument | Execution |
|---|---|---|
| LONG | `BTC-USDT` (SPOT) | Market buy by USDT notional (`tgtCcy=quote_ccy`) |
| SHORT | `BTC-USDT-SWAP` (USDT-margined perpetual) | Market sell by USDT notional, `tdMode=cross` (or `isolated`) |

Configuration (`.env`):

```
EXCHANGE=okx
OKX_API_KEY=...
OKX_API_SECRET=...
OKX_API_PASSPHRASE=...
OKX_DEMO=false            # true = OKX simulated-trading environment
OKX_SPOT_ENABLED=true
OKX_FUTURES_ENABLED=true
OKX_MARGIN_MODE=cross     # cross | isolated
FUTURES_LEVERAGE=1.0
```

Implementation notes:
- `okx_api.py` implements the same client contract as `binance_api.py`: 24h tickers, price, klines, orderbook, market orders, server-side TP/SL algo orders, funding rate, balances and positions.
- `exchange_client.py` is the factory selected by `EXCHANGE`; `orchestrator.py` builds exactly one client and passes the target market down through scanner → momentum → orderbook → risk → portfolio.
- OKX symbols are normalized to Binance style (`BTCUSDT`) internally; the client maps them to `BTC-USDT` / `BTC-USDT-SWAP` per call.
- Only crypto instruments (`instCategory=1`) are scanned. OKX tokenized stocks/commodities (`instCategory=3/4`) are excluded so the bot never trades instruments with equity-market hours.
- OKX spot OCO (`ordType=oco`) protects live LONG entries. The client also exposes futures conditional TP/SL (`ordType=conditional`, `reduceOnly=true` or `posSide`); the portfolio keeps polling exits for futures. Full futures closes read the exact live position size in contracts; partial TP1 closes convert base quantity to contracts using `ctVal`/`lotSz`.
- Both OKX position modes are detected automatically via `/api/v5/account/config`: `net_mode` uses `reduceOnly`, `long_short_mode` (hedge) uses `posSide=long/short`. `FUTURES_LEVERAGE` is applied with `set-leverage`; notional sizing keeps `position_usdt` as exposure, so margin used is notional / leverage.
- SHORT funding checks use `/api/v5/public/funding-rate` on the corresponding SWAP instrument.
- `get_24hr_tickers()` merges SPOT + SWAP liquidity and records a `markets` capability list per symbol; the scanner only offers LONG when SPOT exists and SHORT when a SWAP exists.
- Paper mode needs no OKX credentials: market data is public. Live mode requires read + trade permissions (never enable withdrawals).
- Fee assumptions stay controlled by `ESTIMATED_FEE_PCT`; OKX spot taker is typically 0.10% and USDT-M futures taker 0.05%, so set it to `0.05` when running a futures-only live book.
- `tests/test_okx_api.py` covers signature construction, symbol mapping, ticker merge/filtering, kline normalization, spot/futures sizing, OCO/conditional algos, factory selection, scanner capability gating, and portfolio market routing.

---

## Direction-Aware Entry Gate Repair

- `agents/momentum.py` scores 1h and 4h confirmation in the requested direction. Bearish SHORT setups receive points for price below EMA21/EMA50 and a mirrored 4h RSI corridor of 28–52; bullish LONG scoring is unchanged.
- Both higher-timeframe feeds must contain sufficient closed candles. Missing 1h or 4h data blocks entry instead of silently treating partial confirmation as complete.
- SHORT entries cannot combine a bullish higher-timeframe trend with bearish confirmation from another timeframe. Conflicting higher-timeframe structure remains a hard veto.
- `agents/orderbook.py` accepts `direction="LONG"` by default and `direction="SHORT"` explicitly. Sell-side depth imbalance below -0.35 vetoes LONG, not SHORT; buyer absorption above +0.40 vetoes SHORT. Spread limits remain common to both directions.
- `orchestrator.py` forwards candidate direction to the upstream orderbook check, as well as the momentum, risk, and specialist stages.
- Macro regime authorization, position limits, RSI entry limits, volume confirmation, stops, and the executive approval requirement remain enforced. The repair removes contradictory gates; it does not force orders or guarantee immediate entries.
- `tests/test_directional_gates.py` covers valid mirrored LONG/SHORT fixtures, opposing and missing HTF data, liquidity direction, spread protection, and direction propagation. Fixtures are synthetic test data, not historical or live performance evidence.
- The SHORT portfolio lifecycle test uses temporary portfolio and trade-history files. Verification must also use `BOT_DATA_DIR` to isolate consciousness and other persistent state from the running bot.
- SHORT simulation uses the configured market-data feed. A passing paper test does not verify live Futures routing, order execution, or profitability.

## 🏛️ System Reliability & Gridlock Elimination Engine

The system is engineered to solve scanning deadlocks, upstream timeouts, and geographical ISP blocks (such as Indonesian TrustPositif filters on `api.binance.com`).

### Key Reliability Enhancements:
1. **Multi-Endpoint Failover Layer (`binance_api.py`)**:
   - Primary data gateway points to `https://data-api.binance.vision` (unblocked, low-latency institutional Binance Cloud endpoint).
   - Seamless failover across cluster mirrors: `api.binance.com`, `api1.binance.com`, `api2.binance.com`, `api3.binance.com`, `api4.binance.com`, and `api-gcp.binance.com`.
2. **Deterministic Short-Circuit Evaluation (`orchestrator.py`)**:
   - Candidates that do not meet strict technical baselines are evaluated deterministically in sub-millisecond timeframes (0.05 ms).
   - Prevents cascading sequential LLM latency and eliminates scan freezes.
   - Qualified breakout and breakdown candidates trigger parallel deliberation across all specialist divisions via Python `ThreadPoolExecutor`.
3. **Calibrated Momentum & Trend Gates (`agents/momentum.py` & `config.py`)**:
   - Volume surge evaluated across a 3-bar rolling window (>= 1.1x) to catch sustained momentum continuation.
   - Dynamic Trend Efficiency threshold calibrated to realistic crypto volatility (>= 0.12).
   - Long RSI momentum corridor: 45.0 - 74.0.
   - Short RSI momentum corridor: 26.0 - 55.0.
   - 24h Quote Volume threshold calibrated to $2,000,000 USDT (expanding the liquid asset pool across 130+ pairs).
   - Top candidate evaluation quota scaled to 15 assets per cycle (`SCANNER_TOP_LIMIT = 15`).
4. **Adaptive Circuit Breaker (`ai_engine.py`)**:
   - 45.0s per-request timeout with automatic circuit breaker if upstream AI endpoints experience transient network degradation.
5. **Reasoning-Model JSON Resilience (`ai_engine.py`)**:
   - Token budget sized for thinking models: `LLM_MAX_TOKENS` (default 1500, meta-quant calibration uses >= 2000) prevents "Unterminated string" truncation errors that permanently opened the circuit breaker and froze the bot in deterministic-only mode.
   - Multi-stage defensive parser `_parse_json`: strips markdown fences and `−think−`-style reasoning blocks, removes trailing commas, then scans every balanced `{...}` candidate until one yields a valid JSON object (immune to brace-shaped noise in reasoning prose). Truncated output still fails closed to the deterministic fallback.
6. **Adaptive Loss-Streak Guard with Staleness Decay (`orchestrator.py`)**:
   - Consecutive losses tighten technical score and conviction thresholds stepwise (up to `MAX_TIGHTEN_STEPS`), but steps now decay 1 per `TIGHTEN_STALE_DECAY_HOURS` (default 4h) since the last closed trade. Without the decay a cold loss streak locked the executive conviction bar above every candidate forever (deadlock: no trades -> no wins -> no relaxation). A fresh loss re-arms the full guard immediately; hard risk gates (daily loss limit, sizing, stops) are unaffected by the decay.
7. **Single-Instance Discipline (`main.py`)**:
   - Running `main.py --port N` without `--web` silently starts a FULL second scan loop (AUTO-MODE); two loops double the 7-parallel LLM bursts past the router's 10-concurrent cap (HTTP 429 -> permanent circuit open) and race `portfolio.json`. Always verify with `ps -ef | grep main.py` that exactly one loop runs.

---

## 🧠 Ultra-Context AI Engine & Autonomous Sub-Agent Evolution

The system features an autonomous reinforcement and meta-quant intelligence loop:
1. **Dual-Brain Operational Architecture**:
   - **Online Mode (AI Meta-Quant Active)**: The Clouvia LLM acts as the Chief Intelligence Officer. It analyzes recent trade outcomes (wins, losses, scratches, fees) and automatically upgrades dynamic weights, calibrated thresholds, and empirical rules in `agent_consciousness.json`.
   - **Offline / Circuit-Open Mode (100% Deterministic Mastery)**: If the LLM is down, erroring, or timed out, the 8 divisions and 24 sub-agents execute autonomously using their latest upgraded weights and learned thresholds.
2. **Continuous Self-Evolution ("Semakin Lama Semakin Cerdas")**:
   - Trade outcomes trigger immediate learning:
     * On Loss: Conducts Root Cause Analysis (RCA), appends an immutable preventive rule to `agent_consciousness.json`, tightens risk filters (+3% weight on Risk Division), and prevents repeating identical mistakes.
     * On Win: Rewards high-conviction divisions (+0.02 dynamic weight) and adjusts profit extraction ladders.
   - Even in 100% offline mode, the deterministic evolution engine autonomously adapts parameters from live market feedback.

---

## 👑 Corporate Quant Hierarchy: 8 Divisions & 24 Specialized Sub-Agents (32 AI Roles)

To guarantee institutional-grade precision, every division lead is supported by 3 dedicated employee sub-agents who conduct granular quantitative audits:

### Division 1: Market Flow & Narrative (🌐)
Lead: Head of Flow Strategy
- Sub-Agent 1.1: Volume Velocity Analyst (Audits 24h quote volume magnitude vs institutional threshold)
- Sub-Agent 1.2: Smart Money Tracker (Evaluates average trade size & whale block order footprint)
- Sub-Agent 1.3: Trend Corridor Sentinel (Ensures 24h price gains/drops remain inside safe corridor)

### Division 2: Technical Price Action (📈)
Lead: Head Quantitative Chartist
- Sub-Agent 2.1: EMA Trend Alignment Quant (Audits multi-timeframe 1h and 4h EMA 9/21/50 stack and slope)
- Sub-Agent 2.2: Candle Geometry Analyst (Measures close ratio near candle peak & wick rejection)
- Sub-Agent 2.3: Volume Surge Auditor (Validates 3-bar rolling volume surge >= 1.1x)

### Division 3: Momentum & Exhaustion (⚡)
Lead: Head Momentum Auditor
- Sub-Agent 3.1: RSI Velocity Auditor (Audits prime acceleration zone: 45-74 for Longs, 26-55 for Shorts)
- Sub-Agent 3.2: Overbought/Oversold Divergence Guard (Enforces absolute VETO to prevent buying tops or shorting bottoms)
- Sub-Agent 3.3: Mean Reversion Quant (Audits price distance from EMA21 to prevent rubber-band snap)

### Division 4: Order Book Microstructure (🔬)
Lead: Head Market Maker & Liquidity Quant
- Sub-Agent 4.1: Spread & Slippage Guard (Enforces strict spread <= 0.20% to eliminate friction)
- Sub-Agent 4.2: Depth Imbalance Quant (Measures top bid depth vs ask depth wall absorption)
- Sub-Agent 4.3: Order Book Wall Scanner (Detects heavy opposing walls that could cap progression)

### Division 5: Volatility & Market Regime (📡)
Lead: Head Volatility & Regime Analyst
- Sub-Agent 5.1: ATR Volatility Engineer (Measures ATR volatility expansion vs dead chop)
- Sub-Agent 5.2: Trade Velocity Scout (Audits 24h count of trades for active participation)
- Sub-Agent 5.3: Market Noise Filter (Detects low-participation spoofing and wash trading)

### Division 6: Quantitative Risk & Capital (🛡️) - VETO AUTHORITY
Lead: Chief Risk Officer (Holds Absolute Veto)
- Sub-Agent 6.1: Position Sizing Auditor (Enforces 2% max portfolio risk per trade, max 25% single-asset cap)
- Sub-Agent 6.2: Stop Loss Engineer (Calculates ATR 1.5x volatility stop price, 1.0% floor)
- Sub-Agent 6.3: Risk-to-Reward Calculator (Enforces minimum 1:2.0 R:R mathematical positive expectancy)

### Division 7: Profit Extraction & Tactical Exits (🎯)
Lead: Head Profit Extraction Strategist
- Sub-Agent 7.1: Take Profit Architect (Designs 2-stage harvest: TP1 at 50% partial out + break-even lock)
- Sub-Agent 7.2: Trailing Stop Specialist (Arms Dynamic ATR Trailing Stop: scales distance dynamically based on ATR volatility, e.g. 0.8% - 3.5%, trailing 1.8x - 4.5% triggers)
- Sub-Agent 7.3: Fee & Friction Auditor (Guarantees net profitability accounting for Binance round-trip fee)

### Division 8: Executive Investment Committee (👑)
Lead: Managing Director & Executive Judge
- Sub-Agent 8.1: Department Consensus Auditor (Tallies votes, detects any department veto)
- Sub-Agent 8.2: Conviction Weight Synthesizer (Aggregates division scores into firm-wide conviction >= 75%)
- Sub-Agent 8.3: Order Execution Commander (Formulates trade thesis and authorizes execution ticket)

---

## 💎 Senior Trader Quantitative Enhancements

1. **Dynamic ATR Trailing Stop**: Replaces static 1.2% trailing with volatility-scaled trailing distance ($1.0 \times \text{ATR}$ as percentage of price, bounded between 0.8% and 3.5%). Low-volatility majors get tighter trails to lock profit, while high-beta alts get breathing room.
2. **Anti-Short Squeeze Guard**: Protects against capitulation traps and short squeezes by inspecting funding rate crowding ($< -0.03\%$), selling climax exhaustion (RSI $< 27.0$ combined with $> 4.5\%$ stretch below EMA21), and buyer order book absorption walls ($> +30\%$).
3. **Alpha Relative Strength vs Bitcoin**: Compares 4-hour performance of candidates against Bitcoin's benchmark. Rejects LONGs that lag BTC by $> 1.5\%$ (negative alpha), and rejects SHORTs that resist Bitcoin dumps by $> 1.5\%$ (positive alpha).
4. **Multi-Timeframe (MTF) Fast Trigger**: Augments the 15m trend structure with 5m candlestick confirmation (`drop_forming_bar`) to filter out false wicks and sudden intraday rejection bars before execution.
5. **Configurable Outbound Proxy Gateway**: `BinanceClient` supports `BINANCE_PROXY_URL` or standard proxy environment variables for HTTP connectivity. Proxy configuration and optional funding-data requests do not implement or prove live Futures order routing.

---

## ⚡ Clouvia AI Configuration

The bot interfaces with **Clouvia AI Router** (`https://router.clouvia.id/v1`) via the OpenAI Python SDK.

### Environment Setup (`.env`):
```env
TRADING_MODE=paper
INITIAL_PAPER_BALANCE=1000.0

BINANCE_API_URL=https://data-api.binance.vision
BINANCE_API_KEY=[REDACTED]
BINANCE_API_SECRET=[REDACTED]

OPENAI_BASE_URL=https://router.clouvia.id/v1
OPENAI_API_KEY=[REDACTED]
OPENAI_MODEL=<model-yang-ada-di-.env>
CLOUVIA_MODEL=<model-yang-ada-di-.env>

MIN_VOLUME_USDT=2000000
```

---

## 🚀 Usage & Commands

### 1. Execute a Single Instant Diagnostic Scan:
```bash
python3 main.py --scan
```

### 2. Run the Autonomous Live Trading Engine:
```bash
python3 main.py
```
Or customize scan intervals and launch web surveillance simultaneously:
```bash
python3 main.py --run --interval 10 --web
```

### 3. Launch Web Surveillance Dashboard:
```bash
python3 -m uvicorn web_dashboard:app --host 0.0.0.0 --port 8080
```
Open `http://localhost:8080` in your browser.

---

## 🧪 Test Suite & Empirical Verification

Run the comprehensive unit test suite with an isolated state directory:
```bash
BOT_DATA_DIR="$(mktemp -d "$TMPDIR/binance-bot-tests.XXXXXX")" TRADING_MODE=paper python3 -m unittest discover -s tests -v
```
The Python suite currently contains 238 tests, including regression coverage for fee-aware TP1/break-even exits, gross/fee/realized parity after reload, house-money pyramiding, direction performance probation, live-close retry safety, scratch-loss guards, AI-upgrade clamping, corrupt-state preservation, learned-threshold enforcement, Momentum weight readback, trading-profile presets, directional macro gates, paper stop gap-fill pricing, current-run dashboard analytics, AI absolute override/fallback, external-research parsing/caching (Binance and OKX venue shapes), AI self-evolution (machine-rule enforcement, dedupe, semantic rejection, AI-threshold persistence), dashboard unlimited-capacity rendering, and cash-reconciliation refresh. Browser view regressions use Node's built-in runner (7 tests, no npm dependencies):
```bash
node --test tests/test_dashboard_views.cjs
```
The 7 JavaScript tests cover both visible routes, HTML escaping, malformed rows and dates, reconnect behavior, expandable candidate persistence and unavailable telemetry. Fixtures do not send orders. Portfolio fixtures initialize a numeric price before entry to keep equity snapshots deterministic across second boundaries.

For strict unchanged-file hash verification, pause the autonomous runner first; otherwise legitimate background equity/consciousness writes can change hashes during an isolated test run. Never reset or overwrite the live portfolio to make a test pass. No package manifest or SQL database is present; application state is held in the JSON files under `BOT_DATA_DIR`.

## Autonomous Self-Evolution

The CLI registers `--autonomous-evolve` as `store_true` with a default of `True`, so the flag is currently redundant. There is no `--no-autonomous-evolve` option. The scheduler is intended to run an immediate cycle followed by six-hour intervals, but startup output must be checked because the scheduler can fail during initialization; do not assume an evolution cycle completed solely from the configured interval. Verify resulting counters in `/api/status` before relying on learned thresholds.