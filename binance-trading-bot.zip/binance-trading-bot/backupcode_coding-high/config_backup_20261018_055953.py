import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Auto-load .env file if present
ENV_FILE = BASE_DIR / ".env"
if ENV_FILE.exists():
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip("'\""))

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", str(BASE_DIR / "data"))).expanduser().resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

PORTFOLIO_FILE = DATA_DIR / "portfolio.json"
TRADE_LOG_FILE = DATA_DIR / "trade_history.json"

# Binance API configuration
BINANCE_API_URL = os.getenv("BINANCE_API_URL", "https://api.binance.com")
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET", "")

# Operational Mode: 'paper' (simulated with real live Binance prices) or 'live'
TRADING_MODE = os.getenv("TRADING_MODE", "paper").lower()

# Paper Trading Capital
INITIAL_PAPER_BALANCE_USDT = float(os.getenv("INITIAL_PAPER_BALANCE", "1000.0"))

# OpenAI & Custom LLM Endpoint Configuration (Default: Clouvia Router)
CLOUVIA_API_KEY = os.getenv("CLOUVIA_API_KEY", os.getenv("OPENAI_API_KEY", "[REDACTED_SECRET:CLOUVIA_API_KEY]"))
OPENAI_API_KEY = CLOUVIA_API_KEY
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://router.clouvia.id/v1").rstrip("/")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", os.getenv("CLOUVIA_MODEL", "coding-high"))
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.0"))  # 0 = deterministic; money decisions must be reproducible

# Web Visualization Dashboard
WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
WEB_PORT = int(os.getenv("WEB_PORT", "8080"))

# Universal Multi-Quote Pairing Configuration ("Pairing crypto bebas asalkan menguntungkan")
ACCEPTED_QUOTE_ASSETS = ["USDT", "FDUSD", "USDC"]
MIN_24H_VOLUME_USDT = float(os.getenv("MIN_VOLUME_USDT", "8000000"))  # $8M min volume (deeper liquidity = cleaner fills)
MIN_PRICE_CHANGE_24H = float(os.getenv("MIN_CHANGE_PCT", "0.8"))     # +0.8% min 24h change (skip dead/limp markets)
MAX_PRICE_CHANGE_24H = float(os.getenv("MAX_CHANGE_PCT", "22.0"))    # avoid blow-off tops / late-stage pumps (was 55%)
KLINES_TIMEFRAME = os.getenv("TIMEFRAME", "15m")                      # 15-minute primary timeframe
KLINES_LIMIT = 100

# Excluded tokens (stablecoin-to-stablecoin pairs, leveraged tokens, wrapped)
EXCLUDED_SYMBOLS = {
    "USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "EURUSDT", "DAIUSDT", "USDPUSDT",
    "BUSDUSDT", "AEURUSDT", "WBTCUSDT", "WBETHUSDT", "USDCFDUSD", "FDUSDUSDC",
    "EURUSDC", "USDTUSDC", "USDTFDUSD"
}

# Transaction Fee Engine Configuration ("Menghitung transaksi fee")
ESTIMATED_FEE_PCT = float(os.getenv("ESTIMATED_FEE_PCT", "0.10"))  # Standard Binance 0.10% fee per side
BNB_FEE_DISCOUNT = os.getenv("BNB_FEE_DISCOUNT", "false").lower() == "true"
EFFECTIVE_FEE_PCT = ESTIMATED_FEE_PCT * 0.75 if BNB_FEE_DISCOUNT else ESTIMATED_FEE_PCT

# Risk Management & Capital Preservation Guardrails
MAX_OPEN_POSITIONS = 3
RISK_PER_TRADE_PCT = 2.0         # Risk max 2% of total equity on SL
MAX_POSITION_SIZE_PCT = 25.0     # Max 25% of total portfolio in one asset
MIN_RISK_REWARD_RATIO = 1.8      # Minimum NET fee-adjusted R:R (stricter than old gross 2.0)
MAX_ALLOWABLE_SPREAD_PCT = 0.20  # Max spread 0.20%

# Enhanced Win Rate Optimization Parameters (Target: 65-70% Win Rate)
ADAPTIVE_ATR_MULTIPLIER = 1.2    # Tighter ATR multiplier for stops (was 1.5x)
EARLY_BREAK_EVEN_PCT = 1.1       # Proactive break-even at +1.1% profit (locks risk-free sooner)
ENHANCED_MIN_CONVICTION = 78     # Min executive conviction threshold (quality over quantity)
VOLUME_SURGE_FILTER = 1.3        # Require minimum 1.3x volume surge (up from 1.0x)
TREND_TIMEFRAME_1 = "1h"         # Primary trend confirmation timeframe
TREND_TIMEFRAME_2 = "4h"         # Secondary trend alignment timeframe

# Hard Entry Gates (win-rate critical: every gate must pass before committee vote)
MIN_TECHNICAL_SCORE = 78            # Momentum agent minimum composite score (was 72)
REQUIRE_MOMENTUM_PASS = True        # Veto candidate if momentum agent reports passed=False
REQUIRE_ORDERBOOK_PASS = True       # Veto candidate if orderbook agent reports passed=False
MIN_HTF_SCORE = 8                   # Require real higher-timeframe confirmation (1h/4h)
REQUIRE_HTF_CONFIRMATION = True     # Reject when HTF data unavailable/bearish
RSI_ENTRY_MIN = 50.0                # Entry RSI floor (below = no momentum yet)
RSI_ENTRY_MAX = 70.0                # Entry RSI ceiling (above = exhaustion risk)
MAX_DISTANCE_FROM_EMA21_PCT = 4.0   # Reject chasing: price too far above EMA21
MIN_CANDLE_CLOSE_RATIO = 0.55       # Reject weak/wick-dominant entry candles
MAX_ATR_VOLATILITY_PCT = 6.0        # Reject hyper-volatile assets (ATR > 6% of price)
MIN_ORDERBOOK_IMBALANCE = -0.10     # Require neutral-to-bullish book (bid support)
MIN_TRADE_COUNT_24H = 40000         # Require active participation (not a thin market)
MIN_TREND_EFFICIENCY = 0.30         # Regime filter: net move / path travelled over 20 bars
MAX_RANGE_POSITION = 0.95           # Telemetry only (see momentum.py): uptrends sit at range top by definition
SYMBOL_COOLDOWN_BARS = 3            # Bars to wait before re-entering a symbol after a loss
MAX_CORRELATED_POSITIONS = 2        # Cap simultaneous high-beta altcoin longs
USE_CLOSED_BARS_ONLY = True         # Decisions use closed candles (never the forming bar)

# Adaptive Regime Guard (auto-tightens filters after losses, loosens on healthy streaks)
ADAPTIVE_GATES_ENABLED = True
LOSS_STREAK_TIGHTEN_AFTER = 2       # Consecutive losses before tightening
LOSS_STREAK_SCORE_BONUS = 6         # Extra required score per tighten step
LOSS_STREAK_CONVICTION_BONUS = 4    # Extra required conviction per tighten step
MAX_TIGHTEN_STEPS = 3               # Cap tightening so bot never freezes permanently
DAILY_LOSS_LIMIT_PCT = 4.0          # Pause new entries after -4% equity day (capital guard)

# Dynamic Exit & Profit Scaling Rules (70% target without sacrificing expectancy)
BREAK_EVEN_BUFFER_PCT = 0.25        # Move Stop Loss to Entry + 0.25% (covers round-trip fees + slippage)
TRAILING_STOP_TRIGGER_PCT = 2.2     # Do not choke winners before they reach meaningful profit
TRAILING_STOP_DISTANCE_PCT = 1.2    # Fallback only; actual trail is ATR / original-risk adaptive
HARD_STOP_LOSS_DEFAULT_PCT = 2.0    # Fallback max stop loss if ATR not available
TARGET_TAKE_PROFIT_PCT = 4.5        # Target minimum take-profit level
MAX_HOLD_HOURS_STAGNANT = 8.0       # Exit stagnant trades after 8h (fast capital recycle)
TP1_R_MULTIPLE = 1.25               # TP1 at 1.25R balances hit-rate and net expectancy
TP2_R_MULTIPLE = 3.0                # Let the 35% runner compound into asymmetric returns
FASTER_TP1_RATIO = 0.50             # Bank half; retain half for 3R (was 65%, which crushed expectancy)
MICRO_PROFIT_SALVAGE_PCT = 0.45     # Rescue-close a stalling position at >= +0.45% net instead of risking reversal
MICRO_PROFIT_SALVAGE_AFTER_MIN = 150  # Only salvage after position has aged this many minutes
PAPER_SLIPPAGE_BASE_PCT = 0.05      # Per-leg base simulated slippage (paper realism)
PAPER_SLIPPAGE_ATR_FACTOR = 0.04    # Extra slippage as a fraction of entry ATR%
PAPER_SLIPPAGE_MAX_PCT = 0.35       # Cap normal simulated slippage; no fantasy exact fills
LLM_VETO_ONLY = True                # AI may veto/down-rank, never approve what deterministic gates reject
LLM_CIRCUIT_FAILURES = 3            # Disable failed provider after N consecutive calls
LLM_CIRCUIT_COOLDOWN_SEC = 300      # Deterministic mode for 5 min before probing provider again

# Macro Market Sentinel (Bitcoin Beta & Global Circuit Breaker)
MACRO_BENCHMARK_SYMBOL = "BTCUSDT"
MACRO_CIRCUIT_BREAKER_ENABLED = True
MACRO_MIN_BTC_RSI = 42.0            # Veto altcoin entries if Bitcoin RSI < 42 (market selloff)
