import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

ENV_FILE = BASE_DIR / ".env"
if ENV_FILE.exists():
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip("'\""))

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", str(BASE_DIR / "data"))).expanduser().resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

PORTFOLIO_FILE = DATA_DIR / "portfolio.json"
TRADE_LOG_FILE = DATA_DIR / "trade_history.json"

BINANCE_API_URL = os.getenv("BINANCE_API_URL", "https://data-api.binance.vision")
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET", "")

TRADING_MODE = os.getenv("TRADING_MODE", "paper").lower()

INITIAL_PAPER_BALANCE_USDT = float(os.getenv("INITIAL_PAPER_BALANCE", "1000.0"))

CLOUVIA_API_KEY = os.getenv("CLOUVIA_API_KEY", os.getenv("OPENAI_API_KEY", ""))
OPENAI_API_KEY = CLOUVIA_API_KEY
OPENAI_BASE_URL = os.getenv("CLOUVIA_BASE_URL", os.getenv("OPENAI_BASE_URL", "https://router.clouvia.id/v1")).rstrip("/")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", os.getenv("CLOUVIA_MODEL", "coding-high"))
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.0"))
LLM_TIMEOUT = float(os.getenv("LLM_TIMEOUT", "45.0"))

WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
WEB_PORT = int(os.getenv("WEB_PORT", "8080"))

ACCEPTED_QUOTE_ASSETS = ["USDT", "FDUSD", "USDC"]
MIN_24H_VOLUME_USDT = float(os.getenv("MIN_VOLUME_USDT", "2000000"))
MIN_PRICE_CHANGE_24H = float(os.getenv("MIN_CHANGE_PCT", "0.8"))
MAX_PRICE_CHANGE_24H = float(os.getenv("MAX_CHANGE_PCT", "28.0"))
SCANNER_TOP_LIMIT = int(os.getenv("SCANNER_TOP_LIMIT", "25"))
KLINES_TIMEFRAME = os.getenv("TIMEFRAME", "15m")
KLINES_LIMIT = 100

EXCLUDED_SYMBOLS = {
    "USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "EURUSDT", "DAIUSDT", "USDPUSDT",
    "BUSDUSDT", "AEURUSDT", "WBTCUSDT", "WBETHUSDT", "USDCFDUSD", "FDUSDUSDC",
    "EURUSDC", "USDTUSDC", "USDTFDUSD"
}

ESTIMATED_FEE_PCT = float(os.getenv("ESTIMATED_FEE_PCT", "0.10"))
BNB_FEE_DISCOUNT = os.getenv("BNB_FEE_DISCOUNT", "false").lower() == "true"
EFFECTIVE_FEE_PCT = ESTIMATED_FEE_PCT * 0.75 if BNB_FEE_DISCOUNT else ESTIMATED_FEE_PCT

MAX_OPEN_POSITIONS = 3
RISK_PER_TRADE_PCT = 2.0
MAX_POSITION_SIZE_PCT = 25.0
MIN_RISK_REWARD_RATIO = 1.8
MAX_ALLOWABLE_SPREAD_PCT = 0.20

ADAPTIVE_ATR_MULTIPLIER = 1.2
EARLY_BREAK_EVEN_PCT = 1.1
ENHANCED_MIN_CONVICTION = 75
# 3-bar rolling max must reach at least the 20-bar average. 1.1x rejected
# steady healthy trends (live 2026-10-19: 19/40 candidates, SOLUSDT at 1.03x
# was the ONLY failing gate). Higher surges still earn more technical score.
VOLUME_SURGE_FILTER = float(os.getenv("VOLUME_SURGE_FILTER", "1.0"))
VOLUME_SURGE_WINDOW_BARS = int(os.getenv("VOLUME_SURGE_WINDOW_BARS", "3"))
TREND_TIMEFRAME_1 = "1h"
TREND_TIMEFRAME_2 = "4h"

MIN_TECHNICAL_SCORE = int(os.getenv("MIN_TECHNICAL_SCORE", "70"))
REQUIRE_MOMENTUM_PASS = True
REQUIRE_ORDERBOOK_PASS = True
MIN_HTF_SCORE = 8
REQUIRE_HTF_CONFIRMATION = True
RSI_ENTRY_MIN = 45.0
RSI_ENTRY_MAX = 74.0
MAX_DISTANCE_FROM_EMA21_PCT = 4.8
MIN_CANDLE_CLOSE_RATIO = 0.40
MAX_ATR_VOLATILITY_PCT = 6.0
MIN_ATR_VOLATILITY_PCT = float(os.getenv("MIN_ATR_VOLATILITY_PCT", "0.15"))  # 15m ATR % floor (Regime division)
MIN_ORDERBOOK_IMBALANCE = -0.35
SHORT_MAX_ORDERBOOK_IMBALANCE = 0.40
MIN_TRADE_COUNT_24H = 20000
MIN_TREND_EFFICIENCY = 0.12
# Relaxed choppiness floor, used ONLY when independent evidence confirms the
# trend: perfect 15m EMA stack in the trade direction AND full 1h+4h HTF
# confluence (htf_score >= MIN_HTF_CONFLUENCE_SCORE). Intraday 15m noise lowers
# net/path efficiency even inside clean multi-timeframe trends (BNBUSDT live:
# score 185, HTF 16, efficiency 0.077 -> rejected on that gate alone).
MIN_TREND_EFFICIENCY_CONFLUENCE = float(os.getenv("MIN_TREND_EFFICIENCY_CONFLUENCE", "0.06"))
MIN_HTF_CONFLUENCE_SCORE = 13
MAX_RANGE_POSITION = 0.95
SYMBOL_COOLDOWN_BARS = 3
# Cap of concurrent positions in the SAME direction (correlated beta exposure).
# An opposite-direction position is a hedge, not a correlated bet.
MAX_CORRELATED_POSITIONS = int(os.getenv("MAX_CORRELATED_POSITIONS", "2"))
FUNDING_RATE_SQUEEZE_THRESHOLD = -0.0003  # Binance lastFundingRate is a fraction: -0.0003 == -0.03% per 8h
FUNDING_FETCH_BACKOFF_SEC = 900
USE_CLOSED_BARS_ONLY = True

ADAPTIVE_GATES_ENABLED = True
LOSS_STREAK_TIGHTEN_AFTER = 2
LOSS_STREAK_SCORE_BONUS = 6
LOSS_STREAK_CONVICTION_BONUS = 4
MAX_TIGHTEN_STEPS = 3
DAILY_LOSS_LIMIT_PCT = 4.0

BREAK_EVEN_BUFFER_PCT = 0.25
TRAILING_STOP_TRIGGER_PCT = 2.2
TRAILING_STOP_DISTANCE_PCT = 1.2
HARD_STOP_LOSS_DEFAULT_PCT = 2.0
TARGET_TAKE_PROFIT_PCT = 4.5
MAX_HOLD_HOURS_STAGNANT = 8.0
TP1_R_MULTIPLE = 1.25
TP2_R_MULTIPLE = 3.0
FASTER_TP1_RATIO = 0.50
MICRO_PROFIT_SALVAGE_PCT = 0.45
MICRO_PROFIT_SALVAGE_AFTER_MIN = 150
PAPER_SLIPPAGE_BASE_PCT = 0.05
PAPER_SLIPPAGE_ATR_FACTOR = 0.04
PAPER_SLIPPAGE_MAX_PCT = 0.35
LLM_VETO_ONLY = True
# "advisory" (default): AI dissent = conviction penalty, cannot single-handedly
# block a trade the deterministic engine approved. "veto": legacy hard veto.
LLM_VETO_MODE = os.getenv("LLM_VETO_MODE", "advisory").lower()
LLM_DISSENT_PENALTY = int(os.getenv("LLM_DISSENT_PENALTY", "12"))
LLM_CIRCUIT_FAILURES = 3
LLM_CIRCUIT_COOLDOWN_SEC = 300

MACRO_BENCHMARK_SYMBOL = "BTCUSDT"
MACRO_CIRCUIT_BREAKER_ENABLED = True
MACRO_MIN_BTC_RSI = 42.0
# Shorts pause only on a BTC melt-up. In an ordinary bullish regime shorts stay
# "selective": the asset must show bearish 1h+4h structure and lag BTC.
MACRO_SHORT_SQUEEZE_RSI = float(os.getenv("MACRO_SHORT_SQUEEZE_RSI", "76"))
MACRO_SHORT_SQUEEZE_PUMP_4H_PCT = float(os.getenv("MACRO_SHORT_SQUEEZE_PUMP_4H_PCT", "2.5"))
SELECTIVE_SHORT_MAX_ALPHA_PCT = float(os.getenv("SELECTIVE_SHORT_MAX_ALPHA_PCT", "-0.5"))
SELECTIVE_SHORT_MIN_HTF_SCORE = int(os.getenv("SELECTIVE_SHORT_MIN_HTF_SCORE", "13"))
SELECTIVE_SHORT_RISK_MULT = float(os.getenv("SELECTIVE_SHORT_RISK_MULT", "0.5"))

ENABLE_BI_DIRECTIONAL_TRADING = os.getenv("ENABLE_BI_DIRECTIONAL", "true").lower() == "true"
ENABLE_SPOT_LONGS = os.getenv("ENABLE_SPOT_LONGS", "true").lower() == "true"
ENABLE_FUTURES_SHORTS = os.getenv("ENABLE_FUTURES_SHORTS", "true").lower() == "true"
FUTURES_DEFAULT_LEVERAGE = float(os.getenv("FUTURES_LEVERAGE", "1.0"))
SHORT_RSI_ENTRY_MAX = 55.0
SHORT_RSI_ENTRY_MIN = 26.0

USE_DYNAMIC_ATR_TRAILING = True
TRAILING_ATR_MULTIPLIER = 1.0
REQUIRE_RELATIVE_STRENGTH_FILTER = True
ENABLE_ANTI_SHORT_SQUEEZE_GUARD = True
LTF_TIMEFRAME = "5m"
REQUIRE_LTF_CONFIRMATION = True
BINANCE_PROXY_URL = os.getenv("BINANCE_PROXY_URL", os.getenv("HTTPS_PROXY", os.getenv("HTTP_PROXY", "")))
