(function () {
  'use strict';

  const U = window.AegisUtil;

  const ICONS = {
    scanner: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 12l6-4"/>',
    orderbook: '<path d="M4 18V8M9 18V4M14 18v-6M19 18v-9"/>',
    momentum: '<path d="M3 17l5-6 4 3 4-7 5 4"/><path d="M3 21h18"/>',
    research: '<circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/>',
    risk: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M12 9v4M12 16h.01"/>',
    portfolio: '<path d="M3 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="16" cy="13" r="1.4"/>',
    execution: '<path d="M13 2L4 14h6l-1 8 9-12h-6z"/>',
    default: '<rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M8 12h.01M16 12h.01M9 16h6"/>'
  };

  const svg = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.default}</svg>`;

  const get = (d, path, fallback) => {
    const parts = String(path).split('.');
    let cur = d;
    for (let i = 0; i < parts.length; i += 1) {
      if (cur === null || cur === undefined || typeof cur !== 'object') return fallback;
      cur = cur[parts[i]];
    }
    return cur === undefined || cur === null ? fallback : cur;
  };

  const arr = (value) => (Array.isArray(value) ? value : []);

  const agentList = (d) => {
    const raw = get(d, 'agents', get(d, 'agent_status', get(d, 'agent_consciousness', null)));
    if (Array.isArray(raw)) return raw.filter((a) => a && typeof a === 'object');
    if (raw && typeof raw === 'object') {
      return Object.keys(raw).map((key) => {
        const value = raw[key];
        if (value && typeof value === 'object') {
          return Object.assign({ name: key }, value, {
            message: value.message || value.consciousness_focus || value.summary || '',
            status: value.status || (Number(value.total_audits) > 0 ? 'ACTIVE' : 'IDLE')
          });
        }
        return { name: key, status: String(value) };
      });
    }
    return [];
  };

  const agentKey = (agent) => {
    const text = `${agent.name || ''} ${agent.role || ''} ${agent.id || ''}`.toLowerCase();
    if (text.includes('scan')) return 'scanner';
    if (text.includes('order') || text.includes('book')) return 'orderbook';
    if (text.includes('moment') || text.includes('trend')) return 'momentum';
    if (text.includes('research') || text.includes('intel') || text.includes('news')) return 'research';
    if (text.includes('risk') || text.includes('guard') || text.includes('veto')) return 'risk';
    if (text.includes('portfolio') || text.includes('alloc')) return 'portfolio';
    if (text.includes('exec') || text.includes('order_router')) return 'execution';
    return 'default';
  };

  const statusTag = (status) => {
    const s = String(status || '').toUpperCase();
    if (/APPROVE|OK|PASS|READY|GO|ACTIVE|RUNNING/.test(s)) return 'ok';
    if (/VETO|BLOCK|REJECT|FAIL|DENY/.test(s)) return 'bad';
    if (/WAIT|PAUSE|HOLD|COOLDOWN|PENDING/.test(s)) return 'warn';
    return 'info';
  };

  const agents = (d) => {
    const data = d || {};
    const list = agentList(data);
    const scan = get(data, 'latest_scan', {});
    const loop = get(data, 'autonomous_loop', {});
    const cycleStamp = get(scan, 'completed_at', get(scan, 'last_updated', get(data, 'generated_at', '')));
    const agentStamp = (agent) => {
      const raw = agent.updated_at || agent.timestamp || agent.last_audit_at || agent.last_seen_at || cycleStamp;
      return raw ? U.stamp(raw) : '—';
    };
    const symbol = String(get(scan, 'symbol', get(data, 'pipeline_symbol', '')) || '');
    const pairs = U.safe(get(scan, 'candidates_scanned', 0));
    const cycles = U.safe(get(loop, 'cycle_count', get(loop, 'cycles_completed', 0)));
    const venue = String(get(data, 'exchange', get(data, 'venue', '')) || '').toUpperCase();
    const flowMeta = [symbol || null, `${U.num(pairs, 0)} pair`, `siklus ${U.num(cycles, 0)}`, venue || null]
      .filter(Boolean).join(' · ');
    U.setText('pipelineSymbol', symbol ? `pipeline ${symbol}` : flowMeta || 'pipeline idle');
    U.setText('gateSymbol', symbol || '—');

    const el = document.getElementById('agents');
    if (el) {
      if (!list.length) {
        el.innerHTML = '<div class="agent-bubble"><div class="agent-avatar">' + svg('default') + '</div>'
          + '<div class="agent-body"><div class="agent-top"><span class="agent-name">AEGIS</span></div>'
          + '<div class="agent-say">Belum ada laporan agen pada siklus ini. Pipeline menunggu kandidat pertama.</div></div></div>';
      } else {
        el.innerHTML = list.map((agent) => {
          const key = agentKey(agent);
          const status = String(agent.status || agent.verdict || 'IDLE').toUpperCase();
          const tone = statusTag(status);
          const say = agent.message || agent.summary || agent.verdict_text || agent.reason || 'Tidak ada catatan.';
          const confidence = agent.confidence !== undefined ? U.safe(agent.confidence) : null;
          const latency = agent.latency_ms !== undefined ? U.safe(agent.latency_ms) : null;
          const audits = agent.total_audits !== undefined ? U.safe(agent.total_audits) : null;
          const tags = [`<span class="tag ${tone}">${U.esc(U.title(status))}</span>`];
          if (audits !== null) tags.push(`<span class="tag info">${U.num(audits, 0)} audit</span>`);
          if (confidence !== null) tags.push(`<span class="tag info">conf ${U.pct(confidence <= 1 ? confidence * 100 : confidence, 0)}</span>`);
          if (latency !== null && latency > 0) tags.push(`<span class="tag">${U.num(latency, 0)}ms</span>`);
          return `<div class="agent-bubble"><div class="agent-avatar">${svg(key)}</div>`
            + `<div class="agent-body"><div class="agent-top"><span class="agent-name">${U.esc(U.title(agent.name || agent.role || 'agent'))}</span>`
            + `<span class="agent-time">${U.esc(agentStamp(agent))}</span></div>`
            + `<div class="agent-say">${U.esc(say)}</div>`
            + `<div class="agent-tags">${tags.join('')}</div></div></div>`;
        }).join('');
      }
    }

    const gate = document.getElementById('gateBody');
    if (gate) {
      const checks = arr(get(data, 'quality_gate_checks', get(data, 'gate_checks', [])));
      if (!checks.length) {
        const gates = get(data, 'quality_gates', {});
        const keys = Object.keys(gates).slice(0, 8);
        gate.innerHTML = keys.length
          ? keys.map((k) => {
            const v = gates[k];
            const text = typeof v === 'number' ? U.num(v, 2) : String(v);
            return `<div class="gate-item"><span>${U.esc(U.title(k))}</span><b>${U.esc(text)}</b></div>`;
          }).join('')
          : '<div class="gate-empty">Belum ada konfigurasi gate yang dilaporkan.</div>';
      } else {
        gate.innerHTML = checks.map((c) => {
          const ok = c.passed !== false;
          return `<div class="gate-item"><span>${U.esc(U.title(c.name || c.gate || 'gate'))}</span>`
            + `<b class="${ok ? 'positive' : 'negative'}">${ok ? 'LOLOS' : 'GAGAL'}</b></div>`;
        }).join('');
      }
    }

    const model = document.getElementById('modelInfo');
    if (model) {
      const llm = get(data, 'ai_status', get(data, 'llm_status', {}));
      const name = get(llm, 'model', '—');
      const engineMode = get(llm, 'engine_mode', '');
      const circuit = get(llm, 'circuit_open', false);
      const configured = get(llm, 'configured', null);
      const parts = [String(name)];
      if (engineMode) parts.push(String(engineMode).toLowerCase().replace(/_/g, ' '));
      if (circuit) parts.push('circuit open');
      else if (configured === false) parts.push('belum terkonfigurasi');
      else if (configured === true) parts.push('siap');
      model.textContent = parts.join(' · ');
    }
  };

  const history = (d) => {
    const data = d || {};
    const summary = get(data, 'history_summary', {}) || {};
    const trades = arr(get(data, 'trade_history', get(data, 'recent_trades', [])));
    // Never mix legacy events from a previous run into the current journal: a
    // reset moves counter_since forward while trade_history.json still holds
    // old CLOSED rows. The summary counts the current run, so the table must
    // use the same boundary or it shows 40 "closed" rows beside "0 tertutup".
    const scopeSince = String(get(data, 'counter_since', '') || '');
    const inCurrentRun = (trade) => {
      if (!scopeSince) return true;
      const stamp = String(trade.closed_at || trade.exit_time || trade.timestamp || '');
      return Boolean(stamp) && stamp >= scopeSince;
    };
    const closedTrades = trades.filter((t) => {
      const action = String(t.action || '').toUpperCase();
      return (!action || action === 'CLOSED') && inCurrentRun(t);
    });
    const openTrades = arr(get(data, 'open_trades', []));
    const closedCount = U.safe(summary.closed !== undefined ? summary.closed : trades.length);
    const openCount = U.safe(summary.open !== undefined ? summary.open : openTrades.length);
    U.setText('historyMeta', `${openCount} terbuka · ${closedCount} tertutup`);

    const integrity = document.getElementById('historyIntegrity');
    if (integrity) {
      const issues = arr(summary.issues);
      const ok = String(summary.integrity || 'OK').toUpperCase() === 'OK' && !issues.length;
      integrity.hidden = false;
      integrity.className = `history-integrity ${ok ? 'ok' : 'bad'}`;
      const fees = U.num(U.safe(summary.fees_usdt), 2);
      const realized = U.signed(U.safe(summary.realized_usdt));
      const unrealized = U.signed(U.safe(summary.unrealized_usdt));
      const head = ok
        ? `Data sinkron dengan ledger · fee $${fees} · realized ${realized} · unrealized ${unrealized}`
        : 'Data tidak sinkron dengan ledger';
      integrity.innerHTML = `<span class="integrity-dot" aria-hidden="true"></span><span class="integrity-text">${U.esc(head)}</span>`
        + (issues.length ? `<ul class="integrity-issues">${issues.map((issue) => `<li>${U.esc(issue)}</li>`).join('')}</ul>` : '');
    }

    const openMeta = U.$('openTradesMeta');
    if (openMeta) openMeta.textContent = openTrades.length ? `${openTrades.length} posisi berjalan` : 'tidak ada posisi terbuka';
    const openBody = U.$('openTradeBody');
    if (openBody) {
      if (!openTrades.length) {
        openBody.innerHTML = '<tr class="empty-row"><td colspan="8">Tidak ada posisi terbuka.</td></tr>';
      } else {
        openBody.innerHTML = openTrades.map((t) => {
          const side = String(t.direction || '').toUpperCase();
          const sideClass = side === 'LONG' ? 'long' : side === 'SHORT' ? 'short' : 'unknown';
          const pnl = U.safe(t.pnl_usdt);
          return `<tr><td class="t-symbol">${U.esc(t.symbol || '—')}</td>`
            + `<td><span class="side-badge ${sideClass}" style="margin:0">${U.esc(side || 'N/A')}</span></td>`
            + `<td>${U.esc(String(t.market || '—').toUpperCase())}</td>`
            + `<td>${U.price(U.safe(t.entry_price))}</td>`
            + `<td>${t.current_price === null || t.current_price === undefined ? '—' : U.price(U.safe(t.current_price))}</td>`
            + `<td class="${U.cls(pnl)}">${U.signed(pnl)}</td>`
            + `<td class="${U.cls(U.safe(t.pnl_pct))}">${U.signedPct(U.safe(t.pnl_pct), 2)}</td>`
            + `<td>${U.esc(U.dateTime(t.opened_at))}</td></tr>`;
        }).join('');
      }
    }

    const quality = document.getElementById('qualityStrip');
    if (quality) {
      const pf = U.safe(get(data, 'profit_factor', 0));
      const rolling = U.safe(get(data, 'rolling_win_rate_20', 0));
      const cells = [
        ['Win rate', U.pct(U.safe(get(data, 'win_rate', 0)), 1)],
        ['Profit factor', pf > 0 ? pf.toFixed(2) : '—'],
        ['Rolling WR 20', rolling > 0 ? U.pct(rolling, 1) : '—'],
        ['Trade tertutup', U.num(U.safe(get(data, 'total_trades', 0)), 0)]
      ];
      quality.innerHTML = cells.map(([k, v]) => `<div class="quality-cell"><span>${U.esc(k)}</span><b>${U.esc(v)}</b></div>`).join('');
    }

    const exits = document.getElementById('exitBreakdown');
    if (exits) {
      const raw = get(data, 'exit_reason_breakdown', get(data, 'exit_reasons', get(data, 'exit_breakdown', null)));
      const rowsIn = Array.isArray(raw)
        ? raw
        : raw && typeof raw === 'object'
          ? Object.keys(raw).map((key) => ({ reason: key, count: raw[key] }))
          : [];
      const max = Math.max(1, ...rowsIn.map((r) => U.safe(r.count)));
      exits.innerHTML = rowsIn.length
        ? rowsIn.map((r) => {
          const count = U.safe(r.count);
          return `<div class="exit-row"><div class="exit-name">${U.esc(U.title(r.reason || r.name || 'lain'))}</div>`
            + `<div class="exit-count">${U.num(count, 0)}</div>`
            + `<div class="exit-bar"><i style="width:${Math.round((count / max) * 100)}%"></i></div></div>`;
        }).join('')
        : '<div class="gate-empty">Belum ada trade tertutup.</div>';
    }

    const body = document.getElementById('tradeBody');
    if (body) {
      if (!closedTrades.length) {
        body.innerHTML = '<tr class="empty-row"><td colspan="7">Belum ada trade tertutup pada periode ini.</td></tr>';
      } else {
        body.innerHTML = closedTrades.slice(0, 40).map((t) => {
          const pnl = U.safe(t.pnl_usdt !== undefined ? t.pnl_usdt : (t.pnl !== undefined ? t.pnl : t.net_pnl));
          const pnlPct = U.safe(t.pnl_pct !== undefined ? t.pnl_pct : t.roi_pct);
          const side = String(t.direction || t.display_direction || t.side || '').toUpperCase();
          const sideClass = side === 'LONG' ? 'long' : side === 'SHORT' ? 'short' : 'unknown';
          return `<tr><td class="t-symbol">${U.esc(t.symbol || '—')}</td>`
            + `<td><span class="side-badge ${sideClass}" style="margin:0">${U.esc(side || 'N/A')}</span></td>`
            + `<td>${U.price(U.safe(t.entry_price))}</td>`
            + `<td>${U.price(U.safe(t.exit_price))}</td>`
            + `<td class="${U.cls(pnl)}">${U.signed(pnl)}</td>`
            + `<td class="${U.cls(pnlPct)}">${U.signedPct(pnlPct, 2)}</td>`
            + `<td>${U.esc(U.dateTime(t.closed_at || t.exit_time))}</td></tr>`;
        }).join('');
      }
    }
  };

  const footer = (d) => {
    const data = d || {};
    const left = document.getElementById('footerLeft');
    const right = document.getElementById('footerRight');
    if (left) {
      const ex = get(data, 'market_operations.exchange', get(data, 'exchange', get(data, 'exchange_label', '—')));
      const route = get(data, 'market_operations.dns_route', '—');
      const stampValue = get(data, 'generated_at', get(data, 'market_operations.snapshot_at', ''));
      left.textContent = `${String(ex).toUpperCase()} · DNS ${route} · snapshot ${U.stamp(stampValue)}`;
    }
    if (right) {
      const version = get(data, 'version', 'v3.2');
      const build = get(data, 'build', '');
      right.textContent = `AEGIS ${version}${build ? ` · ${build}` : ''}`;
    }
  };

  window.AegisViews2 = { agents, history, footer };
})();
