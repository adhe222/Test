(function () {
  'use strict';

  const $ = (id) => document.getElementById(String(id).replace(/^#/, ''));
  const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));

  const safe = (value, fallback = 0) => {
    const n = typeof value === 'number' ? value : parseFloat(value);
    return Number.isFinite(n) ? n : fallback;
  };

  const num = (value, digits = 2) => {
    const n = safe(value);
    return n.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
  };

  const money = (value, digits = 2) => {
    const n = safe(value);
    const sign = n < 0 ? '-' : '';
    return `${sign}$${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
  };

  const signed = (value, digits = 2) => {
    const n = safe(value);
    const sign = n > 0 ? '+' : n < 0 ? '-' : '';
    return `${sign}$${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
  };

  const pct = (value, digits = 1) => `${safe(value).toFixed(digits)}%`;

  const signedPct = (value, digits = 1) => {
    const n = safe(value);
    return `${n > 0 ? '+' : ''}${n.toFixed(digits)}%`;
  };

  const cls = (value) => {
    const n = safe(value);
    return n > 0 ? 'positive' : n < 0 ? 'negative' : 'neutral';
  };

  const compact = (value) => {
    const n = safe(value);
    const abs = Math.abs(n);
    if (abs >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
    if (abs >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
    if (abs >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
    return n.toFixed(0);
  };

  const price = (value) => {
    const n = safe(value);
    if (n === 0) return '0';
    if (n >= 1000) return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
    if (n >= 1) return n.toFixed(3);
    return n.toPrecision(4);
  };

  const esc = (value) => String(value === null || value === undefined ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const title = (value) => String(value === null || value === undefined ? '' : value)
    .replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());

  const clamp = (value, min, max) => Math.min(max, Math.max(min, safe(value)));

  const parseDate = (value) => {
    if (!value) return null;
    const d = value instanceof Date ? value : new Date(value);
    return isNaN(d.getTime()) ? null : d;
  };

  const stamp = (value) => {
    const d = parseDate(value);
    if (!d) return 'Waktu belum valid';
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const dateTime = (value) => {
    const d = parseDate(value);
    if (!d) return '—';
    return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  const timeAgo = (value) => {
    const d = parseDate(value);
    if (!d) return 'belum ada data';
    const sec = Math.max(0, Math.round((Date.now() - d.getTime()) / 1000));
    if (sec < 5) return 'baru saja';
    if (sec < 60) return `${sec} detik lalu`;
    if (sec < 3600) return `${Math.floor(sec / 60)} menit lalu`;
    if (sec < 86400) return `${Math.floor(sec / 3600)} jam lalu`;
    return `${Math.floor(sec / 86400)} hari lalu`;
  };

  const setText = (id, text) => {
    const el = $(id);
    if (el) el.textContent = text === null || text === undefined ? '' : String(text);
  };

  const setHTML = (id, html) => {
    const el = $(id);
    if (el) el.innerHTML = html;
  };

  const flash = (id, direction) => {
    const el = $(id);
    if (!el) return;
    el.classList.remove('flash-up', 'flash-down');
    void el.offsetWidth;
    el.classList.add(direction === 'down' ? 'flash-down' : 'flash-up');
  };

  const countTo = (id, target, options) => {
    const el = $(id);
    if (!el) return;
    const opts = options || {};
    const format = typeof opts.format === 'function' ? opts.format : (v) => num(v, opts.digits === undefined ? 2 : opts.digits);
    const to = safe(target);
    const from = safe(el.dataset.value, to);
    el.dataset.value = String(to);
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || from === to) {
      el.textContent = format(to);
      return;
    }
    const start = performance.now();
    const dur = opts.duration || 520;
    const step = (now) => {
      const t = clamp((now - start) / dur, 0, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = format(from + (to - from) * eased);
      if (t < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const setProgress = (id, value) => {
    const el = $(id);
    if (!el) return;
    el.style.width = `${clamp(value, 0, 100).toFixed(1)}%`;
  };

  const icon = (name, extra) => {
    const paths = {
      pulse: '<path d="M2 12h4l3-8 4 16 3-8h6"/>',
      wallet: '<path d="M3 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7V5a2 2 0 0 1 2-2h10"/><circle cx="16" cy="13" r="1.4"/>',
      target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
      scale: '<path d="M12 3v18M5 8h14M7 8l-3 7h6zM17 8l-3 7h6z"/>',
      chart: '<path d="M3 20V4M3 20h18"/><path d="M7 16l4-6 3 3 4-7"/>',
      bot: '<rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M8 12h.01M16 12h.01M9 16h6"/>',
      radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 12l6-4"/>',
      shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
      route: '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.5 6H14a4 4 0 0 1 0 8H9a3 3 0 0 0 0 6h6.5"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
      bolt: '<path d="M13 2L4 14h6l-1 8 9-12h-6z"/>',
      globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
      book: '<path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2z"/><path d="M8 7h6"/>',
      moon: '<path d="M20 14a8 8 0 1 1-10-10 7 7 0 0 0 10 10z"/>',
      sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>'
    };
    const body = paths[name] || paths.pulse;
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${extra ? ` class="${extra}"` : ''}>${body}</svg>`;
  };

  const bubbleStat = (label, value, options) => {
    const opts = options || {};
    const tone = opts.tone ? ` data-tone="${esc(opts.tone)}"` : '';
    const suffix = opts.suffix ? `<small>${esc(opts.suffix)}</small>` : '';
    return `<div class="bubble-stat"${tone}><span>${esc(label)}</span><b class="${opts.cls || ''}">${value}${suffix}</b></div>`;
  };

  const bubble = (options) => {
    const opts = options || {};
    const side = opts.side === 'out' ? 'out' : 'in';
    const tone = opts.tone ? ` data-tone="${esc(opts.tone)}"` : '';
    const author = opts.author
      ? `<div class="bubble-author">${opts.icon ? icon(opts.icon) : ''}<span>${esc(opts.author)}</span></div>`
      : '';
    const heading = opts.title ? `<div class="bubble-title">${opts.title}</div>` : '';
    const copy = opts.copy ? `<div class="bubble-copy">${opts.copy}</div>` : '';
    const meta = opts.meta && opts.meta.length
      ? `<div class="bubble-meta">${opts.meta.map((m) => `<span>${esc(m)}</span>`).join('')}</div>`
      : '';
    const list = opts.items && opts.items.length
      ? `<ul class="bubble-list">${opts.items.map((i) => `<li class="${i.ok ? 'ok' : ''}"><i>${i.ok ? '&#10003;' : '&#10005;'}</i><span>${esc(i.text)}</span></li>`).join('')}</ul>`
      : '';
    return `<div class="bubble-group ${side}"><div class="bubble bubble--${side}"${tone}>${author}${heading}${copy}${list}${meta}</div></div>`;
  };

  window.AegisUtil = {
    $, $$, safe, num, money, signed, pct, signedPct, cls, compact, price, esc, title, clamp,
    stamp, dateTime, timeAgo, setText, setHTML, flash, countTo, setProgress, icon, bubble, bubbleStat, parseDate
  };
})();
