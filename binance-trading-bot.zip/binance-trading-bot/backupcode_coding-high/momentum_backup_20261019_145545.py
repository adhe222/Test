from typing import Dict, Any, Optional
import config
from config import KLINES_TIMEFRAME, KLINES_LIMIT
from indicators import (
    calculate_ema,
    calculate_rsi,
    calculate_ema_and_metrics,
    calculate_volume_surge,
    calculate_candle_metrics,
    drop_forming_bar
)


class MomentumAnalystAgent:
    def __init__(self, binance_client):
        self.client = binance_client
        self.name = "MomentumAnalystAgent"

    def analyze_symbol(self, symbol: str, extra_score_required: int = 0, direction: str = "LONG", btc_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        try:
            raw_klines = self.client.get_klines(symbol, interval=KLINES_TIMEFRAME, limit=KLINES_LIMIT)
        except Exception as e:
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "direction": direction,
                "gate_failures": [f"Market feed fetch error: {e}"],
                "reason": f"Market feed fetch error: {e}"
            }

        klines = drop_forming_bar(raw_klines)
        live_price = raw_klines[-1]["close"] if raw_klines else None

        if len(klines) < 55:
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "direction": direction,
                "gate_failures": ["Insufficient closed historical klines"],
                "reason": "Insufficient closed historical klines"
            }

        closes = [k["close"] for k in klines]
        latest_price = closes[-1]

        metrics = calculate_ema_and_metrics(klines, KLINES_TIMEFRAME)
        vol_surge = calculate_volume_surge(klines, 20)
        recent_window = getattr(config, "VOLUME_SURGE_WINDOW_BARS", 3)
        surges = [calculate_volume_surge(klines[:len(klines) - i], 20) for i in range(min(recent_window, len(klines)))]
        effective_vol_surge = max(surges) if surges else vol_surge

        candle_info = calculate_candle_metrics(klines[-1])

        if not (metrics["ema9"] and metrics["ema21"] and metrics["ema50"] and metrics["atr"]):
            return {
                "symbol": symbol,
                "passed": False,
                "score": 0,
                "direction": direction,
                "gate_failures": ["Indicator calculation returned None/invalid"],
                "reason": "Indicator calculation returned None/invalid"
            }

        ema9 = metrics["ema9"]
        ema21 = metrics["ema21"]
        ema50 = metrics["ema50"]
        rsi = metrics["rsi"]
        atr = metrics["atr"]
        base_score = metrics["score"]

        score = base_score
        reasons = []

        if direction == "SHORT":
            if latest_price < ema9 < ema21 < ema50:
                score += 40
                reasons.append("Perfect bearish breakdown stack (Price < EMA9 < EMA21 < EMA50)")
            elif latest_price < ema21 and ema9 < ema21:
                score += 30
                reasons.append("Moderate bearish alignment (Price & EMA9 < EMA21)")
            elif latest_price > ema21:
                score = max(0, score - 10)
                reasons.append("Price above EMA21 (Bullish structure contradicts short)")

            if 35 <= rsi <= 52:
                score += 30
                reasons.append(f"Ideal bearish breakdown acceleration zone (RSI {rsi:.1f})")
            elif 28 <= rsi < 35:
                score += 18
                reasons.append(f"Strong oversold trend (RSI {rsi:.1f})")
            elif 25 <= rsi < 28:
                score += 8
                reasons.append(f"Approaching panic bounce caution zone (RSI {rsi:.1f})")
            elif 52 < rsi <= 58:
                score += 12
                reasons.append(f"Rolling over from neutral (RSI {rsi:.1f})")
            else:
                score = max(0, score - 10)
                reasons.append(f"Unfavorable RSI for short (RSI {rsi:.1f})")

            if not candle_info["is_bullish"] and candle_info["close_ratio"] < 0.35:
                score += 10
                reasons.append("Dominant bearish close in lower range")
            elif not candle_info["is_bullish"]:
                score += 6
                reasons.append("Moderate bearish candle")
            else:
                score = max(0, score - 5)
                reasons.append("Bullish candle contradicts short entry")
        else:
            if latest_price > ema9 > ema21 > ema50:
                score += 40
                reasons.append("Perfect bullish stack (Price > EMA9 > EMA21 > EMA50)")
            elif latest_price > ema21 and ema9 > ema21:
                score += 30
                reasons.append("Moderate bullish alignment (Price & EMA9 > EMA21)")
            elif latest_price < ema21:
                score = max(0, score - 10)
                reasons.append("Price below EMA21 (Bearish structure warning)")

            if 52 <= rsi <= 68:
                score += 30
                reasons.append(f"Ideal acceleration zone (RSI {rsi:.1f})")
            elif 68 < rsi <= 74:
                score += 18
                reasons.append(f"Elevated but sustainable (RSI {rsi:.1f})")
            elif 74 < rsi <= 76:
                score += 8
                reasons.append(f"Caution zone approaching (RSI {rsi:.1f})")
            elif 45 <= rsi < 52:
                score += 12
                reasons.append(f"Building momentum from neutral (RSI {rsi:.1f})")
            else:
                score = max(0, score - 10)
                reasons.append(f"Weak/negative momentum (RSI {rsi:.1f})")

            if candle_info["is_bullish"] and candle_info["close_ratio"] > 0.75:
                score += 10
                reasons.append("Dominant bullish close (>75% of range)")
            elif candle_info["is_bullish"] and candle_info["close_ratio"] > 0.65:
                score += 7
                reasons.append("Strong bullish close")
            elif candle_info["is_bullish"]:
                score += 3
                reasons.append("Moderate bullish candle")
            else:
                score = max(0, score - 5)
                reasons.append("Bearish wick / rejection zone")

        if effective_vol_surge >= 2.0:
            score += 20
            reasons.append(f"Explosive volume surge ({effective_vol_surge:.2f}x average)")
        elif effective_vol_surge >= 1.5:
            score += 16
            reasons.append(f"Strong volume breakout ({effective_vol_surge:.2f}x average)")
        elif effective_vol_surge >= config.VOLUME_SURGE_FILTER:
            score += 12
            reasons.append(f"Healthy volume support ({effective_vol_surge:.2f}x average)")
        elif effective_vol_surge >= 0.9:
            score += 5
            reasons.append(f"Average volume ({effective_vol_surge:.2f}x average)")
        else:
            score = max(0, score - 8)
            reasons.append(f"Low volume caution (Drought: {effective_vol_surge:.2f}x)")

        htf_score = 0
        htf_1h_available = False
        htf_4h_available = False
        htf_bearish = False
        htf_bullish = False
        try:
            klines_1h = drop_forming_bar(
                self.client.get_klines(symbol, interval=config.TREND_TIMEFRAME_1, limit=60)
            )
            if len(klines_1h) >= 55:
                closes_1h = [k["close"] for k in klines_1h]
                ema21_1h = calculate_ema(closes_1h, 21)
                ema50_1h = calculate_ema(closes_1h, 50)
                htf_1h_available = bool(ema21_1h and ema50_1h)
                htf_bullish = bool(ema21_1h and closes_1h[-1] > ema21_1h[-1])

                if direction == "SHORT":
                    if ema21_1h and ema50_1h and closes_1h[-1] < ema21_1h[-1] < ema50_1h[-1]:
                        score += 8
                        htf_score += 8
                        htf_bearish = True
                        reasons.append("HTF Bearish Stack (1h Price < EMA21 < EMA50)")
                    elif ema21_1h and closes_1h[-1] < ema21_1h[-1]:
                        score += 5
                        htf_score += 5
                        htf_bearish = True
                        reasons.append("HTF Resistance (1h Price < EMA21)")
                    elif ema21_1h and closes_1h[-1] > ema21_1h[-1]:
                        score = max(0, score - 12)
                        reasons.append("HTF Rejection (1h Price > EMA21 opposes short)")
                elif ema21_1h and ema50_1h and closes_1h[-1] > ema21_1h[-1] > ema50_1h[-1]:
                    score += 8
                    htf_score += 8
                    reasons.append("HTF Bullish Stack (1h Price > EMA21 > EMA50)")
                elif ema21_1h and closes_1h[-1] > ema21_1h[-1]:
                    score += 5
                    htf_score += 5
                    reasons.append("HTF Support (1h Price > EMA21)")
                elif ema21_1h and closes_1h[-1] < ema21_1h[-1]:
                    score = max(0, score - 12)
                    htf_bearish = True
                    reasons.append("HTF Rejection (1h Price < EMA21)")

            klines_4h = drop_forming_bar(
                self.client.get_klines(symbol, interval=config.TREND_TIMEFRAME_2, limit=40)
            )
            if len(klines_4h) >= 25:
                closes_4h = [k["close"] for k in klines_4h]
                rsi_4h = calculate_rsi(closes_4h, 14)
                ema21_4h = calculate_ema(closes_4h, 21)
                htf_4h_available = bool(ema21_4h and rsi_4h is not None)
                htf_bullish = htf_bullish or bool(ema21_4h and closes_4h[-1] > ema21_4h[-1])

                if direction == "SHORT":
                    if rsi_4h is not None and 28 <= rsi_4h <= 52:
                        score += 5
                        htf_score += 5
                        reasons.append("4H Bearish RSI Healthy ({:.1f})".format(rsi_4h))
                    elif rsi_4h is not None and (rsi_4h < 24 or rsi_4h > 58):
                        score = max(0, score - 8)
                        reasons.append("4H Short RSI Warning ({:.1f})".format(rsi_4h))

                    if ema21_4h and closes_4h[-1] < ema21_4h[-1]:
                        score += 3
                        htf_score += 3
                        htf_bearish = True
                        reasons.append("4H Downtrend Structure confirmed for short")
                    elif ema21_4h:
                        score = max(0, score - 10)
                        reasons.append("4H Uptrend Structure opposes short")
                else:
                    if rsi_4h is not None and 48 <= rsi_4h <= 72:
                        score += 5
                        htf_score += 5
                        reasons.append("4H RSI Healthy ({:.1f})".format(rsi_4h))
                    elif rsi_4h is not None and (rsi_4h > 76 or rsi_4h < 42):
                        score = max(0, score - 8)
                        htf_bearish = True
                        reasons.append("4H RSI Warning ({:.1f})".format(rsi_4h))

                    if ema21_4h and closes_4h[-1] < ema21_4h[-1]:
                        score = max(0, score - 10)
                        htf_bearish = True
                        reasons.append("4H Downtrend Structure (Price < EMA21 4h)")
                    elif ema21_4h:
                        score += 3
                        htf_score += 3
                        reasons.append("4H Uptrend Structure confirmed")
        except Exception as e:
            reasons.append(f"HTF confirmation unavailable ({type(e).__name__})")

        htf_available = htf_1h_available and htf_4h_available
        if htf_score >= 13:
            score += 5
            reasons.append("Multi-HTF Confluence Bonus")

        recent = closes[-21:]
        net_move = abs(recent[-1] - recent[0])
        path = sum(abs(recent[i] - recent[i - 1]) for i in range(1, len(recent)))
        trend_efficiency = (net_move / path) if path > 0 else 0.0

        lows = [k["low"] for k in klines[-21:]]
        highs = [k["high"] for k in klines[-21:]]
        range_low, range_high = min(lows), max(highs)
        range_span = range_high - range_low
        range_position = ((latest_price - range_low) / range_span) if range_span > 0 else 0.5

        gate_failures = []
        atr_pct = (atr / latest_price * 100.0) if latest_price > 0 else 99.0

        if trend_efficiency < config.MIN_TREND_EFFICIENCY:
            gate_failures.append(
                f"Choppy regime: trend efficiency {trend_efficiency:.2f} < {config.MIN_TREND_EFFICIENCY}"
            )

        if direction == "SHORT":
            short_rsi_max = getattr(config, "SHORT_RSI_ENTRY_MAX", 55.0)
            short_rsi_min = getattr(config, "SHORT_RSI_ENTRY_MIN", 26.0)
            if rsi > short_rsi_max:
                gate_failures.append(f"RSI {rsi:.1f} above short entry ceiling {short_rsi_max}")
            if rsi < short_rsi_min:
                gate_failures.append(f"RSI {rsi:.1f} below oversold panic floor {short_rsi_min}")
            if latest_price >= ema21:
                gate_failures.append("Price above EMA21 (no bearish breakdown structure)")
            if ema21 >= ema50:
                gate_failures.append("EMA21 above EMA50 (downtrend not confirmed)")

            dist_from_ema21 = ((ema21 - latest_price) / ema21 * 100.0) if ema21 > 0 else 99.0
            if dist_from_ema21 > config.MAX_DISTANCE_FROM_EMA21_PCT:
                gate_failures.append(
                    f"Overextended {dist_from_ema21:.2f}% below EMA21 (max {config.MAX_DISTANCE_FROM_EMA21_PCT}%)"
                )

            if effective_vol_surge < config.VOLUME_SURGE_FILTER:
                gate_failures.append(f"Volume surge {effective_vol_surge:.2f}x below {config.VOLUME_SURGE_FILTER}x requirement")

            is_candle_acceptable = (
                not candle_info["is_bullish"] or candle_info["close_ratio"] <= (1.0 - config.MIN_CANDLE_CLOSE_RATIO)
            )
            if not is_candle_acceptable:
                gate_failures.append(
                    f"Weak short entry candle (bullish close, ratio {candle_info['close_ratio']:.2f})"
                )

            if getattr(config, "ENABLE_ANTI_SHORT_SQUEEZE_GUARD", True):
                funding_fn = getattr(self.client, "get_funding_rate", None)
                if callable(funding_fn):
                    try:
                        fr = funding_fn(symbol)
                        if fr is not None and fr < -0.03:
                            gate_failures.append(f"Anti-Squeeze Guard: Overcrowded short funding rate ({fr*100:.3f}% < -0.03%)")
                    except Exception:
                        pass
                if rsi < 27.0 and dist_from_ema21 > 4.5:
                    gate_failures.append(f"Anti-Squeeze Guard: Severe selling climax ({dist_from_ema21:.1f}% below EMA21, RSI {rsi:.1f})")

            if config.REQUIRE_HTF_CONFIRMATION:
                if not htf_available:
                    gate_failures.append("Higher-timeframe data unavailable (cannot confirm trend)")
                elif not htf_bearish or htf_bullish:
                    gate_failures.append("Higher-timeframe structure is not bearish")
                elif htf_score < config.MIN_HTF_SCORE:
                    gate_failures.append(f"HTF bearish confirmation weak ({htf_score} < {config.MIN_HTF_SCORE})")
        else:
            if rsi < config.RSI_ENTRY_MIN:
                gate_failures.append(f"RSI {rsi:.1f} below entry floor {config.RSI_ENTRY_MIN}")
            if rsi > config.RSI_ENTRY_MAX:
                gate_failures.append(f"RSI {rsi:.1f} above exhaustion ceiling {config.RSI_ENTRY_MAX}")
            if latest_price <= ema21:
                gate_failures.append("Price below EMA21 (no bullish structure)")
            if ema21 <= ema50:
                gate_failures.append("EMA21 below EMA50 (trend not established)")

            dist_from_ema21 = ((latest_price - ema21) / ema21 * 100.0) if ema21 > 0 else 99.0
            if dist_from_ema21 > config.MAX_DISTANCE_FROM_EMA21_PCT:
                gate_failures.append(
                    f"Overextended {dist_from_ema21:.2f}% above EMA21 (max {config.MAX_DISTANCE_FROM_EMA21_PCT}%)"
                )

            if effective_vol_surge < config.VOLUME_SURGE_FILTER:
                gate_failures.append(f"Volume surge {effective_vol_surge:.2f}x below {config.VOLUME_SURGE_FILTER}x requirement")

            is_candle_acceptable = (
                candle_info["is_bullish"] and candle_info["close_ratio"] >= config.MIN_CANDLE_CLOSE_RATIO
            ) or (
                latest_price > ema21 and ema21 > ema50 and candle_info["close_ratio"] >= 0.25
            )
            if not is_candle_acceptable:
                gate_failures.append(
                    f"Weak entry candle (close ratio {candle_info['close_ratio']:.2f} < {config.MIN_CANDLE_CLOSE_RATIO})"
                )

            if config.REQUIRE_HTF_CONFIRMATION:
                if not htf_available:
                    gate_failures.append("Higher-timeframe data unavailable (cannot confirm trend)")
                elif htf_bearish:
                    gate_failures.append("Higher-timeframe structure bearish")
                elif htf_score < config.MIN_HTF_SCORE:
                    gate_failures.append(f"HTF confirmation weak ({htf_score} < {config.MIN_HTF_SCORE})")

        if getattr(config, "REQUIRE_RELATIVE_STRENGTH_FILTER", True) and btc_context and symbol != getattr(config, "MACRO_BENCHMARK_SYMBOL", "BTCUSDT"):
            btc_4h = btc_context.get("drop_4h_pct")
            if btc_4h is not None and len(klines) >= 16:
                asset_4h = ((latest_price - klines[-16]["open"]) / klines[-16]["open"] * 100.0)
                alpha_vs_btc = asset_4h - btc_4h
                if direction == "LONG" and alpha_vs_btc < -1.5:
                    gate_failures.append(f"Negative Alpha vs Bitcoin ({alpha_vs_btc:+.2f}% lagging BTC)")
                elif direction == "SHORT" and alpha_vs_btc > 1.5:
                    gate_failures.append(f"Positive Alpha vs Bitcoin ({alpha_vs_btc:+.2f}% resisting dump)")

        if getattr(config, "REQUIRE_LTF_CONFIRMATION", True):
            try:
                ltf_raw = self.client.get_klines(symbol, interval=getattr(config, "LTF_TIMEFRAME", "5m"), limit=5)
                ltf_klines = drop_forming_bar(ltf_raw)
                if ltf_klines:
                    ltf_candle = calculate_candle_metrics(ltf_klines[-1])
                    if direction == "LONG" and not ltf_candle["is_bullish"] and ltf_candle["close_ratio"] < 0.20:
                        gate_failures.append(f"LTF 5m rejection wick opposing breakout (close ratio {ltf_candle['close_ratio']:.2f})")
                    elif direction == "SHORT" and ltf_candle["is_bullish"] and ltf_candle["close_ratio"] > 0.80:
                        gate_failures.append(f"LTF 5m reversal hammer opposing breakdown (close ratio {ltf_candle['close_ratio']:.2f})")
            except Exception:
                pass

        if atr_pct > config.MAX_ATR_VOLATILITY_PCT:
            gate_failures.append(f"Volatility too high (ATR {atr_pct:.2f}% of price)")

        min_score = config.MIN_TECHNICAL_SCORE + extra_score_required
        if score < min_score:
            gate_failures.append(f"Technical score {score} below required {min_score}")

        passed = len(gate_failures) == 0

        return {
            "symbol": symbol,
            "direction": direction,
            "passed": passed,
            "score": score,
            "min_score_required": min_score,
            "gate_failures": gate_failures,
            "price": latest_price,
            "live_price": live_price,
            "trend_efficiency": round(trend_efficiency, 3),
            "range_position": round(range_position, 3),
            "ema9": ema9,
            "ema21": ema21,
            "ema50": ema50,
            "rsi": rsi,
            "atr": atr,
            "atr_pct": round(atr_pct, 3),
            "dist_from_ema21_pct": round(dist_from_ema21, 3),
            "volume_surge": effective_vol_surge,
            "candle": candle_info,
            "htf_score": htf_score,
            "htf_available": htf_available,
            "htf_bearish": htf_bearish,
            "reasons": reasons
        }
