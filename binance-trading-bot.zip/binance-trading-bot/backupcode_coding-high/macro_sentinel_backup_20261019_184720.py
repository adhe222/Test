from typing import Dict, Any
import config
from indicators import calculate_ema_and_metrics, drop_forming_bar
from config import (
    MACRO_BENCHMARK_SYMBOL,
    MACRO_CIRCUIT_BREAKER_ENABLED,
    MACRO_MIN_BTC_RSI
)


class MacroMarketSentinel:
    """
    Macro Market Sentinel & Bitcoin Regime Guard:
    Monitors Bitcoin (BTCUSDT) macro trend & volatility.
    Acts as a global Circuit Breaker: If Bitcoin is in a severe selloff or breakdown,
    altcoin long entries are instantly suspended to protect capital from high-beta market crashes.
    """

    def __init__(self, binance_client, llm_client=None):
        self.client = binance_client
        self.llm = llm_client
        self.benchmark_symbol = MACRO_BENCHMARK_SYMBOL
        self.circuit_breaker_enabled = MACRO_CIRCUIT_BREAKER_ENABLED
        self.min_btc_rsi = MACRO_MIN_BTC_RSI

    def evaluate_macro_health(self) -> Dict[str, Any]:
        """
        Pulls latest BTCUSDT market data and calculates macro health status.
        """
        try:
            klines = self.client.get_klines(self.benchmark_symbol, interval="15m", limit=60)
            if len(klines) < 50:
                return {
                    "symbol": self.benchmark_symbol,
                    "safe_to_trade": True,
                    "status": "INSUFFICIENT_DATA",
                    "circuit_breaker": False,
                    "rationale": "Insufficient historical klines for BTCUSDT, defaulting to normal operations."
                }

            closes = [k["close"] for k in klines]
            btc_price = closes[-1]
            # Regime decisions use CLOSED bars only (PIT-009); live tick stays in btc_price.
            decision_klines = drop_forming_bar(klines)
            if len(decision_klines) >= 50:
                closes = [k["close"] for k in decision_klines]
            else:
                decision_klines = klines
            btc_close = closes[-1]
            
            # Use consolidated indicator calculation (calculate once, reuse)
            ema_series = []
            btc_rsi = 50.0
            indicator_result = calculate_ema_and_metrics(decision_klines, "BTCUSDT")
            if isinstance(indicator_result, list):
                ema_series = indicator_result
                btc_rsi = ema_series[-1]["rsi"] if len(ema_series) > 0 else 50.0
            elif isinstance(indicator_result, dict):
                btc_rsi = indicator_result.get("rsi") or 50.0
                ema_series = [indicator_result]
            
            ema21 = ema_series[-1]["ema21"] if len(ema_series) > 0 and "ema21" in ema_series[-1] else btc_close
            ema50 = ema_series[-1]["ema50"] if len(ema_series) > 0 and "ema50" in ema_series[-1] else btc_close

            # Check 4-hour drop
            price_4h_ago = closes[-16] if len(closes) >= 16 else closes[0]
            drop_4h_pct = ((btc_close - price_4h_ago) / price_4h_ago) * 100.0

            circuit_breaker = False
            safe_to_trade = True
            reasons = []

            # 1. Extreme RSI breakdown check (Panic selling)
            if btc_rsi < self.min_btc_rsi:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append(f"BTC RSI ({btc_rsi:.1f}) is oversold/collapsing below {self.min_btc_rsi}")

            # 2. Steep 4h dump check
            if drop_4h_pct < -2.5:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append(f"BTC experienced sharp 4h dump of {drop_4h_pct:.2f}%")

            # 3. Severe trend breakdown
            if btc_close < ema50 and ema21 < ema50 and drop_4h_pct < -1.0:
                circuit_breaker = True
                safe_to_trade = False
                reasons.append("BTC is trading below EMA50 with bearish EMA death cross")

            if not self.circuit_breaker_enabled:
                safe_to_trade = True

            # `safe_for_shorts` means the SHORT route may SCAN selective weak
            # assets; it is not blanket permission. In a bullish BTC regime the
            # asset must independently prove bearish HTF structure and negative
            # relative strength in MomentumAnalystAgent. The old blanket False
            # hid 4 fully-qualified shorts in a live sample of 28.
            safe_for_longs = safe_to_trade
            safe_for_shorts = True
            selective_shorts = False
            short_block_reason = ""
            # Hard short pause only on a BTC melt-up (beta squeeze risk), not on
            # an ordinary uptrend.
            squeeze_rsi = getattr(config, "MACRO_SHORT_SQUEEZE_RSI", 76.0)
            squeeze_pump = getattr(config, "MACRO_SHORT_SQUEEZE_PUMP_4H_PCT", 2.5)
            if btc_rsi >= squeeze_rsi or drop_4h_pct >= squeeze_pump:
                safe_for_shorts = False
                short_block_reason = (
                    f"BTC melt-up (RSI {btc_rsi:.1f}, 4h {drop_4h_pct:+.2f}%) - short squeeze risk"
                )

            if safe_to_trade:
                if btc_close > ema21 > ema50:
                    regime = "STRONG_BULLISH"
                    selective_shorts = True
                    rationale = f"Bitcoin in strong bullish expansion (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Altcoin longs approved; shorts require independent bearish HTF structure and relative weakness."
                elif btc_close > ema50:
                    regime = "HEALTHY_CONSOLIDATION"
                    rationale = f"Bitcoin holding above key EMA50 support (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Altcoin longs and selective shorts approved."
                else:
                    regime = "NEUTRAL_CAUTION"
                    rationale = f"Bitcoin displaying neutral behavior (${btc_price:,.1f}, RSI {btc_rsi:.1f}). Normal position limits apply."
            else:
                regime = "CIRCUIT_BREAKER_ACTIVE"
                rationale = f"CIRCUIT BREAKER TRIPPED: {' | '.join(reasons)}. Altcoin longs suspended. Bearish trend favors tactical short hedging."

            return {
                "symbol": self.benchmark_symbol,
                "price": btc_price,
                "rsi": round(btc_rsi, 1),
                "ema21": round(ema21, 2),
                "ema50": round(ema50, 2),
                "drop_4h_pct": round(drop_4h_pct, 2),
                "safe_to_trade": safe_to_trade,
                "safe_for_longs": safe_for_longs,
                "safe_for_shorts": safe_for_shorts,
                "selective_shorts": selective_shorts,
                "short_block_reason": short_block_reason,
                "circuit_breaker": circuit_breaker,
                "regime": regime,
                "rationale": rationale
            }
        except Exception as e:
            return {
                "symbol": self.benchmark_symbol,
                "price": 0.0,
                "rsi": 50.0,
                "safe_to_trade": True,
                "safe_for_longs": True,
                "safe_for_shorts": True,
                "circuit_breaker": False,
                "regime": "FALLBACK_NORMAL",
                "rationale": f"Benchmark check bypassed due to API error: {e}"
            }
