"""Analysis-driven open-position exits.

The tick guard calls ``evaluate`` synchronously for cheap local technical analysis.
AI reviews run in daemon threads so a slow provider can never block hard-risk checks.
Elapsed holding time is context only: it is never an exit trigger in this module.
"""
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import config
from indicators import calculate_atr, calculate_ema, calculate_rsi, drop_forming_bar
from market_stream import market_stream


class PositionExitAnalyst:
    def __init__(self, client, llm=None, stream=None):
        self.client = client
        self.llm = llm
        self.market_stream = stream or market_stream
        self._klines_cache: Dict[Any, Any] = {}
        self._cache_lock = threading.RLock()
        self._ai_lock = threading.RLock()
        self._ai_inflight = set()
        self._ai_last_request: Dict[str, float] = {}
        self._ai_last_signature: Dict[str, str] = {}
        self._ai_reviews: Dict[str, Dict[str, Any]] = {}

    @staticmethod
    def _key(pos: Dict[str, Any]) -> str:
        market = str(pos.get("market") or "SPOT").upper()
        return f"{market}:{str(pos.get('symbol') or '').upper()}"

    def _closed_klines(self, symbol: str, interval: str, market: Optional[str]):
        key = (symbol.upper(), interval, str(market or "SPOT").upper())
        now = time.monotonic()
        ttl = max(1.0, float(getattr(config, "POSITION_ANALYSIS_CACHE_SEC", 8.0)))
        with self._cache_lock:
            cached = self._klines_cache.get(key)
            if cached and now - cached[0] < ttl:
                return cached[1]
        rows = drop_forming_bar(self.client.get_klines(symbol, interval=interval, limit=80, market=market))
        if not rows:
            raise ValueError(f"no closed {interval} candles")
        with self._cache_lock:
            self._klines_cache[key] = (now, rows)
        return rows

    @staticmethod
    def _metrics(rows):
        closes = [float(row["close"]) for row in rows]
        ema9_series = calculate_ema(closes, 9)
        ema21_series = calculate_ema(closes, 21)
        ema50_series = calculate_ema(closes, 50)
        recent = rows[-5:]
        return {
            "close": closes[-1],
            "ema9": ema9_series[-1],
            "ema21": ema21_series[-1],
            "ema50": ema50_series[-1],
            "ema9_slope": ema9_series[-1] - ema9_series[-2] if len(ema9_series) > 1 else 0.0,
            "rsi": float(calculate_rsi(closes, 14) or 50.0),
            "atr": float(calculate_atr(rows, 14) or 0.0),
            "recent_high": max(float(row["high"]) for row in recent),
            "recent_low": min(float(row["low"]) for row in recent),
        }

    def _local_decision(self, pos: Dict[str, Any], current_price: float) -> Dict[str, Any]:
        symbol = str(pos["symbol"]).upper()
        market = pos.get("market")
        is_short = pos.get("direction") == "SHORT" or pos.get("side") == "SELL"
        m5 = self._metrics(self._closed_klines(symbol, "5m", market))
        m15 = self._metrics(self._closed_klines(symbol, "15m", market))
        try:
            velocity = self.market_stream.velocity(
                symbol, market, float(getattr(config, "POSITION_ANALYSIS_VELOCITY_WINDOW_SEC", 60.0))
            )
        except Exception:
            velocity = None

        threshold = float(getattr(config, "POSITION_ANALYSIS_ADVERSE_VELOCITY_PCT", 0.25))
        score = 0.0
        reasons = []
        if is_short:
            if m5["ema9"] > m5["ema21"]:
                score += 1.0
                reasons.append("5m EMA9 crossed above EMA21")
            if m15["ema9"] > m15["ema21"]:
                score += 1.0
                reasons.append("15m bearish structure lost")
            if current_price > m5["ema21"]:
                score += 1.0
                reasons.append("price reclaimed 5m EMA21")
            if velocity is not None and velocity >= threshold:
                score += 1.5
                reasons.append(f"adverse tick velocity +{velocity:.2f}%")
            if m5["rsi"] >= 60.0 and m5["ema9_slope"] > 0:
                score += 0.5
                reasons.append("bullish RSI/EMA acceleration")
            structure_broken = current_price > m5["recent_high"]
            atr_buffer = max(m5["atr"], current_price * 0.0005) * float(
                getattr(config, "POSITION_ANALYSIS_STOP_ATR_BUFFER", 0.35)
            )
            suggested_stop = m5["recent_high"] + atr_buffer
        else:
            if m5["ema9"] < m5["ema21"]:
                score += 1.0
                reasons.append("5m EMA9 crossed below EMA21")
            if m15["ema9"] < m15["ema21"]:
                score += 1.0
                reasons.append("15m bullish structure lost")
            if current_price < m5["ema21"]:
                score += 1.0
                reasons.append("price lost 5m EMA21")
            if velocity is not None and velocity <= -threshold:
                score += 1.5
                reasons.append(f"adverse tick velocity {velocity:.2f}%")
            if m5["rsi"] <= 40.0 and m5["ema9_slope"] < 0:
                score += 0.5
                reasons.append("bearish RSI/EMA acceleration")
            structure_broken = current_price < m5["recent_low"]
            atr_buffer = max(m5["atr"], current_price * 0.0005) * float(
                getattr(config, "POSITION_ANALYSIS_STOP_ATR_BUFFER", 0.35)
            )
            suggested_stop = m5["recent_low"] - atr_buffer

        if structure_broken:
            score += 2.0
            reasons.append("recent swing structure invalidated")

        close_score = float(getattr(config, "POSITION_ANALYSIS_CLOSE_SCORE", 4.0))
        tighten_score = float(getattr(config, "POSITION_ANALYSIS_TIGHTEN_SCORE", 2.0))
        old_stop = float(pos.get("stop_loss_price") or 0.0)
        if structure_broken:
            action = "CLOSE"
            reason = "ANALYSIS_STRUCTURE_EXIT"
        elif score >= close_score:
            action = "CLOSE"
            reason = "ANALYSIS_REVERSAL_EXIT"
        elif score >= tighten_score and suggested_stop > 0:
            improves = suggested_stop < old_stop if is_short else suggested_stop > old_stop
            already_breached = suggested_stop <= current_price if is_short else suggested_stop >= current_price
            if already_breached:
                action = "CLOSE"
                reason = "ANALYSIS_STRUCTURE_EXIT"
                reasons.append("analysis stop already breached")
            elif improves:
                action = "TIGHTEN"
                reason = "ANALYSIS_STOP_TIGHTENED"
            else:
                action = "HOLD"
                reason = "ANALYSIS_WATCH"
        else:
            action = "HOLD"
            reason = "ANALYSIS_THESIS_INTACT" if not reasons else "ANALYSIS_WATCH"

        return {
            "action": action,
            "reason": reason,
            "score": round(score, 2),
            "suggested_stop": round(suggested_stop, 12) if suggested_stop > 0 else None,
            "reasons": reasons[:6],
            "velocity_60s_pct": round(float(velocity), 4) if velocity is not None else None,
            "metrics": {
                "5m": {k: round(v, 8) if isinstance(v, float) else v for k, v in m5.items()},
                "15m": {k: round(v, 8) if isinstance(v, float) else v for k, v in m15.items()},
            },
            "engine": "LOCAL_TICK_ANALYSIS",
        }

    def _fresh_ai_review(self, key: str, entry_time: str, current_price: float):
        with self._ai_lock:
            review = dict(self._ai_reviews.get(key) or {})
        if not review or review.get("entry_time") != entry_time:
            return None
        ttl = max(1.0, float(getattr(config, "POSITION_AI_REVIEW_TTL_SEC", 20.0)))
        if time.monotonic() - float(review.get("created_monotonic", 0.0)) > ttl:
            return None
        reviewed_price = float(review.get("price") or 0.0)
        if reviewed_price <= 0 or abs(current_price - reviewed_price) / reviewed_price > 0.01:
            return None
        return review

    def _maybe_schedule_ai(self, pos: Dict[str, Any], current_price: float, local: Dict[str, Any]):
        if self.llm is None or not bool(getattr(config, "POSITION_AI_REVIEW_ENABLED", True)):
            return
        key = self._key(pos)
        now = time.monotonic()
        interval = max(2.0, float(getattr(config, "POSITION_AI_REVIEW_INTERVAL_SEC", 30.0)))
        signature = str(local.get("action") or "HOLD")
        with self._ai_lock:
            if key in self._ai_inflight:
                return
            if (
                now - self._ai_last_request.get(key, 0.0) < interval
                and self._ai_last_signature.get(key) == signature
            ):
                return
            self._ai_inflight.add(key)
            self._ai_last_request[key] = now
            self._ai_last_signature[key] = signature
        entry_time = str(pos.get("entry_time") or pos.get("opened_at") or "")
        context = {
            "symbol": pos.get("symbol"),
            "market": pos.get("market"),
            "direction": "SHORT" if (pos.get("direction") == "SHORT" or pos.get("side") == "SELL") else "LONG",
            "entry_price": pos.get("entry_price"),
            "current_price": current_price,
            "stop_loss_price": pos.get("stop_loss_price"),
            "take_profit_1": pos.get("take_profit_1"),
            "take_profit_2": pos.get("take_profit_2"),
            "unrealized_pnl_pct": pos.get("unrealized_pnl_pct"),
            "entry_metrics": pos.get("entry_metrics") or {},
            "local_exit_analysis": local,
            "instruction": "Holding time is context only. Never close solely because time elapsed.",
        }
        thread = threading.Thread(
            target=self._ai_worker,
            args=(key, entry_time, context),
            name=f"position-ai-{pos.get('symbol')}",
            daemon=True,
        )
        thread.start()

    def _ai_worker(self, key: str, entry_time: str, context: Dict[str, Any]):
        try:
            def fallback(_ctx):
                return {
                    "verdict": "REJECT",
                    "conviction": 0,
                    "rationale": "AI unavailable; no independent AI close.",
                    "signal": "HOLD",
                }

            result = self.llm.query_specialist(
                "POSITION EXIT ANALYSIS",
                "Evaluate one open position using current price, EMA structure, RSI, ATR, tick velocity, "
                "entry thesis and bracket. APPROVE means CLOSE now because the trade thesis is invalidated "
                "or upside/downside is exhausted. REJECT means HOLD. Never use elapsed time alone as a reason. "
                "Do not suggest widening risk. Be aggressive about protecting capital, but do not invent data.",
                context,
                fallback,
            )
            is_fallback = bool(result.get("is_fallback"))
            conviction = int(result.get("conviction", 0) or 0)
            should_close = (
                not is_fallback
                and str(result.get("verdict", "")).upper() == "APPROVE"
                and conviction >= int(getattr(config, "POSITION_AI_MIN_CONVICTION", 65))
            )
            review = {
                "action": "CLOSE" if should_close else "HOLD",
                "reason": "AI_ANALYSIS_EXIT" if should_close else "AI_HOLD",
                "conviction": conviction,
                "rationale": str(result.get("rationale") or "")[:600],
                "engine_mode": result.get("engine_mode"),
                "is_fallback": is_fallback,
                "entry_time": entry_time,
                "price": float(context["current_price"]),
                "created_monotonic": time.monotonic(),
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as exc:
            review = {
                "action": "HOLD",
                "reason": "AI_REVIEW_ERROR",
                "error": f"{type(exc).__name__}: {exc}"[:240],
                "entry_time": entry_time,
                "price": float(context["current_price"]),
                "created_monotonic": time.monotonic(),
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        with self._ai_lock:
            self._ai_reviews[key] = review
            self._ai_inflight.discard(key)

    def evaluate(self, pos: Dict[str, Any], current_price: float) -> Dict[str, Any]:
        current_price = float(current_price)
        local = self._local_decision(pos, current_price)
        key = self._key(pos)
        entry_time = str(pos.get("entry_time") or pos.get("opened_at") or "")
        ai_review = self._fresh_ai_review(key, entry_time, current_price)
        self._maybe_schedule_ai(pos, current_price, local)
        decision = dict(local)
        if local.get("action") != "CLOSE" and ai_review and ai_review.get("action") == "CLOSE":
            decision["action"] = "CLOSE"
            decision["reason"] = "AI_ANALYSIS_EXIT"
            decision["suggested_stop"] = None
        decision["ai"] = ai_review or {"action": "PENDING", "reason": "AI_REVIEW_PENDING"}
        decision["checked_at"] = datetime.now(timezone.utc).isoformat()
        return decision
