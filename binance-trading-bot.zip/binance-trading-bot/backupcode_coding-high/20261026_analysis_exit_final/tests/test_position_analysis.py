"""Analysis-driven position exits: no time-based liquidation."""
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from agents.portfolio_manager import PortfolioManagerAgent
from position_analysis import PositionExitAnalyst


class PositionExitPortfolioTests(unittest.TestCase):
    def _pm(self, root, price=100.0):
        client = MagicMock()
        client.get_price.return_value = price
        pm = PortfolioManagerAgent(client, mode="paper")
        pm.market_stream = MagicMock()
        pm.market_stream.price.return_value = None
        pm.market_stream.velocity.return_value = 0.0
        self.assertTrue(pm.execute_buy({
            "symbol": "AAAUSDT",
            "direction": "LONG",
            "side": "BUY",
            "market": "SPOT",
            "entry_price": 100.0,
            "quantity": 1.0,
            "position_usdt": 100.0,
            "stop_loss_price": 98.0,
            "stop_loss_pct": 2.0,
            "take_profit_1": 110.0,
            "take_profit_2": 120.0,
            "trailing_trigger_pct": 5.0,
            "trailing_distance_pct": 1.0,
        }))
        return pm

    def test_old_position_is_not_closed_by_time_in_analysis_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "POSITION_ANALYSIS_EXIT_ENABLED", True), patch.object(
                config, "TIME_STOP_SOFT_ENABLED", True
            ), patch.object(config, "TIME_STOP_AFTER_MIN", 0), patch.object(
                config, "TIME_STOP_HARD_MIN", 0
            ):
                pm = self._pm(root, price=100.0)
                pm.state["open_positions"][0]["entry_time"] = "2020-01-01T00:00:00+00:00"
                pm._save_portfolio(pm.state)
                analyst = MagicMock()
                analyst.evaluate.return_value = {"action": "HOLD", "reason": "ANALYSIS_THESIS_INTACT"}
                pm.position_analyst = analyst
                actions = pm.update_and_monitor_positions()
                self.assertEqual(actions, [])
                self.assertEqual(len(pm.get_open_positions()), 1)
                analyst.evaluate.assert_called_once()

    def test_analysis_reversal_closes_before_hard_stop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "POSITION_ANALYSIS_EXIT_ENABLED", True):
                pm = self._pm(root, price=99.0)
                analyst = MagicMock()
                analyst.evaluate.return_value = {
                    "action": "CLOSE",
                    "reason": "ANALYSIS_REVERSAL_EXIT",
                    "score": 6.0,
                    "reasons": ["5m structure flipped"],
                    "ai": {"action": "HOLD"},
                }
                pm.position_analyst = analyst
                actions = pm.update_and_monitor_positions()
                self.assertEqual([a["reason"] for a in actions], ["ANALYSIS_REVERSAL_EXIT"])
                self.assertAlmostEqual(actions[0]["exit_price"], 99.0)
                self.assertEqual(actions[0]["exit_analysis"]["score"], 6.0)
                self.assertEqual(pm.get_open_positions(), [])

    def test_analysis_tightens_stop_without_widening_or_closing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "POSITION_ANALYSIS_EXIT_ENABLED", True):
                pm = self._pm(root, price=101.0)
                analyst = MagicMock()
                analyst.evaluate.return_value = {
                    "action": "TIGHTEN",
                    "reason": "ANALYSIS_STOP_TIGHTENED",
                    "suggested_stop": 100.5,
                }
                pm.position_analyst = analyst
                actions = pm.update_and_monitor_positions()
                self.assertEqual(actions, [])
                self.assertEqual(pm.get_open_positions()[0]["stop_loss_price"], 100.5)
                self.assertTrue(pm.get_open_positions()[0]["analysis_stop_active"])

    def test_analysis_stop_update_is_throttled(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "POSITION_ANALYSIS_EXIT_ENABLED", True):
                pm = self._pm(root, price=101.0)
                pm.state["open_positions"][0]["_analysis_stop_ts"] = time.time()
                pm._save_portfolio(pm.state)
                analyst = MagicMock()
                analyst.evaluate.return_value = {
                    "action": "TIGHTEN",
                    "reason": "ANALYSIS_STOP_TIGHTENED",
                    "suggested_stop": 100.5,
                }
                pm.position_analyst = analyst
                actions = pm.update_and_monitor_positions()
                self.assertEqual(actions, [])
                self.assertEqual(pm.get_open_positions()[0]["stop_loss_price"], 98.0)


class PositionExitAnalystTests(unittest.TestCase):
    def setUp(self):
        self.pos = {
            "symbol": "AAAUSDT",
            "market": "SPOT",
            "direction": "LONG",
            "side": "BUY",
            "entry_price": 100.0,
            "entry_time": "2026-01-01T00:00:00+00:00",
            "stop_loss_price": 98.0,
            "take_profit_1": 110.0,
            "take_profit_2": 120.0,
            "entry_metrics": {},
        }

    @staticmethod
    def _metrics(close, ema9, ema21, ema50, slope, rsi, recent_low, recent_high):
        return {
            "close": close,
            "ema9": ema9,
            "ema21": ema21,
            "ema50": ema50,
            "ema9_slope": slope,
            "rsi": rsi,
            "atr": 1.0,
            "recent_low": recent_low,
            "recent_high": recent_high,
        }

    def test_local_reversal_closes_from_structure_not_elapsed_time(self):
        analyst = PositionExitAnalyst(MagicMock(), llm=None, stream=MagicMock())
        analyst._closed_klines = MagicMock(return_value=[{}])
        analyst._metrics = MagicMock(side_effect=[
            self._metrics(90, 95, 100, 105, -2, 30, 85, 110),
            self._metrics(90, 96, 100, 105, -1, 35, 85, 112),
        ])
        analyst.market_stream.velocity.return_value = -0.8
        result = analyst._local_decision(self.pos, 90.0)
        self.assertEqual(result["action"], "CLOSE")
        self.assertEqual(result["reason"], "ANALYSIS_REVERSAL_EXIT")
        self.assertGreaterEqual(result["score"], 4.0)

    def test_local_healthy_trend_holds(self):
        analyst = PositionExitAnalyst(MagicMock(), llm=None, stream=MagicMock())
        analyst._closed_klines = MagicMock(return_value=[{}])
        analyst._metrics = MagicMock(side_effect=[
            self._metrics(110, 108, 105, 100, 1, 60, 100, 112),
            self._metrics(110, 107, 104, 100, 1, 62, 102, 113),
        ])
        analyst.market_stream.velocity.return_value = 0.5
        result = analyst._local_decision(self.pos, 110.0)
        self.assertEqual(result["action"], "HOLD")

    def test_swing_structure_break_closes_even_without_reversal_score(self):
        analyst = PositionExitAnalyst(MagicMock(), llm=None, stream=MagicMock())
        analyst._closed_klines = MagicMock(return_value=[{}])
        analyst._metrics = MagicMock(side_effect=[
            self._metrics(94, 94, 93, 90, 0, 50, 95, 110),
            self._metrics(94, 94, 93, 90, 0, 50, 95, 110),
        ])
        analyst.market_stream.velocity.return_value = 0.0
        result = analyst._local_decision(self.pos, 94.0)
        self.assertEqual(result["action"], "CLOSE")
        self.assertEqual(result["reason"], "ANALYSIS_STRUCTURE_EXIT")

    def test_ai_review_can_close_without_blocking_first_tick(self):
        llm = MagicMock()
        llm.query_specialist.return_value = {
            "verdict": "APPROVE",
            "conviction": 90,
            "rationale": "structure and momentum invalidated",
            "signal": "CLOSE",
            "engine_mode": "AI_ABSOLUTE",
            "is_fallback": False,
        }
        analyst = PositionExitAnalyst(MagicMock(), llm=llm, stream=MagicMock())
        analyst._local_decision = MagicMock(return_value={
            "action": "HOLD", "reason": "ANALYSIS_THESIS_INTACT", "score": 0,
        })
        with patch.object(config, "POSITION_AI_REVIEW_ENABLED", True), patch.object(
            config, "POSITION_AI_REVIEW_INTERVAL_SEC", 0.0
        ), patch.object(config, "POSITION_AI_REVIEW_TTL_SEC", 60.0), patch.object(
            config, "POSITION_AI_MIN_CONVICTION", 65
        ):
            first = analyst.evaluate(self.pos, 100.0)
            self.assertEqual(first["action"], "HOLD")
            for _ in range(100):
                with analyst._ai_lock:
                    done = bool(analyst._ai_reviews)
                if done:
                    break
                time.sleep(0.01)
            second = analyst.evaluate(self.pos, 100.0)
        self.assertEqual(second["action"], "CLOSE")
        self.assertEqual(second["reason"], "AI_ANALYSIS_EXIT")
        self.assertEqual(second["ai"]["engine_mode"], "AI_ABSOLUTE")


if __name__ == "__main__":
    unittest.main()
