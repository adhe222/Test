# POSITION_ANALYSIS_EXIT final backup (2026-10-26)

Exit policy:
- No time-stop close and no momentum-fade close while POSITION_ANALYSIS_EXIT_ENABLED=true.
- Local closed-candle analysis runs on every tick: 5m/15m EMA structure, RSI, ATR, recent swing and tick velocity.
- Swing structure invalidation closes immediately (ANALYSIS_STRUCTURE_EXIT).
- Reversal score >= POSITION_ANALYSIS_CLOSE_SCORE closes (ANALYSIS_REVERSAL_EXIT).
- Lower score may tighten the existing stop only; it never widens risk.
- Live stop updates are throttled by step size and refresh interval to avoid order churn.
- Async AI reviewer can close independently (AI_ANALYSIS_EXIT), never blocks tick guard.
- Hard stop remains emergency circuit breaker only.
- AI review failure is fail-safe: HOLD, never an independent close.

Runtime verified:
- 412 tests OK.
- API position_exit_policy: analysis=true, ai_review=true, time_stop=false, momentum_fade=false.
- Live paper positions received local analysis and AI_ABSOLUTE reviews without fallback.
