(function () {
  'use strict';

  const U = window.AegisUtil;

  const STAGES = [
    { id: 'scan', label: 'Scanner', icon: 'radar' },
    { id: 'book', label: 'Orderbook', icon: 'layers' },
    { id: 'momentum', label: 'Momentum', icon: 'chart' },
    { id: 'research', label: 'Research', icon: 'globe' },
    { id: 'risk', label: 'Risk Guard', icon: 'shield' },
    { id: 'portfolio', label: 'Portfolio', icon: 'wallet' },
    { id: 'execution', label: 'Execution', icon: 'bolt' }
  ];

  const nodes = STAGES.map((stage) => Object.assign({}, stage, { status: 'IDLE', note: '', metric: '—' }));
  let hovered = -1;
  let rafId = 0;
  let running = false;
  let lastFrame = 0;
  let paused = false;
  let cycle = 0;
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const num = (value) => {
    if (value === null || value === undefined || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const pick = (source, keys) => {
    if (!source || typeof source !== 'object') return null;
    for (let i = 0; i < keys.length; i += 1) {
      const value = source[keys[i]];
      if (value !== undefined && value !== null) return value;
    }
    return null;
  };

  const metricText = (value, unit) => {
    const parsed = num(value);
    return parsed === null ? '—' : `${parsed} ${unit}`;
  };

  const metrics = (d) => {
    const data = d || {};
    const scan = data.latest_scan || {};
    const positions = Array.isArray(data.open_positions) ? data.open_positions : null;
    return {
      scan: metricText(pick(scan, ['candidates_scanned']), 'pair'),
      book: metricText(pick(scan, ['orderbook_checks', 'books_scanned', 'book_checks']), 'book'),
      momentum: metricText(pick(scan, ['momentum_hits', 'momentum_candidates', 'signals']), 'sinyal'),
      research: metricText(pick(scan, ['research_checks', 'research_requests', 'intel_checks']), 'riset'),
      risk: metricText(pick(scan, ['gates_passed_count', 'gates_passed']), 'lolos'),
      portfolio: metricText(positions ? positions.length : pick(data, ['open_position_count']), 'posisi'),
      execution: metricText(pick(data, ['orders_today', 'executed_today', 'orders_placed']), 'order')
    };
  };

  const stageStatus = (d) => {
    const data = d || {};
    const raw = data.agents || data.agent_status || data.agent_consciousness;
    const list = Array.isArray(raw) ? raw
      : raw && typeof raw === 'object'
        ? Object.keys(raw).map((k) => (typeof raw[k] === 'object' && raw[k] ? Object.assign({ name: k }, raw[k]) : { name: k, status: raw[k] }))
        : [];
    const find = (keys) => list.find((a) => {
      const text = `${a.name || ''} ${a.role || ''} ${a.id || ''}`.toLowerCase();
      return keys.some((k) => text.includes(k));
    });
    const map = {
      scan: find(['scan']),
      book: find(['order book', 'orderbook', 'microstructure', 'order']),
      momentum: find(['moment', 'trend', 'exhaustion']),
      research: find(['research', 'intel', 'news', 'narrative', 'flow']),
      risk: find(['risk', 'guard', 'veto', 'capital']),
      portfolio: find(['portfolio', 'alloc', 'profit extraction', 'exit']),
      execution: find(['exec', 'router', 'judge', 'committee'])
    };
    const counts = metrics(data);
    const loop = data.autonomous_loop || {};
    paused = loop.active === false || loop.running === false;
    cycle = num(pick(loop, ['cycle_count', 'cycles_completed'])) || 0;
    nodes.forEach((node) => {
      node.metric = counts[node.id] || '—';
      const agent = map[node.id];
      if (agent) {
        node.status = String(agent.status || agent.verdict || (Number(agent.total_audits) > 0 ? 'ACTIVE' : 'IDLE')).toUpperCase();
        node.note = String(agent.message || agent.reason || agent.summary || agent.consciousness_focus || '').slice(0, 120);
      } else {
        node.status = paused ? 'PAUSE' : 'IDLE';
        node.note = paused ? 'Mesin dalam mode jeda' : 'Menunggu laporan siklus ini';
      }
    });
    const pill = document.getElementById('pipelineLive');
    const pillText = document.getElementById('pipelineLiveText');
    if (pill) pill.dataset.state = paused ? 'paused' : 'live';
    if (pillText) pillText.textContent = paused ? 'jeda' : `live · siklus ${cycle}`;
  };

  const tone = (status) => {
    const s = String(status || '').toUpperCase();
    if (/APPROVE|OK|PASS|READY|GO|RUNNING|DONE|ACTIVE/.test(s)) return 'ok';
    if (/VETO|BLOCK|REJECT|FAIL|DENY|HALT/.test(s)) return 'bad';
    if (/WAIT|PAUSE|HOLD|PENDING|COOLDOWN|SCAN/.test(s)) return 'warn';
    return 'idle';
  };

  const colors = () => {
    const css = getComputedStyle(document.documentElement);
    const v = (name, fallback) => css.getPropertyValue(name).trim() || fallback;
    return {
      ok: v('--teal', '#2dd4bf'),
      bad: v('--rose', '#fb7185'),
      warn: v('--amber', '#f5b544'),
      idle: v('--muted-2', '#66788f'),
      cyan: v('--cyan', '#22d3ee'),
      grid: v('--hairline', 'rgba(120,180,235,.14)'),
      node: v('--node-bg', 'rgba(10,18,32,.94)'),
      ink: v('--ink', '#e8f0fb'),
      muted: v('--muted', '#7e90a8')
    };
  };

  const layout = (w, h) => {
    const cols = w < 560 ? 1 : w < 960 ? 2 : 4;
    const rows = Math.ceil(nodes.length / cols);
    const padX = cols === 1 ? 16 : 22;
    const padY = 14;
    const cellW = (w - padX * 2) / cols;
    const cellH = (h - padY * 2) / rows;
    const boxW = cols === 1 ? Math.min(cellW, 330) : Math.min(cellW - 18, 172);
    const boxH = Math.max(32, Math.min(cellH - 16, 54));
    return nodes.map((node, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      return {
        node,
        index: i,
        cols,
        rows,
        cx: padX + cellW * col + cellW / 2,
        cy: padY + cellH * row + cellH / 2,
        w: boxW,
        h: boxH
      };
    });
  };

  const bezier = (p0, p1, p2, p3, t) => {
    const mt = 1 - t;
    return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
  };

  const draw = (now) => {
    const canvas = document.getElementById('pipelineCanvas');
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 40 || rect.height < 40) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.floor(rect.width);
    const h = Math.floor(rect.height);
    if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const C = colors();
    const boxes = layout(w, h);
    const segments = [];

    boxes.forEach((box, i) => {
      if (i === 0) return;
      const prev = boxes[i - 1];
      const sameRow = Math.floor(i / box.cols) === Math.floor((i - 1) / prev.cols);
      const x1 = sameRow ? prev.cx + prev.w / 2 : prev.cx;
      const y1 = sameRow ? prev.cy : prev.cy + prev.h / 2;
      const x2 = sameRow ? box.cx - box.w / 2 : box.cx;
      const y2 = sameRow ? box.cy : box.cy - box.h / 2;
      const c1x = sameRow ? x1 + 22 : x1;
      const c1y = sameRow ? y1 : y1 + 26;
      const c2x = sameRow ? x2 - 22 : x2;
      const c2y = sameRow ? y2 : y2 - 26;
      const active = tone(nodes[i - 1].status) !== 'idle';
      segments.push({ x1, y1, c1x, c1y, c2x, c2y, x2, y2, active, index: i });
      ctx.lineWidth = active ? 1.6 : 1.2;
      ctx.strokeStyle = active ? C.cyan : C.grid;
      ctx.globalAlpha = active ? 0.6 : 0.42;
      ctx.setLineDash([5, 7]);
      ctx.lineDashOffset = reduceMotion ? 0 : -((now * (active ? 0.045 : 0.022)) % 24);
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.bezierCurveTo(c1x, c1y, c2x, c2y, x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    });

    boxes.forEach((box) => {
      const node = box.node;
      const t = tone(node.status);
      const color = C[t] || C.idle;
      const x = box.cx - box.w / 2;
      const y = box.cy - box.h / 2;
      const isHover = box.index === hovered;
      const active = t !== 'idle';
      const r = 12;

      ctx.save();
      if (active) {
        const pulse = 0.5 + 0.5 * Math.sin(now * 0.0022 + box.index * 0.7);
        ctx.shadowColor = color;
        ctx.shadowBlur = reduceMotion ? 8 : 8 + pulse * 9;
      }
      ctx.fillStyle = C.node;
      ctx.strokeStyle = isHover ? C.cyan : color;
      ctx.globalAlpha = isHover ? 1 : active ? 0.95 : 0.8;
      ctx.lineWidth = isHover ? 2 : 1.2;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, box.w, box.h, r);
      else ctx.rect(x, y, box.w, box.h);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      ctx.globalAlpha = 1;

      ctx.beginPath();
      ctx.arc(x + 14, box.cy - (box.h > 42 ? 8 : 0), 3.6, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();

      const labelY = box.h > 42 ? box.cy - 6 : box.cy - 1;
      ctx.fillStyle = C.ink;
      ctx.font = '650 12.5px Inter, system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(node.label, x + 24, labelY);

      if (box.h > 42) {
        ctx.fillStyle = C.muted;
        ctx.font = '10px "JetBrains Mono", monospace';
        const statusText = String(node.status || 'IDLE').slice(0, 16);
        ctx.fillText(statusText, x + 24, box.cy + 10);
      }

      ctx.fillStyle = active ? C.cyan : C.muted;
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'right';
      ctx.globalAlpha = active ? 0.95 : 0.7;
      ctx.fillText(node.metric, x + box.w - 12, box.cy + 10);
      ctx.globalAlpha = 1;
      ctx.textAlign = 'left';
    });

    if (!reduceMotion) {
      segments.forEach((seg) => {
        const speed = seg.active ? 0.0005 : 0.00024;
        const phase = ((now * speed) + seg.index * 0.17) % 1;
        const px = bezier(seg.x1, seg.c1x, seg.c2x, seg.x2, phase);
        const py = bezier(seg.y1, seg.c1y, seg.c2y, seg.y2, phase);
        const fade = Math.sin(phase * Math.PI);
        ctx.save();
        ctx.globalAlpha = (seg.active ? 0.95 : 0.5) * fade;
        ctx.fillStyle = seg.active ? C.cyan : C.muted;
        ctx.shadowColor = seg.active ? C.cyan : 'transparent';
        ctx.shadowBlur = seg.active ? 10 : 0;
        ctx.beginPath();
        ctx.arc(px, py, seg.active ? 3 : 2.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
    }

    const legend = document.getElementById('pipelineLegend');
    if (legend && !legend.dataset.bound) {
      legend.dataset.bound = '1';
      legend.innerHTML = ['ok', 'warn', 'bad', 'idle'].map((k) => {
        const label = k === 'ok' ? 'Lolos' : k === 'warn' ? 'Ditahan' : k === 'bad' ? 'Veto' : 'Idle';
        return `<span><i style="background:${C[k]}"></i>${label}</span>`;
      }).join('');
    }
  };

  const loop = (now) => {
    if (!running) return;
    rafId = requestAnimationFrame(loop);
    if (now - lastFrame < 1000 / 30) return;
    lastFrame = now;
    draw(now);
  };

  const start = () => {
    if (running || reduceMotion) return;
    running = true;
    rafId = requestAnimationFrame(loop);
  };

  const stop = () => {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
  };

  const bindHover = () => {
    const canvas = document.getElementById('pipelineCanvas');
    const tooltip = document.getElementById('pipelineTooltip');
    if (!canvas || canvas.dataset.bound === '1') return;
    canvas.dataset.bound = '1';
    const hit = (clientX, clientY) => {
      const rect = canvas.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      const boxes = layout(rect.width, rect.height);
      return boxes.find((b) => Math.abs(x - b.cx) <= b.w / 2 && Math.abs(y - b.cy) <= b.h / 2);
    };
    const show = (box) => {
      if (!tooltip || !box) return;
      tooltip.innerHTML = `<strong>${U.esc(box.node.label)}</strong>`
        + `<div class="tt-row">status ${U.esc(box.node.status)} · ${U.esc(box.node.metric)}</div>`
        + `<div class="tt-row">${U.esc(box.node.note || '—')}</div>`;
      tooltip.style.left = `${Math.min(Math.max(box.cx - 60, 8), Math.max(8, canvas.clientWidth - 210))}px`;
      tooltip.style.top = `${box.cy + box.h / 2 + 6}px`;
      tooltip.classList.add('show');
    };
    canvas.addEventListener('mousemove', (e) => {
      const box = hit(e.clientX, e.clientY);
      hovered = box ? box.index : -1;
      if (box) show(box);
      else if (tooltip) tooltip.classList.remove('show');
      if (reduceMotion) draw(performance.now());
    });
    canvas.addEventListener('mouseleave', () => {
      hovered = -1;
      if (tooltip) tooltip.classList.remove('show');
      if (reduceMotion) draw(performance.now());
    });
    canvas.addEventListener('click', (e) => {
      const box = hit(e.clientX, e.clientY);
      if (box) show(box);
    });
  };

  const render = (d) => {
    stageStatus(d || {});
    bindHover();
    draw(performance.now());
    if (!reduceMotion) start();
  };

  let resizeTimer = 0;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => draw(performance.now()), 150);
  }, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else if (!reduceMotion) start();
  });

  window.AegisPipeline = { render, stop, start };
})();
