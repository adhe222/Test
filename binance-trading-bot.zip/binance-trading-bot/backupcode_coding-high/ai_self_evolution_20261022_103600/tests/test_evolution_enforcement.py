import tempfile
import unittest
from pathlib import Path

import config
from agents.consciousness import AgentConsciousnessEngine
from agents.specialists import MomentumExhaustionSpecialist


class TestMomentumDivisionWeightReadback(unittest.TestCase):
    def test_role_name_matches_consciousness_memory_key(self):
        spec = MomentumExhaustionSpecialist(None)
        self.assertEqual(spec.role_name, "Momentum Exhaustion Division")


class TestScratchGuards(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_scratch_outcome_not_learned_as_loss(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "SOLUSDT", "pnl_usdt": -0.0029, "pnl_pct": -0.01,
            "outcome": "SCRATCH", "reason": "BREAK_EVEN",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before)

    def test_legacy_tiny_loss_without_outcome_ignored(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "BTCUSDT", "pnl_usdt": -0.0029, "pnl_pct": -0.002,
            "reason": "BREAK_EVEN",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before)

    def test_real_loss_still_learned(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "SOLUSDT", "pnl_usdt": -5.0, "pnl_pct": -2.0,
            "outcome": "LOSS", "reason": "STOP_LOSS",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before + 1)

    def test_win_outcome_still_rewarded(self):
        before = self.engine.get_weight("Technical Price Action Division")
        self.engine.record_trade_success_and_reward({
            "pnl_usdt": 5.0, "pnl_pct": 2.0, "outcome": "WIN",
        })
        self.assertGreater(
            self.engine.get_weight("Technical Price Action Division"), before
        )

    def test_scratch_outcome_not_rewarded(self):
        before = self.engine.get_weight("Technical Price Action Division")
        self.engine.record_trade_success_and_reward({
            "pnl_usdt": 0.001, "pnl_pct": 0.01, "outcome": "SCRATCH",
        })
        self.assertEqual(self.engine.get_weight("Technical Price Action Division"), before)


class TestAIUpgradeValidation(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_weights_clamped_to_sane_bounds(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "9.9.9-ULTRA",
            "dynamic_weights": {"Quantitative Risk & Capital Division": 100},
        })
        self.assertEqual(
            self.engine.get_weight("Quantitative Risk & Capital Division"), 2.0
        )

    def test_thresholds_clamped_and_non_numeric_dropped(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "9.9.9-ULTRA",
            "calibrated_thresholds": {
                "Momentum Exhaustion Division": {"max_rsi": -5.0, "min_rsi": "corrupt"},
            },
        })
        self.assertEqual(
            self.engine.get_threshold("Momentum Exhaustion Division", "max_rsi", 74.0), 55.0
        )
        self.assertEqual(
            self.engine.get_threshold("Momentum Exhaustion Division", "min_rsi", 45.0), 45.0
        )

    def test_corrupt_memory_file_is_preserved_not_wiped(self):
        self._tmp2 = tempfile.TemporaryDirectory()
        path = Path(self._tmp2.name) / "corrupt.json"
        path.write_text("{ truncated garbage", encoding="utf-8")
        AgentConsciousnessEngine(path)
        backups = list(path.parent.glob("corrupt.json.corrupt-*"))
        self.assertTrue(backups)
        self._tmp2.cleanup()


class TestLearnedThresholdEnforcement(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_learned_volume_floor_vetoes(self):
        self.engine.memory["divisions"]["Technical Price Action Division"][
            "calibrated_thresholds"]["min_volume_surge"] = 1.30
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division", {"candle": {}, "volume_surge": 1.05}
        )
        self.assertIsNotNone(audit)
        self.assertTrue(audit["violation"])
        self.assertEqual(audit["rule_id"], "PA-VOL-LEARNED")

    def test_founder_floor_does_not_veto(self):
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division", {"candle": {}, "volume_surge": 1.05}
        )
        self.assertIsNone(audit)

    def test_learned_rsi_ceiling_vetoes(self):
        self.engine.memory["divisions"]["Momentum Exhaustion Division"][
            "calibrated_thresholds"]["max_rsi"] = 71.0
        audit = self.engine.audit_against_experience(
            "Momentum Exhaustion Division", {"rsi": 73.5}
        )
        self.assertIsNotNone(audit)
        self.assertTrue(audit["violation"])
        self.assertEqual(audit["action"], "VETO")


class TestTradingProfiles(unittest.TestCase):
    KNOBS = (
        "MIN_TECHNICAL_SCORE", "ENHANCED_MIN_CONVICTION", "MIN_RISK_REWARD_RATIO",
        "RISK_PER_TRADE_PCT", "DAILY_LOSS_LIMIT_PCT", "LOSS_STREAK_TIGHTEN_AFTER",
    )

    def setUp(self):
        self.saved = {k: getattr(config, k) for k in self.KNOBS}

    def tearDown(self):
        for k, v in self.saved.items():
            setattr(config, k, v)
        config.apply_trading_profile("balanced")

    def test_aggressive_profile_applies_presets(self):
        config.apply_trading_profile("aggressive")
        self.assertEqual(config.MIN_TECHNICAL_SCORE, 62)
        self.assertEqual(config.ENHANCED_MIN_CONVICTION, 66)
        self.assertEqual(config.MIN_RISK_REWARD_RATIO, 1.4)
        self.assertEqual(config.RISK_PER_TRADE_PCT, 4.0)
        self.assertEqual(config.DAILY_LOSS_LIMIT_PCT, 8.0)
        self.assertEqual(config.LOSS_STREAK_TIGHTEN_AFTER, 3)

    def test_conservative_profile_applies_presets(self):
        config.apply_trading_profile("conservative")
        self.assertEqual(config.MIN_TECHNICAL_SCORE, 76)
        self.assertEqual(config.ENHANCED_MIN_CONVICTION, 82)
        self.assertEqual(config.RISK_PER_TRADE_PCT, 1.0)

    def test_explicit_env_knob_beats_profile(self):
        before = config.RISK_PER_TRADE_PCT
        config._PROFILE_KNOBS_EXPLICIT["RISK_PER_TRADE_PCT"] = True
        try:
            config.apply_trading_profile("aggressive")
            self.assertEqual(config.RISK_PER_TRADE_PCT, before)
        finally:
            config._PROFILE_KNOBS_EXPLICIT["RISK_PER_TRADE_PCT"] = False

    def test_unknown_profile_rejected(self):
        with self.assertRaises(ValueError):
            config.apply_trading_profile("yolo")


if __name__ == "__main__":
    unittest.main()
