from typing import Dict, Any, List
from datetime import datetime, timezone
from binance_api import BinanceClient
from ai_engine import LLMClient
from agents.scanner import ScannerAgent
from agents.momentum import MomentumAnalystAgent
from agents.orderbook import OrderbookAgent
from agents.risk_manager import RiskManagementAgent
from agents.portfolio_manager import PortfolioManagerAgent
from agents.macro_sentinel import MacroMarketSentinel
from agents.specialists import (
    MarketNarrativeSpecialist,
    PriceActionSpecialist,
    MomentumExhaustionSpecialist,
    MicrostructureSpecialist,
    MarketSentimentSpecialist,
    ChiefRiskOfficerSpecialist,
    ProfitExtractionSpecialist,
    ExecutiveStrategistSpecialist
)
from agents.consciousness import consciousness_engine
import config
from config import MAX_OPEN_POSITIONS


class TradingOrchestrator:
    def __init__(self):
        self.client = BinanceClient()
        self.llm = LLMClient()
        self.macro_sentinel = MacroMarketSentinel(self.client, self.llm)
        self.scanner = ScannerAgent(self.client)
        self.momentum_data_agent = MomentumAnalystAgent(self.client)
        self.orderbook_data_agent = OrderbookAgent(self.client)
        self.risk_data_agent = RiskManagementAgent()
        self.portfolio = PortfolioManagerAgent(self.client)

        self.narrative_spec = MarketNarrativeSpecialist(self.llm)
        self.price_action_spec = PriceActionSpecialist(self.llm)
        self.exhaustion_spec = MomentumExhaustionSpecialist(self.llm)
        self.microstructure_spec = MicrostructureSpecialist(self.llm)
        self.sentiment_spec = MarketSentimentSpecialist(self.llm)
        self.cro_spec = ChiefRiskOfficerSpecialist(self.llm)
        self.profit_spec = ProfitExtractionSpecialist(self.llm)
        self.executive_spec = ExecutiveStrategistSpecialist(self.llm)

    def _consecutive_losses(self) -> int:
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return 0
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
            streak = 0
            for event in reversed(events):
                if event.get("action") != "CLOSED":
                    continue
                if float(event.get("pnl_usdt", 0.0)) < 0:
                    streak += 1
                else:
                    break
            return streak
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return 0

    def _adaptive_tightening(self) -> Dict[str, int]:
        streak = self._consecutive_losses()
        if not config.ADAPTIVE_GATES_ENABLED or streak < config.LOSS_STREAK_TIGHTEN_AFTER:
            return {"loss_streak": streak, "steps": 0, "score_bonus": 0, "conviction_bonus": 0}
        steps = min(
            config.MAX_TIGHTEN_STEPS,
            1 + (streak - config.LOSS_STREAK_TIGHTEN_AFTER),
        )
        return {
            "loss_streak": streak,
            "steps": steps,
            "score_bonus": steps * config.LOSS_STREAK_SCORE_BONUS,
            "conviction_bonus": steps * config.LOSS_STREAK_CONVICTION_BONUS,
        }

    def _daily_loss_limit_hit(self) -> bool:
        perf = self.portfolio.get_periodic_performance().get("today", {})
        net = float(perf.get("net_pnl_usdt", 0.0))
        initial = float(self.portfolio.state.get("initial_capital", config.INITIAL_PAPER_BALANCE_USDT))
        return net < 0 and abs(net) >= initial * (config.DAILY_LOSS_LIMIT_PCT / 100.0)

    def _symbols_in_cooldown(self) -> Dict[str, str]:
        blocked: Dict[str, str] = {}
        try:
            import json
            if not config.TRADE_LOG_FILE.exists():
                return blocked
            with open(config.TRADE_LOG_FILE, "r", encoding="utf-8") as f:
                events = json.load(f)
        except (OSError, ValueError, TypeError):
            return blocked

        tf_minutes = {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240}
        bar_min = tf_minutes.get(config.KLINES_TIMEFRAME, 15)
        window_min = bar_min * config.SYMBOL_COOLDOWN_BARS
        now = datetime.now(timezone.utc)

        for event in reversed(events[-60:]):
            if event.get("action") != "CLOSED":
                continue
            if float(event.get("pnl_usdt", 0.0)) >= 0:
                continue
            try:
                exited = datetime.fromisoformat(event["exit_time"])
            except (KeyError, ValueError):
                continue
            age_min = (now - exited).total_seconds() / 60.0
            if age_min < window_min:
                remaining = window_min - age_min
                blocked[event["symbol"]] = f"Cooldown after loss ({remaining:.0f}m left)"
        return blocked

    def _deterministic_specialist_report(self, spec, data: Dict[str, Any]) -> Dict[str, Any]:
        staff_reports = []
        for m in spec.staff:
            r = m.evaluate(data)
            staff_reports.append({
                "staff_name": m.name,
                "role_title": m.role_title,
                "system_role": getattr(m, "system_role", ""),
                "verdict": r["verdict"],
                "conviction": r["conviction"],
                "rationale": r["rationale"],
                "signal": r["signal"]
            })
        vetoes = [s for s in staff_reports if s["verdict"] == "REJECT"]
        verdict = "REJECT" if vetoes else "APPROVE"
        conv = min(s["conviction"] for s in staff_reports) if vetoes else int(sum(s["conviction"] for s in staff_reports) / len(staff_reports))
        rat = f"Department Veto: {vetoes[0]['staff_name']} rejected trade: {vetoes[0]['rationale']}" if vetoes else f"{spec.role_name} approved."

        audit = consciousness_engine.audit_against_experience(spec.role_name, data)
        if audit and audit.get("violation"):
            if audit.get("action") == "VETO":
                verdict = "REJECT"
                conv = min(conv, 20)
                rat = audit.get("reason", rat)
            elif audit.get("action") == "PENALTY_OR_VETO":
                conv = max(10, conv - 25)
                rat = f"{rat} | {audit.get('reason', '')}"

        return {
            "specialist": spec.role_name,
            "lead_title": spec.lead_title,
            "icon": spec.icon,
            "verdict": verdict,
            "conviction": conv,
            "rationale": rat,
            "engine": "Deterministic Engine (Learned Heuristics)",
            "engine_mode": "DETERMINISTIC_LEARNED",
            "ai_verdict": None,
            "staff_reports": staff_reports
        }

    def maybe_upgrade_agent_intelligence(self) -> Dict[str, Any]:
        try:
            trade_history = self.portfolio.get_trade_history()
            portfolio_state = self.portfolio.state
            return self.llm.upgrade_agent_intelligence(consciousness_engine, trade_history, portfolio_state)
        except Exception:
            return {"success": False, "mode": "SKIPPED"}

    def run_cycle(self) -> Dict[str, Any]:
        adaptive = self._adaptive_tightening()
        results = {
            "ai_status": self.llm.status_summary,
            "macro_health": {},
            "exit_events": [],
            "candidates_scanned": 0,
            "candidates_evaluated": [],
            "executed_trades": [],
            "portfolio_summary": {},
            "adaptive_guard": adaptive,
            "daily_loss_limit_hit": False,
        }

        exit_events = self.portfolio.update_and_monitor_positions()
        results["exit_events"] = exit_events

        if exit_events:
            for ev in exit_events:
                if float(ev.get("pnl_usdt", 0.0)) < 0:
                    consciousness_engine.record_trade_failure_and_learn(ev)
                else:
                    consciousness_engine.record_trade_success_and_reward(ev)
            self.maybe_upgrade_agent_intelligence()

        open_positions = self.portfolio.get_open_positions()
        current_equity = self.portfolio.get_equity()

        macro_health = self.macro_sentinel.evaluate_macro_health()
        results["macro_health"] = macro_health

        available_slots = MAX_OPEN_POSITIONS - len(open_positions)
        circuit_breaker_active = not macro_health.get("safe_to_trade", True)
        daily_limit_hit = self._daily_loss_limit_hit()
        results["daily_loss_limit_hit"] = daily_limit_hit
        cooldowns = self._symbols_in_cooldown()
        results["symbols_in_cooldown"] = cooldowns
        correlation_full = len(open_positions) >= config.MAX_CORRELATED_POSITIONS

        top_limit = getattr(config, "SCANNER_TOP_LIMIT", 20)
        candidates = self.scanner.scan_trending_pairs(top_limit=top_limit)
        results["candidates_scanned"] = len(candidates)

        for candidate in candidates:
            try:
                symbol = candidate["symbol"]

                if any(pos["symbol"] == symbol for pos in open_positions):
                    continue

                ob_eval = self.orderbook_data_agent.inspect_orderbook(symbol)
                mom_eval = self.momentum_data_agent.analyze_symbol(
                    symbol, extra_score_required=adaptive["score_bonus"]
                )
                risk_eval = self.risk_data_agent.evaluate_risk(
                    symbol=symbol,
                    current_price=mom_eval.get("price", candidate["price"]),
                    atr=mom_eval.get("atr", 0.0),
                    total_equity=current_equity,
                    open_positions=open_positions
                )

                hard_gate_failures: List[str] = []

                if symbol in cooldowns:
                    hard_gate_failures.append(cooldowns[symbol])
                if config.REQUIRE_MOMENTUM_PASS and not mom_eval.get("passed", False):
                    hard_gate_failures.extend(
                        mom_eval.get("gate_failures") or [mom_eval.get("reason", "Momentum gate failed")]
                    )
                if config.REQUIRE_ORDERBOOK_PASS and not ob_eval.get("passed", False):
                    hard_gate_failures.append(
                        f"Orderbook gate: {ob_eval.get('reason', 'liquidity check failed')}"
                    )
                if ob_eval.get("passed") and ob_eval.get("imbalance", 0.0) < config.MIN_ORDERBOOK_IMBALANCE:
                    hard_gate_failures.append(
                        f"Orderbook bid support weak (imbalance {ob_eval.get('imbalance', 0.0):.2f})"
                    )
                if candidate.get("count_trades", 0) < config.MIN_TRADE_COUNT_24H:
                    hard_gate_failures.append(
                        f"Thin participation ({candidate.get('count_trades', 0):,} trades/24h < {config.MIN_TRADE_COUNT_24H:,})"
                    )
                if not risk_eval.get("approved"):
                    hard_gate_failures.append(f"Risk desk: {risk_eval.get('reason', 'risk plan rejected')}")

                gates_passed = len(hard_gate_failures) == 0
                skip_llm = not gates_passed

                if skip_llm:
                    rep_narrative = self._deterministic_specialist_report(self.narrative_spec, candidate)
                    rep_pa = self._deterministic_specialist_report(self.price_action_spec, {"momentum_data": mom_eval})
                    rep_exhaustion = self._deterministic_specialist_report(self.exhaustion_spec, {"momentum_data": mom_eval})
                    rep_micro = self._deterministic_specialist_report(self.microstructure_spec, {"orderbook_data": ob_eval})
                    rep_sentiment = self._deterministic_specialist_report(self.sentiment_spec, {"momentum_data": mom_eval, "ticker_data": candidate})
                    rep_cro = self._deterministic_specialist_report(self.cro_spec, {"risk_plan": risk_eval})
                    rep_profit = self._deterministic_specialist_report(self.profit_spec, {"risk_plan": risk_eval})
                else:
                    from concurrent.futures import ThreadPoolExecutor
                    with ThreadPoolExecutor(max_workers=7) as executor:
                        fn = executor.submit(self.narrative_spec.analyze, {**candidate, "skip_llm": False})
                        fp = executor.submit(self.price_action_spec.analyze, {"momentum_data": mom_eval, "skip_llm": False})
                        fe = executor.submit(self.exhaustion_spec.analyze, {"momentum_data": mom_eval, "skip_llm": False})
                        fm = executor.submit(self.microstructure_spec.analyze, {"orderbook_data": ob_eval, "skip_llm": False})
                        fs = executor.submit(self.sentiment_spec.analyze, {"momentum_data": mom_eval, "ticker_data": candidate, "skip_llm": False})
                        fc = executor.submit(self.cro_spec.analyze, {"risk_plan": risk_eval, "skip_llm": False})
                        fr = executor.submit(self.profit_spec.analyze, {"risk_plan": risk_eval, "skip_llm": False})
                        rep_narrative = fn.result()
                        rep_pa = fp.result()
                        rep_exhaustion = fe.result()
                        rep_micro = fm.result()
                        rep_sentiment = fs.result()
                        rep_cro = fc.result()
                        rep_profit = fr.result()

                all_specialist_reports = [
                    rep_narrative,
                    rep_pa,
                    rep_exhaustion,
                    rep_micro,
                    rep_sentiment,
                    rep_cro,
                    rep_profit
                ]

                if not gates_passed:
                    executive_verdict = {
                        "specialist": self.executive_spec.role_name,
                        "lead_title": self.executive_spec.lead_title,
                        "icon": self.executive_spec.icon,
                        "final_verdict": "REJECT",
                        "consensus_conviction": 0,
                        "consensus_status": "GATES_BLOCKED",
                        "engine_mode": "DETERMINISTIC",
                        "summary": f"Trade blocked by Quality Gates: {hard_gate_failures[0]}",
                        "staff_reports": []
                    }
                else:
                    executive_verdict = self.executive_spec.synthesize(
                        all_specialist_reports,
                        extra_conviction_required=adaptive["conviction_bonus"]
                    )

                can_execute = (
                    available_slots > 0
                    and not circuit_breaker_active
                    and not daily_limit_hit
                    and not correlation_full
                    and gates_passed
                )
                if available_slots <= 0:
                    execution_note = "CAPACITY_FULL_SURVEILLANCE"
                elif circuit_breaker_active:
                    execution_note = "CIRCUIT_BREAKER_ACTIVE"
                elif daily_limit_hit:
                    execution_note = "DAILY_LOSS_LIMIT_PAUSE"
                elif correlation_full:
                    execution_note = f"CORRELATION_CAP_REACHED ({config.MAX_CORRELATED_POSITIONS} correlated longs)"
                elif not gates_passed:
                    execution_note = f"QUALITY_GATE_BLOCKED: {hard_gate_failures[0]}"
                else:
                    execution_note = "READY_TO_EXECUTE"

                eval_record = {
                    "symbol": symbol,
                    "price": candidate["price"],
                    "price_change_24h": candidate["price_change_24h"],
                    "quote_volume_24h": candidate["quote_volume_24h"],
                    "technical_score": mom_eval.get("score", 0),
                    "min_score_required": mom_eval.get("min_score_required"),
                    "hard_gate_failures": hard_gate_failures,
                    "gates_passed": gates_passed,
                    "specialist_reports": all_specialist_reports,
                    "executive_verdict": executive_verdict,
                    "risk_plan": risk_eval,
                    "can_execute": can_execute,
                    "execution_note": execution_note
                }
                results["candidates_evaluated"].append(eval_record)

                if can_execute and executive_verdict["final_verdict"] == "APPROVE" and risk_eval.get("approved"):
                    success = self.portfolio.execute_buy(risk_eval)
                    if success:
                        results["executed_trades"].append(eval_record)
                        open_positions = self.portfolio.get_open_positions()
                        available_slots = MAX_OPEN_POSITIONS - len(open_positions)
                        correlation_full = len(open_positions) >= config.MAX_CORRELATED_POSITIONS

                if available_slots <= 0 and len(results["candidates_evaluated"]) >= 2:
                    break
            except Exception as e:
                print(f"[Orchestrator Warning] Candidate {candidate.get('symbol')} skipped due to network glitch: {e}")
                continue

        if available_slots <= 0:
            status = "Capacity full (3/3) - Watchlist surveillance active"
        elif daily_limit_hit:
            status = f"Daily loss guard active (-{config.DAILY_LOSS_LIMIT_PCT}%) - entries paused, surveillance live"
        elif circuit_breaker_active:
            status = "Macro circuit breaker active - entries paused, surveillance live"
        elif adaptive["steps"] > 0:
            status = f"Active scanning (defensive mode: +{adaptive['score_bonus']} score / +{adaptive['conviction_bonus']}% conviction required)"
        else:
            status = "Active scanning"

        results["portfolio_summary"] = {
            "equity_usdt": round(self.portfolio.get_equity(), 2),
            "cash_usdt": round(self.portfolio.state["cash_usdt"], 2),
            "open_positions": self.portfolio.get_open_positions(),
            "realized_pnl_usdt": round(self.portfolio.state.get("realized_pnl_usdt", 0.0), 4),
            "total_trades": self.portfolio.state.get("total_trades", 0),
            "winning_trades": self.portfolio.state.get("winning_trades", 0),
            "status": status
        }
        results["consciousness"] = consciousness_engine.get_ultra_context_summary()

        return results
