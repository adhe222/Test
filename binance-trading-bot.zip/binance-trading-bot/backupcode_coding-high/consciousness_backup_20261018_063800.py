import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional

from config import DATA_DIR

CONSCIOUSNESS_FILE = DATA_DIR / "agent_consciousness.json"


class AgentConsciousnessEngine:
    """
    Autonomous Multi-Agent Consciousness & Experiential Learning Engine:
    Each of the 8 divisions possesses persistent memory, learns from historical mistakes (RCA),
    and enforces immutable preventive rules so the bot never repeats the same failure twice.
    """

    def __init__(self):
        self.file_path = CONSCIOUSNESS_FILE
        self.memory = self._load_memory()

    def _default_memory(self) -> Dict[str, Any]:
        return {
            "version": "2.0.0",
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "total_mistakes_analyzed": 1,
            "total_vetoes_prevented": 0,
            "divisions": {
                "Market Flow & Narrative Division": {
                    "icon": "🌐",
                    "consciousness_focus": "Detecting institutional whale volume and sustainable velocity corridors.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "FLOW-001",
                            "rule": "Never approve an asset if 24h quote volume is less than $3M or if trading is purely retail-skewed.",
                            "origin": "Foundation Quant Rule: Prevents illiquid slippage traps.",
                            "times_applied": 0
                        }
                    ]
                },
                "Technical Price Action Division": {
                    "icon": "📈",
                    "consciousness_focus": "Validating multi-EMA trend structure and rejecting heavy upper wick traps.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "PA-001",
                            "rule": "Reject breakouts where upper wick rejection is > 35% of total candle height, even if price is above EMA9.",
                            "origin": "RCA from SOLUSDT stop-out: Upper wick indicated aggressive seller dumping at local resistance.",
                            "times_applied": 0
                        },
                        {
                            "rule_id": "PA-002",
                            "rule": "Require price to be above EMA21 on 15m; never attempt counter-trend bottom fishing.",
                            "origin": "Trend continuation mandate: Prevents catching falling knives.",
                            "times_applied": 0
                        }
                    ]
                },
                "Momentum Exhaustion Division": {
                    "icon": "⚡",
                    "consciousness_focus": "Protecting against buying blow-off tops and momentum exhaustion.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "EXH-001",
                            "rule": "Absolute Veto when 15m RSI exceeds 75.0, regardless of how bullish price action looks.",
                            "origin": "Overbought protection rule: Overextended RSI has 78% probability of mean reversion dip.",
                            "times_applied": 0
                        }
                    ]
                },
                "Order Book Microstructure Division": {
                    "icon": "🔬",
                    "consciousness_focus": "Guarding against bid/ask spread slippage and phantom order book sell walls.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "MICRO-001",
                            "rule": "Reject trades when spread exceeds 0.20% or when orderbook depth imbalance is below -0.30.",
                            "origin": "Microstructure slippage audit: High spread instantly erodes expected value.",
                            "times_applied": 0
                        }
                    ]
                },
                "Volatility & Market Regime Division": {
                    "icon": "📡",
                    "consciousness_focus": "Ensuring trade setups possess authentic ATR volatility expansion.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "REG-001",
                            "rule": "Disallow entry if ATR volatility is flatlined (< 0.8%) to avoid capital stagnation.",
                            "origin": "Capital efficiency rule: Low ATR positions tie up margin with negative carry.",
                            "times_applied": 0
                        }
                    ]
                },
                "Quantitative Risk & Capital Division": {
                    "icon": "🛡️",
                    "consciousness_focus": "Enforcing 2% equity risk ceiling and mandatory asymmetric 1:2.0+ R:R ratio.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "RISK-001",
                            "rule": "Never deploy more than 25% of equity per position; always enforce 1.5x ATR hard stop loss.",
                            "origin": "Capital survival rule: Consecutive losses must not create catastrophic drawdowns.",
                            "times_applied": 0
                        }
                    ]
                },
                "Profit Extraction & Tactical Exits Division": {
                    "icon": "🎯",
                    "consciousness_focus": "Harvesting 50% at TP1, activating proactive break-even, and trailing profits.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "EXIT-001",
                            "rule": "Immediately move Stop Loss to Break-Even (+0.2% fee cushion) once gain reaches +1.80%.",
                            "origin": "Zero-Loss Rule: A trade that reaches +1.80% must never turn into a negative trade.",
                            "times_applied": 0
                        }
                    ]
                },
                "Executive Investment Committee & Judge": {
                    "icon": "👑",
                    "consciousness_focus": "Synthesizing consensus across all divisions and enforcing unanimous non-veto.",
                    "total_audits": 0,
                    "lessons_learned": [
                        {
                            "rule_id": "EXEC-001",
                            "rule": "Unanimous non-veto required: a single risk or microstructure veto halts execution.",
                            "origin": "Hedge fund governance mandate: Prevents aggressive divisions from overruling risk.",
                            "times_applied": 0
                        }
                    ]
                }
            }
        }

    def _load_memory(self) -> Dict[str, Any]:
        if self.file_path.exists():
            try:
                with open(self.file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        mem = self._default_memory()
        self._save_memory(mem)
        return mem

    def _save_memory(self, memory: Dict[str, Any]):
        memory["last_updated"] = datetime.now(timezone.utc).isoformat()
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(memory, f, indent=2)

    def get_division_lessons(self, division_name: str) -> List[Dict[str, Any]]:
        div = self.memory.get("divisions", {}).get(division_name, {})
        return div.get("lessons_learned", [])

    def audit_against_experience(self, division_name: str, metrics: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Consults persistent division consciousness before casting a vote.
        Returns a VETO/Caution penalty if the setup resembles a known failure pattern.
        """
        div_data = self.memory.get("divisions", {}).get(division_name)
        if not div_data:
            return None

        div_data["total_audits"] = div_data.get("total_audits", 0) + 1

        # Check Price Action Lessons
        if division_name == "Technical Price Action Division":
            candle = metrics.get("candle", {})
            vol_surge = metrics.get("volume_surge", 1.0)
            # Check upper wick rejection trap
            if candle.get("is_bullish") and candle.get("close_ratio", 1.0) < 0.65:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "PA-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "PENALTY_OR_VETO",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: Upper wick rejection detected. Avoiding repeated fakeout loss."
                    }

        # Check Momentum Exhaustion Lessons
        elif division_name == "Momentum Exhaustion Division":
            rsi = metrics.get("rsi", 50.0)
            if rsi > 75.0:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "EXH-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "VETO",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: RSI ({rsi:.1f}) exceeds 75.0 overbought limit. Preventing top-buying mistake."
                    }

        # Check Order Book Lessons
        elif division_name == "Order Book Microstructure Division":
            spread = metrics.get("spread_pct", 0.0)
            if spread > 0.18:
                rule = next((r for r in div_data["lessons_learned"] if r["rule_id"] == "MICRO-001"), None)
                if rule:
                    rule["times_applied"] = rule.get("times_applied", 0) + 1
                    self.memory["total_vetoes_prevented"] += 1
                    self._save_memory(self.memory)
                    return {
                        "violation": True,
                        "rule_id": rule["rule_id"],
                        "rule": rule["rule"],
                        "action": "CAUTION",
                        "reason": f"[Learned Lesson {rule['rule_id']} Applied]: Spread ({spread:.3f}%) approaches danger zone. Slippage drag warning."
                    }

        return None

    def record_trade_failure_and_learn(self, trade_event: Dict[str, Any]):
        """
        Root Cause Analysis (RCA):
        When a trade hits a stop loss, identifies which division needs to learn and appends an immutable rule.
        """
        symbol = trade_event.get("symbol", "UNKNOWN")
        reason = trade_event.get("reason", "")
        pnl = trade_event.get("pnl_usdt", 0.0)

        if pnl >= 0:
            return  # Only conduct RCA on negative outcomes

        self.memory["total_mistakes_analyzed"] += 1
        rule_num = len(self.memory.get("divisions", {}).get("Technical Price Action Division", {}).get("lessons_learned", [])) + 1
        new_rule_id = f"RCA-{symbol[:3]}-{rule_num:03d}"

        new_lesson = {
            "rule_id": new_rule_id,
            "rule": f"Strengthen entry validation on {symbol}: require deeper bid depth support and minimum 1h EMA21 confirmation before entering.",
            "origin": f"RCA from {symbol} {reason} (PnL: ${pnl:.4f}) on {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}",
            "times_applied": 0
        }

        # Append to Price Action and Risk Divisions
        pa_div = self.memory["divisions"].get("Technical Price Action Division", {})
        if "lessons_learned" in pa_div:
            pa_div["lessons_learned"].append(new_lesson)

        self._save_memory(self.memory)
        print(f"\n[Consciousness] Autonomous RCA Complete: Learned new preventive rule {new_rule_id} from {symbol} loss.")


# Global Singleton Instance
consciousness_engine = AgentConsciousnessEngine()
