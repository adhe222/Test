import json
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import config

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_FENCE = re.compile(r"```(?:json)?", re.IGNORECASE)
_JSON_BLOCK = re.compile(r"\{.*\}", re.DOTALL)

SYSTEM_PROMPT = (
    "You are a crypto market narrative analyst. Use live social and news search to judge "
    "crowd positioning and narrative heat for the requested pair. Reply with JSON only, "
    "no prose, no markdown."
)


def _clamp(value: Any, low: float, high: float, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number != number:
        return default
    return round(max(low, min(high, number)), 2)


def _clean(text: Any, limit: int) -> str:
    if not isinstance(text, str):
        if text is None:
            return ""
        text = str(text)
    out = _CONTROL_CHARS.sub(" ", text)
    out = re.sub(r"\s+", " ", out).strip()
    return out[:limit]


def _as_list(value: Any, limit: int = 3, chars: int = 140) -> list:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    out = []
    for item in value[:limit]:
        if isinstance(item, dict):
            item = item.get("text") or item.get("title") or item.get("name") or ""
        cleaned = _clean(item, chars)
        if cleaned:
            out.append(cleaned)
    return out


class GrokIntelAgent:
    name = "GrokIntelAgent"

    def __init__(
        self,
        client: Optional[Any] = None,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ):
        self.api_key = str(api_key if api_key is not None else getattr(config, "XAI_API_KEY", "")).strip()
        self.model = model or getattr(config, "GROK_MODEL", "grok-4-fast")
        self.base_url = (base_url or getattr(config, "GROK_BASE_URL", "https://api.x.ai/v1")).rstrip("/")
        self.timeout = float(timeout if timeout is not None else getattr(config, "GROK_TIMEOUT_SEC", 20.0))
        self.ttl = float(getattr(config, "GROK_TTL_SEC", 600.0))
        self.min_interval = float(getattr(config, "GROK_MIN_INTERVAL_SEC", 45.0))
        self.live_search = bool(getattr(config, "GROK_LIVE_SEARCH", True))
        self.max_chars = int(getattr(config, "GROK_MAX_CHARS", 600))
        self.enabled = bool(getattr(config, "GROK_ENABLED", True)) and bool(self.api_key or client is not None)
        self._client = client
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._last_call = 0.0

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled,
            "model": self.model,
            "base_url": self.base_url,
            "live_search": self.live_search,
            "ttl_sec": self.ttl,
            "cached_symbols": len(self._cache),
        }

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        from openai import OpenAI

        self._client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=0,
        )
        return self._client

    def collect(
        self,
        symbol: str,
        direction: str = "LONG",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        symbol = str(symbol or "").upper()
        if not self.enabled:
            return {"symbol": symbol, "status": "DISABLED", "sources": []}
        now = time.monotonic()
        with self._lock:
            cached = self._cache.get(symbol)
            if cached and float(cached.get("_expires", 0.0)) > now:
                return {k: v for k, v in cached.items() if k != "_expires"}
        prompt = self._prompt(symbol, direction, context or {})
        started = time.monotonic()
        try:
            content, search_used = self._call(prompt)
            parsed = self._parse(content)
            latency = round((time.monotonic() - started) * 1000.0, 1)
            result: Dict[str, Any] = {
                "symbol": symbol,
                "direction": direction,
                "status": "OK",
                "model": self.model,
                "live_search": search_used,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "latency_ms": latency,
                "sentiment_score": parsed["sentiment_score"],
                "narrative_strength": parsed["narrative_strength"],
                "crowd_positioning": parsed["crowd_positioning"],
                "confidence": parsed["confidence"],
                "summary": parsed["summary"],
                "catalysts": parsed["catalysts"],
                "risks": parsed["risks"],
                "sources": [
                    {"name": "xai_grok", "ok": True, "live_search": search_used, "latency_ms": latency}
                ],
            }
        except Exception as exc:
            latency = round((time.monotonic() - started) * 1000.0, 1)
            error = _clean(str(exc), 200) or exc.__class__.__name__
            result = {
                "symbol": symbol,
                "direction": direction,
                "status": "DEGRADED",
                "model": self.model,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "latency_ms": latency,
                "error": error,
                "sources": [
                    {"name": "xai_grok", "ok": False, "error": error, "latency_ms": latency}
                ],
            }
        ttl = self.ttl if result.get("status") == "OK" else min(60.0, self.ttl)
        with self._lock:
            self._cache[symbol] = dict(result, _expires=time.monotonic() + ttl)
        return result

    def _call(self, prompt: str) -> tuple:
        client = self._get_client()
        with self._lock:
            wait = self.min_interval - (time.monotonic() - self._last_call)
            self._last_call = time.monotonic() + max(0.0, wait)
        if wait > 0:
            time.sleep(min(wait, self.min_interval))
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.0,
            "max_tokens": 700,
            "response_format": {"type": "json_object"},
        }
        search_used = False
        if self.live_search:
            kwargs["extra_body"] = {
                "search_parameters": {
                    "mode": "on",
                    "return_citations": True,
                    "sources": [{"type": "x"}, {"type": "news"}],
                    "max_search_results": 12,
                }
            }
            search_used = True
        try:
            response = client.chat.completions.create(**kwargs)
        except Exception:
            if not search_used:
                raise
            kwargs.pop("extra_body", None)
            response = client.chat.completions.create(**kwargs)
            search_used = False
        choices = getattr(response, "choices", None) or []
        if not choices:
            raise ValueError("grok returned no choices")
        content = getattr(getattr(choices[0], "message", None), "content", "") or ""
        return content, search_used

    def _parse(self, content: Any) -> Dict[str, Any]:
        text = _FENCE.sub("", str(content or "")).strip()
        match = _JSON_BLOCK.search(text)
        if not match:
            raise ValueError("non-JSON grok response")
        try:
            data = json.loads(match.group(0))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"unparsable grok JSON: {exc}")
        if not isinstance(data, dict):
            raise ValueError("grok JSON is not an object")
        return {
            "sentiment_score": _clamp(data.get("sentiment_score"), -100.0, 100.0, 0.0),
            "narrative_strength": _clamp(data.get("narrative_strength"), 0.0, 100.0, 0.0),
            "crowd_positioning": _clean(data.get("crowd_positioning") or data.get("positioning"), 40),
            "confidence": _clamp(data.get("confidence"), 0.0, 100.0, 0.0),
            "summary": _clean(data.get("summary") or data.get("narrative"), self.max_chars),
            "catalysts": _as_list(data.get("catalysts")),
            "risks": _as_list(data.get("risks")),
        }

    def _prompt(self, symbol: str, direction: str, context: Dict[str, Any]) -> str:
        base = symbol
        for quote in getattr(config, "ACCEPTED_QUOTE_ASSETS", ["USDT"]):
            if symbol.endswith(str(quote)) and len(symbol) > len(str(quote)):
                base = symbol[: -len(str(quote))]
                break
        lines = [
            f"Pair: {symbol} (base asset {base})",
            f"Direction under review: {str(direction).upper()}",
        ]
        for key, label in (
            ("price_change_24h", "24h change percent"),
            ("rsi", "RSI 15m"),
            ("funding", "funding rate"),
            ("bias", "technical bias"),
        ):
            value = context.get(key)
            if value not in (None, ""):
                lines.append(f"{label}: {_clean(value, 60)}")
        lines.append(
            "Search X posts and crypto news from the last 24 hours for this asset. "
            "Return JSON with keys: sentiment_score (-100 very bearish to 100 very bullish), "
            "narrative_strength (0-100), crowd_positioning (short label), confidence (0-100), "
            "summary (max 60 words), catalysts (max 3 short strings), risks (max 3 short strings)."
        )
        return "\n".join(lines)
