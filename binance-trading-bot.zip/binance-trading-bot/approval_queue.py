import json
import os
import re
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import config

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", "data"))
QUEUE_PATH = DATA_DIR / "approval_queue.json"

PENDING = "PENDING"
APPROVED = "APPROVED"
REJECTED = "REJECTED"
EXPIRED = "EXPIRED"
CONSUMED = "CONSUMED"

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_LOCK = threading.Lock()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _text(value: Any, limit: int) -> str:
    if value is None:
        return ""
    out = _CONTROL.sub(" ", str(value))
    return re.sub(r"\s+", " ", out).strip()[:limit]


def _num(value: Any) -> Optional[float]:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number:
        return None
    return number


class ApprovalQueue:
    def __init__(self, path: Optional[Path] = None, ttl_sec: Optional[float] = None):
        self.path = Path(path or QUEUE_PATH)
        self.ttl_sec = float(ttl_sec if ttl_sec is not None else getattr(config, "APPROVAL_TICKET_TTL_SEC", 900.0))
        self.max_pending = int(getattr(config, "APPROVAL_MAX_PENDING", 20))

    def _load(self) -> List[Dict[str, Any]]:
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return []
        if not isinstance(data, list):
            return []
        return [item for item in data if isinstance(item, dict)]

    def _save(self, tickets: List[Dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(tickets, handle, indent=2)
        os.replace(tmp, self.path)

    @staticmethod
    def _expire_due(tickets: List[Dict[str, Any]], now: datetime) -> bool:
        changed = False
        for ticket in tickets:
            if ticket.get("status") != PENDING:
                continue
            deadline = _parse(ticket.get("expires_at"))
            if deadline and deadline <= now:
                ticket["status"] = EXPIRED
                ticket["decided_at"] = now.isoformat()
                ticket["decided_by"] = "system"
                ticket["note"] = "expired without decision"
                changed = True
        return changed

    def submit(
        self,
        plan: Dict[str, Any],
        rationale: str = "",
        conviction: Optional[float] = None,
        market_decision: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        now = _now()
        with _LOCK:
            tickets = self._load()
            changed = self._expire_due(tickets, now)
            pending = [t for t in tickets if t.get("status") == PENDING]
            if len(pending) >= self.max_pending:
                changed = False
                for ticket in sorted(pending, key=lambda t: str(t.get("created_at") or ""))[: len(pending) - self.max_pending + 1]:
                    ticket["status"] = EXPIRED
                    ticket["decided_at"] = now.isoformat()
                    ticket["decided_by"] = "system"
                    ticket["note"] = "queue overflow"
                    changed = True
            ticket = {
                "id": uuid.uuid4().hex[:12],
                "status": PENDING,
                "created_at": now.isoformat(),
                "expires_at": (now + timedelta(seconds=self.ttl_sec)).isoformat(),
                "symbol": _text(plan.get("symbol"), 24).upper(),
                "direction": _text(plan.get("direction"), 8).upper(),
                "market": _text(plan.get("target_market"), 12).upper(),
                "side": _text(plan.get("side"), 8).upper(),
                "entry_price": _num(plan.get("entry_price")),
                "stop_loss_price": _num(plan.get("stop_loss_price")),
                "take_profit_1": _num(plan.get("take_profit_1")),
                "take_profit_2": _num(plan.get("take_profit_2")),
                "quantity": _num(plan.get("quantity")),
                "position_usdt": _num(plan.get("position_usdt")),
                "risk_reward_ratio": _num(plan.get("risk_reward_ratio")),
                "stop_loss_pct": _num(plan.get("stop_loss_pct")),
                "atr": _num(plan.get("atr")),
                "leverage": _num(plan.get("leverage")),
                "conviction": _num(conviction),
                "rationale": _text(rationale, 400),
                "entry_metrics": plan.get("entry_metrics") if isinstance(plan.get("entry_metrics"), dict) else {},
                "market_decision": market_decision if isinstance(market_decision, dict) else {},
                "decided_at": None,
                "decided_by": None,
                "note": "",
                "consumed_at": None,
            }
            tickets.append(ticket)
            self._save(tickets)
            return ticket

    def decide(self, ticket_id: str, approve: bool, decided_by: str = "operator", note: str = "") -> Tuple[bool, Dict[str, Any]]:
        now = _now()
        with _LOCK:
            tickets = self._load()
            self._expire_due(tickets, now)
            for ticket in tickets:
                if ticket.get("id") != ticket_id:
                    continue
                if ticket.get("status") != PENDING:
                    self._save(tickets)
                    return False, ticket
                ticket["status"] = APPROVED if approve else REJECTED
                ticket["decided_at"] = now.isoformat()
                ticket["decided_by"] = _text(decided_by, 40) or "operator"
                ticket["note"] = _text(note, 200)
                self._save(tickets)
                return True, ticket
            self._save(tickets)
            return False, {"id": ticket_id, "status": "NOT_FOUND"}

    def get(self, ticket_id: str) -> Optional[Dict[str, Any]]:
        with _LOCK:
            tickets = self._load()
            if self._expire_due(tickets, _now()):
                self._save(tickets)
        for ticket in tickets:
            if ticket.get("id") == ticket_id:
                return ticket
        return None

    def pending(self) -> List[Dict[str, Any]]:
        with _LOCK:
            tickets = self._load()
            if self._expire_due(tickets, _now()):
                self._save(tickets)
        return [t for t in tickets if t.get("status") == PENDING]

    def history(self, limit: int = 50) -> List[Dict[str, Any]]:
        with _LOCK:
            tickets = self._load()
            if self._expire_due(tickets, _now()):
                self._save(tickets)
        return tickets[-max(1, int(limit)):]

    def consume(self, ticket_id: Optional[str], plan: Dict[str, Any]) -> Tuple[bool, str]:
        if not ticket_id:
            return False, "missing approval ticket id"
        now = _now()
        with _LOCK:
            tickets = self._load()
            self._expire_due(tickets, now)
            for ticket in tickets:
                if ticket.get("id") != ticket_id:
                    continue
                if ticket.get("status") != APPROVED:
                    self._save(tickets)
                    return False, f"ticket {ticket_id} is {ticket.get('status')}"
                if ticket.get("symbol") != _text(plan.get("symbol"), 24).upper():
                    self._save(tickets)
                    return False, "ticket symbol mismatch"
                if ticket.get("direction") != _text(plan.get("direction"), 8).upper():
                    self._save(tickets)
                    return False, "ticket direction mismatch"
                deadline = _parse(ticket.get("expires_at"))
                if deadline and deadline <= now:
                    ticket["status"] = EXPIRED
                    self._save(tickets)
                    return False, "ticket expired after approval"
                ticket["status"] = CONSUMED
                ticket["consumed_at"] = now.isoformat()
                self._save(tickets)
                return True, "ok"
            self._save(tickets)
            return False, f"ticket {ticket_id} not found"


approval_queue = ApprovalQueue()
