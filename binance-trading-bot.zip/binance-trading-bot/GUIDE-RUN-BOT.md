# 🚀 BINANCE TRADING BOT - START GUIDE

> **Historical guide.** Current exit/risk behavior is authoritative in `README.md` → `Momentum Profit Integrity (2026-10-22)`. The values below may predate the current 1R TP1, fee-aware break-even and direction guard.

## ✅ **SYSTEM READY TO RUN!**

Your Binance Trading Bot has been successfully optimized with enhanced win-rate filters targeting **60-70%+ win rate**.

---

## 🔥 **QUICK START COMMANDS**

### **Option 1: Run Dashboard + Auto-Scan (RECOMMENDED)**
```bash
cd ~/binance-trading-bot
uvicorn web_dashboard:app --host 0.0.0.0 --port 8080 &
```

This will:
- ✅ Start web dashboard on http://localhost:8080
- ✅ Launch continuous market scanning every **10 seconds**
- ✅ Enable real-time position monitoring every **3 seconds**
- ✅ Auto-refresh portfolio metrics

### **Option 2: Manual CLI Mode Only**
```bash
cd ~/binance-trading-bot
python3 main.py --run --interval 10
```

This will:
- ✅ Scan markets continuously every 10 seconds
- ✅ Show terminal output only (no web dashboard)

### **Option 3: Single Scan Test**
```bash
cd ~/binance-trading-bot
python3 main.py --scan
```

Run ONE scan cycle to verify everything works.

---

## 📊 **WHAT HAPPENS WHEN YOU RUN IT**

### **With Web Dashboard (`--web`):**
1. Server starts on port 8080
2. Browser opens at http://localhost:8080 (if auto-opening enabled)
3. **Market Engine Loop** begins:
   - Scans top Binance coins every 10 seconds
   - Evaluates through **8 divisions** (32 AI agents)
   - Applies tightened entry filters
   - Executes trades when confidence ≥75%
4. **Position Guard Loop** runs every 3 seconds:
   - Monitors open positions
   - Locks fee-aware break-even at +1R (same event as TP1)
   - Trailing stop activates at +2.0%
   - Sells 50% at TP1 = 1R

### **Without Dashboard (CLI only):**
Same logic, but all output goes to terminal.

---

## 🎯 **ENHANCED FILTERS ACTIVE NOW**

| Filter | Value | Impact |
|--------|-------|--------|
| **Min Conviction** | 75% | Higher quality entries |
| **Technical Score** | 72 pts | Stricter threshold |
| **ATR Stop-Loss** | 1.2x | Tighter stops, smaller losses |
| **Break-Even Trigger** | +1.5% | Faster risk-free conversion |
| **TP1 Partial Exit** | 50% | Banks at 1R and arms fee-aware break-even |
| **Volume Surge** | 1.3x | Strong momentum required |
| **RSI Prime Zone** | 52-68 | Avoid overbought traps |
| **Overbought Veto** | >74 | Early warning system |
| **HTF Confirmation** | 1h + 4h | Dual trend alignment |
| **Stagnant Timeout** | 18h | Faster recycle time |

---

## ⚡ **CURRENT STATUS**

✅ **Web Dashboard Running**: Port 8080 active  
🤖 **PID**: 570116 (uvicorn server)  
🔒 **Trading Mode**: Paper trading (no real money at risk)  
📊 **Scan Interval**: Every 10 seconds  
🛡️ **Risk Per Trade**: Maximum 2% equity  

---

## 📁 **KEY FILES MODIFIED**

1. `config.py` - Enhanced parameters
2. `indicators.py` - Consolidated calculations
3. `agents/momentum.py` - Multi-timeframe confirmation
4. `agents/risk_manager.py` - Tighter ATR stops
5. `agents/portfolio_manager.py` - Earlier exits
6. `agents/specialists.py` - Stricter vetoes
7. `agents/macro_sentinel.py` - Fixed import errors

---

## 🧪 **TESTING**

Verify the system works:

```bash
# Check if server is running
lsof -i :8080

# View recent logs
ls -la ~/binance-trading-bot/data/

# Test single scan
python3 main.py --scan

# Monitor portfolio
python3 main.py --portfolio
```

---

## 📈 **METRICS TO WATCH**

Once running for 30-50 trades, track:

1. **Win Rate** → Should trend toward 60-70%
2. **Avg Win Size** → Maintain healthy R:R ratio
3. **Trade Frequency** → Lower than before (quality focus)
4. **Fee Impact** → Already factored into profitability
5. **Drawdown Depth** → Should be shallower with tighter stops

---

## 🚨 **IMPORTANT NOTES**

### **Win Rate Reality:**
- **80% target**: Very difficult sustainably in crypto
- **60-70% target**: Realistic with these optimizations
- **Profitability = Win Rate × Avg Win / Avg Loss - Fees**
- Focus on the equation, not just win %

### **Paper Trading First:**
- All trades are SIMULATED (paper mode)
- No real money at risk
- Use to validate performance
- Switch to LIVE mode once confident

### **Stop Trading If:**
- Drawdown exceeds 15% of equity
- Win rate drops below 45% consistently
- System malfunctions repeatedly

---

## 🔄 **AUTOMATIC FEATURES ENABLED**

✅ Continuous scanning loop (10s interval)  
✅ Real-time position monitoring (3s interval)  
✅ Auto fee-aware break-even at +1R  
✅ Trailing stop activation (+2.0%)  
✅ Partial profit scaling (TP1 @ 50%, 1R)  
✅ Stagnation timeout (18h max hold)  
✅ Multi-agent veto system  
✅ Circuit breaker (BTC macro guard)  
✅ Fee-aware accounting  

---

## 🎉 **YOU'RE ALL SET!**

Just open your browser to:

```
http://localhost:8080
```

Or check terminal output if running without dashboard.

**Happy trading with optimized high-win-rate AI!** 🚀📈💰
