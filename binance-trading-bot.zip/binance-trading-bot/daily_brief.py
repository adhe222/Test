import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", "data"))
BRIEF_PATH = DATA_DIR / "daily_brief.json"
PORTFOLIO_PATH = DATA_DIR / "portfolio.json"
BRIEF_LIMIT = 60


def _load(path: Path, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


class DailyBrief:
    def __init__(
        self,
        portfolio_path: Optional[Path] = None,
        brief_path: Optional[Path] = None,
        history_path: Optional[Path] = None,
    ):
        self.portfolio_path = Path(portfolio_path or PORTFOLIO_PATH)
        self.brief_path = Path(brief_path or BRIEF_PATH)
        self.history_path = Path(history_path or DATA_DIR / "trade_history.json")

    def build(self, persist: bool = False) -> Dict[str, Any]:
        from approval_queue import approval_queue
        from trade_reviewer import TradeReviewer

        portfolio = _load(self.portfolio_path, {}) or {}
        review = TradeReviewer(history_path=self.history_path, portfolio_path=self.portfolio_path).review(persist=False)
        metrics = review["metrics"]
        positions = [p for p in (portfolio.get("open_positions") or []) if isinstance(p, dict)]
        cash = float(portfolio.get("cash_usdt") or 0.0)
        allocated = round(sum(float(p.get("position_usdt") or 0.0) for p in positions), 4)
        book_equity = round(cash + allocated, 4)
        pending = approval_queue.pending()

        actions: List[str] = []
        if review["verdict"] == "SAMPLE_TOO_SMALL":
            actions.append(
                f"Sample only {review['sample']['closed_trades']} closed trades in this run; do not tune thresholds yet."
            )
        if review["verdict"] == "NEGATIVE_EDGE":
            actions.append("Profit factor below 1.0: reduce size or pause entries until the ledger turns.")
        fee_share = metrics.get("fee_share_of_gross_pct")
        if isinstance(fee_share, (int, float)) and fee_share > 60:
            actions.append(
                f"Fees consume {fee_share:.1f}% of gross profit: cut trade count or widen targets before adding size."
            )
        worst = review.get("worst_reason") or {}
        if worst.get("trades", 0) >= 3 and worst.get("net_usdt", 0) < 0:
            actions.append(
                f"Largest leak is {worst['key']} (n={worst['trades']}, net {worst['net_usdt']:+.2f}): review that exit rule."
            )
        defects = review.get("defects") or {}
        if defects.get("DEGENERATE_TARGET"):
            actions.append(
                "Degenerate targets booked in this run (pre-fix history): confirm no new ones appear now that "
                "PRICE_SIG_DIGITS/MIN_TARGET_GAP_PCT are enforced."
            )
        if defects.get("FEE_DOMINATED"):
            actions.append("Fee-dominated exits detected: entries are too small relative to round-trip cost.")
        if pending:
            actions.append(f"{len(pending)} approval ticket(s) waiting: decide them in the dashboard before they expire.")
        if not actions:
            actions.append("No structural defect detected in this run; keep collecting out-of-sample trades.")

        brief = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "mode": portfolio.get("mode"),
            "scope_since": review.get("scope_since"),
            "equity_book_usdt": book_equity,
            "cash_usdt": round(cash, 4),
            "allocated_usdt": allocated,
            "initial_capital_usdt": portfolio.get("initial_capital"),
            "open_positions": [
                {
                    "symbol": p.get("symbol"),
                    "direction": p.get("direction"),
                    "market": p.get("market"),
                    "entry_price": p.get("entry_price"),
                    "stop_loss_price": p.get("stop_loss_price"),
                    "take_profit_1": p.get("take_profit_1"),
                    "take_profit_2": p.get("take_profit_2"),
                    "position_usdt": p.get("position_usdt"),
                }
                for p in positions
            ],
            "review": {
                "verdict": review["verdict"],
                "sample": review["sample"],
                "metrics": metrics,
                "worst_reason": review.get("worst_reason"),
                "worst_direction": review.get("worst_direction"),
                "defects": review.get("defects"),
                "process_clean_pct": review.get("process_clean_pct"),
            },
            "approvals_pending": [
                {
                    "id": t.get("id"),
                    "symbol": t.get("symbol"),
                    "direction": t.get("direction"),
                    "entry_price": t.get("entry_price"),
                    "position_usdt": t.get("position_usdt"),
                    "expires_at": t.get("expires_at"),
                }
                for t in pending
            ],
            "actions": actions,
        }
        brief["text"] = self.render(brief)
        if persist:
            self._append(brief)
        return brief

    @staticmethod
    def render(brief: Dict[str, Any]) -> str:
        review = brief["review"]
        metrics = review["metrics"]
        lines = [
            f"DAILY BRIEF {brief['generated_at']}  mode={brief['mode']}",
            (
                f"equity(book) {brief['equity_book_usdt']:.2f} USDT | cash {brief['cash_usdt']:.2f} | "
                f"allocated {brief['allocated_usdt']:.2f} | open {len(brief['open_positions'])}"
            ),
            (
                f"run since {brief['scope_since']} | closed {review['sample']['closed_trades']} | "
                f"net {metrics['net_usdt']:+.2f} | fees {metrics['fees_usdt']:.2f} | "
                f"WR {metrics['win_rate_pct']}% | PF {metrics['profit_factor']}"
            ),
            f"verdict {review['verdict']} | process clean {review['process_clean_pct']}%",
        ]
        if brief["open_positions"]:
            lines.append("open:")
            for pos in brief["open_positions"]:
                lines.append(
                    f"  {pos['symbol']:<10} {str(pos['direction']):<5} entry {pos['entry_price']} "
                    f"SL {pos['stop_loss_price']} TP1 {pos['take_profit_1']} TP2 {pos['take_profit_2']}"
                )
        if brief["approvals_pending"]:
            lines.append("approvals pending:")
            for ticket in brief["approvals_pending"]:
                lines.append(
                    f"  {ticket['id']} {ticket['symbol']} {ticket['direction']} "
                    f"{ticket['position_usdt']} USDT expires {ticket['expires_at']}"
                )
        lines.append("actions:")
        for action in brief["actions"]:
            lines.append(f"  - {action}")
        return "\n".join(lines)

    def _append(self, brief: Dict[str, Any]) -> None:
        journal = _load(self.brief_path, [])
        if not isinstance(journal, list):
            journal = []
        journal.append({
            "generated_at": brief["generated_at"],
            "mode": brief["mode"],
            "equity_book_usdt": brief["equity_book_usdt"],
            "review": brief["review"],
            "approvals_pending": len(brief["approvals_pending"]),
            "actions": brief["actions"],
        })
        journal = journal[-BRIEF_LIMIT:]
        tmp = self.brief_path.with_suffix(".json.tmp")
        try:
            self.brief_path.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(journal, handle, indent=2)
            os.replace(tmp, self.brief_path)
        except OSError:
            try:
                tmp.unlink()
            except OSError:
                pass


if __name__ == "__main__":
    import sys

    save = "--save" in sys.argv[1:]
    print(DailyBrief().build(persist=save)["text"])
