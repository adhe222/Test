import tempfile
import unittest
from pathlib import Path

import config
from agents.consciousness import AgentConsciousnessEngine
from agents.specialists import MomentumExhaustionSpecialist


class TestMomentumDivisionWeightReadback(unittest.TestCase):
    def test_role_name_matches_consciousness_memory_key(self):
        spec = MomentumExhaustionSpecialist(None)
        self.assertEqual(spec.role_name, "Momentum Exhaustion Division")


class TestScratchGuards(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_scratch_outcome_not_learned_as_loss(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "SOLUSDT", "pnl_usdt": -0.0029, "pnl_pct": -0.01,
            "outcome": "SCRATCH", "reason": "BREAK_EVEN",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before)

    def test_legacy_tiny_loss_without_outcome_ignored(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "BTCUSDT", "pnl_usdt": -0.0029, "pnl_pct": -0.002,
            "reason": "BREAK_EVEN",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before)

    def test_real_loss_still_learned(self):
        before = self.engine.memory["total_mistakes_analyzed"]
        self.engine.record_trade_failure_and_learn({
            "symbol": "SOLUSDT", "pnl_usdt": -5.0, "pnl_pct": -2.0,
            "outcome": "LOSS", "reason": "STOP_LOSS",
        })
        self.assertEqual(self.engine.memory["total_mistakes_analyzed"], before + 1)

    def test_win_outcome_still_rewarded(self):
        before = self.engine.get_weight("Technical Price Action Division")
        self.engine.record_trade_success_and_reward({
            "pnl_usdt": 5.0, "pnl_pct": 2.0, "outcome": "WIN",
        })
        self.assertGreater(
            self.engine.get_weight("Technical Price Action Division"), before
        )

    def test_scratch_outcome_not_rewarded(self):
        before = self.engine.get_weight("Technical Price Action Division")
        self.engine.record_trade_success_and_reward({
            "pnl_usdt": 0.001, "pnl_pct": 0.01, "outcome": "SCRATCH",
        })
        self.assertEqual(self.engine.get_weight("Technical Price Action Division"), before)


class TestAIUpgradeValidation(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_weights_clamped_to_sane_bounds(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "9.9.9-ULTRA",
            "dynamic_weights": {"Quantitative Risk & Capital Division": 100},
        })
        self.assertEqual(
            self.engine.get_weight("Quantitative Risk & Capital Division"), 2.0
        )

    def test_thresholds_clamped_and_non_numeric_dropped(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "9.9.9-ULTRA",
            "calibrated_thresholds": {
                "Momentum Exhaustion Division": {"max_rsi": -5.0, "min_rsi": "corrupt"},
            },
        })
        self.assertEqual(
            self.engine.get_threshold("Momentum Exhaustion Division", "max_rsi", 74.0), 55.0
        )
        self.assertEqual(
            self.engine.get_threshold("Momentum Exhaustion Division", "min_rsi", 45.0), 45.0
        )

    def test_corrupt_memory_file_is_preserved_not_wiped(self):
        self._tmp2 = tempfile.TemporaryDirectory()
        path = Path(self._tmp2.name) / "corrupt.json"
        path.write_text("{ truncated garbage", encoding="utf-8")
        AgentConsciousnessEngine(path)
        backups = list(path.parent.glob("corrupt.json.corrupt-*"))
        self.assertTrue(backups)
        self._tmp2.cleanup()


class TestAIMachineRuleEnforcement(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_ai_machine_rule_is_applied_and_enforced(self):
        result = self.engine.apply_ai_upgrade({
            "upgrade_version": "2.5.0-ULTRA",
            "executive_diagnosis": "Volume spikes without follow-through are bleeding.",
            "new_rules": [{
                "division": "Technical Price Action Division",
                "rule_id": "AI-VOL-01",
                "rule": "Reject volume spikes above 1.50x without a strong close.",
                "origin": "AI audit of recent losses",
                "machine_check": {
                    "metric": "volume_surge",
                    "operator": ">",
                    "threshold": 1.50,
                    "direction": "ANY",
                    "action": "PENALTY_OR_VETO",
                },
            }],
        }, meta={"mode": "AI_ULTRA_CONTEXT", "trigger": "SCHEDULED_6H", "model": "test-model"})
        self.assertTrue(result["applied"])
        self.assertEqual(result["changes"]["rules_added"], 1)
        self.assertEqual(self.engine.get_ultra_context_summary()["machine_rule_count"], 1)
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division",
            {"candle": {}, "volume_surge": 1.80},
        )
        self.assertIsNotNone(audit)
        self.assertEqual(audit["rule_id"], "AI-VOL-01")
        self.engine.record_veto_enforced("Technical Price Action Division", "AI-VOL-01")
        rule = next(
            r for r in self.engine.memory["divisions"]["Technical Price Action Division"]["lessons_learned"]
            if r["rule_id"] == "AI-VOL-01"
        )
        self.assertEqual(rule["times_applied"], 1)
        self.assertEqual(self.engine.memory["last_upgrade"]["trigger"], "SCHEDULED_6H")

    def test_require_at_least_rule_uses_less_than_violation(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "2.5.1-ULTRA",
            "new_rules": [{
                "division": "Technical Price Action Division",
                "rule_id": "AI-WEAK-VOL-01",
                "rule": "Require volume_surge >= 1.50 for LONG.",
                "machine_check": {
                    "metric": "volume_surge", "operator": "<", "threshold": 1.50,
                    "direction": "LONG", "action": "VETO",
                },
            }],
        })
        weak = self.engine.audit_against_experience(
            "Technical Price Action Division",
            {"candle": {}, "volume_surge": 1.10, "direction": "LONG"},
        )
        strong = self.engine.audit_against_experience(
            "Technical Price Action Division",
            {"candle": {}, "volume_surge": 1.80, "direction": "LONG"},
        )
        self.assertIsNotNone(weak)
        self.assertEqual(weak["rule_id"], "AI-WEAK-VOL-01")
        self.assertIsNone(strong)

    def test_duplicate_machine_rule_is_rejected(self):
        rule = {
            "division": "Technical Price Action Division",
            "rule_id": "AI-DUP-01",
            "rule": "Require volume_surge >= 1.50.",
            "machine_check": {
                "metric": "volume_surge", "operator": "<", "threshold": 1.50,
                "direction": "LONG", "action": "VETO",
            },
        }
        first = self.engine.apply_ai_upgrade({"new_rules": [rule]})
        second_rule = dict(rule)
        second_rule["rule_id"] = "AI-DUP-02"
        second = self.engine.apply_ai_upgrade({"new_rules": [second_rule]})
        self.assertEqual(first["changes"]["rules_added"], 1)
        self.assertEqual(second["changes"]["rules_added"], 0)
        self.assertEqual(second["changes"]["rejected_rules"], 1)
        self.assertEqual(self.engine.get_ultra_context_summary()["machine_rule_count"], 1)

    def test_short_depth_contradiction_is_rejected(self):
        result = self.engine.apply_ai_upgrade({
            "new_rules": [{
                "division": "Order Book Microstructure Division",
                "rule_id": "AI-BAD-SHORT-DEPTH",
                "rule": "Veto SHORT when bid depth is low.",
                "machine_check": {
                    "metric": "bid_depth_ratio", "operator": "<", "threshold": 2.5,
                    "direction": "SHORT", "action": "VETO",
                },
            }],
        })
        self.assertEqual(result["changes"]["rules_added"], 0)
        self.assertEqual(result["changes"]["rejected_rules"], 1)
        self.assertEqual(self.engine.get_ultra_context_summary()["machine_rule_count"], 0)

    def test_free_text_rule_is_advisory_only(self):
        result = self.engine.apply_ai_upgrade({
            "upgrade_version": "2.5.0-ULTRA",
            "new_rules": [{
                "division": "Technical Price Action Division",
                "rule_id": "AI-FREE-01",
                "rule": "Be careful in chop.",
            }],
        })
        self.assertFalse(result["applied"])
        self.assertEqual(result["changes"]["advisory_rules_added"], 1)
        self.assertEqual(self.engine.get_ultra_context_summary()["machine_rule_count"], 0)
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division",
            {"candle": {}, "volume_surge": 1.80},
        )
        self.assertIsNone(audit)

    def test_no_change_does_not_inflate_upgrade_counter(self):
        before = self.engine.memory["total_upgrades_performed"]
        result = self.engine.apply_ai_upgrade({"upgrade_version": "9.9.9"})
        self.assertFalse(result["applied"])
        self.assertEqual(self.engine.memory["total_upgrades_performed"], before)
        self.assertFalse(self.engine.memory["last_upgrade"]["applied"])


class TestLearnedThresholdEnforcement(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "c.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_learned_volume_floor_vetoes(self):
        self.engine.memory["divisions"]["Technical Price Action Division"][
            "calibrated_thresholds"]["min_volume_surge"] = 1.30
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division", {"candle": {}, "volume_surge": 1.05}
        )
        self.assertIsNotNone(audit)
        self.assertTrue(audit["violation"])
        self.assertEqual(audit["rule_id"], "PA-VOL-LEARNED")

    def test_founder_floor_does_not_veto(self):
        audit = self.engine.audit_against_experience(
            "Technical Price Action Division", {"candle": {}, "volume_surge": 1.05}
        )
        self.assertIsNone(audit)

    def test_learned_rsi_ceiling_vetoes(self):
        self.engine.memory["divisions"]["Momentum Exhaustion Division"][
            "calibrated_thresholds"]["max_rsi"] = 71.0
        audit = self.engine.audit_against_experience(
            "Momentum Exhaustion Division", {"rsi": 73.5}
        )
        self.assertIsNotNone(audit)
        self.assertTrue(audit["violation"])
        self.assertEqual(audit["action"], "VETO")


class TestTradingProfiles(unittest.TestCase):
    KNOBS = (
        "MIN_TECHNICAL_SCORE", "ENHANCED_MIN_CONVICTION", "MIN_RISK_REWARD_RATIO",
        "RISK_PER_TRADE_PCT", "DAILY_LOSS_LIMIT_PCT", "LOSS_STREAK_TIGHTEN_AFTER",
    )

    def setUp(self):
        self.saved = {k: getattr(config, k) for k in self.KNOBS}
        self.saved_explicit = dict(config._PROFILE_KNOBS_EXPLICIT)
        for knob in config._PROFILE_KNOBS_EXPLICIT:
            config._PROFILE_KNOBS_EXPLICIT[knob] = False

    def tearDown(self):
        for k, v in self.saved.items():
            setattr(config, k, v)
        config._PROFILE_KNOBS_EXPLICIT.clear()
        config._PROFILE_KNOBS_EXPLICIT.update(self.saved_explicit)
        config.apply_trading_profile("balanced")

    def test_aggressive_profile_applies_presets(self):
        config.apply_trading_profile("aggressive")
        self.assertEqual(config.MIN_TECHNICAL_SCORE, 62)
        self.assertEqual(config.ENHANCED_MIN_CONVICTION, 66)
        self.assertEqual(config.MIN_RISK_REWARD_RATIO, 1.4)
        self.assertEqual(config.RISK_PER_TRADE_PCT, 4.0)
        self.assertEqual(config.DAILY_LOSS_LIMIT_PCT, 8.0)
        self.assertEqual(config.LOSS_STREAK_TIGHTEN_AFTER, 3)

    def test_conservative_profile_applies_presets(self):
        config.apply_trading_profile("conservative")
        self.assertEqual(config.MIN_TECHNICAL_SCORE, 76)
        self.assertEqual(config.ENHANCED_MIN_CONVICTION, 82)
        self.assertEqual(config.RISK_PER_TRADE_PCT, 1.0)

    def test_explicit_env_knob_beats_profile(self):
        before = config.RISK_PER_TRADE_PCT
        config._PROFILE_KNOBS_EXPLICIT["RISK_PER_TRADE_PCT"] = True
        try:
            config.apply_trading_profile("aggressive")
            self.assertEqual(config.RISK_PER_TRADE_PCT, before)
        finally:
            config._PROFILE_KNOBS_EXPLICIT["RISK_PER_TRADE_PCT"] = False

    def test_unknown_profile_rejected(self):
        with self.assertRaises(ValueError):
            config.apply_trading_profile("yolo")


if __name__ == "__main__":
    unittest.main()
