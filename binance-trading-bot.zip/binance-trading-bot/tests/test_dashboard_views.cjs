const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function makeView() {
  const nodes = new Map();
  const get = (selector) => {
    const id = selector.replace(/^#/, '');
    if (!nodes.has(id)) nodes.set(id, { textContent: '', innerHTML: '', hidden: true, open: false, classList: { toggle() {} } });
    return nodes.get(id);
  };
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const context = { window: { AegisUtil: {
    $: get,
    setText: (id, text) => { get(id).textContent = text; },
    setHTML: (id, html) => { get(id).innerHTML = html; },
    safe: (value) => Number.isFinite(Number(value)) ? Number(value) : 0,
    num: (value) => String(value),
    esc
  } }, Intl, Date };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../static/js/operations.js'), 'utf8'), context);
  return { view: context.window.AegisOperations, get };
}

function fixture() {
  return { market_operations: {
    mode: 'PAPER', mode_mismatch: false,
    execution_notice: 'Simulasi PAPER. Tidak ada order yang dikirim ke exchange.',
    routes: [
      { market: 'SPOT', direction: 'LONG', execution: 'SIMULATION', configured: true, status: 'WAITING_SETUP', entry_eligible: true, reason: 'Menunggu setup' },
      { market: 'FUTURES', direction: 'SHORT', execution: 'SIMULATION', configured: true, status: 'MACRO_PAUSED', entry_eligible: false, reason: 'Macro paused' }
    ],
    activity: 'SCANNING', snapshot_at: '2026-10-19T00:00:00Z', data_market: 'SPOT', data_host: 'data-api.binance.vision',
    timeframes: ['15m', '1h', '4h', '5m'], data_notice: 'Data Spot untuk simulasi', futures_notice: 'Tidak ada leverage', configured_leverage: 1,
    candidates: [], evaluated_count: 0, executed_count: 0
  } };
}

test('shows both simulated routes even with no open positions', () => {
  const { view, get } = makeView();
  view.render(fixture());
  assert.match(get('marketRoutes').innerHTML, /SPOT LONG/);
  assert.match(get('marketRoutes').innerHTML, /FUTURES SHORT/);
  assert.match(get('marketRoutes').innerHTML, /Entry ditahan makro/);
  assert.equal(get('executionMode').textContent, 'PAPER · SIMULASI');
  assert.match(get('botActivity').textContent, /Memindai/);
});

test('dynamic symbols and reasons are HTML escaped', () => {
  const { view, get } = makeView();
  const data = fixture();
  data.market_operations.candidates = [{ symbol: '<img src=x onerror=alert(1)>', market: 'FUTURES', direction: 'SHORT', status: 'BLOCKED', blockers: ['<script>alert(1)</script>'] }];
  view.render(data);
  assert.doesNotMatch(get('candidateAudit').innerHTML, /<img|<script/);
  assert.match(get('candidateAudit').innerHTML, /&lt;img/);
});

test('invalid dates and malformed row envelopes do not crash rendering', () => {
  const { view } = makeView();
  assert.match(view.stamp('bad date'), /belum valid/);
  assert.equal(view.rows({ items: {} }).length, 0);
  assert.equal(view.rows({ items: [null, { direction: 'SHORT' }] }).length, 1);
});

test('disconnection marks retained route information stale', () => {
  const { view, get } = makeView();
  view.render(fixture());
  const retained = get('marketRoutes').innerHTML;
  view.stale(true);
  assert.equal(get('operationsFreshness').hidden, false);
  assert.equal(get('marketRoutes').innerHTML, retained);
  view.render(fixture());
  assert.equal(get('operationsFreshness').hidden, true);
});

test('more candidates disclosure remains open during telemetry refresh', () => {
  const { view, get } = makeView();
  const data = fixture();
  data.market_operations.candidates = Array.from({ length: 15 }, (_, index) => ({ symbol: `ASSET${index}`, market: 'SPOT', direction: 'LONG', status: 'BLOCKED', blockers: ['Gate denied'] }));
  view.render(data);
  assert.match(get('candidateAudit').innerHTML, /Lihat 12 kandidat lainnya/);
  get('remainingCandidates').open = true;
  data.market_operations.candidates[0].blockers.push('Fresh reason');
  view.render(data);
  assert.match(get('candidateAudit').innerHTML, /id="remainingCandidates" open/);
  assert.equal((get('candidateAudit').innerHTML.match(/class="audit-row"/g) || []).length, 15);
});

test('unknown API does not pretend to confirm Spot or Futures', () => {
  const { view, get } = makeView();
  view.render({});
  assert.equal(get('executionMode').textContent, 'MENUNGGU API BARU');
  assert.equal(get('operationsFreshness').hidden, false);
});

function makeSummaryView() {
  const nodes = new Map();
  const get = (selector) => {
    const id = selector.replace(/^#/, '');
    if (!nodes.has(id)) nodes.set(id, {
      textContent: '', innerHTML: '', hidden: true, className: '', style: {},
      dataset: {}, classList: { toggle() {}, add() {}, remove() {} }, setAttribute() {},
    });
    return nodes.get(id);
  };
  const U = {
    $: get,
    $$: () => [],
    setText: (id, text) => { get(id).textContent = text; },
    setHTML: (id, html) => { get(id).innerHTML = html; },
    flash() {}, countTo() {}, setProgress() {},
    safe: (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback,
    num: (value) => String(value), money: (value) => String(value), signed: (value) => String(value),
    pct: (value) => String(value) + '%', cls: () => '', esc: (value) => String(value ?? ''),
    title: (value) => String(value), stamp: () => '',
  };
  const context = {
    window: {
      AegisUtil: U,
      AegisOperations: { rows: () => [], stamp: () => '' },
      AegisTheme: { current: () => 'dark', onChange() {} },
    },
    Intl, Date, Math,
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../static/js/views.js'), 'utf8'), context);
  return { view: context.window.AegisViews, get };
}

test('summary renders unlimited capacity without throwing', () => {
  const { view, get } = makeSummaryView();
  const data = {
    mode: 'PAPER', capacity_used: 3, capacity_max: 0,
    capacity_unlimited: true, correlation_unlimited: true,
    quality_gates: { max_position_size_pct: 15 },
    autonomous_loop: {}, latest_scan: {}, market_operations: { routes: [] },
    open_positions: [], periodic_performance: {}, rejection_funnel: [], accepted_quotes: [],
    macro_health: {}, adaptive_guard: {},
  };
  assert.doesNotThrow(() => view.overview(data));
  assert.match(get('capacity').textContent, /∞/);
  assert.match(get('capacityCaption').textContent, /Tanpa batas searah/);
});
