import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from trade_reviewer import TradeReviewer, format_report


def _event(symbol, reason, pnl, gross, fee, pct, entry, exit_, direction="SHORT"):
    return {
        "symbol": symbol,
        "action": "CLOSED",
        "direction": direction,
        "reason": reason,
        "pnl_usdt": pnl,
        "gross_pnl_usdt": gross,
        "fee_paid_usdt": fee,
        "pnl_pct": pct,
        "entry_time": entry,
        "exit_time": exit_,
    }


class TradeReviewerCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.history = self.root / "trade_history.json"
        self.portfolio = self.root / "portfolio.json"
        self.journal = self.root / "review_journal.json"
        self.reviewer = TradeReviewer(self.history, self.portfolio, self.journal)
        self.start = datetime(2026, 10, 22, 7, 0, tzinfo=timezone.utc)

    def tearDown(self):
        self.tmp.cleanup()

    def _write(self, events, counter_since=None):
        self.history.write_text(json.dumps(events), encoding="utf-8")
        self.portfolio.write_text(
            json.dumps({"counter_since": (counter_since or self.start).isoformat()}), encoding="utf-8"
        )

    def test_flags_degenerate_target_and_fee_only_loss(self):
        entry = self.start.isoformat()
        exit_ = (self.start + timedelta(seconds=2)).isoformat()
        self._write([
            _event("SHIBUSDT", "TAKE_PROFIT_2_HIT", -0.2996, 0.0, 0.1498, -0.2, entry, exit_),
            _event(
                "SUIUSDT", "MOMENTUM_TIME_STOP_EXIT", -1.0546, -0.7538, 0.3008, -0.7,
                (self.start + timedelta(minutes=1)).isoformat(),
                (self.start + timedelta(minutes=31)).isoformat(),
            ),
        ])
        report = self.reviewer.review(persist=False)
        flags = report["defects"]
        self.assertEqual(flags.get("DEGENERATE_TARGET"), 1)
        self.assertEqual(flags.get("FEE_ONLY_LOSS"), 1)
        self.assertEqual(flags.get("SUB_MINUTE_HOLD"), 1)
        self.assertEqual(report["sample"]["closed_trades"], 2)
        self.assertEqual(report["process_clean_pct"], 50.0)
        self.assertEqual(report["verdict"], "SAMPLE_TOO_SMALL")

    def test_scope_excludes_events_before_counter_since(self):
        old = (self.start - timedelta(days=2)).isoformat()
        new = (self.start + timedelta(minutes=5)).isoformat()
        self._write([
            _event("BTCUSDT", "TAKE_PROFIT_2_HIT", 25.0, 25.2, 0.2, 2.0, old, old),
            _event("ETHUSDT", "STOP_LOSS_HIT", -3.0, -2.7, 0.3, -1.5, new, new),
        ])
        report = self.reviewer.review(persist=False)
        self.assertEqual(report["sample"]["closed_trades"], 1)
        self.assertEqual(report["metrics"]["net_usdt"], -3.0)
        self.assertEqual(report["metrics"]["wins"], 0)

    def test_profit_factor_and_fee_share(self):
        base = self.start
        events = []
        for index in range(3):
            entry = (base + timedelta(hours=index)).isoformat()
            exit_ = (base + timedelta(hours=index, minutes=45)).isoformat()
            events.append(_event("INJUSDT", "TRAILING_STOP_EXIT", 4.0, 4.3, 0.3, 2.0, entry, exit_))
        for index in range(2):
            entry = (base + timedelta(hours=10 + index)).isoformat()
            exit_ = (base + timedelta(hours=10 + index, minutes=20)).isoformat()
            events.append(_event("NEARUSDT", "STOP_LOSS_HIT", -3.0, -2.7, 0.3, -1.5, entry, exit_))
        self._write(events)
        report = self.reviewer.review(persist=False)
        self.assertEqual(report["metrics"]["net_usdt"], 6.0)
        self.assertAlmostEqual(report["metrics"]["profit_factor"], 2.0, places=3)
        self.assertAlmostEqual(report["metrics"]["fee_share_of_gross_pct"], 1.5 / 7.5 * 100.0, places=1)
        self.assertEqual(report["verdict"], "SAMPLE_TOO_SMALL")

    def test_aggregation_surfaces_worst_reason_first(self):
        base = self.start
        events = [
            _event("SUIUSDT", "MOMENTUM_TIME_STOP_EXIT", -1.05, -0.75, 0.30, -0.7,
                   (base + timedelta(hours=1)).isoformat(), (base + timedelta(hours=2)).isoformat()),
            _event("SUIUSDT", "MOMENTUM_TIME_STOP_EXIT", -0.95, -0.65, 0.30, -0.6,
                   (base + timedelta(hours=3)).isoformat(), (base + timedelta(hours=4)).isoformat()),
            _event("AAVEUSDT", "TRAILING_STOP_EXIT", 1.59, 1.74, 0.15, 1.07,
                   (base + timedelta(hours=5)).isoformat(), (base + timedelta(hours=6)).isoformat()),
        ]
        self._write(events)
        report = self.reviewer.review(persist=False)
        self.assertEqual(report["worst_reason"]["key"], "MOMENTUM_TIME_STOP_EXIT")
        self.assertEqual(report["by_reason"][0]["trades"], 2)
        self.assertEqual(report["by_direction"][0]["key"], "SHORT")

    def test_journal_appends_and_caps(self):
        base = self.start
        self._write([
            _event("BTCUSDT", "TAKE_PROFIT_2_HIT", 2.0, 2.2, 0.2, 1.0,
                   (base + timedelta(hours=1)).isoformat(), (base + timedelta(hours=2)).isoformat())
        ])
        self.reviewer.review(persist=True)
        self.reviewer.review(persist=True)
        journal = json.loads(self.journal.read_text(encoding="utf-8"))
        self.assertEqual(len(journal), 2)
        self.assertIn("metrics", journal[0])
        self.assertEqual(journal[-1]["verdict"], "SAMPLE_TOO_SMALL")

    def test_missing_files_produce_empty_report(self):
        report = self.reviewer.review(persist=False)
        self.assertEqual(report["sample"]["closed_trades"], 0)
        self.assertEqual(report["verdict"], "SAMPLE_TOO_SMALL")
        self.assertIn("REVIEW", format_report(report))

    def test_format_report_contains_verdict_and_reasons(self):
        base = self.start
        self._write([
            _event("BTCUSDT", "STOP_LOSS_HIT", -2.0, -1.7, 0.3, -1.0,
                   (base + timedelta(hours=1)).isoformat(), (base + timedelta(hours=2)).isoformat())
        ])
        text = format_report(self.reviewer.review(persist=False))
        self.assertIn("SAMPLE_TOO_SMALL", text)
        self.assertIn("STOP_LOSS_HIT", text)
        self.assertIn("by direction", text)


if __name__ == "__main__":
    unittest.main()
