import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("TV_VERIFY_ENABLED", "true")
os.environ.setdefault("BOT_DATA_DIR", tempfile.mkdtemp(prefix="tv-bridge-tests-"))

from tv_bridge import TIMEFRAMES, TV_INTERVALS, TradingViewBridge


def synthetic_row(score: float = 0.6):
    """Build one scanner row whose columns match the requested contract."""
    row = {}
    for tf, code in TV_INTERVALS.items():
        row[f"Recommend.All|{code}"] = score
        row[f"Recommend.MA|{code}"] = score
        row[f"Recommend.Other|{code}"] = score
        row[f"RSI|{code}"] = 60.0 if score > 0 else 40.0
        row[f"close|{code}"] = 100.0
        row[f"EMA20|{code}"] = 99.0 if score > 0 else 101.0
        row[f"EMA50|{code}"] = 98.0 if score > 0 else 102.0
        row[f"EMA200|{code}"] = 97.0 if score > 0 else 103.0
        row[f"ADX|{code}"] = 28.0
        row[f"ATR|{code}"] = 1.0
        row[f"volume|{code}"] = 1000.0
        row[f"change|{code}"] = 1.0
        row[f"MACD.macd|{code}"] = 0.5 if score > 0 else -0.5
        row[f"MACD.signal|{code}"] = 0.2 if score > 0 else -0.2
    return row


class TradingViewBridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.journal = Path(self.tmp.name) / "tv.jsonl"
        self.bridge = TradingViewBridge(journal_path=self.journal)
        self.bridge.enabled = True
        self.bridge.mode = "veto"
        self.bridge.require_data = False
        self.bridge.veto_threshold = 0.30
        self.bridge.confirm_threshold = 0.15

    def tearDown(self):
        self.tmp.cleanup()

    def test_symbol_mapping_uses_venue_and_keeps_quote(self):
        self.bridge.exchange = "OKX"
        self.assertEqual(self.bridge.tv_ticker("BTCUSDT"), "OKX:BTCUSDT")
        self.assertEqual(self.bridge.tv_ticker("ETH-USDT"), "OKX:ETHUSDT")

    def test_row_analysis_produces_aligned_long_bias(self):
        analysis = self.bridge._analyze_row("BTCUSDT", synthetic_row(0.6))
        self.assertEqual(analysis["bias"], "LONG")
        self.assertGreater(analysis["score"], 0.3)
        self.assertEqual(sorted(analysis["timeframes"]), sorted(TIMEFRAMES))
        self.assertEqual(analysis["aligned"]["LONG"], 4)
        self.assertAlmostEqual(analysis["price"], 100.0)

    def test_negative_row_produces_short_bias(self):
        analysis = self.bridge._analyze_row("BTCUSDT", synthetic_row(-0.6))
        self.assertEqual(analysis["bias"], "SHORT")
        self.assertLess(analysis["score"], -0.3)
        self.assertEqual(analysis["aligned"]["SHORT"], 4)

    def _analyse(self, score, symbol="BTCUSDT"):
        return self.bridge._analyze_row(symbol, synthetic_row(score))

    def test_entry_long_confirmed_by_bullish_stack(self):
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(0.6)}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "CONFIRMED")
        self.assertFalse(result["veto"])
        self.assertEqual(result["verdict"], "APPROVE")
        self.assertGreater(result["directional_score"], 0)

    def test_entry_long_vetoed_by_bearish_htf(self):
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(-0.6)}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "CONFLICT")
        self.assertTrue(result["veto"])
        self.assertEqual(result["verdict"], "REJECT")

    def test_short_direction_inverts_confirmation(self):
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(-0.6)}):
            result = self.bridge.verify_entry("BTCUSDT", "SHORT")
        self.assertEqual(result["status"], "CONFIRMED")
        self.assertFalse(result["veto"])

    def test_advisory_mode_never_vetoes(self):
        self.bridge.mode = "advisory"
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(-0.6)}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "CONFLICT")
        self.assertFalse(result["veto"])
        self.assertEqual(result["verdict"], "APPROVE")

    def test_missing_data_fails_open_by_default(self):
        with patch.object(self.bridge, "snapshot", return_value={}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertFalse(result["veto"])

    def test_missing_data_fails_closed_when_required(self):
        self.bridge.require_data = True
        with patch.object(self.bridge, "snapshot", return_value={}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertTrue(result["veto"])
        self.assertEqual(result["verdict"], "REJECT")

    def test_verification_report_rejects_on_conflict(self):
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(-0.6)}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        report = self.bridge.verification_report(result)
        self.assertEqual(report["verdict"], "REJECT")
        self.assertLess(report["conviction"], 50)
        self.assertIn("TradingView", report["specialist"])

    def test_journal_entry_monitor_and_exit_are_persisted(self):
        plan = {
            "symbol": "BTCUSDT", "direction": "LONG", "target_market": "SPOT",
            "entry_price": 100.0, "stop_loss_price": 98.0, "take_profit_1": 103.0,
            "take_profit_2": 106.0, "quantity": 1.0,
        }
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": self._analyse(0.6)}):
            verification = self.bridge.verify_entry("BTCUSDT", "LONG")
            self.bridge.journal_entry(plan, verification)
            self.bridge.journal_monitor({"symbol": "BTCUSDT", "direction": "LONG", "entry_price": 100.0, "current_price": 101.0})
            event = {"symbol": "BTCUSDT", "direction": "LONG", "action": "CLOSED", "exit_time": "2026-10-26T01:00:00Z", "pnl_usdt": 1.2}
            self.bridge.journal_exit(event)
            self.bridge.journal_exit(event)  # duplicate must be ignored
        events = self.bridge.trail("BTCUSDT", limit=20)
        kinds = [e["event"] for e in events]
        self.assertEqual(kinds.count("ENTRY_EXECUTED"), 1)
        self.assertEqual(kinds.count("POSITION_MONITORED"), 1)
        self.assertEqual(kinds.count("POSITION_CLOSED"), 1)
        self.assertEqual(len(self.journal.read_text().strip().splitlines()), 3)
        self.assertTrue(all("verified" not in e for e in events))

    def test_trail_filters_other_symbols(self):
        self.bridge._journal({"event": "ENTRY_EXECUTED", "symbol": "BTCUSDT"})
        self.bridge._journal({"event": "ENTRY_EXECUTED", "symbol": "ETHUSDT"})
        events = self.bridge.trail("ETHUSDT")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["symbol"], "ETHUSDT")

    def test_disabled_bridge_returns_no_snapshots(self):
        self.bridge.enabled = False
        self.assertEqual(self.bridge.snapshot(["BTCUSDT"]), {})
        result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertFalse(result["veto"])

    def test_local_venue_indicator_engine_scores_uptrend(self):
        class FakeClient:
            def get_klines(self, symbol, interval="15m", limit=180, market="SPOT"):
                rows = []
                for i in range(260):
                    price = 100.0 + i * 0.1
                    rows.append({
                        "open_time": 1_700_000_000_000 + i * 900_000,
                        "open": price - 0.05, "high": price + 0.15,
                        "low": price - 0.15, "close": price,
                        "volume": 10.0, "is_closed": True,
                    })
                return rows

        self.bridge.client = FakeClient()
        local = self.bridge._local_analysis("BTCUSDT", "SPOT")
        self.assertIsNotNone(local)
        self.assertEqual(local["engine"], "tradingview-mcp/indicators_calc")
        self.assertGreater(local["score"], 0.3)
        self.assertEqual(local["candles"], 260)
        with patch.object(self.bridge, "snapshot", return_value={}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG", market="SPOT")
        self.assertIsNotNone(result["local"])
        self.assertEqual(result["source"], "tradingview-scanner+venue-candles")

    def test_local_engine_returns_none_without_client(self):
        self.bridge.client = None
        self.assertIsNone(self.bridge._local_analysis("BTCUSDT", "SPOT"))

    def test_stale_snapshot_cannot_veto_a_fresh_signal(self):
        stale = self._analyse(-0.6)
        stale["stale"] = True
        stale["age_sec"] = 900.0
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": stale}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertFalse(result["veto"])
        self.assertNotEqual(result["status"], "CONFLICT")
        self.assertTrue(result["tv_stale"])
        self.assertIsNone(result["tv_directional_score"])

    def test_stale_snapshot_falls_back_to_venue_candles(self):
        class FakeClient:
            def get_klines(self, symbol, interval="15m", limit=180, market="SPOT"):
                return [
                    {
                        "open_time": 1_700_000_000_000 + i * 900_000,
                        "open": 100.0 + i * 0.1, "high": 100.2 + i * 0.1,
                        "low": 99.9 + i * 0.1, "close": 100.1 + i * 0.1,
                        "volume": 10.0, "is_closed": True,
                    }
                    for i in range(260)
                ]

        self.bridge.client = FakeClient()
        stale = self._analyse(-0.6)
        stale["stale"] = True
        with patch.object(self.bridge, "snapshot", return_value={"BTCUSDT": stale}):
            result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertIsNotNone(result["local"])
        self.assertGreater(result["directional_score"], 0)
        self.assertFalse(result["veto"])

    def test_disabled_bridge_ignores_venue_candle_fallback(self):
        class FakeClient:
            def get_klines(self, *args, **kwargs):
                raise AssertionError("venue candles must not be read when disabled")

        self.bridge.client = FakeClient()
        self.bridge.enabled = False
        result = self.bridge.verify_entry("BTCUSDT", "LONG")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertIsNone(result["local"])
        self.assertIn("disabled", result["reason"].lower())

    def test_journal_monitor_reuses_prefetched_verification(self):
        plan = {"symbol": "BTCUSDT", "direction": "LONG"}
        verification = {"symbol": "BTCUSDT", "status": "CONFIRMED", "veto": False}
        with patch.object(self.bridge, "verify_entry") as verify:
            event = self.bridge.journal_monitor(
                {"symbol": "BTCUSDT", "direction": "LONG"}, verification=verification
            )
        verify.assert_not_called()
        self.assertEqual(event["verification"]["status"], "CONFIRMED")

    def test_scanner_failure_opens_cooldown_and_serves_cache(self):
        self.bridge._cache["BTCUSDT"] = {
            **self._analyse(0.6),
            "fetched_ts": 0.0,
        }

        class Boom(Exception):
            response = type("R", (), {"status_code": 429, "headers": {}})()

        with patch.object(self.bridge, "_fetch", side_effect=Boom("429")):
            first = self.bridge.snapshot(["BTCUSDT"], force=True)
        self.assertGreater(self.bridge._backoff_until, 0)
        self.assertEqual(self.bridge.health()["status"], "DEGRADED")
        self.assertGreater(self.bridge.health()["retry_after_sec"], 0)
        self.assertIn("BTCUSDT", first)
        calls = self.bridge._fetch_calls
        # Inside the cooldown the bridge must not spend another request.
        with patch.object(self.bridge, "_fetch", side_effect=AssertionError("no refetch")):
            self.bridge.snapshot(["BTCUSDT"], force=True)
        self.assertEqual(self.bridge._fetch_calls, calls)

    def test_unlisted_symbol_is_negative_cached_not_an_outage(self):
        class FakeResponse:
            status_code = 200
            headers = {}

            def raise_for_status(self):
                return None

            def json(self):
                return {"totalCount": 0, "data": [], "columns": self_columns}

        self_columns = self.bridge._columns()
        with patch.object(self.bridge._session, "post", return_value=FakeResponse()):
            result = self.bridge.snapshot(["NOPEUSDT"], force=True)
        self.assertEqual(result, {})
        self.assertEqual(self.bridge._consecutive_failures, 0)
        self.assertEqual(self.bridge.health()["status"], "WARMING_UP")
        self.assertEqual(self.bridge.health()["missing_symbols"], 1)
        # Second call must not spend another HTTP request inside the TTL.
        with patch.object(self.bridge._session, "post", side_effect=AssertionError("no refetch")):
            self.bridge.snapshot(["NOPEUSDT"], force=True)


if __name__ == "__main__":
    unittest.main()
