"""Tick-by-tick market stream: parser, staleness, velocity and fallback contract."""
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import market_stream as ms


class StreamParserTests(unittest.TestCase):
    def setUp(self):
        self.stream = ms.MarketStream(exchange="okx")
        self.stream.enabled = True

    def test_okx_inst_mapping(self):
        self.assertEqual(self.stream._okx_inst("BTCUSDT", "SPOT"), "BTC-USDT")
        self.assertEqual(self.stream._okx_inst("BTCUSDT", "FUTURES"), "BTC-USDT-SWAP")
        self.assertEqual(self.stream._okx_inst("ETH-USDT", "SPOT"), "ETH-USDT")

    def test_okx_ticker_stored_and_priced(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        self.stream._handle(
            '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"65000.5","bidPx":"64999","askPx":"65001","ts":"1793000000000","vol24h":"123"}]}',
            "SPOT",
        )
        self.assertAlmostEqual(self.stream.price("BTCUSDT", "SPOT"), 65000.5)
        quote = self.stream.quote("BTCUSDT", "SPOT")
        self.assertEqual(quote["source"], "okx-ws")
        self.assertLess(quote["age_sec"], 1.0)

    def test_stale_quote_is_not_returned(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        self.stream._handle(
            '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"65000"}]}',
            "SPOT",
        )
        with patch("market_stream.time.time", return_value=time.time() + 30):
            self.assertIsNone(self.stream.price("BTCUSDT", "SPOT"))
            self.assertIsNone(self.stream.quote("BTCUSDT", "SPOT"))

    def test_binance_aggtrade_stored(self):
        stream = ms.MarketStream(exchange="binance")
        stream._inst_map["btcusdt@aggTrade"] = ("BTCUSDT", "SPOT")
        stream._handle(
            '{"stream":"btcusdt@aggTrade","data":{"s":"BTCUSDT","p":"65123.4","q":"0.01","T":1793000000000}}',
            "SPOT",
        )
        self.assertAlmostEqual(stream.price("BTCUSDT", "SPOT"), 65123.4)

    def test_velocity_uses_tick_history(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        now = time.time()
        with patch("market_stream.time.time", return_value=now - 30):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"100"}]}',
                "SPOT",
            )
        with patch("market_stream.time.time", return_value=now):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"101"}]}',
                "SPOT",
            )
            self.assertAlmostEqual(self.stream.velocity("BTCUSDT", "SPOT", window_sec=60), 1.0, places=4)

    def test_stats_contract(self):
        stats = self.stream.stats()
        for key in ("enabled", "connected", "healthy", "symbols_streaming", "ticks", "ticks_per_sec", "reconnects"):
            self.assertIn(key, stats)
        self.assertFalse(stats["healthy"])

    def test_pong_and_garbage_are_ignored(self):
        self.stream._handle("pong", "SPOT")
        self.stream._handle("not json", "SPOT")
        self.stream._handle('{"event":"subscribe"}', "SPOT")
        self.assertEqual(self.stream.stats()["ticks"], 0)

    def test_disabled_stream_never_starts(self):
        stream = ms.MarketStream()
        stream.enabled = False
        self.assertFalse(stream.start())

    def test_listener_receives_every_parsed_tick(self):
        received = []
        self.stream.add_listener(received.append)
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        self.stream._handle(
            '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"65001"}]}',
            "SPOT",
        )
        self.assertEqual(len(received), 1)
        self.assertEqual(received[0]["symbol"], "BTCUSDT")
        self.assertEqual(received[0]["price"], 65001.0)

    def test_mover_emits_market_symbol_key_once_per_cooldown(self):
        self.stream._inst_map["BTC-USDT"] = ("BTCUSDT", "SPOT")
        now = time.time()
        with patch("market_stream.time.time", return_value=now - 30):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"100"}]}',
                "SPOT",
            )
        with patch("market_stream.time.time", return_value=now):
            self.stream._handle(
                '{"arg":{"channel":"tickers","instId":"BTC-USDT"},"data":[{"last":"100.6"}]}',
                "SPOT",
            )
            self.assertEqual(self.stream.movers(0.5, 60.0, 45.0), ["SPOT:BTCUSDT"])
            self.assertEqual(self.stream.movers(0.5, 60.0, 45.0), [])


class PortfolioFallbackTests(unittest.TestCase):
    def test_price_for_uses_rest_when_stream_stale(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock

        client = MagicMock()
        client.get_price.return_value = 42.0
        pm = PortfolioManagerAgent(client, mode="paper")
        pm.market_stream = MagicMock()
        pm.market_stream.price.return_value = None
        self.assertEqual(pm._price_for("BTCUSDT", "SPOT"), 42.0)
        client.get_price.assert_called_once()

    def test_price_for_prefers_stream(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock

        client = MagicMock()
        client.get_price.return_value = 42.0
        pm = PortfolioManagerAgent(client, mode="paper")
        pm.market_stream = MagicMock()
        pm.market_stream.price.return_value = 43.5
        self.assertEqual(pm._price_for("BTCUSDT", "SPOT"), 43.5)
        client.get_price.assert_not_called()

    def test_targeted_tick_closes_only_matching_position(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock
        import config

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ):
                client = MagicMock()
                client.get_price.side_effect = lambda symbol, market=None: 97.0
                pm = PortfolioManagerAgent(client, mode="paper")
                pm.market_stream = MagicMock()
                pm.market_stream.price.return_value = None
                for symbol in ("AAAUSDT", "BBBUSDT"):
                    self.assertTrue(pm.execute_buy({
                        "symbol": symbol,
                        "entry_price": 100.0,
                        "quantity": 1.0,
                        "position_usdt": 100.0,
                        "stop_loss_price": 98.0,
                        "stop_loss_pct": 2.0,
                        "take_profit_1": 103.0,
                        "take_profit_2": 106.0,
                        "trailing_trigger_pct": 2.0,
                        "trailing_distance_pct": 1.0,
                    }))
                actions = pm.update_and_monitor_positions(symbols=["AAAUSDT"])
                self.assertEqual([a["symbol"] for a in actions], ["AAAUSDT"])
                self.assertEqual([p["symbol"] for p in pm.get_open_positions()], ["BBBUSDT"])

    def test_targeted_tick_persists_mark_state_on_throttled_interval(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock
        import config

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with patch.object(config, "PORTFOLIO_FILE", root / "portfolio.json"), patch.object(
                config, "TRADE_LOG_FILE", root / "trades.json"
            ), patch.object(config, "TICK_STATE_PERSIST_SEC", 2.0):
                client = MagicMock()
                client.get_price.return_value = 100.5
                pm = PortfolioManagerAgent(client, mode="paper")
                pm.market_stream = MagicMock()
                pm.market_stream.price.return_value = None
                self.assertTrue(pm.execute_buy({
                    "symbol": "AAAUSDT", "entry_price": 100.0, "quantity": 1.0,
                    "position_usdt": 100.0, "stop_loss_price": 98.0,
                    "stop_loss_pct": 2.0, "take_profit_1": 103.0,
                    "take_profit_2": 106.0, "trailing_trigger_pct": 2.0,
                    "trailing_distance_pct": 1.0,
                }))
                pm._last_tick_persist = 0.0
                with patch.object(pm, "_save_portfolio", wraps=pm._save_portfolio) as save:
                    actions = pm.update_and_monitor_positions(symbols=["AAAUSDT"])
                self.assertEqual(actions, [])
                save.assert_called_once()
                saved = json.loads((root / "portfolio.json").read_text())
                self.assertEqual(saved["open_positions"][0]["current_price"], 100.5)


if __name__ == "__main__":
    unittest.main()
