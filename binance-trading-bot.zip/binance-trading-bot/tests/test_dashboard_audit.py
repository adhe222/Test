import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")


class DashboardAuditWiringCase(unittest.TestCase):
    def setUp(self):
        self.html = (ROOT / "templates" / "dashboard.html").read_text(encoding="utf-8")
        self.js = (ROOT / "static" / "js" / "audit.js").read_text(encoding="utf-8")
        self.app = (ROOT / "static" / "js" / "app.js").read_text(encoding="utf-8")
        self.css = (ROOT / "static" / "css" / "audit.css").read_text(encoding="utf-8")
        self.dashboard = (ROOT / "web_dashboard.py").read_text(encoding="utf-8")

    def test_audit_tab_and_panel_exist(self):
        self.assertIn('id="tab-audit"', self.html)
        self.assertIn('id="view-audit"', self.html)
        self.assertEqual(self.html.count('data-tab="audit"'), 2)

    def test_audit_assets_are_included(self):
        self.assertIn("/static/js/audit.js?v=", self.html)
        self.assertIn("/static/css/audit.css?v=", self.html)

    def test_every_element_id_used_by_audit_js_exists(self):
        used = set(re.findall(r"getElementById\(['\"]([A-Za-z0-9_-]+)['\"]\)", self.js))
        present = set(re.findall(r'id="([A-Za-z0-9_-]+)"', self.html))
        self.assertTrue(used)
        self.assertEqual(used - present, set())

    def test_audit_endpoints_are_served(self):
        for path in ("/api/review", "/api/brief", "/api/approvals", "/api/playbooks"):
            self.assertIn(f'"{path}"', self.dashboard)

    def test_approval_decisions_are_posted(self):
        self.assertIn('"/api/approvals/{ticket_id}/approve"', self.dashboard)
        self.assertIn('"/api/approvals/{ticket_id}/reject"', self.dashboard)
        self.assertIn("/${action}`", self.js)

    def test_tab_activation_is_wired_both_ways(self):
        self.assertIn("window.AegisAudit.activate()", self.app)
        self.assertIn("window.AegisAudit.deactivate()", self.app)

    def test_approve_requires_second_click(self):
        self.assertIn("state.confirmUntil", self.js)
        self.assertIn('data-action="approve"', self.js)
        self.assertIn("Konfirmasi setujui", self.js)

    def test_audit_assets_carry_no_emoji(self):
        self.assertIsNone(EMOJI.search(self.js))
        self.assertIsNone(EMOJI.search(self.css))

    def test_playbooks_are_labelled_advisory(self):
        self.assertIn("advisory", self.html.lower())
        self.assertIn("sample_ok", self.js)


if __name__ == "__main__":
    unittest.main()
