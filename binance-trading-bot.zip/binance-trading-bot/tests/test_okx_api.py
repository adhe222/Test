import hashlib
import hmac
import base64
import json
import tempfile
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from exchange_client import create_exchange_client
from okx_api import OKXClient, OKXAPIError
from agents.scanner import ScannerAgent


class FakeResponse:
    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload

    def raise_for_status(self):
        return None


class RecordingSession:
    def __init__(self, payload):
        self.payload = payload
        self.headers = {}
        self.calls = []

    def request(self, method, url, data=None, headers=None, timeout=None, params=None):
        self.calls.append({
            "method": method, "url": url, "data": data,
            "headers": dict(headers or {}), "params": params,
        })
        return FakeResponse(self.payload)


class TestOKXSymbolMapping(unittest.TestCase):
    def test_spot_and_swap_inst_ids(self):
        self.assertEqual(OKXClient.to_inst_id("BTCUSDT", "SPOT"), "BTC-USDT")
        self.assertEqual(OKXClient.to_inst_id("BTCUSDT", "FUTURES"), "BTC-USDT-SWAP")
        self.assertEqual(OKXClient.to_inst_id("ETH-USDC", "FUTURES"), "ETH-USDC-SWAP")
        self.assertEqual(OKXClient.from_inst_id("BTC-USDT-SWAP"), "BTCUSDT")
        self.assertEqual(OKXClient.from_inst_id("ETH-USDC"), "ETHUSDC")

    def test_unknown_symbol_rejected(self):
        with self.assertRaises(ValueError):
            OKXClient.to_inst_id("BTC", "SPOT")


class TestOKXSignature(unittest.TestCase):
    def test_signature_formula_matches_hmac_contract(self):
        secret = "test-secret"
        timestamp = "2026-10-22T06:00:00.123Z"
        method = "POST"
        path = "/api/v5/trade/order"
        body = '{"instId":"BTC-USDT","side":"buy","ordType":"market","sz":"10","tdMode":"cash"}'
        expected = base64.b64encode(
            hmac.new(
                secret.encode(),
                f"{timestamp}{method}{path}{body}".encode(),
                hashlib.sha256,
            ).digest()
        ).decode()
        self.assertEqual(OKXClient.sign(secret, timestamp, method, path, body), expected)

    def test_signed_get_includes_query_string(self):
        session = RecordingSession({"code": "0", "data": [{"ok": 1}]})
        client = OKXClient(base_url="https://www.okx.com", api_key="k", api_secret="s",
                           passphrase="p", session=session)
        with patch.object(client, "_timestamp_ms", return_value=1792650000123):
            rows = client._private("GET", "/api/v5/account/balance", {"ccy": "BTC"})
        self.assertEqual(rows, [{"ok": 1}])
        call = session.calls[0]
        self.assertTrue(call["url"].endswith("/api/v5/account/balance?ccy=BTC"))
        expected = OKXClient.sign(
            "s", client._iso_timestamp(1792650000123), "GET", "/api/v5/account/balance?ccy=BTC"
        )
        self.assertEqual(call["headers"]["OK-ACCESS-SIGN"], expected)
        self.assertEqual(call["headers"]["OK-ACCESS-KEY"], "k")
        self.assertEqual(call["headers"]["OK-ACCESS-PASSPHRASE"], "p")

    def test_signed_post_signs_exact_compact_body(self):
        session = RecordingSession({"code": "0", "data": []})
        client = OKXClient(base_url="https://www.okx.com", api_key="k", api_secret="s",
                           passphrase="p", session=session)
        body = {"instId": "BTC-USDT", "tdMode": "cash", "side": "buy", "ordType": "market", "sz": "10"}
        with patch.object(client, "_timestamp_ms", return_value=1792650000123):
            client._private("POST", "/api/v5/trade/order", body=body)
        call = session.calls[0]
        compact = json.dumps(body, separators=(",", ":"))
        self.assertEqual(call["data"], compact)
        expected = OKXClient.sign(
            "s", client._iso_timestamp(1792650000123), "POST", "/api/v5/trade/order", compact
        )
        self.assertEqual(call["headers"]["OK-ACCESS-SIGN"], expected)

    def test_demo_header(self):
        session = RecordingSession({"code": "0", "data": []})
        OKXClient(base_url="https://www.okx.com", demo=True, session=session)
        self.assertEqual(session.headers.get("x-simulated-trading"), "1")

    def test_partial_credentials_rejected(self):
        with self.assertRaises(ValueError):
            OKXClient(base_url="https://www.okx.com", api_key="k", api_secret="", passphrase="")

    def test_business_error_raises(self):
        session = RecordingSession({"code": "51000", "msg": "Parameter instId error", "data": []})
        client = OKXClient(base_url="https://www.okx.com", session=session)
        with self.assertRaises(OKXAPIError) as ctx:
            client._public("/api/v5/market/ticker", {"instId": "NOPE"})
        self.assertEqual(ctx.exception.code, "51000")


class TestOKXMarketData(unittest.TestCase):
    def _client(self):
        client = OKXClient(base_url="https://www.okx.com", api_key="", api_secret="", passphrase="")
        client.supports_spot = True
        client.supports_futures = True
        return client

    def test_tickers_merge_spot_and_futures_and_exclude_stock_tokens(self):
        client = self._client()
        spot_rows = [
            {"instId": "BTC-USDT", "last": "100", "open24h": "95", "high24h": "101",
             "low24h": "94", "volCcy24h": "1000000", "vol24h": "10000", "bidPx": "99.9", "askPx": "100.1"},
            {"instId": "SKHY-USDT", "last": "10", "open24h": "9", "volCcy24h": "500",
             "vol24h": "50", "high24h": "11", "low24h": "8"},
        ]
        swap_rows = [
            {"instId": "BTC-USDT-SWAP", "last": "100.5", "open24h": "95", "vol24h": "500000",
             "volCcy24h": "5000", "high24h": "102", "low24h": "93"},
            {"instId": "SKHY-USDT-SWAP", "last": "10.1", "open24h": "9", "vol24h": "500000",
             "volCcy24h": "5000", "high24h": "11", "low24h": "8"},
        ]
        client._public = MagicMock(side_effect=[spot_rows, swap_rows])
        client._instruments = MagicMock(side_effect=[
            {"BTC-USDT": {"instCategory": "1"}, "SKHY-USDT": {"instCategory": "3"}},
            {"BTC-USDT-SWAP": {"instCategory": "1"}, "SKHY-USDT-SWAP": {"instCategory": "3"}},
        ])
        tickers = client.get_24hr_tickers()
        self.assertEqual([t["symbol"] for t in tickers], ["BTCUSDT"])
        btc = tickers[0]
        self.assertEqual(btc["markets"], ["FUTURES", "SPOT"])
        self.assertAlmostEqual(float(btc["quoteVolume"]), 1_000_000.0)
        self.assertAlmostEqual(float(btc["priceChangePercent"]), (100 - 95) / 95 * 100)

    def test_klines_are_chronological_and_confirm_flag_mapped(self):
        client = self._client()
        rows = [
            ["1700000900000", "2", "3", "1", "2.5", "10", "20", "25", "0"],
            ["1700000000000", "1", "2", "0.5", "1.5", "8", "12", "18", "1"],
        ]
        client._public = MagicMock(return_value=rows)
        klines = client.get_klines("BTCUSDT", "15m", 2, market="SPOT")
        self.assertEqual(len(klines), 2)
        self.assertEqual(klines[0]["open_time"], 1700000000000)
        self.assertTrue(klines[0]["is_closed"])
        self.assertFalse(klines[-1]["is_closed"])
        self.assertEqual(klines[0]["volume"], 8.0)
        self.assertEqual(klines[0]["quote_volume"], 18.0)

    def test_swap_klines_use_base_volume_column(self):
        client = self._client()
        rows = [["1700000000000", "1", "2", "0.5", "1.5", "100", "1.2", "180", "1"]]
        client._public = MagicMock(return_value=rows)
        klines = client.get_klines("BTCUSDT", "15m", 1, market="FUTURES")
        self.assertEqual(klines[0]["volume"], 1.2)
        self.assertEqual(klines[0]["quote_volume"], 180.0)

    def test_orderbook_normalized(self):
        client = self._client()
        client._public = MagicMock(return_value=[{
            "bids": [["100", "2", "0", "1"]],
            "asks": [["101", "3", "0", "1"]],
            "ts": "1700000000000",
        }])
        book = client.get_orderbook("BTCUSDT", 20, use_cache=False, market="SPOT")
        self.assertEqual(book["bids"], [[100.0, 2.0]])
        self.assertEqual(book["asks"], [[101.0, 3.0]])

    def test_swap_orderbook_quantities_are_converted_from_contracts(self):
        client = self._client()
        client._public = MagicMock(return_value=[{
            "bids": [["100", "100", "0", "1"]],
            "asks": [["101", "50", "0", "1"]],
        }])
        client._instrument = MagicMock(return_value={"ctVal": "0.01"})
        book = client.get_orderbook("BTCUSDT", 20, use_cache=False, market="FUTURES")
        self.assertEqual(book["bids"], [[100.0, 1.0]])
        self.assertEqual(book["asks"], [[101.0, 0.5]])

    def test_funding_rate(self):
        client = self._client()
        client._public = MagicMock(return_value=[{"fundingRate": "-0.0005"}])
        self.assertAlmostEqual(client.get_funding_rate("BTCUSDT"), -0.0005)

    def test_price_uses_market_specific_inst_id(self):
        client = self._client()
        client._public = MagicMock(return_value=[{"last": "101.5"}])
        self.assertEqual(client.get_price("BTCUSDT", market="FUTURES"), 101.5)
        client._public.assert_called_with("/api/v5/market/ticker", {"instId": "BTC-USDT-SWAP"}, timeout=4.0)


class TestOKXOrders(unittest.TestCase):
    def _client(self):
        client = OKXClient(base_url="https://www.okx.com", api_key="k", api_secret="s", passphrase="p")
        client.supports_spot = True
        client.supports_futures = True
        client._private = MagicMock(return_value=[{"sCode": "0", "ordId": "42", "clOrdId": "c1"}])
        client._prepare_leverage = MagicMock()
        return client

    def test_spot_market_buy_by_quote_notional(self):
        client = self._client()
        resp = client.place_order("BTCUSDT", "BUY", quote_order_qty=50.0, market="SPOT")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["instId"], "BTC-USDT")
        self.assertEqual(body["tdMode"], "cash")
        self.assertEqual(body["sz"], "50")
        self.assertEqual(body["tgtCcy"], "quote_ccy")
        self.assertEqual(resp["orderId"], "42")

    def test_spot_market_sell_by_base_quantity_uses_lot_size(self):
        client = self._client()
        client._instrument = MagicMock(return_value={"lotSz": "0.00000001", "minSz": "0.00001"})
        client.place_order("BTCUSDT", "SELL", quantity=0.123456789, market="SPOT")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["sz"], "0.12345678")
        self.assertEqual(body["tgtCcy"], "base_ccy")

    def test_futures_quantity_is_converted_to_contracts(self):
        client = self._client()
        client._instrument = MagicMock(return_value={"ctVal": "0.01", "lotSz": "0.01", "minSz": "0.01"})
        client.place_order("BTCUSDT", "SELL", quantity=0.05, market="FUTURES")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["instId"], "BTC-USDT-SWAP")
        self.assertEqual(body["tdMode"], "cross")
        self.assertEqual(body["sz"], "5")
        self.assertNotIn("tgtCcy", body)
        client._prepare_leverage.assert_called_once_with("BTC-USDT-SWAP")

    def test_futures_open_by_quote_notional(self):
        client = self._client()
        client.place_order("BTCUSDT", "SELL", quote_order_qty=250.0, market="FUTURES")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["sz"], "250")
        self.assertEqual(body["tgtCcy"], "quote_ccy")

    def test_futures_full_close_uses_live_position_size(self):
        client = self._client()
        client._position_contracts = MagicMock(return_value="3.5")
        client.place_order("BTCUSDT", "BUY", quantity=0.05, market="FUTURES",
                           reduce_only=True, close_full=True)
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["sz"], "3.5")
        self.assertTrue(body["reduceOnly"])
        client._position_contracts.assert_called_once_with("BTC-USDT-SWAP", None)

    def test_futures_partial_close_converts_requested_quantity(self):
        client = self._client()
        client._instrument = MagicMock(return_value={"ctVal": "0.01", "lotSz": "0.01", "minSz": "0.01"})
        client.place_order("BTCUSDT", "BUY", quantity=0.02, market="FUTURES", reduce_only=True)
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["sz"], "2")
        self.assertTrue(body["reduceOnly"])

    def test_disabled_market_rejects_orders(self):
        client = self._client()
        client.supports_spot = False
        with self.assertRaises(ValueError):
            client.place_order("BTCUSDT", "BUY", quote_order_qty=50.0, market="SPOT")
        client.supports_futures = False
        with self.assertRaises(ValueError):
            client.place_order("BTCUSDT", "SELL", quote_order_qty=50.0, market="FUTURES")

    def test_futures_hedge_mode_uses_pos_side(self):
        client = self._client()
        client._position_mode = MagicMock(return_value="hedge")
        client._instrument = MagicMock(return_value={"ctVal": "0.01", "lotSz": "0.01", "minSz": "0.01"})
        client.place_order("BTCUSDT", "SELL", quote_order_qty=100.0, market="FUTURES")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["posSide"], "short")
        self.assertNotIn("reduceOnly", body)
        client.place_order("BTCUSDT", "BUY", quantity=0.02, market="FUTURES", reduce_only=True)
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["posSide"], "short")
        self.assertNotIn("reduceOnly", body)
        client._position_contracts = MagicMock(return_value="1")
        client.place_order("BTCUSDT", "BUY", quantity=0.02, market="FUTURES",
                           reduce_only=True, close_full=True)
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["posSide"], "short")
        client._position_contracts.assert_called_once_with("BTC-USDT-SWAP", "short")

    def test_spot_oco_uses_algo_endpoint(self):
        client = self._client()
        client._private = MagicMock(return_value=[{"sCode": "0", "algoId": "777"}])
        client._instrument = MagicMock(return_value={"lotSz": "0.00000001", "minSz": "0.00001"})
        resp = client.place_oco_order("BTCUSDT", "SELL", 0.01, take_profit_price=120.0,
                                      stop_price=90.0, stop_limit_price=89.5, market="SPOT")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["ordType"], "oco")
        self.assertEqual(body["tdMode"], "cash")
        self.assertEqual(body["tpTriggerPx"], "120")
        self.assertEqual(body["slTriggerPx"], "90")
        self.assertEqual(body["tpOrdPx"], "-1")
        self.assertEqual(resp["orderListId"], "777")

    def test_futures_conditional_algo_is_reduce_only(self):
        client = self._client()
        client._private = MagicMock(return_value=[{"sCode": "0", "algoId": "888"}])
        client._position_contracts = MagicMock(return_value="2")
        resp = client.place_oco_order("BTCUSDT", "BUY", 0.02, take_profit_price=80.0,
                                      stop_price=110.0, market="FUTURES")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body["ordType"], "conditional")
        self.assertEqual(body["tdMode"], "cross")
        self.assertTrue(body["reduceOnly"])
        self.assertEqual(body["sz"], "2")
        self.assertEqual(resp["algoId"], "888")

    def test_cancel_algo(self):
        client = self._client()
        client._private = MagicMock(return_value=[{"sCode": "0", "algoId": "777"}])
        client.cancel_oco_order("BTCUSDT", "777", market="SPOT")
        body = client._private.call_args.kwargs["body"]
        self.assertEqual(body, [{"algoId": "777", "instId": "BTC-USDT"}])


class TestBinanceFuturesRouting(unittest.TestCase):
    def _client(self):
        from binance_api import BinanceClient
        client = BinanceClient(base_url="https://data-api.binance.vision", api_key="k", api_secret="s")
        client._futures_step_size = MagicMock(return_value=0.001)
        return client

    def test_futures_price_uses_fapi(self):
        client = self._client()
        client._futures_request = MagicMock(return_value=FakeResponse({"price": "123.5"}))
        self.assertEqual(client.get_price("BTCUSDT", market="FUTURES"), 123.5)
        client._futures_request.assert_called_once_with(
            "GET", "/fapi/v1/ticker/price", params={"symbol": "BTCUSDT"}, timeout=4.0
        )

    def test_futures_quote_notional_converts_to_base_quantity(self):
        client = self._client()
        client.get_price = MagicMock(return_value=100000.0)
        session = MagicMock()
        session.post.return_value = FakeResponse({"orderId": 99})
        client.session = session
        out = client.place_order("BTCUSDT", "SELL", quote_order_qty=250.0, market="FUTURES")
        self.assertEqual(out["orderId"], 99)
        url = session.post.call_args.args[0]
        params = session.post.call_args.kwargs["params"]
        self.assertTrue(url.endswith("/fapi/v1/order"))
        self.assertEqual(params["quantity"], "0.002")
        self.assertEqual(params["side"], "SELL")
        self.assertIn("signature", params)

    def test_futures_reduce_only_flag(self):
        client = self._client()
        session = MagicMock()
        session.post.return_value = FakeResponse({"orderId": 100})
        client.session = session
        client.place_order("BTCUSDT", "BUY", quantity=0.002, market="FUTURES", reduce_only=True)
        params = session.post.call_args.kwargs["params"]
        self.assertEqual(params["reduceOnly"], "true")


class TestExchangeFactory(unittest.TestCase):
    def test_okx_selected(self):
        with patch.object(config, "EXCHANGE", "okx"):
            client = create_exchange_client()
        self.assertIsInstance(client, OKXClient)

    def test_binance_default(self):
        with patch.object(config, "EXCHANGE", "binance"):
            client = create_exchange_client()
        self.assertEqual(client.exchange_name, "binance")

    def test_unknown_exchange_rejected(self):
        with patch.object(config, "EXCHANGE", "kraken"):
            with self.assertRaises(ValueError):
                create_exchange_client()


class TestScannerMarketCapabilities(unittest.TestCase):
    def test_only_scans_directions_the_exchange_supports(self):
        class Client:
            def get_24hr_tickers(self):
                return [
                    {"symbol": "FUTONLYUSDT", "lastPrice": "1", "priceChangePercent": "-3.0",
                     "quoteVolume": "50000000", "markets": ["FUTURES"]},
                    {"symbol": "SPOTONLYUSDT", "lastPrice": "1", "priceChangePercent": "-3.0",
                     "quoteVolume": "50000000", "markets": ["SPOT"]},
                    {"symbol": "LONGUSDT", "lastPrice": "1", "priceChangePercent": "3.0",
                     "quoteVolume": "50000000", "markets": ["SPOT"]},
                ]

        candidates = ScannerAgent(Client()).scan_trending_pairs(top_limit=10)
        by_symbol = {c["symbol"]: c for c in candidates}
        self.assertEqual(by_symbol["FUTONLYUSDT"]["direction"], "SHORT")
        self.assertEqual(by_symbol["FUTONLYUSDT"]["target_market"], "FUTURES")
        self.assertNotIn("SPOTONLYUSDT", by_symbol)
        self.assertEqual(by_symbol["LONGUSDT"]["direction"], "LONG")


class TestPortfolioMarketRouting(unittest.TestCase):
    def _plan(self):
        return {
            "symbol": "BTCUSDT",
            "direction": "SHORT",
            "target_market": "FUTURES",
            "side": "SELL",
            "entry_price": 100.0,
            "quantity": 1.0,
            "position_usdt": 100.0,
            "stop_loss_price": 102.0,
            "stop_loss_pct": 2.0,
            "take_profit_1": 98.0,
            "take_profit_2": 92.0,
            "trailing_trigger_pct": 2.0,
            "trailing_distance_pct": 1.5,
            "atr": 1.0,
            "atr_pct": 1.0,
        }

    def test_live_entry_passes_market_to_exchange(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        client = MagicMock()
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(config, "PORTFOLIO_FILE", Path(tmp) / "portfolio.json"), \
                 patch.object(config, "TRADE_LOG_FILE", Path(tmp) / "trades.json"), \
                 patch.object(config, "REQUIRE_APPROVAL_TICKET", False):
                pm = PortfolioManagerAgent(client, mode="live")
                pm._sync_state_if_file_newer = lambda: None
                pm._save_portfolio = MagicMock()
                pm.record_equity_snapshot = MagicMock()
                pm.state = {"cash_usdt": 1000.0, "open_positions": [], "total_fees_paid_usdt": 0.0}
                self.assertTrue(pm.execute_trade(self._plan()))
        client.place_order.assert_called_once()
        kwargs = client.place_order.call_args.kwargs
        self.assertEqual(kwargs["market"], "FUTURES")
        self.assertEqual(kwargs["quote_order_qty"], 100.0)
        self.assertEqual(pm.state["open_positions"][0]["market"], "FUTURES")

    def test_live_futures_exit_is_reduce_only(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        client = MagicMock()
        client.get_price.return_value = 91.0
        now = datetime.now(timezone.utc).isoformat()
        position = {
            "symbol": "BTCUSDT", "direction": "SHORT", "market": "FUTURES", "side": "SELL",
            "entry_price": 100.0, "quantity": 1.0, "initial_quantity": 1.0,
            "position_usdt": 100.0, "initial_cost_usdt": 100.0, "buy_fee_usdt": 0.1,
            "stop_loss_price": 90.0, "stop_loss_pct": 10.0, "entry_stop_loss_pct": 10.0,
            "take_profit_1": 80.0, "take_profit_2": 70.0, "tp1_hit": False,
            "partial_pnl_realized": 0.0, "break_even_active": False, "trailing_active": False,
            "highest_price": 100.0, "lowest_price": 91.0, "trailing_stop_price": 90.0,
            "trailing_trigger_pct": 2.0, "trailing_distance_pct": 1.5,
            "entry_time": now, "holding_minutes": 1, "entry_metrics": {}, "pyramids_added": 0,
        }
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(config, "PORTFOLIO_FILE", Path(tmp) / "portfolio.json"), \
                 patch.object(config, "TRADE_LOG_FILE", Path(tmp) / "trades.json"):
                pm = PortfolioManagerAgent(client, mode="live")
                pm._sync_state_if_file_newer = lambda: None
                pm._save_portfolio = MagicMock()
                pm.record_equity_snapshot = MagicMock()
                pm._log_trade = MagicMock()
                pm.state = {"cash_usdt": 0.0, "open_positions": [position],
                            "total_trades": 0, "winning_trades": 0, "losing_trades": 0,
                            "scratch_trades": 0, "total_fees_paid_usdt": 0.0,
                            "gross_realized_pnl_usdt": 0.0, "realized_pnl_usdt": 0.0}
                events = pm.update_and_monitor_positions()
        self.assertEqual(len(events), 1)
        kwargs = client.place_order.call_args.kwargs
        self.assertEqual(kwargs["market"], "FUTURES")
        self.assertTrue(kwargs["reduce_only"])
        self.assertTrue(kwargs["close_full"])


if __name__ == "__main__":
    unittest.main()
