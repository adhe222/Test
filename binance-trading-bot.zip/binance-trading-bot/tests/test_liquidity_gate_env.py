import os
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read_gate(env_overrides):
    env = dict(os.environ)
    for key, value in env_overrides.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    env["PYTHONPATH"] = ROOT
    out = subprocess.run(
        [
            sys.executable,
            "-c",
            "import config;print(config.MIN_QUOTE_VOLUME_24H, config.MIN_TRADE_COUNT_24H)",
        ],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if out.returncode != 0:
        raise AssertionError(out.stderr[-2000:])
    return out.stdout.strip().split()


class LiquidityGateEnvTest(unittest.TestCase):
    def test_defaults_match_the_previous_hardcoded_values(self):
        quote, trades = read_gate(
            {"MIN_QUOTE_VOLUME_24H": None, "MIN_TRADE_COUNT_24H": None}
        )
        self.assertEqual(quote, "20000000.0")
        self.assertEqual(trades, "20000")

    def test_quote_volume_floor_is_overridable(self):
        quote, trades = read_gate({"MIN_QUOTE_VOLUME_24H": "3000000"})
        self.assertEqual(quote, "3000000.0")
        self.assertEqual(trades, "20000")

    def test_trade_count_floor_is_overridable(self):
        quote, trades = read_gate({"MIN_TRADE_COUNT_24H": "5000"})
        self.assertEqual(quote, "20000000.0")
        self.assertEqual(trades, "5000")

    def test_quote_volume_accepts_decimals(self):
        quote, _ = read_gate({"MIN_QUOTE_VOLUME_24H": "12500000.5"})
        self.assertEqual(quote, "12500000.5")


if __name__ == "__main__":
    unittest.main()
