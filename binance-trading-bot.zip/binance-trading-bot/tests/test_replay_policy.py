import math
import unittest

import replay


def bars_from_closes(closes, volume=100.0, spread=0.001):
    bars = []
    for i, close in enumerate(closes):
        open_price = closes[i - 1] if i > 0 else close
        high = max(open_price, close) * (1.0 + spread)
        low = min(open_price, close) * (1.0 - spread)
        bars.append({
            "open": open_price,
            "high": high,
            "low": low,
            "close": close,
            "volume": volume,
            "is_closed": True,
        })
    return bars


class ExitEngineCase(unittest.TestCase):
    def test_long_takes_partial_then_books_a_win(self):
        bars = bars_from_closes([100.0, 100.0, 103.0, 104.0, 105.0])
        trade = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["scalp"], 15)
        self.assertIsNotNone(trade)
        self.assertTrue(trade["tp1_taken"])
        self.assertGreater(trade["net_pct"], 0.0)

    def test_long_stop_costs_stop_plus_round_trip_fee(self):
        bars = bars_from_closes([100.0, 100.0, 97.0])
        trade = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["scalp"], 15)
        self.assertEqual(trade["reason"], "STOP_LOSS_HIT")
        self.assertAlmostEqual(trade["gross_pct"], -2.0, places=6)
        self.assertAlmostEqual(trade["net_pct"], -2.2, places=6)

    def test_short_stop_costs_stop_plus_round_trip_fee(self):
        bars = bars_from_closes([100.0, 100.0, 103.0])
        trade = replay.simulate_trade(bars, 1, "SHORT", replay.POLICIES["scalp"], 15)
        self.assertEqual(trade["reason"], "STOP_LOSS_HIT")
        self.assertAlmostEqual(trade["net_pct"], -2.2, places=6)

    def test_flat_market_hits_the_hard_window(self):
        bars = bars_from_closes([100.0] * 12)
        trade = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["scalp"], 15)
        self.assertEqual(trade["reason"], "MOMENTUM_TIME_STOP_EXIT")
        self.assertEqual(trade["hold_minutes"], replay.POLICIES["scalp"]["hard_minutes"])

    def test_scalp_window_recycles_sooner_than_baseline(self):
        bars = bars_from_closes([100.0] * 12)
        scalp = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["scalp"], 15)
        baseline = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["baseline"], 15)
        self.assertLess(scalp["hold_minutes"], baseline["hold_minutes"])

    def test_hold_window_exits_on_the_configured_bar(self):
        bars = bars_from_closes([100.0] * 40)
        trade = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["swing_hold"], 15)
        self.assertEqual(trade["reason"], "HOLD_WINDOW_EXIT")
        self.assertEqual(trade["hold_minutes"], replay.POLICIES["swing_hold"]["hold_bars"] * 15)

    def test_hold_window_policy_has_no_stop(self):
        closes = [100.0, 100.0, 90.0, 90.0] + [90.0] * 36
        bars = bars_from_closes(closes)
        trade = replay.simulate_trade(bars, 1, "LONG", replay.POLICIES["swing_hold"], 15)
        self.assertEqual(trade["reason"], "HOLD_WINDOW_EXIT")
        self.assertLess(trade["gross_pct"], -2.0)


class SignalGateCase(unittest.TestCase):
    def test_quiet_market_produces_no_signal(self):
        bars = bars_from_closes([100.0 + (i % 2) * 0.01 for i in range(40)])
        self.assertIsNone(replay.signal_at(bars, len(bars) - 1, replay.POLICIES["scalp"]))

    def test_volume_spike_in_an_uptrend_produces_a_long(self):
        closes = [100.0 + 0.30 * i for i in range(70)] + [121.0 - 0.15 * i for i in range(10)]
        bars = bars_from_closes(closes)
        bars[-1]["volume"] = 900.0
        signal = replay.signal_at(bars, len(bars) - 1, replay.POLICIES["scalp"])
        self.assertIsNotNone(signal)
        self.assertEqual(signal["direction"], "LONG")
        self.assertGreater(signal["volume_surge"], 2.0)
        self.assertGreater(signal["trend_efficiency"], 0.40)
        self.assertLess(signal["rsi"], 55.0)

    def test_overbought_straight_line_is_rejected(self):
        closes = [100.0 + 0.4 * i for i in range(80)]
        bars = bars_from_closes(closes)
        bars[-1]["volume"] = 900.0
        self.assertIsNone(replay.signal_at(bars, len(bars) - 1, replay.POLICIES["scalp"]))

    def test_trend_efficiency_max_rejects_the_cleanest_trend(self):
        closes = [100.0 + 0.30 * i for i in range(70)] + [121.0 - 0.15 * i for i in range(10)]
        bars = bars_from_closes(closes)
        bars[-1]["volume"] = 900.0
        policy = dict(replay.POLICIES["swing_hold"])
        policy.update(volume_surge_min=1.4, trend_efficiency_min=0.15)
        uncapped = replay.signal_at(bars, len(bars) - 1, policy)
        self.assertIsNotNone(uncapped)
        self.assertGreater(uncapped["trend_efficiency"], 0.30)
        capped = dict(policy)
        capped["trend_efficiency_max"] = 0.30
        self.assertIsNone(replay.signal_at(bars, len(bars) - 1, capped))
        raised = dict(policy)
        raised["trend_efficiency_max"] = 0.50
        self.assertIsNotNone(replay.signal_at(bars, len(bars) - 1, raised))

    def test_entries_never_use_the_signal_bar(self):
        closes = [100.0 + 0.15 * i + 2.0 * math.sin(i / 3.0) for i in range(80)]
        bars = bars_from_closes(closes)
        for i in range(30, len(bars)):
            bars[i]["volume"] = 900.0 if i % 4 == 0 else 100.0
        report = replay.simulate(bars, replay.POLICIES["scalp"], interval="15m", symbol="TESTUSDT")
        self.assertGreater(report["trades"], 0)
        for trade in report["trades_detail"]:
            self.assertIsNotNone(
                replay.signal_at(bars, trade["entry_index"] - 1, replay.POLICIES["scalp"]),
                "entry must follow a bar that already carried the signal",
            )


class AggregateCase(unittest.TestCase):
    def test_empty_sample_is_reported_not_crashed(self):
        report = replay.aggregate([], symbol="NONE", interval="15m")
        self.assertEqual(report["trades"], 0)
        self.assertEqual(report["win_rate_pct"], 0.0)
        self.assertIsNone(report["profit_factor"])

    def test_profit_factor_and_reason_breakdown(self):
        trades = [
            {"net_pct": 1.0, "hold_minutes": 15, "reason": "TRAILING_STOP_EXIT"},
            {"net_pct": -2.2, "hold_minutes": 15, "reason": "STOP_LOSS_HIT"},
            {"net_pct": 0.4, "hold_minutes": 30, "reason": "MOMENTUM_TIME_STOP_EXIT"},
        ]
        report = replay.aggregate(trades, symbol="TESTUSDT", interval="15m")
        self.assertEqual(report["trades"], 3)
        self.assertAlmostEqual(report["profit_factor"], 0.636, places=3)
        self.assertEqual(report["by_reason"]["STOP_LOSS_HIT"], 1)
        self.assertEqual(report["median_hold_minutes"], 15)


if __name__ == "__main__":
    unittest.main()
