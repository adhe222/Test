import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from playbook_library import PlaybookLibrary


def _event(symbol, pnl, direction="SHORT", metrics=None, when=None):
    return {
        "symbol": symbol,
        "action": "CLOSED",
        "direction": direction,
        "reason": "TRAILING_STOP_EXIT" if pnl > 0 else "STOP_LOSS_HIT",
        "pnl_usdt": pnl,
        "gross_pnl_usdt": pnl,
        "fee_paid_usdt": 0.3,
        "pnl_pct": pnl / 1.5,
        "entry_time": when.isoformat() if when else None,
        "exit_time": when.isoformat() if when else None,
        "entry_metrics": metrics or {"rsi": 48.0, "trend_efficiency": 0.05, "atr_pct": 1.6, "volume_surge": 1.1},
    }


class PlaybookLibraryCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.history = self.root / "trade_history.json"
        self.portfolio = self.root / "portfolio.json"
        self.start = datetime(2026, 10, 22, 7, 0, tzinfo=timezone.utc)
        self.library = PlaybookLibrary(self.history, self.portfolio, min_sample=2)

    def tearDown(self):
        self.tmp.cleanup()

    def _write(self, events, counter_since=None):
        self.history.write_text(json.dumps(events), encoding="utf-8")
        self.portfolio.write_text(
            json.dumps({"counter_since": (counter_since or self.start).isoformat()}), encoding="utf-8"
        )

    def test_fingerprint_buckets(self):
        key = self.library.fingerprint(
            {"rsi": 45.0, "trend_efficiency": 0.2, "atr_pct": 1.4, "volume_surge": 1.5}, "short"
        )
        self.assertEqual(key, "SHORT|rsi:40-50|trend:0.1-0.3|atr:1-2|vol:1.3-2")

    def test_fingerprint_handles_missing_metrics(self):
        self.assertEqual(
            self.library.fingerprint(None, "LONG"),
            "LONG|rsi:na|trend:na|atr:na|vol:na",
        )

    def test_build_groups_by_fingerprint(self):
        base = self.start
        events = [
            _event("INJUSDT", 2.0, when=base + timedelta(hours=1)),
            _event("INJUSDT", -1.0, when=base + timedelta(hours=2)),
            _event(
                "SOLUSDT", -2.0, direction="LONG",
                metrics={"rsi": 65.0, "trend_efficiency": 0.6, "atr_pct": 2.4, "volume_surge": 2.2},
                when=base + timedelta(hours=3),
            ),
        ]
        self._write(events)
        report = self.library.build()
        self.assertEqual(report["closed_trades"], 3)
        self.assertEqual(len(report["playbooks"]), 2)
        short_book = next(p for p in report["playbooks"] if p["fingerprint"].startswith("SHORT"))
        self.assertEqual(short_book["trades"], 2)
        self.assertEqual(short_book["wins"], 1)
        self.assertAlmostEqual(short_book["net_usdt"], 1.0, places=4)
        self.assertAlmostEqual(short_book["win_rate_pct"], 50.0, places=2)
        self.assertTrue(short_book["sample_ok"])
        self.assertTrue(report["advisory_only"])

    def test_lookup_exact_and_direction_fallback(self):
        base = self.start
        metrics = {"rsi": 48.0, "trend_efficiency": 0.05, "atr_pct": 1.6, "volume_surge": 1.1}
        self._write([
            _event("INJUSDT", 2.0, metrics=metrics, when=base + timedelta(hours=1)),
            _event("NEARUSDT", -1.0, metrics=metrics, when=base + timedelta(hours=2)),
        ])
        exact = self.library.lookup(metrics, "SHORT")
        self.assertEqual(exact["match"], "exact")
        self.assertEqual(exact["stats"]["trades"], 2)

        other = {"rsi": 68.0, "trend_efficiency": 0.7, "atr_pct": 3.0, "volume_surge": 2.5}
        fallback = self.library.lookup(other, "SHORT")
        self.assertEqual(fallback["match"], "direction")
        self.assertEqual(fallback["stats"]["trades"], 2)

        missing = self.library.lookup(other, "LONG")
        self.assertEqual(missing["match"], "none")
        self.assertIsNone(missing["stats"])

    def test_scope_excludes_legacy_trades(self):
        old = self.start - timedelta(days=3)
        self._write([
            _event("BTCUSDT", 10.0, when=old),
            _event("ETHUSDT", -1.0, when=self.start + timedelta(hours=1)),
        ])
        report = self.library.build()
        self.assertEqual(report["closed_trades"], 1)
        self.assertEqual(report["playbooks"][0]["trades"], 1)

    def test_small_sample_is_flagged(self):
        self._write([_event("INJUSDT", 2.0, when=self.start + timedelta(hours=1))])
        report = self.library.build()
        self.assertFalse(report["playbooks"][0]["sample_ok"])
        self.assertEqual(report["min_sample"], 2)

    def test_empty_history_returns_empty_report(self):
        report = self.library.build()
        self.assertEqual(report["closed_trades"], 0)
        self.assertEqual(report["playbooks"], [])
        self.assertEqual(report["by_direction"], [])


if __name__ == "__main__":
    unittest.main()
