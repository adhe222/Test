import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import config
from agents.consciousness import AgentConsciousnessEngine


class ThresholdDriftBoundCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.path = self.tmp / "consciousness.json"
        self.path.write_text(json.dumps({
            "divisions": {
                "Volatility & Market Regime Division": {
                    "calibrated_thresholds": {"min_trend_efficiency": 0.36, "min_atr_pct": 0.5}
                },
                "Order Book Microstructure Division": {
                    "calibrated_thresholds": {"max_spread_pct": 0.06, "min_bid_depth_ratio": 1.4}
                },
                "Technical Price Action Division": {
                    "calibrated_thresholds": {"min_close_ratio": 0.70}
                },
            }
        }), encoding="utf-8")
        self.engine = AgentConsciousnessEngine(self.path)

    def test_learned_min_threshold_is_capped_relative_to_base(self):
        with patch.object(config, "CONSCIOUSNESS_MAX_THRESHOLD_DRIFT", 1.5):
            value = self.engine.get_threshold("Volatility & Market Regime Division", "min_trend_efficiency", 0.12)
        self.assertAlmostEqual(value, 0.18, places=6)

    def test_learned_max_threshold_is_floored_relative_to_base(self):
        with patch.object(config, "CONSCIOUSNESS_MAX_THRESHOLD_DRIFT", 1.5):
            value = self.engine.get_threshold("Order Book Microstructure Division", "max_spread_pct", 0.2)
        self.assertAlmostEqual(value, 0.2 / 1.5, places=6)

    def test_in_bound_threshold_is_returned_unchanged(self):
        with patch.object(config, "CONSCIOUSNESS_MAX_THRESHOLD_DRIFT", 1.5):
            value = self.engine.get_threshold("Technical Price Action Division", "min_close_ratio", 0.5)
        self.assertAlmostEqual(value, 0.70, places=6)

    def test_drift_zero_disables_the_bound(self):
        with patch.object(config, "CONSCIOUSNESS_MAX_THRESHOLD_DRIFT", 0.0):
            value = self.engine.get_threshold("Volatility & Market Regime Division", "min_trend_efficiency", 0.12)
        self.assertAlmostEqual(value, 0.36, places=6)

    def test_missing_key_falls_back_to_base(self):
        value = self.engine.get_threshold("Volatility & Market Regime Division", "min_missing", 0.25)
        self.assertEqual(value, 0.25)


if __name__ == "__main__":
    unittest.main()
