import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from agents.portfolio_manager import PortfolioManagerAgent


class FeeByMarketTest(unittest.TestCase):
    def setUp(self):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", directory / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", directory / "trades.json"))
        self.enterContext(patch.object(config, "FUTURES_FEE_PCT", 0.05))
        self.enterContext(patch.object(config, "EFFECTIVE_FEE_PCT", 0.10))
        self.client = MagicMock()
        self.client.get_price.return_value = 100.0
        self.pm = PortfolioManagerAgent(self.client, mode="paper")
        self.pm.reset_portfolio(1000.0)

    def _plan(self, market, direction="SHORT"):
        short = direction == "SHORT"
        return {
            "symbol": "FIXUSDT",
            "direction": direction,
            "target_market": market,
            "side": "SELL" if short else "BUY",
            "position_usdt": 100.0,
            "quantity": 1.0,
            "entry_price": 100.0,
            "stop_loss_price": 103.0 if short else 97.0,
            "stop_loss_pct": 3.0,
            "take_profit_1": 96.0 if short else 104.0,
            "take_profit_2": 92.0 if short else 108.0,
            "trailing_trigger_pct": 50.0,
            "trailing_distance_pct": 1.0,
        }

    def test_helper_returns_futures_rate_for_futures_market(self):
        self.assertAlmostEqual(self.pm._fee_pct("FUTURES"), 0.05, places=6)
        self.assertAlmostEqual(self.pm._fee_pct("futures"), 0.05, places=6)

    def test_helper_returns_spot_rate_for_spot_and_unknown_market(self):
        self.assertAlmostEqual(self.pm._fee_pct("SPOT"), 0.10, places=6)
        self.assertAlmostEqual(self.pm._fee_pct(None), 0.10, places=6)
        self.assertAlmostEqual(self.pm._fee_pct(""), 0.10, places=6)

    def test_futures_entry_charges_half_the_spot_fee(self):
        self.assertTrue(self.pm.execute_trade(self._plan("FUTURES")))
        futures_fee = self.pm.state["total_fees_paid_usdt"]
        self.assertAlmostEqual(futures_fee, 100.0 * 0.05 / 100.0, places=6)

        self.pm.reset_portfolio(1000.0)
        self.assertTrue(self.pm.execute_trade(self._plan("SPOT")))
        spot_fee = self.pm.state["total_fees_paid_usdt"]
        self.assertAlmostEqual(spot_fee, 100.0 * 0.10 / 100.0, places=6)
        self.assertAlmostEqual(spot_fee / futures_fee, 2.0, places=4)

    def test_break_even_cushion_uses_market_fee(self):
        futures_pos = {"entry_price": 100.0, "direction": "SHORT", "market": "FUTURES", "side": "SELL"}
        spot_pos = {"entry_price": 100.0, "direction": "SHORT", "market": "SPOT", "side": "SELL"}
        with patch.object(config, "BREAK_EVEN_BUFFER_PCT", 0.0), patch.object(
            self.pm, "_slippage_pct", return_value=0.0
        ):
            futures_be = self.pm._fee_aware_break_even_price(futures_pos)
            spot_be = self.pm._fee_aware_break_even_price(spot_pos)
        self.assertAlmostEqual(100.0 - futures_be, 0.20, places=6)
        self.assertAlmostEqual(100.0 - spot_be, 0.30, places=6)
        self.assertLess(spot_be, futures_be)


if __name__ == "__main__":
    unittest.main()
