import json
import unittest
from unittest.mock import patch

import config
from market_intel import ExternalResearchAgent


class FakeResponse:
    def __init__(self, payload=None, text=None, status_code=200):
        self._payload = payload
        self.text = text or ""
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self, fail_symbol=False):
        self.calls = []
        self.fail_symbol = fail_symbol
        self.headers = {}

    def get(self, url, params=None, timeout=None):
        self.calls.append(url)
        if self.fail_symbol and ("fapi.binance.com" in url or "okx.com" in url or "alternative.me" in url or "coindesk.com" in url or "cointelegraph.com" in url):
            raise RuntimeError("network down")
        if "premiumIndex" in url:
            return FakeResponse({
                "symbol": "BTCUSDT",
                "markPrice": "83000.0",
                "indexPrice": "83010.0",
                "lastFundingRate": "0.0001",
                "nextFundingTime": 1792636800000,
            })
        if "openInterestHist" in url:
            return FakeResponse([
                {"sumOpenInterestValue": "1000000"},
                {"sumOpenInterestValue": "1010000"},
                {"sumOpenInterestValue": "1030000"},
            ])
        if "globalLongShortAccountRatio" in url:
            return FakeResponse([
                {"longAccount": "0.50", "shortAccount": "0.50", "longShortRatio": "1.0"},
                {"longAccount": "0.58", "shortAccount": "0.42", "longShortRatio": "1.38"},
            ])
        if "takerlongshortRatio" in url:
            return FakeResponse([
                {"buySellRatio": "0.95", "buyVol": "100", "sellVol": "105"},
                {"buySellRatio": "1.20", "buyVol": "150", "sellVol": "125"},
            ])
        if "alternative.me" in url:
            return FakeResponse({"data": [{"value": "55", "value_classification": "Neutral", "timestamp": "1792636800"}]})
        if "okx.com" in url:
            if "funding-rate" in url:
                return FakeResponse({"code": "0", "data": [{"fundingRate": "0.0001", "fundingTime": "1792684800000"}]})
            if "open-interest-volume" in url:
                return FakeResponse({"code": "0", "data": [
                    ["1792664700000", "1030000", "2000"],
                    ["1792664400000", "1010000", "1900"],
                    ["1792664100000", "1000000", "1800"],
                ]})
            if "long-short-account-ratio" in url:
                return FakeResponse({"code": "0", "data": [
                    ["1792664700000", "1.0"],
                    ["1792664400000", "1.0"],
                ]})
            if "taker-volume" in url:
                return FakeResponse({"code": "0", "data": [
                    ["1792664700000", "125", "150"],
                    ["1792664400000", "105", "100"],
                ]})
            raise RuntimeError(f"unexpected okx url {url}")
        if "coindesk.com" in url:
            return FakeResponse(text="""<?xml version="1.0"?><rss><channel>
            <item><title>Bitcoin ETF inflows rise</title><link>https://example.com/a</link><pubDate>Wed, 22 Oct 2026 01:00:00 GMT</pubDate></item>
            <item><title>Market outlook improves</title><link>https://example.com/b</link><pubDate>Wed, 22 Oct 2026 00:30:00 GMT</pubDate></item>
            </channel></rss>""")
        if "cointelegraph.com" in url:
            return FakeResponse(text="""<?xml version="1.0"?><rss><channel>
            <item><title>BTCUSDT momentum builds</title><link>https://example.com/c</link><pubDate>Wed, 22 Oct 2026 00:45:00 GMT</pubDate></item>
            </channel></rss>""")
        raise RuntimeError(f"unexpected url {url}")


class TestExternalResearch(unittest.TestCase):
    @patch.object(config, "EXCHANGE", "binance")
    def test_collect_aggregates_external_sources(self):
        session = FakeSession()
        agent = ExternalResearchAgent(session=session, timeout=1.0)
        dossier = agent.collect("BTCUSDT", direction="LONG", price_change_24h=2.0)
        self.assertEqual(dossier["status"], "OK")
        self.assertGreaterEqual(dossier["healthy_sources"], 4)
        self.assertEqual(dossier["funding"]["rate_pct"], 0.01)
        self.assertEqual(dossier["open_interest"]["trend"], "RISING")
        self.assertEqual(dossier["positioning"]["crowding"], "BALANCED")
        self.assertEqual(dossier["taker_flow"]["pressure"], "BUYERS")
        self.assertEqual(dossier["fear_greed"]["value"], 55)
        self.assertTrue(any("BTCUSDT" in item["title"] for item in dossier["news"]["symbol"]))
        names = {item["name"] for item in dossier["sources"]}
        self.assertIn("binance_futures_funding", names)
        self.assertIn("news:CoinDesk", names)

    @patch.object(config, "EXCHANGE", "okx")
    def test_okx_venue_uses_okx_derivative_endpoints(self):
        session = FakeSession()
        agent = ExternalResearchAgent(session=session, timeout=1.0)
        dossier = agent.collect("BTCUSDT", direction="SHORT", price_change_24h=-3.0)
        names = {item["name"] for item in dossier["sources"]}
        self.assertIn("okx_funding", names)
        self.assertIn("okx_open_interest", names)
        self.assertIn("okx_long_short_ratio", names)
        self.assertIn("okx_taker_flow", names)
        self.assertFalse(any("fapi.binance.com" in url for url in session.calls))
        self.assertEqual(dossier["funding"]["rate_pct"], 0.01)
        self.assertEqual(dossier["open_interest"]["trend"], "RISING")
        self.assertEqual(dossier["positioning"]["crowding"], "BALANCED")
        self.assertEqual(dossier["taker_flow"]["pressure"], "BUYERS")
        self.assertEqual(dossier["status"], "OK")

    def test_collect_uses_cache(self):
        session = FakeSession()
        agent = ExternalResearchAgent(session=session, timeout=1.0)
        first = agent.collect("BTCUSDT")
        call_count = len(session.calls)
        second = agent.collect("BTCUSDT")
        self.assertEqual(len(session.calls), call_count)
        self.assertEqual(first["generated_at"], second["generated_at"])

    def test_degraded_when_all_external_sources_fail(self):
        agent = ExternalResearchAgent(session=FakeSession(fail_symbol=True), timeout=1.0)
        dossier = agent.collect("BTCUSDT")
        self.assertEqual(dossier["status"], "DEGRADED")
        self.assertEqual(dossier["healthy_sources"], 0)

    @patch.object(config, "EXCHANGE", "binance")
    def test_prompt_view_drops_cache_metadata(self):
        agent = ExternalResearchAgent(session=FakeSession(), timeout=1.0)
        dossier = agent.collect("BTCUSDT")
        prompt = ExternalResearchAgent.format_for_prompt(dossier)
        self.assertEqual(prompt["status"], "OK")
        self.assertNotIn("_expires", json.dumps(prompt))
        self.assertIn("sources", prompt)


if __name__ == "__main__":
    unittest.main()
