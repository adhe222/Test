import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock

from market_recorder import append_jsonl, book_features, build_record, capture


class BookFeaturesTest(unittest.TestCase):
    def test_midpoint_and_spread(self):
        bids = [[100.0, 2.0], [99.5, 1.0]]
        asks = [[100.2, 1.5], [100.7, 1.0]]
        features = book_features(bids, asks, levels=2)
        self.assertAlmostEqual(features["mid"], 100.1, places=6)
        self.assertAlmostEqual(features["spread_pct"], round(0.2 / 100.1 * 100.0, 6), places=6)
        self.assertAlmostEqual(features["bid_depth"], 3.0, places=6)
        self.assertAlmostEqual(features["ask_depth"], 2.5, places=6)
        self.assertAlmostEqual(features["depth_ratio"], 1.2, places=4)

    def test_empty_book_returns_nulls(self):
        features = book_features([], [])
        self.assertIsNone(features["mid"])
        self.assertIsNone(features["spread_pct"])
        self.assertIsNone(features["depth_ratio"])

    def test_zero_ask_depth_does_not_divide_by_zero(self):
        features = book_features([[100.0, 1.0]], [[100.1, 0.0]])
        self.assertIsNone(features["depth_ratio"])


class BuildRecordTest(unittest.TestCase):
    def test_record_carries_funding_in_percent_and_book_features(self):
        bars = [{"close": 101.5, "open_time": 1700000000000}]
        book = {"bids": [[101.4, 1.0]], "asks": [[101.6, 1.0]]}
        record = build_record("BTCUSDT", bars, 0.0001, book, "1h")
        self.assertEqual(record["symbol"], "BTCUSDT")
        self.assertEqual(record["bars"], 1)
        self.assertAlmostEqual(record["funding_rate_pct"], 0.01, places=6)
        self.assertAlmostEqual(record["book"]["depth_ratio"], 1.0, places=4)
        self.assertEqual(record["last_close"], 101.5)

    def test_missing_funding_is_null_not_zero(self):
        bars = [{"close": 1.0, "open_time": 1}]
        record = build_record("XRPUSDT", bars, None, {}, "1h")
        self.assertIsNone(record["funding_rate_pct"])


class AppendJsonlTest(unittest.TestCase):
    def test_appends_one_line_per_record(self):
        directory = Path(self.enterContext(tempfile.TemporaryDirectory()))
        path = directory / "nested" / "snapshots.jsonl"
        append_jsonl(path, {"symbol": "A"})
        append_jsonl(path, {"symbol": "B"})
        lines = path.read_text(encoding="utf-8").strip().splitlines()
        self.assertEqual(len(lines), 2)
        self.assertEqual([json.loads(line)["symbol"] for line in lines], ["A", "B"])


class CaptureTest(unittest.TestCase):
    def _client(self, bars, funding=0.0002, book=None):
        client = MagicMock()
        client.get_klines.return_value = bars
        client.get_funding_rate.return_value = funding
        client.get_orderbook.return_value = book if book is not None else {
            "bids": [[100.0, 1.0]],
            "asks": [[100.1, 1.0]],
        }
        return client

    def test_drops_forming_bar(self):
        bars = [
            {"close": 99.0, "open_time": 1, "is_closed": True},
            {"close": 100.0, "open_time": 2, "is_closed": False},
        ]
        record = capture(self._client(bars), "ETHUSDT", "1h", 300, 40, 5)
        self.assertEqual(record["bars"], 1)
        self.assertEqual(record["last_close"], 99.0)

    def test_orderbook_failure_still_records_bars(self):
        client = self._client([{"close": 5.0, "open_time": 1, "is_closed": True}])
        client.get_orderbook.side_effect = RuntimeError("depth down")
        record = capture(client, "SUIUSDT", "1h", 300, 40, 5)
        self.assertEqual(record["last_close"], 5.0)
        self.assertIsNone(record["book"]["mid"])

    def test_empty_bars_returns_none(self):
        self.assertIsNone(capture(self._client([]), "SOLUSDT", "1h", 300, 40, 5))


if __name__ == "__main__":
    unittest.main()
