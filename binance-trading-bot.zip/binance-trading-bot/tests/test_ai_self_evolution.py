import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from agents.consciousness import AgentConsciousnessEngine
from ai_engine import LLMClient
from orchestrator import TradingOrchestrator


def _trade(symbol, direction, pnl, reason="TRAILING_STOP_EXIT", outcome="WIN"):
    return {
        "action": "CLOSED",
        "symbol": symbol,
        "direction": direction,
        "pnl_usdt": pnl,
        "pnl_pct": 1.2 if pnl > 0 else -0.8,
        "outcome": outcome,
        "reason": reason,
        "exit_time": "2026-10-22T02:00:00+00:00",
        "entry_metrics": {"rsi": 58.0, "volume_surge": 1.6, "atr_pct": 1.1},
    }


class TestAiSelfEvolution(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "consciousness.json")
        self.trades = [
            _trade("BTCUSDT", "LONG", 2.5),
            _trade("ETHUSDT", "SHORT", -1.1, reason="STOP_LOSS_HIT", outcome="LOSS"),
        ]

    def tearDown(self):
        self._tmp.cleanup()

    def _client(self, payload):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="test-model")
        client.client = MagicMock()
        content = json.dumps(payload)
        client.client.chat.completions.create.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=content))]
        )
        return client

    def test_ai_upgrade_applies_thresholds_weights_and_machine_rule(self):
        client = self._client({
            "upgrade_version": "2.5.0-ULTRA",
            "executive_diagnosis": "Volume spikes are not converting into follow-through.",
            "calibrated_thresholds": {
                "Technical Price Action Division": {"min_volume_surge": 1.20},
            },
            "dynamic_weights": {"Technical Price Action Division": 1.30},
            "new_rules": [{
                "division": "Technical Price Action Division",
                "rule_id": "AI-VOL-01",
                "rule": "Reject volume surge above 1.50x without a strong close.",
                "origin": "AI audit",
                "machine_check": {
                    "metric": "volume_surge", "operator": ">", "threshold": 1.50,
                    "direction": "ANY", "action": "PENALTY_OR_VETO",
                },
            }],
        })
        result = client.upgrade_agent_intelligence(
            self.engine, self.trades,
            {"total_trades": 2, "winning_trades": 1, "losing_trades": 1, "realized_pnl_usdt": 1.4},
            audit_summary={"total_audits": 4, "audited_trades": 2},
            trigger="SCHEDULED_6H",
            external_context={"status": "OK", "bias": {"bias": "MIXED"}},
        )
        self.assertTrue(result["applied"])
        self.assertEqual(result["mode"], "AI_ULTRA_CONTEXT")
        self.assertEqual(result["changes"]["thresholds"], 1)
        self.assertEqual(result["changes"]["weights"], 1)
        self.assertEqual(result["changes"]["rules_added"], 1)
        self.assertEqual(self.engine.get_threshold("Technical Price Action Division", "min_volume_surge", 1.1), 1.20)
        self.assertEqual(self.engine.get_weight("Technical Price Action Division"), 1.30)
        self.assertEqual(self.engine.get_ultra_context_summary()["machine_rule_count"], 1)
        self.assertEqual(self.engine.memory["last_upgrade"]["trigger"], "SCHEDULED_6H")
        self.assertEqual(self.engine.memory["last_upgrade"]["model"], "test-model")
        self.assertEqual(client.status_summary["engine_mode"], "AI_ULTRA_CONTEXT")

    def test_ai_no_change_is_reported_without_inflating_counter(self):
        client = self._client({
            "upgrade_version": "2.5.0-ULTRA",
            "executive_diagnosis": "No valid change.",
            "calibrated_thresholds": {},
            "dynamic_weights": {},
            "new_rules": [],
        })
        before = self.engine.memory["total_upgrades_performed"]
        result = client.upgrade_agent_intelligence(
            self.engine, self.trades, {"total_trades": 2}, trigger="SCHEDULED_6H",
        )
        self.assertFalse(result["applied"])
        self.assertEqual(result["mode"], "AI_ULTRA_NO_CHANGE")
        self.assertEqual(self.engine.memory["total_upgrades_performed"], before)

    def test_provider_failure_falls_back_and_is_visible(self):
        client = LLMClient(api_key="test-key", base_url="http://127.0.0.1:9/v1", model="test-model")
        client.client = MagicMock()
        error = RuntimeError("bad gateway")
        error.status_code = 502
        client.client.chat.completions.create.side_effect = error
        result = client.upgrade_agent_intelligence(
            self.engine, self.trades, {"total_trades": 2}, trigger="SCHEDULED_6H",
        )
        self.assertFalse(result["success"])
        self.assertEqual(result["mode"], "DETERMINISTIC_AUTONOMOUS_FALLBACK")
        self.assertEqual(client.status_summary["last_error_kind"], "HTTP_502")


class TestAiThresholdPersistence(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.engine = AgentConsciousnessEngine(Path(self._tmp.name) / "consciousness.json")

    def tearDown(self):
        self._tmp.cleanup()

    def test_ai_thresholds_are_not_relaxed_by_staleness_decay(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "2.6.0-ULTRA",
            "calibrated_thresholds": {
                "Technical Price Action Division": {"min_volume_surge": 1.80},
            },
        })
        self.engine.apply_staleness_decay(24.0)
        self.assertAlmostEqual(
            self.engine.get_threshold("Technical Price Action Division", "min_volume_surge", 1.1),
            1.80,
        )

    def test_fresh_loss_overrides_ai_lock_and_tightens(self):
        self.engine.apply_ai_upgrade({
            "upgrade_version": "2.6.0-ULTRA",
            "calibrated_thresholds": {
                "Technical Price Action Division": {"min_volume_surge": 1.80},
            },
        })
        self.engine.record_trade_failure_and_learn({
            "symbol": "BTCUSDT", "outcome": "LOSS", "pnl_usdt": -1.0,
            "pnl_pct": -0.8, "reason": "STOP_LOSS_HIT",
        })
        self.assertGreater(
            self.engine.get_threshold("Technical Price Action Division", "min_volume_surge", 1.1),
            1.80,
        )
        self.assertFalse(
            self.engine.memory.get("ai_locked", {})
            .get("Technical Price Action Division", {})
            .get("min_volume_surge", True)
        )


class TestAutonomousEvolutionScheduler(unittest.TestCase):
    def test_scheduled_cycle_skips_ai_when_no_new_closed_trades(self):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.audit_all_divisions = MagicMock(return_value={
            "success": True, "total_audits": 0, "vetoes_enforced": 0, "audited_trades": 0,
        })
        orch.external_research = MagicMock()
        orch.maybe_upgrade_agent_intelligence = MagicMock()
        result = orch.autonomous_evolve()
        self.assertEqual(result["status"], "no_new_trades")
        self.assertEqual(result["ai_upgrade"]["mode"], "NO_NEW_TRADES")
        orch.external_research.collect.assert_not_called()
        orch.maybe_upgrade_agent_intelligence.assert_not_called()

    def test_scheduled_cycle_calls_ai_upgrade_with_market_context(self):
        orch = TradingOrchestrator.__new__(TradingOrchestrator)
        orch.audit_all_divisions = MagicMock(return_value={
            "success": True, "total_audits": 4, "vetoes_enforced": 1, "audited_trades": 2,
        })
        orch.external_research = MagicMock()
        orch.external_research.collect.return_value = {"status": "OK", "bias": {"bias": "MIXED"}}
        orch.maybe_upgrade_agent_intelligence = MagicMock(return_value={
            "success": True, "mode": "AI_ULTRA_CONTEXT", "applied": True,
            "changes": {"thresholds": 1, "weights": 1, "rules_added": 1},
        })
        with patch("orchestrator.consciousness_engine") as ce:
            result = orch.autonomous_evolve()
        orch.maybe_upgrade_agent_intelligence.assert_called_once()
        kwargs = orch.maybe_upgrade_agent_intelligence.call_args.kwargs
        self.assertEqual(kwargs["trigger"], "SCHEDULED_6H")
        self.assertEqual(kwargs["audit_summary"]["total_audits"], 4)
        self.assertEqual(kwargs["external_context"]["status"], "OK")
        ce.reload_memory.assert_called_once()
        self.assertEqual(result["status"], "evolved")
        self.assertEqual(result["ai_upgrade"]["mode"], "AI_ULTRA_CONTEXT")


if __name__ == "__main__":
    unittest.main()
