import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import approval_queue as approval_module
from daily_brief import DailyBrief


def _event(symbol, reason, pnl, gross, fee, pct, entry, exit_, direction="SHORT", metrics=None):
    return {
        "symbol": symbol,
        "action": "CLOSED",
        "direction": direction,
        "reason": reason,
        "pnl_usdt": pnl,
        "gross_pnl_usdt": gross,
        "fee_paid_usdt": fee,
        "pnl_pct": pct,
        "entry_time": entry,
        "exit_time": exit_,
        "entry_metrics": metrics or {"rsi": 48.0, "trend_efficiency": 0.05, "atr_pct": 1.6, "volume_surge": 1.0},
    }


class DailyBriefCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.history = self.root / "trade_history.json"
        self.portfolio = self.root / "portfolio.json"
        self.brief_path = self.root / "daily_brief.json"
        self.queue_path = self.root / "approval_queue.json"
        self.start = datetime(2026, 10, 22, 7, 0, tzinfo=timezone.utc)
        self._original_queue_path = approval_module.approval_queue.path
        approval_module.approval_queue.path = self.queue_path
        self.brief = DailyBrief(self.portfolio, self.brief_path, self.history)

    def tearDown(self):
        approval_module.approval_queue.path = self._original_queue_path
        self.tmp.cleanup()

    def _write(self, events, cash=299.2, positions=None):
        self.history.write_text(json.dumps(events), encoding="utf-8")
        self.portfolio.write_text(json.dumps({
            "mode": "paper",
            "cash_usdt": cash,
            "initial_capital": 1000.0,
            "counter_since": self.start.isoformat(),
            "open_positions": positions or [],
        }), encoding="utf-8")

    def test_brief_reports_equity_and_verdict(self):
        base = self.start
        self._write([
            _event("SUIUSDT", "MOMENTUM_TIME_STOP_EXIT", -1.05, -0.75, 0.30, -0.7,
                   (base + timedelta(hours=1)).isoformat(), (base + timedelta(hours=2)).isoformat()),
        ], cash=299.2, positions=[{"symbol": "INJUSDT", "direction": "SHORT", "market": "FUTURES",
                                   "entry_price": 8.145, "stop_loss_price": 8.09613,
                                   "take_profit_1": 8.037, "take_profit_2": 7.714,
                                   "position_usdt": 75.0}])
        brief = self.brief.build(persist=False)
        self.assertAlmostEqual(brief["equity_book_usdt"], 374.2, places=4)
        self.assertEqual(len(brief["open_positions"]), 1)
        self.assertEqual(brief["review"]["verdict"], "SAMPLE_TOO_SMALL")
        self.assertTrue(any("do not tune" in action for action in brief["actions"]))
        self.assertIn("DAILY BRIEF", brief["text"])
        self.assertIn("INJUSDT", brief["text"])

    def test_fee_share_action_when_costs_dominate(self):
        base = self.start
        events = [
            _event("INJUSDT", "TRAILING_STOP_EXIT", 0.1, 1.0, 0.9, 2.0,
                   (base + timedelta(hours=1)).isoformat(), (base + timedelta(hours=2)).isoformat()),
            _event("NEARUSDT", "STOP_LOSS_HIT", -0.5, 0.0, 0.5, -0.3,
                   (base + timedelta(hours=3)).isoformat(), (base + timedelta(hours=4)).isoformat()),
        ]
        self._write(events)
        brief = self.brief.build(persist=False)
        self.assertGreater(brief["review"]["metrics"]["fee_share_of_gross_pct"], 60)
        self.assertTrue(any("Fees consume" in action for action in brief["actions"]))

    def test_degenerate_target_action(self):
        base = self.start
        self._write([
            _event("SHIBUSDT", "TAKE_PROFIT_2_HIT", -0.2996, 0.0, 0.1498, -0.2,
                   base.isoformat(), (base + timedelta(seconds=2)).isoformat()),
        ])
        brief = self.brief.build(persist=False)
        self.assertEqual(brief["review"]["defects"].get("DEGENERATE_TARGET"), 1)
        self.assertTrue(any("PRICE_SIG_DIGITS" in action for action in brief["actions"]))

    def test_pending_tickets_are_surfaced(self):
        approval_module.approval_queue.submit({
            "symbol": "BTCUSDT", "direction": "SHORT", "target_market": "FUTURES",
            "entry_price": 81785.83, "stop_loss_price": 82603.68,
            "take_profit_1": 80967.97, "take_profit_2": 78514.39,
            "quantity": 0.0018, "position_usdt": 149.49,
        })
        self._write([])
        brief = self.brief.build(persist=False)
        self.assertEqual(len(brief["approvals_pending"]), 1)
        self.assertTrue(any("approval ticket" in action for action in brief["actions"]))
        self.assertIn("approvals pending", brief["text"])

    def test_persist_appends_journal(self):
        self._write([])
        self.brief.build(persist=True)
        self.brief.build(persist=True)
        journal = json.loads(self.brief_path.read_text(encoding="utf-8"))
        self.assertEqual(len(journal), 2)
        self.assertIn("review", journal[0])
        self.assertIn("actions", journal[0])

    def test_missing_files_do_not_raise(self):
        brief = self.brief.build(persist=False)
        self.assertEqual(brief["open_positions"], [])
        self.assertEqual(brief["review"]["verdict"], "SAMPLE_TOO_SMALL")
        self.assertTrue(brief["actions"])


if __name__ == "__main__":
    unittest.main()
