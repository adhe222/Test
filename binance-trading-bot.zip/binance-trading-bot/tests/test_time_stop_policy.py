import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import config
from agents.portfolio_manager import PortfolioManagerAgent

BASE_MS = 1_700_000_000_000


def _plan():
    return {
        "symbol": "FIXUSDT",
        "direction": "SHORT",
        "target_market": "FUTURES",
        "side": "SELL",
        "position_usdt": 100.0,
        "quantity": 1.0,
        "entry_price": 100.0,
        "stop_loss_price": 103.0,
        "stop_loss_pct": 3.0,
        "take_profit_1": 97.0,
        "take_profit_2": 88.0,
        "trailing_trigger_pct": 3.0,
        "trailing_distance_pct": 1.0,
        "entry_atr_pct": 1.0,
        "atr": 1.0,
    }


def _klines(last_close, drift=0.0, count=40):
    rows = []
    for i in range(count):
        close = last_close - drift * (count - 1 - i)
        rows.append({
            "open_time": BASE_MS + i * 900_000,
            "close_time": BASE_MS + i * 900_000 + 899_999,
            "open": close,
            "high": close,
            "low": close,
            "close": close,
            "volume": 1.0,
            "is_closed": True,
        })
    return rows


class TimeStopPolicyCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.enterContext(patch.object(config, "PORTFOLIO_FILE", self.tmp / "portfolio.json"))
        self.enterContext(patch.object(config, "TRADE_LOG_FILE", self.tmp / "trades.json"))
        self.enterContext(patch.object(config, "TIME_STOP_SOFT_ENABLED", False))
        self.enterContext(patch.object(config, "TIME_STOP_AFTER_MIN", 30))
        self.enterContext(patch.object(config, "TIME_STOP_HARD_MIN", 90))
        self.client = MagicMock()
        self.client.get_price.return_value = 100.0
        self.client.get_klines.return_value = _klines(100.0)
        self.portfolio = PortfolioManagerAgent(self.client, mode="paper")
        self.portfolio.reset_portfolio(1000.0)
        self.assertTrue(self.portfolio.execute_trade(_plan()))
        self.pos = self.portfolio.state["open_positions"][0]

    def age(self, minutes):
        self.pos["entry_time"] = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat()

    def run_cycle(self, price):
        self.client.get_price.return_value = price
        events = self.portfolio.update_and_monitor_positions()
        return [e for e in events if e.get("action") == "CLOSED"]

    def test_flat_trade_is_not_cut_at_soft_window(self):
        self.age(40)
        self.client.get_klines.return_value = _klines(99.0, drift=0.05)
        closed = self.run_cycle(99.75)
        self.assertEqual(closed, [])
        self.assertEqual(len(self.portfolio.state["open_positions"]), 1)

    def test_soft_window_cuts_a_real_loss_after_fees(self):
        self.age(40)
        with patch.object(config, "TIME_STOP_SOFT_ENABLED", True):
            closed = self.run_cycle(100.25)
        self.assertEqual(len(closed), 1)
        self.assertEqual(closed[0]["reason"], "MOMENTUM_TIME_STOP_EXIT")
        self.assertLess(closed[0]["pnl_usdt"], 0.0)

    def test_soft_cut_is_off_by_default(self):
        self.age(40)
        self.assertFalse(getattr(config, "TIME_STOP_SOFT_ENABLED", False))
        closed = self.run_cycle(100.25)
        self.assertEqual(closed, [])
        self.assertEqual(len(self.portfolio.state["open_positions"]), 1)

    def test_hard_window_recycles_a_trade_the_soft_stage_spares(self):
        self.age(95)
        self.client.get_klines.return_value = _klines(99.0, drift=0.05)
        closed = self.run_cycle(99.75)
        self.assertEqual(len(closed), 1)
        self.assertEqual(closed[0]["reason"], "MOMENTUM_TIME_STOP_EXIT")
        self.assertGreater(closed[0]["gross_pnl_usdt"], 0.0)

    def test_no_cut_between_soft_and_hard_window(self):
        self.age(60)
        self.client.get_klines.return_value = _klines(99.0, drift=0.05)
        closed = self.run_cycle(99.75)
        self.assertEqual(closed, [])

    def test_hard_window_is_configurable(self):
        self.age(95)
        self.client.get_klines.return_value = _klines(99.0, drift=0.05)
        with patch.object(config, "TIME_STOP_HARD_MIN", 200):
            closed = self.run_cycle(99.75)
        self.assertEqual(closed, [])

    def test_ema_flip_still_required_for_the_soft_cut(self):
        self.age(40)
        self.client.get_klines.return_value = _klines(101.0, drift=-0.05)
        with patch.object(config, "TIME_STOP_SOFT_ENABLED", True):
            closed = self.run_cycle(100.25)
        self.assertEqual(closed, [])


if __name__ == "__main__":
    unittest.main()
