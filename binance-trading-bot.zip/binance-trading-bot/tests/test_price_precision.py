import unittest

import config
from agents.portfolio_manager import PortfolioManagerAgent
from agents.risk_manager import RiskManagementAgent, price_decimals, round_price


class TestSubCentPricePrecision(unittest.TestCase):
    def setUp(self):
        self.risk = RiskManagementAgent()

    def test_round_price_keeps_sub_cent_resolution(self):
        self.assertGreaterEqual(price_decimals(0.000005), 12)
        self.assertNotEqual(round_price(0.0000047), round_price(0.000005))

    def test_short_bracket_never_collapses_on_penny_asset(self):
        entry = 0.000005
        plan = self.risk.evaluate_risk(
            "SHIBUSDT", entry, entry * 0.01, 1000.0, [], direction="SHORT", target_market="SPOT"
        )
        self.assertTrue(plan["approved"], plan.get("reason"))
        self.assertGreater(plan["stop_loss_price"], entry)
        self.assertGreater(entry, plan["take_profit_1"])
        self.assertGreater(plan["take_profit_1"], plan["take_profit_2"])
        self.assertGreater(entry - plan["take_profit_2"], entry * 0.0005)

    def test_long_bracket_never_collapses_on_penny_asset(self):
        entry = 0.000005
        plan = self.risk.evaluate_risk(
            "SHIBUSDT", entry, entry * 0.01, 1000.0, [], direction="LONG", target_market="SPOT"
        )
        self.assertTrue(plan["approved"], plan.get("reason"))
        self.assertLess(plan["stop_loss_price"], entry)
        self.assertLess(entry, plan["take_profit_1"])
        self.assertLess(plan["take_profit_1"], plan["take_profit_2"])

    def test_high_price_bracket_ordering(self):
        entry = 81785.83
        plan = self.risk.evaluate_risk(
            "BTCUSDT", entry, entry * 0.005, 1000.0, [], direction="SHORT", target_market="SPOT"
        )
        self.assertTrue(plan["approved"], plan.get("reason"))
        self.assertGreater(plan["stop_loss_price"], entry)
        self.assertGreater(entry, plan["take_profit_1"])
        self.assertGreater(plan["take_profit_1"], plan["take_profit_2"])

    def test_fee_floor_rejects_fee_sized_tp1(self):
        original = getattr(config, "MIN_TP1_NET_FEE_MULT", 1.0)
        config.MIN_TP1_NET_FEE_MULT = 100.0
        try:
            plan = self.risk.evaluate_risk(
                "BTCUSDT", 81785.83, 408.9, 1000.0, [], direction="SHORT", target_market="SPOT"
            )
        finally:
            config.MIN_TP1_NET_FEE_MULT = original
        self.assertFalse(plan["approved"])
        self.assertIn("TP1 net of fees", plan["reason"])


class TestDegenerateBracketGuard(unittest.TestCase):
    def test_collapsed_targets_rejected_before_order(self):
        plan = {
            "stop_loss_price": 0.000005,
            "take_profit_1": 0.000005,
            "take_profit_2": 0.000005,
        }
        reason = PortfolioManagerAgent._degenerate_bracket("SHORT", 0.000005, plan)
        self.assertIn("degenerate bracket", reason)

    def test_valid_bracket_accepted(self):
        plan = {
            "stop_loss_price": 0.000005075,
            "take_profit_1": 0.000004925,
            "take_profit_2": 0.0000047,
        }
        self.assertEqual(PortfolioManagerAgent._degenerate_bracket("SHORT", 0.000005, plan), "")

    def test_missing_levels_rejected(self):
        plan = {"stop_loss_price": 0.0, "take_profit_1": 0.0, "take_profit_2": 0.0}
        self.assertIn("missing bracket levels", PortfolioManagerAgent._degenerate_bracket("LONG", 1.0, plan))


if __name__ == "__main__":
    unittest.main()
