import unittest

import config
import market_router


class MarketRouterTestCase(unittest.TestCase):
    def setUp(self):
        self.router = market_router.MarketRouter()
        self._snapshot = {
            name: getattr(config, name)
            for name in (
                "AUTO_MARKET_SWITCH_MARGIN_PCT",
                "FUTURES_AUTO_LEVERAGE_MAX",
                "FUTURES_LIQUIDATION_BUFFER_MULT",
                "FUTURES_FEE_PCT",
                "FUTURES_MARGIN_ENABLED",
                "FUNDING_HOLD_PERIODS",
                "FUNDING_CREDIT_EDGE_PCT",
                "EFFECTIVE_FEE_PCT",
                "ENABLE_SPOT_LONGS",
                "ENABLE_FUTURES_SHORTS",
                "ROUTER_STOP_FLOOR_PCT",
                "ROUTER_STOP_CAP_PCT",
                "RISK_PER_TRADE_PCT",
                "MAX_POSITION_SIZE_PCT",
                "TP1_R_MULTIPLE",
                "ADAPTIVE_ATR_MULTIPLIER",
            )
            if hasattr(config, name)
        }

    def tearDown(self):
        for name, value in self._snapshot.items():
            setattr(config, name, value)

    def choose(self, **overrides):
        payload = dict(
            symbol="NEARUSDT",
            direction="LONG",
            price=2.1,
            atr_pct=1.2,
            quote_volume_24h=90_000_000,
            spot_available=True,
            futures_available=True,
            funding_rate=0.0001,
            equity=1000.0,
            free_cash=1000.0,
        )
        payload.update(overrides)
        return self.router.choose(**payload)

    def test_short_is_always_routed_to_futures(self):
        decision = self.choose(direction="SHORT")
        self.assertTrue(decision["approved"])
        self.assertEqual(decision["market"], "FUTURES")
        self.assertGreaterEqual(decision["leverage"], 1.0)

    def test_short_vetoed_when_futures_unavailable(self):
        decision = self.choose(direction="SHORT", futures_available=False)
        self.assertFalse(decision["approved"])
        self.assertIsNone(decision["market"])
        self.assertIn("FUTURES", decision["reason"])

    def test_long_prefers_spot_when_both_venues_available(self):
        decision = self.choose()
        self.assertTrue(decision["approved"])
        self.assertEqual(decision["market"], "SPOT")
        self.assertEqual(decision["leverage"], 1.0)

    def test_long_uses_spot_when_futures_missing(self):
        decision = self.choose(futures_available=False)
        self.assertEqual(decision["market"], "SPOT")

    def test_long_uses_futures_when_spot_missing(self):
        decision = self.choose(spot_available=False)
        self.assertEqual(decision["market"], "FUTURES")
        self.assertGreaterEqual(decision["leverage"], 1.0)

    def test_long_takes_futures_funding_credit(self):
        decision = self.choose(funding_rate=-0.0004)
        self.assertEqual(decision["market"], "FUTURES")
        self.assertIn("funding credit", decision["reason"])
        self.assertLess(decision["funding_pct"], 0)

    def test_long_switches_on_cheaper_futures_edge(self):
        config.EFFECTIVE_FEE_PCT = 0.20
        config.FUTURES_FEE_PCT = 0.02
        config.AUTO_MARKET_SWITCH_MARGIN_PCT = 0.01
        decision = self.choose(funding_rate=0.0)
        self.assertEqual(decision["market"], "FUTURES")
        self.assertGreater(decision["net_edge_futures_pct"], decision["net_edge_spot_pct"])

    def test_no_venue_available_is_vetoed(self):
        decision = self.choose(spot_available=False, futures_available=False)
        self.assertFalse(decision["approved"])
        self.assertIsNone(decision["market"])

    def test_leverage_respects_liquidation_buffer(self):
        config.FUTURES_AUTO_LEVERAGE_MAX = 50.0
        config.FUTURES_LIQUIDATION_BUFFER_MULT = 3.0
        decision = self.choose(spot_available=False, atr_pct=2.0)
        self.assertEqual(decision["market"], "FUTURES")
        self.assertLessEqual(decision["liquidation_distance_pct"], decision["stop_pct"] * 3.0 + 0.01)
        self.assertGreaterEqual(decision["liquidation_distance_pct"], decision["stop_pct"])

    def test_leverage_capped_by_configured_ceiling(self):
        config.FUTURES_AUTO_LEVERAGE_MAX = 2.5
        decision = self.choose(spot_available=False, atr_pct=0.2)
        self.assertLessEqual(decision["leverage"], 2.5)

    def test_margin_mode_switches_long_to_futures(self):
        config.FUTURES_MARGIN_ENABLED = True
        decision = self.choose(free_cash=50.0, equity=1000.0)
        self.assertEqual(decision["market"], "FUTURES")
        self.assertGreater(decision["capital_freed_usdt"], 0.0)

    def test_expected_move_uses_r_multiple(self):
        config.TP1_R_MULTIPLE = 2.0
        config.ADAPTIVE_ATR_MULTIPLIER = 1.5
        decision = self.choose(atr_pct=1.0)
        self.assertAlmostEqual(decision["expected_move_pct"], decision["stop_pct"] * 2.0, places=4)


class ExecutionPlanLeverageTestCase(unittest.TestCase):
    def test_refresh_plan_carries_routed_leverage(self):
        from datetime import datetime, timezone
        from agents.risk_manager import RiskManagementAgent
        from orchestrator import TradingOrchestrator

        class FakeOrderbook:
            def inspect_orderbook(self, symbol, direction="LONG", use_cache=True, market=None):
                return {"passed": True, "best_bid": 100.0, "best_ask": 100.05, "imbalance": 0.2, "spread_pct": 0.05}

        orchestrator = object.__new__(TradingOrchestrator)
        orchestrator.orderbook_data_agent = FakeOrderbook()
        orchestrator.risk_data_agent = RiskManagementAgent()
        plan, error = orchestrator._refresh_execution_plan(
            symbol="NEARUSDT",
            direction="SHORT",
            signal_price=100.0,
            signal_generated_at=datetime.now(timezone.utc).isoformat(),
            atr=1.0,
            total_equity=1000.0,
            open_positions=[],
            target_market="FUTURES",
            risk_scale=1.0,
            entry_metrics={},
            leverage=3.0,
            market_decision={"market": "FUTURES", "leverage": 3.0, "reason": "short"},
        )
        self.assertIsNone(error)
        self.assertIsNotNone(plan)
        self.assertEqual(plan["leverage"], 3.0)
        self.assertEqual(plan["target_market"], "FUTURES")
        self.assertAlmostEqual(plan["margin_usdt"], round(plan["position_usdt"] / 3.0, 2), places=2)
        self.assertEqual(plan["market_decision"]["market"], "FUTURES")

    def test_futures_fee_lowers_roundtrip_cost(self):
        from agents.risk_manager import RiskManagementAgent

        agent = RiskManagementAgent()
        kwargs = dict(
            symbol="NEARUSDT",
            current_price=100.0,
            atr=1.0,
            total_equity=1000.0,
            open_positions=[],
            direction="SHORT",
            risk_scale=1.0,
        )
        spot_plan = agent.evaluate_risk(target_market="SPOT", leverage=1.0, **kwargs)
        futures_plan = agent.evaluate_risk(target_market="FUTURES", leverage=3.0, **kwargs)
        self.assertTrue(spot_plan["approved"])
        self.assertTrue(futures_plan["approved"])
        self.assertGreaterEqual(futures_plan["risk_reward_ratio"], spot_plan["risk_reward_ratio"])


if __name__ == "__main__":
    unittest.main()
