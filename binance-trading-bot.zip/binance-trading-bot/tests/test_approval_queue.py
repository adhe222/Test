import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import approval_queue as approval_module
import config
from approval_queue import (
    APPROVED,
    CONSUMED,
    EXPIRED,
    PENDING,
    REJECTED,
    ApprovalQueue,
)


def _plan(symbol="BTCUSDT", direction="SHORT", entry=81785.83, market="FUTURES"):
    return {
        "symbol": symbol,
        "direction": direction,
        "target_market": market,
        "side": "SELL" if direction == "SHORT" else "BUY",
        "entry_price": entry,
        "stop_loss_price": entry * 1.01,
        "take_profit_1": entry * 0.99,
        "take_profit_2": entry * 0.96,
        "quantity": 0.0018,
        "position_usdt": 149.49,
        "risk_reward_ratio": 2.1,
        "stop_loss_pct": 1.0,
        "trailing_trigger_pct": 1.0,
        "trailing_distance_pct": 1.2,
        "atr": 408.9,
        "leverage": 1.0,
        "entry_metrics": {"rsi": 48.6, "trend_efficiency": 0.06},
    }


class ApprovalQueueCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "approval_queue.json"
        self.queue = ApprovalQueue(self.path, ttl_sec=900)

    def tearDown(self):
        self.tmp.cleanup()

    def test_submit_creates_pending_ticket(self):
        ticket = self.queue.submit(_plan(), rationale="momentum breakdown", conviction=82)
        self.assertEqual(ticket["status"], PENDING)
        self.assertEqual(ticket["symbol"], "BTCUSDT")
        self.assertEqual(ticket["direction"], "SHORT")
        self.assertEqual(ticket["conviction"], 82.0)
        self.assertEqual(len(self.queue.pending()), 1)
        stored = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(stored[0]["id"], ticket["id"])

    def test_consume_requires_approval(self):
        ticket = self.queue.submit(_plan())
        ok, reason = self.queue.consume(ticket["id"], _plan())
        self.assertFalse(ok)
        self.assertIn("PENDING", reason)

    def test_approved_ticket_consumes_once(self):
        ticket = self.queue.submit(_plan())
        ok, _ = self.queue.decide(ticket["id"], True, "operator", "ok")
        self.assertTrue(ok)
        self.assertEqual(self.queue.get(ticket["id"])["status"], APPROVED)
        ok, reason = self.queue.consume(ticket["id"], _plan())
        self.assertTrue(ok, reason)
        self.assertEqual(self.queue.get(ticket["id"])["status"], CONSUMED)
        ok, reason = self.queue.consume(ticket["id"], _plan())
        self.assertFalse(ok)
        self.assertIn(CONSUMED, reason)

    def test_missing_ticket_id_blocks_execution(self):
        ok, reason = self.queue.consume(None, _plan())
        self.assertFalse(ok)
        self.assertIn("missing approval ticket", reason)

    def test_symbol_and_direction_mismatch_blocked(self):
        ticket = self.queue.submit(_plan())
        self.queue.decide(ticket["id"], True, "operator")
        ok, reason = self.queue.consume(ticket["id"], _plan(symbol="ETHUSDT"))
        self.assertFalse(ok)
        self.assertIn("symbol mismatch", reason)
        ok, reason = self.queue.consume(ticket["id"], _plan(direction="LONG"))
        self.assertFalse(ok)
        self.assertIn("direction mismatch", reason)

    def test_reject_is_terminal(self):
        ticket = self.queue.submit(_plan())
        ok, decided = self.queue.decide(ticket["id"], False, "operator", "too risky")
        self.assertTrue(ok)
        self.assertEqual(decided["status"], REJECTED)
        ok, reason = self.queue.consume(ticket["id"], _plan())
        self.assertFalse(ok)
        self.assertIn(REJECTED, reason)

    def test_expiry_marks_ticket_expired(self):
        queue = ApprovalQueue(self.path, ttl_sec=0)
        ticket = queue.submit(_plan())
        expired_at = (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()
        stored = json.loads(self.path.read_text(encoding="utf-8"))
        stored[0]["expires_at"] = expired_at
        self.path.write_text(json.dumps(stored), encoding="utf-8")
        self.assertEqual(queue.pending(), [])
        self.assertEqual(queue.get(ticket["id"])["status"], EXPIRED)
        ok, reason = queue.consume(ticket["id"], _plan())
        self.assertFalse(ok)

    def test_overflow_expires_oldest_pending(self):
        queue = ApprovalQueue(self.path, ttl_sec=900)
        queue.max_pending = 2
        first = queue.submit(_plan(symbol="BTCUSDT"))
        queue.submit(_plan(symbol="ETHUSDT"))
        queue.submit(_plan(symbol="SOLUSDT"))
        statuses = {t["symbol"]: t["status"] for t in queue.history(10)}
        self.assertEqual(statuses["BTCUSDT"], EXPIRED)
        self.assertEqual(statuses["SOLUSDT"], PENDING)
        self.assertEqual(queue.get(first["id"])["status"], EXPIRED)

    def test_unknown_ticket_decision_reports_not_found(self):
        ok, ticket = self.queue.decide("doesnotexist", True, "operator")
        self.assertFalse(ok)
        self.assertEqual(ticket["status"], "NOT_FOUND")

    def test_text_fields_are_sanitised(self):
        ticket = self.queue.submit(_plan(), rationale="bad\x00idea\x1b" + "y" * 900, conviction="nan")
        self.assertNotIn("\x00", ticket["rationale"])
        self.assertLessEqual(len(ticket["rationale"]), 400)
        self.assertIsNone(ticket["conviction"])


class LiveExecutionGateCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.queue_path = self.root / "approval_queue.json"
        self._original = approval_module.approval_queue.path
        approval_module.approval_queue.path = self.queue_path
        self.queue = approval_module.approval_queue
        self.queue.max_pending = 20

    def tearDown(self):
        approval_module.approval_queue.path = self._original
        self.tmp.cleanup()

    def _manager(self):
        from agents.portfolio_manager import PortfolioManagerAgent
        from unittest.mock import MagicMock, patch

        client = MagicMock()
        pm = PortfolioManagerAgent(client, mode="live")
        pm._sync_state_if_file_newer = lambda: None
        pm._save_portfolio = MagicMock()
        pm.record_equity_snapshot = MagicMock()
        pm.state = {"cash_usdt": 1000.0, "open_positions": [], "total_fees_paid_usdt": 0.0}
        return pm, client, patch

    def test_live_entry_blocked_without_ticket(self):
        from unittest.mock import patch

        pm, client, _ = self._manager()
        with patch.object(config, "REQUIRE_APPROVAL_TICKET", True):
            self.assertFalse(pm.execute_trade(_plan()))
        client.place_order.assert_not_called()

    def test_live_entry_blocked_while_pending(self):
        from unittest.mock import patch

        pm, client, _ = self._manager()
        ticket = self.queue.submit(_plan())
        plan = dict(_plan(), approval_ticket_id=ticket["id"])
        with patch.object(config, "REQUIRE_APPROVAL_TICKET", True):
            self.assertFalse(pm.execute_trade(plan))
        client.place_order.assert_not_called()

    def test_live_entry_executes_once_approved(self):
        from unittest.mock import patch

        pm, client, _ = self._manager()
        ticket = self.queue.submit(_plan())
        self.queue.decide(ticket["id"], True, "operator", "approved in dashboard")
        plan = dict(_plan(), approval_ticket_id=ticket["id"])
        with patch.object(config, "REQUIRE_APPROVAL_TICKET", True):
            self.assertTrue(pm.execute_trade(plan))
        client.place_order.assert_called_once()
        self.assertEqual(self.queue.get(ticket["id"])["status"], CONSUMED)

    def test_replay_of_consumed_ticket_is_blocked(self):
        from unittest.mock import patch

        pm, client, _ = self._manager()
        ticket = self.queue.submit(_plan())
        self.queue.decide(ticket["id"], True, "operator")
        plan = dict(_plan(), approval_ticket_id=ticket["id"])
        with patch.object(config, "REQUIRE_APPROVAL_TICKET", True):
            self.assertTrue(pm.execute_trade(plan))
            pm.state = {"cash_usdt": 1000.0, "open_positions": [], "total_fees_paid_usdt": 0.0}
            self.assertFalse(pm.execute_trade(plan))
        self.assertEqual(client.place_order.call_count, 1)


if __name__ == "__main__":
    unittest.main()
