import os
import socket
import sys
import threading
import time
from typing import Dict, List, Optional, Tuple

import requests

DOH_ENDPOINTS = (
    "https://cloudflare-dns.com/dns-query",
    "https://dns.google/resolve",
    "https://1.1.1.1/dns-query",
)
DEFAULT_SUFFIXES = ("okx.com", "binance.com")


def _is_ip(value: str) -> bool:
    try:
        socket.inet_aton(value)
        return value.count(".") == 3
    except OSError:
        return False


class DohResolver:
    def __init__(self, endpoints: Optional[List[str]] = None, ttl: float = 600.0, timeout: float = 5.0):
        self.endpoints = list(endpoints or DOH_ENDPOINTS)
        self.ttl = float(ttl)
        self.timeout = float(timeout)
        self._cache: Dict[str, Tuple[float, List[str]]] = {}
        self._lock = threading.Lock()
        self._session = requests.Session()
        self._session.headers.update({"accept": "application/dns-json"})
        self._preferred = 0

    def _query(self, name: str) -> List[str]:
        order = self.endpoints[self._preferred:] + self.endpoints[:self._preferred]
        for endpoint in order:
            try:
                resp = self._session.get(endpoint, params={"name": name, "type": "A"}, timeout=self.timeout)
                if resp.status_code != 200:
                    continue
                payload = resp.json()
                ips = [
                    str(row.get("data"))
                    for row in (payload.get("Answer") or [])
                    if row.get("type") == 1 and row.get("data") and _is_ip(str(row.get("data")))
                ]
                if ips:
                    self._preferred = self.endpoints.index(endpoint)
                    return ips
            except Exception:
                continue
        return []

    def resolve(self, host: str) -> List[str]:
        key = str(host or "").lower().rstrip(".")
        if not key:
            return []
        now = time.time()
        with self._lock:
            hit = self._cache.get(key)
            if hit and hit[0] > now:
                return list(hit[1])
        ips = self._query(key)
        if ips:
            with self._lock:
                self._cache[key] = (now + self.ttl, list(ips))
        return ips


class DohRouting:
    def __init__(self, suffixes=None, resolver: Optional[DohResolver] = None):
        self.suffixes = tuple(
            s.strip().lower()
            for s in (suffixes if suffixes is not None else DEFAULT_SUFFIXES)
            if s and s.strip()
        )
        self.resolver = resolver or DohResolver(ttl=float(os.getenv("DOH_CACHE_TTL_SEC", "600")))
        self._original = None
        self._lock = threading.Lock()

    def routed(self, host: str) -> bool:
        key = str(host or "").lower().rstrip(".")
        if not key or _is_ip(key):
            return False
        return any(key == suffix or key.endswith("." + suffix) for suffix in self.suffixes)

    def connect_addresses(self, host: str) -> List[str]:
        if not self.routed(host):
            return []
        return self.resolver.resolve(host)

    def install(self) -> bool:
        with self._lock:
            if self._original is not None:
                return True
            from urllib3.util import connection as _connection

            original = _connection.create_connection
            if getattr(original, "_aegis_doh", False):
                self._original = original
                return True

            def routed_create_connection(address, *args, **kwargs):
                host, port = address[0], address[1]
                if self.routed(host):
                    candidates = self.resolver.resolve(host)
                    if candidates:
                        last_error = None
                        for ip in candidates:
                            try:
                                return original((ip, port) + tuple(address[2:]), *args, **kwargs)
                            except OSError as exc:
                                last_error = exc
                                continue
                        if last_error is not None:
                            raise last_error
                return original(address, *args, **kwargs)

            routed_create_connection._aegis_doh = True
            self._original = original
            for name, module in list(sys.modules.items()):
                if not name.startswith("urllib3"):
                    continue
                if getattr(module, "create_connection", None) is original:
                    setattr(module, "create_connection", routed_create_connection)
            _connection.create_connection = routed_create_connection
            return True


_routing: Optional[DohRouting] = None
_install_lock = threading.Lock()


def active_routing() -> DohRouting:
    global _routing
    with _install_lock:
        if _routing is None:
            enabled = str(os.getenv("DOH_ROUTING_ENABLED", "true")).strip().lower() in ("1", "true", "yes", "on")
            suffixes = os.getenv("DOH_ROUTED_HOSTS", ",".join(DEFAULT_SUFFIXES)).split(",")
            _routing = DohRouting(suffixes=suffixes if enabled else [])
            if enabled:
                _routing.install()
        return _routing


def ensure_routing() -> None:
    active_routing()


def resolve_host(host: str) -> List[str]:
    return active_routing().resolver.resolve(host)
