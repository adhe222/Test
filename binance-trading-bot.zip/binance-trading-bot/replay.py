import argparse
import json
import statistics
from typing import Any, Dict, List, Optional

FEE_PCT_PER_SIDE = 0.10
INTERVAL_MINUTES = {"1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "2h": 120, "4h": 240}
LOOKBACK = 20
RSI_PERIOD = 14

POLICIES: Dict[str, Dict[str, float]] = {
    "baseline": {
        "stop_pct": 2.0,
        "tp1_r": 1.0,
        "tp1_frac": 0.5,
        "trail_trigger_pct": 2.2,
        "trail_distance_pct": 1.5,
        "hard_minutes": 90,
        "volume_surge_min": 1.10,
        "trend_efficiency_min": 0.12,
        "rsi_long_max": 74.0,
        "rsi_short_min": 26.0,
    },
    "scalp": {
        "stop_pct": 2.0,
        "tp1_r": 1.2,
        "tp1_frac": 0.5,
        "trail_trigger_pct": 1.6,
        "trail_distance_pct": 1.0,
        "hard_minutes": 30,
        "volume_surge_min": 2.0,
        "trend_efficiency_min": 0.40,
        "rsi_long_max": 55.0,
        "rsi_short_min": 45.0,
    },
    "swing_hold": {
        "stop_pct": 0.0,
        "tp1_r": 0.0,
        "tp1_frac": 0.0,
        "trail_trigger_pct": 0.0,
        "trail_distance_pct": 0.0,
        "hold_bars": 32,
        "hard_minutes": 99999,
        "volume_surge_min": 1.40,
        "trend_efficiency_min": 0.15,
        "rsi_long_max": 55.0,
        "rsi_short_min": 45.0,
    },
}


def _rsi(closes: List[float], period: int = RSI_PERIOD) -> Optional[float]:
    if len(closes) <= period:
        return None
    gains = 0.0
    losses = 0.0
    for i in range(len(closes) - period, len(closes)):
        delta = closes[i] - closes[i - 1]
        if delta >= 0:
            gains += delta
        else:
            losses -= delta
    if gains + losses == 0:
        return 50.0
    avg_gain = gains / period
    avg_loss = losses / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def _trend_efficiency(closes: List[float], lookback: int = LOOKBACK) -> Optional[float]:
    if len(closes) <= lookback:
        return None
    window = closes[-(lookback + 1):]
    path = sum(abs(window[i] - window[i - 1]) for i in range(1, len(window)))
    if path <= 0:
        return 0.0
    return abs(window[-1] - window[0]) / path


def _volume_surge(volumes: List[float], lookback: int = LOOKBACK) -> Optional[float]:
    if len(volumes) <= lookback:
        return None
    prior = volumes[-(lookback + 1):-1]
    base = sum(prior) / len(prior)
    if base <= 0:
        return None
    return volumes[-1] / base


def signal_at(bars: List[Dict[str, Any]], index: int, policy: Dict[str, float]) -> Optional[Dict[str, Any]]:
    if index < LOOKBACK + RSI_PERIOD:
        return None
    window = bars[: index + 1]
    closes = [float(b["close"]) for b in window]
    volumes = [float(b.get("volume") or 0.0) for b in window]
    surge = _volume_surge(volumes)
    efficiency = _trend_efficiency(closes)
    rsi = _rsi(closes)
    if surge is None or efficiency is None or rsi is None:
        return None
    if surge < policy["volume_surge_min"] or efficiency < policy["trend_efficiency_min"]:
        return None
    efficiency_max = policy.get("trend_efficiency_max")
    if efficiency_max is not None and efficiency > float(efficiency_max):
        return None
    reference = closes[-(LOOKBACK + 1)]
    direction = "LONG" if closes[-1] > reference else "SHORT"
    if direction == "LONG" and rsi > policy["rsi_long_max"]:
        return None
    if direction == "SHORT" and rsi < policy["rsi_short_min"]:
        return None
    return {
        "direction": direction,
        "volume_surge": round(surge, 4),
        "trend_efficiency": round(efficiency, 4),
        "rsi": round(rsi, 2),
    }


def simulate_trade(
    bars: List[Dict[str, Any]],
    entry_index: int,
    direction: str,
    policy: Dict[str, float],
    minutes_per_bar: int,
) -> Optional[Dict[str, Any]]:
    if entry_index >= len(bars):
        return None
    entry_price = float(bars[entry_index]["open"])
    if entry_price <= 0:
        return None
    sign = 1.0 if direction == "LONG" else -1.0
    stop_pct = float(policy.get("stop_pct") or 0.0)
    tp1_r = float(policy.get("tp1_r") or 0.0)
    trail_trigger_pct = float(policy.get("trail_trigger_pct") or 0.0)
    hold_bars = int(policy.get("hold_bars") or 0)
    use_stop = stop_pct > 0
    use_tp1 = tp1_r > 0
    use_trail = trail_trigger_pct > 0
    stop_price = entry_price * (1.0 - sign * stop_pct / 100.0)
    tp1_price = entry_price * (1.0 + sign * tp1_r * stop_pct / 100.0)
    trail_trigger_price = entry_price * (1.0 + sign * trail_trigger_pct / 100.0)
    peak = entry_price
    tp1_taken = False
    tp1_frac = float(policy.get("tp1_frac", 0.5))

    def leg_pct(exit_price: float, weight: float) -> float:
        return sign * (exit_price - entry_price) / entry_price * 100.0 * weight

    realized = 0.0
    reason = None
    exit_index = entry_index
    for offset in range(1, len(bars) - entry_index):
        bar = bars[entry_index + offset]
        high = float(bar["high"])
        low = float(bar["low"])
        close = float(bar["close"])
        exit_index = entry_index + offset
        held_minutes = offset * minutes_per_bar

        if direction == "LONG":
            if use_stop and low <= stop_price:
                realized += leg_pct(stop_price, 1.0 if not tp1_taken else 1.0 - tp1_frac)
                reason = "STOP_LOSS_HIT"
                break
            if use_tp1 and not tp1_taken and high >= tp1_price:
                realized += leg_pct(tp1_price, tp1_frac)
                tp1_taken = True
                peak = max(peak, high)
            elif tp1_taken:
                peak = max(peak, high)
        else:
            if use_stop and high >= stop_price:
                realized += leg_pct(stop_price, 1.0 if not tp1_taken else 1.0 - tp1_frac)
                reason = "STOP_LOSS_HIT"
                break
            if use_tp1 and not tp1_taken and low <= tp1_price:
                realized += leg_pct(tp1_price, tp1_frac)
                tp1_taken = True
                peak = min(peak, low)
            elif tp1_taken:
                peak = min(peak, low)

        if use_trail and tp1_taken:
            if direction == "LONG" and peak >= trail_trigger_price:
                trail_price = peak * (1.0 - policy["trail_distance_pct"] / 100.0)
                if low <= trail_price:
                    realized += leg_pct(trail_price, 1.0 - tp1_frac)
                    reason = "TRAILING_STOP_EXIT"
                    break
            elif direction == "SHORT" and peak <= trail_trigger_price:
                trail_price = peak * (1.0 + policy["trail_distance_pct"] / 100.0)
                if high >= trail_price:
                    realized += leg_pct(trail_price, 1.0 - tp1_frac)
                    reason = "TRAILING_STOP_EXIT"
                    break

        if hold_bars > 0 and offset >= hold_bars:
            realized += leg_pct(close, 1.0 if not tp1_taken else 1.0 - tp1_frac)
            reason = "HOLD_WINDOW_EXIT"
            break

        if held_minutes >= policy["hard_minutes"]:
            realized += leg_pct(close, 1.0 if not tp1_taken else 1.0 - tp1_frac)
            reason = "MOMENTUM_TIME_STOP_EXIT"
            break

    if reason is None:
        close = float(bars[-1]["close"])
        realized += leg_pct(close, 1.0 if not tp1_taken else 1.0 - tp1_frac)
        reason = "DATA_END"

    fees_pct = 2.0 * FEE_PCT_PER_SIDE
    net_pct = realized - fees_pct
    return {
        "direction": direction,
        "entry_index": entry_index,
        "exit_index": exit_index,
        "entry_price": round(entry_price, 8),
        "hold_minutes": (exit_index - entry_index) * minutes_per_bar,
        "gross_pct": round(realized, 4),
        "net_pct": round(net_pct, 4),
        "reason": reason,
        "tp1_taken": tp1_taken,
    }


def simulate(
    bars: List[Dict[str, Any]],
    policy: Dict[str, float],
    interval: str = "15m",
    symbol: str = "",
) -> Dict[str, Any]:
    minutes = INTERVAL_MINUTES.get(str(interval).lower(), 15)
    trades: List[Dict[str, Any]] = []
    index = LOOKBACK + RSI_PERIOD
    while index < len(bars) - 1:
        signal = signal_at(bars, index, policy)
        if signal is None:
            index += 1
            continue
        trade = simulate_trade(bars, index + 1, signal["direction"], policy, minutes)
        if trade is None:
            index += 1
            continue
        trade["symbol"] = symbol
        trade["signal"] = signal
        trades.append(trade)
        index = max(trade["exit_index"], index + 1) + 1
    return aggregate(trades, symbol=symbol, interval=interval)


def aggregate(trades: List[Dict[str, Any]], symbol: str = "", interval: str = "15m") -> Dict[str, Any]:
    sample = len(trades)
    wins = [t["net_pct"] for t in trades if t["net_pct"] > 0]
    losses = [t["net_pct"] for t in trades if t["net_pct"] < 0]
    gross_win = sum(wins)
    gross_loss = abs(sum(losses))
    by_reason: Dict[str, int] = {}
    for trade in trades:
        by_reason[trade["reason"]] = by_reason.get(trade["reason"], 0) + 1
    holds = [t["hold_minutes"] for t in trades] or [0]
    return {
        "symbol": symbol,
        "interval": interval,
        "trades": sample,
        "win_rate_pct": round(len(wins) / sample * 100.0, 2) if sample else 0.0,
        "net_pct_sum": round(sum(t["net_pct"] for t in trades), 4),
        "avg_net_pct": round(sum(t["net_pct"] for t in trades) / sample, 4) if sample else 0.0,
        "profit_factor": round(gross_win / gross_loss, 3) if gross_loss > 0 else (None if not wins else float("inf")),
        "avg_win_pct": round(sum(wins) / len(wins), 4) if wins else 0.0,
        "avg_loss_pct": round(sum(losses) / len(losses), 4) if losses else 0.0,
        "median_hold_minutes": round(statistics.median(holds), 1),
        "by_reason": dict(sorted(by_reason.items(), key=lambda kv: -kv[1])),
        "fee_pct_round_trip": round(2.0 * FEE_PCT_PER_SIDE, 4),
        "trades_detail": trades,
    }


def fetch_bars(symbol: str, interval: str, limit: int, market: str) -> List[Dict[str, Any]]:
    from exchange_client import create_exchange_client

    client = create_exchange_client()
    bars = client.get_klines(symbol, interval=interval, limit=limit, market=market)
    return [b for b in bars if b.get("is_closed", True)]


def _summary_row(name: str, report: Dict[str, Any]) -> str:
    pf = report["profit_factor"]
    pf_text = "inf" if pf == float("inf") else ("n/a" if pf is None else f"{pf:.2f}")
    return (
        f"{name:<10} trades={report['trades']:<3} WR={report['win_rate_pct']:>5.1f}% "
        f"PF={pf_text:>5} net={report['net_pct_sum']:>8.2f}% avg={report['avg_net_pct']:>6.3f}% "
        f"hold_med={report['median_hold_minutes']:>6.1f}m reasons={report['by_reason']}"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Replay the exit policy over closed candles before risking paper trades.")
    parser.add_argument("--symbol", default="BTCUSDT")
    parser.add_argument("--interval", default="15m")
    parser.add_argument("--limit", type=int, default=300)
    parser.add_argument("--market", default="FUTURES", choices=["SPOT", "FUTURES"])
    parser.add_argument("--policy", default="scalp", choices=sorted(POLICIES))
    parser.add_argument("--compare", action="store_true", help="Run every policy over the same bars.")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    bars = fetch_bars(args.symbol, args.interval, args.limit, args.market)
    if len(bars) < LOOKBACK + RSI_PERIOD + 5:
        print(json.dumps({"error": "not enough closed candles", "got": len(bars)}))
        return 1

    names = sorted(POLICIES) if args.compare else [args.policy]
    reports = {}
    for name in names:
        reports[name] = simulate(bars, POLICIES[name], interval=args.interval, symbol=args.symbol)

    if args.json:
        print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "trades_detail"} for k, v in reports.items()}, indent=2))
        return 0

    print(f"{args.symbol} {args.interval} {args.market} closed_candles={len(bars)} fee_round_trip={2 * FEE_PCT_PER_SIDE:.2f}%")
    for name in names:
        print(_summary_row(name, reports[name]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
