from typing import Any, Dict, Optional

import config

SPOT = "SPOT"
FUTURES = "FUTURES"


def _num(value: Any, fallback: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return fallback
    if number != number or number in (float("inf"), float("-inf")):
        return fallback
    return number


class MarketRouter:
    name = "MarketRouter"

    def _stop_pct(self, atr_pct: float) -> float:
        multiplier = _num(getattr(config, "ADAPTIVE_ATR_MULTIPLIER", 1.5), 1.5)
        raw = _num(atr_pct) * multiplier
        floor = _num(getattr(config, "ROUTER_STOP_FLOOR_PCT", 1.0), 1.0)
        cap = _num(getattr(config, "ROUTER_STOP_CAP_PCT", 3.5), 3.5)
        if raw <= 0:
            raw = floor
        return max(floor, min(cap, raw))

    def _leverage(self, stop_pct: float) -> Dict[str, float]:
        ceiling = max(1.0, _num(getattr(config, "FUTURES_AUTO_LEVERAGE_MAX", 3.0), 3.0))
        buffer_mult = max(1.0, _num(getattr(config, "FUTURES_LIQUIDATION_BUFFER_MULT", 3.0), 3.0))
        safe_cap = 100.0 / max(0.01, buffer_mult * stop_pct)
        leverage = max(1.0, min(ceiling, safe_cap))
        leverage = round(min(leverage, ceiling), 2)
        return {
            "leverage": leverage,
            "liquidation_distance_pct": round(100.0 / leverage, 2),
            "required_buffer_pct": round(stop_pct * buffer_mult, 2),
        }

    def choose(
        self,
        symbol: str,
        direction: str,
        price: float = 0.0,
        atr_pct: float = 0.0,
        quote_volume_24h: float = 0.0,
        spot_available: bool = True,
        futures_available: bool = True,
        funding_rate: Optional[float] = None,
        equity: float = 0.0,
        free_cash: float = 0.0,
        spot_enabled: Optional[bool] = None,
        futures_enabled: Optional[bool] = None,
    ) -> Dict[str, Any]:
        direction = str(direction or "LONG").upper()
        spot_ok = bool(getattr(config, "ENABLE_SPOT_LONGS", True)) if spot_enabled is None else bool(spot_enabled)
        futures_ok = (
            bool(getattr(config, "ENABLE_FUTURES_SHORTS", True)) if futures_enabled is None else bool(futures_enabled)
        )
        spot_ok = spot_ok and bool(spot_available)
        futures_ok = futures_ok and bool(futures_available)

        stop_pct = self._stop_pct(atr_pct)
        tp1_r = _num(getattr(config, "TP1_R_MULTIPLE", 1.5), 1.5)
        expected_move_pct = round(stop_pct * tp1_r, 4)
        hold_periods = _num(getattr(config, "FUNDING_HOLD_PERIODS", 3), 3.0)
        rate = _num(funding_rate, 0.0)
        funding_pct = round(rate * 100.0 * hold_periods, 4)
        spot_fee_pct = round(_num(getattr(config, "EFFECTIVE_FEE_PCT", 0.075), 0.075) * 2.0, 4)
        futures_fee_pct = round(_num(getattr(config, "FUTURES_FEE_PCT", 0.05), 0.05) * 2.0, 4)

        funding_cost_spot = 0.0
        funding_cost_futures = funding_pct if direction == "LONG" else -funding_pct
        net_spot_pct = round(expected_move_pct - spot_fee_pct - funding_cost_spot, 4)
        net_futures_pct = round(expected_move_pct - futures_fee_pct - funding_cost_futures, 4)
        liquidation_risk_pct = _num(getattr(config, "FUTURES_LIQUIDATION_RISK_PCT", 0.05), 0.05)
        net_futures_adjusted_pct = round(net_futures_pct - liquidation_risk_pct, 4)

        lev = self._leverage(stop_pct)
        risk_pct = _num(getattr(config, "RISK_PER_TRADE_PCT", 1.0), 1.0)
        size_cap_pct = _num(getattr(config, "MAX_POSITION_SIZE_PCT", 25.0), 25.0)
        desired_notional = _num(equity) * (risk_pct / 100.0) * (100.0 / stop_pct)
        if _num(equity) > 0:
            desired_notional = min(desired_notional, _num(equity) * (size_cap_pct / 100.0))
        cash = max(0.0, _num(free_cash))
        cash_gap = round(max(0.0, desired_notional - cash), 2)
        capital_freed = round(cash_gap - (cash_gap / lev["leverage"]), 2) if cash_gap > 0 else 0.0

        result: Dict[str, Any] = {
            "symbol": symbol,
            "direction": direction,
            "approved": True,
            "market": SPOT,
            "reason": "",
            "leverage": 1.0,
            "stop_pct": round(stop_pct, 4),
            "expected_move_pct": expected_move_pct,
            "funding_rate": round(rate, 8),
            "funding_pct": funding_pct,
            "spot_fee_pct": spot_fee_pct,
            "futures_fee_pct": futures_fee_pct,
            "net_edge_spot_pct": net_spot_pct,
            "net_edge_futures_pct": net_futures_pct,
            "net_edge_futures_adjusted_pct": net_futures_adjusted_pct,
            "liquidation_distance_pct": 100.0,
            "capital_freed_usdt": 0.0,
            "quote_volume_24h": round(_num(quote_volume_24h), 2),
        }

        if direction == "SHORT":
            if not futures_ok:
                result.update(
                    approved=False,
                    market=None,
                    reason="Short requires FUTURES but futures is unavailable or disabled for this symbol",
                )
                return result
            result.update(
                market=FUTURES,
                leverage=lev["leverage"],
                liquidation_distance_pct=lev["liquidation_distance_pct"],
                capital_freed_usdt=capital_freed,
                reason=(
                    f"Short routed to FUTURES (spot cannot short); funding "
                    f"{'credit' if funding_pct > 0 else 'cost'} {abs(funding_pct):.3f}%, "
                    f"net edge {net_futures_pct:.2f}%"
                ),
            )
            return result

        if not spot_ok and not futures_ok:
            result.update(approved=False, market=None, reason="Neither SPOT nor FUTURES is available for this symbol")
            return result

        if spot_ok and not futures_ok:
            result.update(
                market=SPOT,
                reason=f"SPOT only venue available; net edge {net_spot_pct:.2f}%",
            )
            return result

        if futures_ok and not spot_ok:
            result.update(
                market=FUTURES,
                leverage=lev["leverage"],
                liquidation_distance_pct=lev["liquidation_distance_pct"],
                capital_freed_usdt=capital_freed,
                reason=f"FUTURES only venue available; net edge {net_futures_pct:.2f}%",
            )
            return result

        switch_margin = _num(getattr(config, "AUTO_MARKET_SWITCH_MARGIN_PCT", 0.02), 0.02)
        funding_credit_floor = -abs(_num(getattr(config, "FUNDING_CREDIT_EDGE_PCT", 0.005), 0.005))
        margin_mode = bool(getattr(config, "FUTURES_MARGIN_ENABLED", False))
        margin_advantage = margin_mode and capital_freed > 0

        if margin_advantage:
            result.update(
                market=FUTURES,
                leverage=lev["leverage"],
                liquidation_distance_pct=lev["liquidation_distance_pct"],
                capital_freed_usdt=capital_freed,
                reason=(
                    f"FUTURES frees ${capital_freed:.2f} of margin at {lev['leverage']:.2f}x "
                    f"(liquidation {lev['liquidation_distance_pct']:.1f}% vs stop {stop_pct:.2f}%)"
                ),
            )
            return result

        if funding_pct <= funding_credit_floor and net_futures_pct > net_spot_pct:
            result.update(
                market=FUTURES,
                leverage=lev["leverage"],
                liquidation_distance_pct=lev["liquidation_distance_pct"],
                capital_freed_usdt=capital_freed,
                reason=(
                    f"FUTURES pays a funding credit {abs(funding_pct):.3f}% to longs; "
                    f"net edge {net_futures_pct:.2f}% vs spot {net_spot_pct:.2f}%"
                ),
            )
            return result

        if net_futures_adjusted_pct > net_spot_pct + switch_margin:
            result.update(
                market=FUTURES,
                leverage=lev["leverage"],
                liquidation_distance_pct=lev["liquidation_distance_pct"],
                capital_freed_usdt=capital_freed,
                reason=(
                    f"FUTURES net edge {net_futures_pct:.2f}% beats spot {net_spot_pct:.2f}% "
                    f"by more than {switch_margin:.2f}%"
                ),
            )
            return result

        result.update(
            market=SPOT,
            reason=(
                f"SPOT has the better risk-adjusted edge ({net_spot_pct:.2f}% vs futures "
                f"{net_futures_pct:.2f}%); no funding, no liquidation"
            ),
        )
        return result


_ROUTER = MarketRouter()


def choose_market(**kwargs: Any) -> Dict[str, Any]:
    return _ROUTER.choose(**kwargs)
