import math
from typing import Dict, Any, List, Optional
import config
from config import (
    RISK_PER_TRADE_PCT,
    MIN_RISK_REWARD_RATIO,
    HARD_STOP_LOSS_DEFAULT_PCT,
    TARGET_TAKE_PROFIT_PCT,
    TRAILING_STOP_TRIGGER_PCT,
    TRAILING_STOP_DISTANCE_PCT
)


def price_decimals(price: float) -> int:
    if price is None:
        return 6
    try:
        value = float(price)
    except (TypeError, ValueError):
        return 6
    if value <= 0:
        return 6
    sig = int(getattr(config, "PRICE_SIG_DIGITS", 8))
    magnitude = math.floor(math.log10(value))
    return max(6, min(14, sig - magnitude - 1))


def round_price(price: float) -> float:
    if price is None:
        return 0.0
    try:
        value = float(price)
    except (TypeError, ValueError):
        return 0.0
    return round(value, price_decimals(value))



class RiskManagementAgent:
    """
    Risk & Capital Management Agent (The Veto Agent):
    Mandate: Guarantee capital preservation and positive expectancy.
    Calculates volatility-based stop loss, asymmetric risk-to-reward targets,
    and strict position sizing.
    """

    def __init__(self):
        self.name = "RiskManagementAgent"

    def evaluate_risk(
        self,
        symbol: str,
        current_price: float,
        atr: float,
        total_equity: float,
        open_positions: List[Dict[str, Any]],
        direction: str = "LONG",
        target_market: str = "SPOT",
        leverage: float = 1.0,
        risk_scale: float = 1.0,
        analysis_stop: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if config.MAX_OPEN_POSITIONS > 0 and len(open_positions) >= config.MAX_OPEN_POSITIONS:
            return {
                "approved": False,
                "reason": f"Maximum open positions limit ({config.MAX_OPEN_POSITIONS}) reached."
            }

        for pos in open_positions:
            if pos.get("symbol") == symbol:
                return {
                    "approved": False,
                    "reason": f"Active position for {symbol} already exists."
                }

        if atr and atr > 0:
            sl_distance = config.ADAPTIVE_ATR_MULTIPLIER * atr
            sl_pct = (sl_distance / current_price) * 100.0
        else:
            sl_pct = HARD_STOP_LOSS_DEFAULT_PCT
            sl_distance = current_price * (sl_pct / 100.0)

        if sl_pct > 3.5:
            sl_pct = 3.5
            sl_distance = current_price * 0.035
        elif sl_pct < 1.0:
            sl_pct = 1.0
            sl_distance = current_price * 0.01

        # Entry stop is an analysis decision: use the closed 5m swing level
        # (LONG below swing low, SHORT above swing high) plus its ATR buffer.
        # ATR-only remains the fallback when structure is unavailable.
        stop_source = "ATR_VOLATILITY"
        initial_stop_analysis: Dict[str, Any] = {}
        if analysis_stop and getattr(config, "POSITION_ANALYSIS_INITIAL_STOP_ENABLED", True):
            try:
                candidate = float(analysis_stop.get("stop_loss_price") or 0.0)
                candidate_pct = (
                    abs(candidate - current_price) / current_price * 100.0
                    if current_price > 0
                    else 0.0
                )
                side_ok = (
                    candidate > current_price
                    if direction == "SHORT"
                    else candidate < current_price
                )
                min_pct = max(
                    0.0,
                    float(getattr(config, "POSITION_ANALYSIS_INITIAL_STOP_MIN_PCT", 1.0)),
                )
                max_pct = max(
                    min_pct,
                    float(getattr(config, "POSITION_ANALYSIS_INITIAL_STOP_MAX_PCT", 3.5)),
                )
                if candidate > 0 and side_ok and min_pct <= candidate_pct <= max_pct:
                    sl_distance = abs(current_price - candidate)
                    sl_pct = candidate_pct
                    stop_source = str(analysis_stop.get("source") or "ANALYSIS_STRUCTURE")
                    initial_stop_analysis = dict(analysis_stop)
            except (TypeError, ValueError, ZeroDivisionError):
                pass

        # Apply the hard portfolio cap before building TP1/TP2, otherwise the
        # bracket would be calculated from a stop that is no longer placed.
        max_sl = (
            float(getattr(config, "MAX_STOP_LOSS_PCT", 3.5) or 0.0)
            if getattr(config, "MAX_STOP_LOSS_CAP_ENABLED", False)
            else 0.0
        )
        if max_sl > 0 and sl_pct > max_sl:
            sl_pct = max_sl
            sl_distance = current_price * (max_sl / 100.0)
            if initial_stop_analysis:
                stop_source = f"{stop_source}_RISK_CAP"

        fee_pct_one_way = (
            float(getattr(config, "FUTURES_FEE_PCT", config.EFFECTIVE_FEE_PCT))
            if str(target_market).upper() == "FUTURES"
            else config.EFFECTIVE_FEE_PCT
        )
        roundtrip_fee_pct = fee_pct_one_way * 2.0
        fee_cost_abs = current_price * (roundtrip_fee_pct / 100.0)

        if direction == "SHORT":
            sl_price = current_price + sl_distance
            tp1_price = current_price - (config.TP1_R_MULTIPLE * sl_distance)
            tp2_price = current_price - (config.TP2_R_MULTIPLE * sl_distance)
        else:
            sl_price = current_price - sl_distance
            tp1_price = current_price + (config.TP1_R_MULTIPLE * sl_distance)
            tp2_price = current_price + (config.TP2_R_MULTIPLE * sl_distance)

        sl_price = round_price(sl_price)
        tp1_price = round_price(tp1_price)
        tp2_price = round_price(tp2_price)

        gap_floor = current_price * (float(getattr(config, "MIN_TARGET_GAP_PCT", 0.05)) / 100.0)
        if direction == "SHORT":
            ordered = sl_price > current_price > tp1_price > tp2_price
        else:
            ordered = sl_price < current_price < tp1_price < tp2_price
        gaps = (
            abs(current_price - tp1_price),
            abs(tp1_price - tp2_price),
            abs(sl_price - current_price),
        )
        if not ordered or any(gap < gap_floor for gap in gaps):
            return {
                "approved": False,
                "reason": (
                    f"Degenerate bracket for {symbol}: entry={current_price} "
                    f"SL={sl_price} TP1={tp1_price} TP2={tp2_price} min_gap={gap_floor}"
                ),
            }

        if direction == "SHORT":
            net_reward = (current_price - tp2_price) - fee_cost_abs
        else:
            net_reward = (tp2_price - current_price) - fee_cost_abs
        net_risk = abs(sl_price - current_price) + fee_cost_abs

        actual_rr_ratio = net_reward / net_risk if net_risk > 0 else 0.0

        tp1_move_pct = (abs(current_price - tp1_price) / current_price) * 100.0 if current_price > 0 else 0.0
        tp1_net_pct = tp1_move_pct - roundtrip_fee_pct
        fee_floor = fee_pct_one_way * float(getattr(config, "MIN_TP1_NET_FEE_MULT", 1.0))
        if tp1_net_pct < fee_floor:
            return {
                "approved": False,
                "reason": (
                    f"TP1 net of fees {tp1_net_pct:.3f}% below floor {fee_floor:.3f}% "
                    f"(gross {tp1_move_pct:.3f}%, roundtrip fee {roundtrip_fee_pct:.3f}%)"
                ),
            }


        if actual_rr_ratio < MIN_RISK_REWARD_RATIO:
            return {
                "approved": False,
                "reason": f"Net fee-adjusted Risk-Reward ratio {actual_rr_ratio:.2f} below minimum {MIN_RISK_REWARD_RATIO}"
            }

        # risk_scale < 1 for counter-regime trades (selective shorts in a
        # bullish BTC regime): same stop logic, half the capital at risk.
        risk_scale = max(0.1, min(1.0, float(risk_scale or 1.0)))
        risk_dollar_amount = total_equity * (RISK_PER_TRADE_PCT / 100.0) * risk_scale
        
        if direction == "SHORT":
            tokens_qty = risk_dollar_amount / (sl_price - current_price) if (sl_price > current_price) else 0.0
        else:
            tokens_qty = risk_dollar_amount / (current_price - sl_price) if (current_price > sl_price) else 0.0

        position_cost_usdt = tokens_qty * current_price

        # The size cap scales too, otherwise the 25% cap (not the risk budget)
        # binds on tight-stop assets and risk_scale would have no effect.
        max_allowable_cost = total_equity * (config.MAX_POSITION_SIZE_PCT / 100.0) * risk_scale
        if position_cost_usdt > max_allowable_cost:
            position_cost_usdt = max_allowable_cost
            tokens_qty = position_cost_usdt / current_price if current_price > 0 else 0.0

        if position_cost_usdt < 10.0:
            return {
                "approved": False,
                "reason": f"Calculated position size (${position_cost_usdt:.2f}) below minimum trade threshold ($10)"
            }

        if getattr(config, "USE_DYNAMIC_ATR_TRAILING", True) and atr and current_price > 0:
            atr_pct_val = (atr / current_price) * 100.0
            mult = getattr(config, "TRAILING_ATR_MULTIPLIER", 2.5)
            dist_floor = getattr(config, "TRAILING_MIN_DIST_PCT", 1.2)
            dist_cap = getattr(config, "TRAILING_MAX_DIST_PCT", 6.0)
            dyn_trailing_dist = max(dist_floor, min(dist_cap, round(atr_pct_val * mult, 2)))
            # Trailing arms exactly when TP1 banks: trigger equals the TP1 gain
            # (R-based). The runner half starts trailing right after the first
            # partial instead of an unrelated flat percentage.
            dyn_trigger = max(1.0, min(6.0, round(sl_pct * config.TP1_R_MULTIPLE, 2)))
        else:
            dyn_trailing_dist = TRAILING_STOP_DISTANCE_PCT
            dyn_trigger = TRAILING_STOP_TRIGGER_PCT

        return {
            "approved": True,
            "symbol": symbol,
            "direction": direction,
            "target_market": target_market,
            "side": "SELL" if direction == "SHORT" else "BUY",
            "entry_price": current_price,
            "atr": round(atr, 8) if atr else 0.0,
            "atr_pct": round((atr / current_price * 100.0), 4) if atr and current_price > 0 else 0.0,
            "stop_loss_price": round_price(sl_price),
            "stop_loss_pct": round(sl_pct, 2),
            "stop_source": stop_source,
            "initial_stop_analysis": initial_stop_analysis,
            "take_profit_1": round_price(tp1_price),
            "take_profit_2": round_price(tp2_price),
            "risk_reward_ratio": round(actual_rr_ratio, 2),
            "position_usdt": round(position_cost_usdt, 2),
            "quantity": round(tokens_qty, 6),
            "leverage": round(max(1.0, float(leverage or 1.0)), 2),
            "margin_usdt": round(position_cost_usdt / max(1.0, float(leverage or 1.0)), 2),
            "trailing_trigger_pct": dyn_trigger,
            "trailing_distance_pct": dyn_trailing_dist,
            "risk_scale": risk_scale
        }
