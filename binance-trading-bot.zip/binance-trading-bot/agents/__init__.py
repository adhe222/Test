# AI Agents Package for Crypto Momentum Trading
