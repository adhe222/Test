import json
import os
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", "data"))
HISTORY_PATH = DATA_DIR / "trade_history.json"
PORTFOLIO_PATH = DATA_DIR / "portfolio.json"
MIN_SAMPLE = 5


def _load(path: Path, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def _num(value: Any) -> Optional[float]:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number:
        return None
    return number


def _parse(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _bucket_rsi(value: Optional[float]) -> str:
    if value is None:
        return "na"
    if value < 30:
        return "<30"
    if value < 40:
        return "30-40"
    if value < 50:
        return "40-50"
    if value < 60:
        return "50-60"
    if value < 70:
        return "60-70"
    return ">=70"


def _bucket_trend(value: Optional[float]) -> str:
    if value is None:
        return "na"
    if value < 0.1:
        return "<0.1"
    if value < 0.3:
        return "0.1-0.3"
    if value < 0.5:
        return "0.3-0.5"
    return ">=0.5"


def _bucket_atr(value: Optional[float]) -> str:
    if value is None:
        return "na"
    if value < 0.5:
        return "<0.5"
    if value < 1.0:
        return "0.5-1"
    if value < 2.0:
        return "1-2"
    if value < 3.5:
        return "2-3.5"
    return ">=3.5"


def _bucket_volume(value: Optional[float]) -> str:
    if value is None:
        return "na"
    if value < 1.0:
        return "<1"
    if value < 1.3:
        return "1-1.3"
    if value < 2.0:
        return "1.3-2"
    return ">=2"


class PlaybookLibrary:
    def __init__(
        self,
        history_path: Optional[Path] = None,
        portfolio_path: Optional[Path] = None,
        min_sample: Optional[int] = None,
    ):
        self.history_path = Path(history_path or HISTORY_PATH)
        self.portfolio_path = Path(portfolio_path or PORTFOLIO_PATH)
        self.min_sample = int(min_sample if min_sample is not None else MIN_SAMPLE)

    def fingerprint(self, metrics: Optional[Dict[str, Any]], direction: str) -> str:
        metrics = metrics if isinstance(metrics, dict) else {}
        parts = [
            str(direction or "NA").upper(),
            f"rsi:{_bucket_rsi(_num(metrics.get('rsi')))}",
            f"trend:{_bucket_trend(_num(metrics.get('trend_efficiency')))}",
            f"atr:{_bucket_atr(_num(metrics.get('atr_pct')))}",
            f"vol:{_bucket_volume(_num(metrics.get('volume_surge')))}",
        ]
        return "|".join(parts)

    @staticmethod
    def _stats(events: List[Dict[str, Any]]) -> Dict[str, Any]:
        pnls = [_num(e.get("pnl_usdt")) or 0.0 for e in events]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        net = sum(pnls)
        gross_win = sum(wins)
        gross_loss = abs(sum(losses))
        return {
            "trades": len(events),
            "wins": len(wins),
            "losses": len(losses),
            "net_usdt": round(net, 4),
            "avg_usdt": round(net / len(events), 4) if events else 0.0,
            "win_rate_pct": round(len(wins) / len(events) * 100.0, 2) if events else 0.0,
            "profit_factor": round(gross_win / gross_loss, 3) if gross_loss > 0 else None,
        }

    def _scoped(self) -> List[Dict[str, Any]]:
        portfolio = _load(self.portfolio_path, {}) or {}
        since = _parse(portfolio.get("counter_since"))
        history = _load(self.history_path, []) or []
        events = [e for e in history if isinstance(e, dict) and str(e.get("action", "")).upper() == "CLOSED"]
        if since is None:
            return events
        kept = []
        for event in events:
            stamp = _parse(event.get("exit_time") or event.get("entry_time"))
            if stamp is None or stamp >= since:
                kept.append(event)
        return kept

    def build(self) -> Dict[str, Any]:
        events = self._scoped()
        groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for event in events:
            direction = str(event.get("direction") or "NA").upper()
            groups[self.fingerprint(event.get("entry_metrics"), direction)].append(event)

        playbooks = []
        for key, group in groups.items():
            stats = self._stats(group)
            stats["fingerprint"] = key
            stats["symbols"] = sorted({str(e.get("symbol")) for e in group})
            stats["sample_ok"] = stats["trades"] >= self.min_sample
            playbooks.append(stats)
        playbooks.sort(key=lambda row: (-row["net_usdt"], -row["trades"]))

        by_direction = []
        for direction in ("LONG", "SHORT"):
            group = [e for e in events if str(e.get("direction") or "").upper() == direction]
            if group:
                stats = self._stats(group)
                stats["direction"] = direction
                by_direction.append(stats)

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "min_sample": self.min_sample,
            "closed_trades": len(events),
            "playbooks": playbooks,
            "by_direction": by_direction,
            "advisory_only": True,
            "note": "Playbooks are descriptive statistics of past trades, not entry permissions. No gate reads this data.",
        }

    def lookup(self, metrics: Optional[Dict[str, Any]], direction: str) -> Dict[str, Any]:
        key = self.fingerprint(metrics, direction)
        report = self.build()
        for playbook in report["playbooks"]:
            if playbook["fingerprint"] == key:
                return {"match": "exact", "fingerprint": key, "stats": playbook, "sample_ok": playbook["sample_ok"]}
        for row in report["by_direction"]:
            if row["direction"] == str(direction or "").upper():
                return {
                    "match": "direction",
                    "fingerprint": key,
                    "stats": row,
                    "sample_ok": row["trades"] >= self.min_sample,
                }
        return {"match": "none", "fingerprint": key, "stats": None, "sample_ok": False}
