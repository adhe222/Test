(function () {
  'use strict';

  const U = window.AegisUtil;
  const REFRESH_MS = 15000;
  const CONFIRM_MS = 6000;

  const state = {
    timer: 0,
    busy: false,
    loaded: false,
    confirmId: '',
    confirmUntil: 0,
    confirmTimer: 0
  };

  const getJSON = (url) => fetch(url, { headers: { Accept: 'application/json' } })
    .then((res) => res.json().catch(() => ({}))
      .then((body) => ({ ok: res.ok, status: res.status, body: body && typeof body === 'object' ? body : {} })));

  const text = (value, fallback) => {
    const out = String(value === null || value === undefined ? '' : value).trim();
    return out || (fallback === undefined ? '—' : fallback);
  };

  const human = (key) => U.title(String(key || '').replace(/\|/g, ' · '));

  const verdictClass = (verdict) => {
    const code = String(verdict || '').toUpperCase();
    if (code === 'POSITIVE_EDGE') return 'live';
    if (code === 'FEE_BREAK_EVEN') return 'paper';
    if (code === 'NEGATIVE_EDGE') return 'blocked';
    return 'off';
  };

  const verdictLabel = (verdict) => {
    const code = String(verdict || '').toUpperCase();
    if (code === 'POSITIVE_EDGE') return 'Edge positif';
    if (code === 'FEE_BREAK_EVEN') return 'Impas biaya';
    if (code === 'NEGATIVE_EDGE') return 'Edge negatif';
    if (code === 'SAMPLE_TOO_SMALL') return 'Sampel kecil';
    return human(verdict);
  };

  const factRow = (label, value, tone) => `<div class="fact"><span>${U.esc(label)}</span>`
    + `<strong class="${tone || ''}">${value}</strong></div>`;

  const reasonRow = (row) => {
    const net = U.safe(row && row.net_usdt);
    return `<tr>`
      + `<td>${U.esc(human(row && row.key))}</td>`
      + `<td class="num mono">${U.safe(row && row.trades)}</td>`
      + `<td class="num mono ${U.cls(net)}">${U.signed(net)}</td>`
      + `<td class="num mono">${U.pct(row && row.win_rate_pct)}</td>`
      + `<td class="num mono">${U.money(row && row.fees_usdt)}</td>`
      + `</tr>`;
  };

  const playbookRow = (row) => {
    const net = U.safe(row && row.net_usdt);
    const pf = row && row.profit_factor;
    const sample = row && row.sample_ok
      ? ''
      : '<span class="small-sample">sampel kecil</span>';
    return `<tr>`
      + `<td class="fingerprint">${U.esc(text(row && row.fingerprint))}${sample}</td>`
      + `<td class="num mono">${U.safe(row && row.trades)}</td>`
      + `<td class="num mono ${U.cls(net)}">${U.signed(net)}</td>`
      + `<td class="num mono">${pf === null || pf === undefined ? '—' : U.safe(pf).toFixed(2)}</td>`
      + `<td class="num mono">${U.pct(row && row.win_rate_pct, 0)}</td>`
      + `</tr>`;
  };

  const renderReview = (payload, ok) => {
    const pill = document.getElementById('auditVerdict');
    const facts = document.getElementById('auditFacts');
    const flags = document.getElementById('auditFlags');
    const meta = document.getElementById('auditCleanMeta');
    if (!facts || !flags) return;
    if (!ok) {
      if (pill) {
        pill.className = 'state-pill blocked';
        pill.textContent = 'Tidak tersedia';
      }
      facts.innerHTML = `<div class="fact"><span>Reviewer</span><strong>HTTP ${U.esc(payload && payload.status)}</strong></div>`;
      flags.innerHTML = '<div class="audit-empty">Reviewer belum bisa dihitung.</div>';
      if (meta) meta.textContent = '—';
      return;
    }
    const metrics = payload.metrics || {};
    const sample = payload.sample || {};
    if (pill) {
      pill.className = `state-pill ${verdictClass(payload.verdict)}`;
      pill.textContent = verdictLabel(payload.verdict);
    }
    facts.innerHTML = [
      factRow('Trade tertutup', U.safe(sample.closed_trades), 'mono'),
      factRow('Net', U.signed(metrics.net_usdt), `mono ${U.cls(metrics.net_usdt)}`),
      factRow('Gross', U.signed(metrics.gross_usdt), `mono ${U.cls(metrics.gross_usdt)}`),
      factRow('Biaya', U.money(metrics.fees_usdt), 'mono'),
      factRow('Win rate', U.pct(metrics.win_rate_pct), 'mono'),
      factRow('Profit factor', metrics.profit_factor === null || metrics.profit_factor === undefined ? '—' : U.safe(metrics.profit_factor).toFixed(2), 'mono'),
      factRow('Expectancy', U.signed(metrics.expectancy_usdt), `mono ${U.cls(metrics.expectancy_usdt)}`),
      factRow('Payoff', metrics.payoff_ratio === null || metrics.payoff_ratio === undefined ? '—' : U.safe(metrics.payoff_ratio).toFixed(2), 'mono')
    ].join('');

    const defects = payload.defects && typeof payload.defects === 'object' ? payload.defects : {};
    const entries = Object.keys(defects).filter((key) => U.safe(defects[key]) > 0);
    flags.innerHTML = entries.length
      ? entries.map((key) => `<span class="audit-flag ${key === 'DEGENERATE_TARGET' ? 'hot' : 'warm'}">`
        + `${U.esc(key.replace(/_/g, ' ').toLowerCase())}<b>${U.safe(defects[key])}</b></span>`).join('')
      : '<span class="audit-flag">tidak ada defect</span>';

    if (meta) {
      meta.textContent = `proses bersih ${U.pct(payload.process_clean_pct)}`;
    }

    const worst = payload.worst_reason || {};
    const clean = document.getElementById('auditWorst');
    if (clean) {
      clean.innerHTML = worst.key
        ? factRow('Kebocoran terbesar', `${U.esc(human(worst.key))} · ${U.signed(worst.net_usdt)}`,
          U.cls(worst.net_usdt))
        : factRow('Kebocoran terbesar', '—', 'mono');
    }
  };

  const renderReasons = (payload, ok) => {
    const body = document.getElementById('auditReasons');
    if (!body) return;
    if (!ok) {
      body.innerHTML = `<tr class="empty-row"><td colspan="5">HTTP ${U.esc(payload && payload.status)}</td></tr>`;
      return;
    }
    const rows = Array.isArray(payload.by_reason) ? payload.by_reason : [];
    body.innerHTML = rows.length
      ? rows.map(reasonRow).join('')
      : '<tr class="empty-row"><td colspan="5">Belum ada trade tertutup pada run ini.</td></tr>';
  };

  const renderPlaybooks = (payload, ok) => {
    const body = document.getElementById('auditPlaybooks');
    const meta = document.getElementById('auditPlaybookMeta');
    if (!body) return;
    if (!ok) {
      body.innerHTML = `<tr class="empty-row"><td colspan="5">HTTP ${U.esc(payload && payload.status)}</td></tr>`;
      if (meta) meta.textContent = '—';
      return;
    }
    const rows = (Array.isArray(payload.playbooks) ? payload.playbooks.slice() : [])
      .sort((a, b) => U.safe(b && b.net_usdt) - U.safe(a && a.net_usdt))
      .slice(0, 8);
    body.innerHTML = rows.length
      ? rows.map(playbookRow).join('')
      : '<tr class="empty-row"><td colspan="5">Belum ada fingerprint setup yang tercatat.</td></tr>';
    if (meta) {
      meta.textContent = `${U.safe(payload.closed_trades)} trade · min sampel ${U.safe(payload.min_sample)}`;
    }
  };

  const renderActions = (payload, ok) => {
    const list = document.getElementById('auditActions');
    if (!list) return;
    if (!ok) {
      list.innerHTML = `<li>Brief tidak tersedia (HTTP ${U.esc(payload && payload.status)}).</li>`;
      return;
    }
    const actions = Array.isArray(payload.actions) ? payload.actions : [];
    list.innerHTML = actions.length
      ? actions.map((item) => `<li>${U.esc(text(item))}</li>`).join('')
      : '<li>Tidak ada tindakan wajib: tidak ada angka yang melewati ambang.</li>';
  };

  const setStatus = (message, tone) => {
    const el = document.getElementById('auditApprovalStatus');
    if (!el) return;
    el.textContent = message || '';
    el.className = `audit-status ${tone || ''}`.trim();
  };

  const expireIn = (iso) => {
    const when = U.parseDate(iso);
    if (!when) return 'tanpa batas';
    const sec = Math.round((when.getTime() - Date.now()) / 1000);
    if (sec <= 0) return 'kedaluwarsa';
    if (sec < 60) return `${sec}s lagi`;
    return `${Math.floor(sec / 60)}m ${sec % 60}s lagi`;
  };

  const approvalCard = (ticket) => {
    const id = text(ticket && ticket.id, '');
    const confirm = state.confirmId === id && Date.now() < state.confirmUntil;
    const side = String((ticket && ticket.direction) || '').toUpperCase();
    const sideClass = side === 'LONG' ? 'long' : side === 'SHORT' ? 'short' : 'unknown';
    return `<div class="approval-row" data-id="${U.esc(id)}">`
      + `<div class="approval-head">`
      + `<span class="approval-symbol">${U.esc(text(ticket && ticket.symbol))}</span>`
      + `<span class="side-badge ${sideClass}">${U.esc(side || '—')}</span>`
      + `<span class="state-pill off">${U.esc(text(ticket && ticket.market, 'SPOT'))}</span>`
      + `<span class="approval-age">${U.esc(expireIn(ticket && ticket.expires_at))}</span>`
      + `</div>`
      + `<div class="approval-grid">`
      + factRow('Entry', U.price(ticket && ticket.entry_price), 'mono')
      + factRow('Stop', U.price(ticket && ticket.stop_loss_price), 'mono')
      + factRow('TP1', U.price(ticket && ticket.take_profit_1), 'mono')
      + factRow('TP2', U.price(ticket && ticket.take_profit_2), 'mono')
      + factRow('Notional', U.money(ticket && ticket.position_usdt), 'mono')
      + factRow('R:R', U.safe(ticket && ticket.risk_reward_ratio).toFixed(2), 'mono')
      + `</div>`
      + (text(ticket && ticket.rationale, '') === '—' ? ''
        : `<p class="approval-rationale">${U.esc(text(ticket && ticket.rationale))}</p>`)
      + `<div class="approval-actions">`
      + `<button class="btn primary" type="button" data-action="approve" data-id="${U.esc(id)}">`
      + `${confirm ? 'Konfirmasi setujui' : 'Setujui'}</button>`
      + `<button class="btn danger" type="button" data-action="reject" data-id="${U.esc(id)}">Tolak</button>`
      + `</div>`
      + `</div>`;
  };

  const renderApprovals = (payload, ok) => {
    const wrap = document.getElementById('auditApprovals');
    const meta = document.getElementById('auditApprovalMeta');
    const history = document.getElementById('auditHistory');
    if (!wrap) return;
    if (!ok) {
      wrap.innerHTML = `<div class="audit-empty">Antrean approval tidak tersedia (HTTP ${U.esc(payload && payload.status)}).</div>`;
      if (meta) meta.textContent = '—';
      if (history) history.innerHTML = '';
      return;
    }
    const pending = Array.isArray(payload.pending) ? payload.pending : [];
    wrap.innerHTML = pending.length
      ? pending.map(approvalCard).join('')
      : '<div class="audit-empty">Tidak ada tiket menunggu. Mode paper tidak membuat tiket; mode live akan menahan setiap entry di sini.</div>';
    if (meta) meta.textContent = `${pending.length} pending`;
    const rows = Array.isArray(payload.history) ? payload.history.slice(0, 6) : [];
    if (history) {
      history.innerHTML = rows.length
        ? rows.map((row) => `<div class="audit-history-row">`
          + `<span class="mono">${U.esc(text(row && row.id, '—'))}</span>`
          + `<span>${U.esc(text(row && row.symbol))} ${U.esc(text(row && row.direction))}</span>`
          + `<span class="mono">${U.esc(String(row && row.status || '').toLowerCase())}</span>`
          + `<span class="mono" style="margin-left:auto">${U.esc(text(row && row.decided_by, 'system'))}</span>`
          + `</div>`).join('')
        : '';
    }
  };

  const renderGenerated = (payload, ok) => {
    const el = document.getElementById('auditGenerated');
    if (!el) return;
    el.textContent = ok
      ? `diperbarui ${U.timeAgo(payload.generated_at)}`
      : 'telemetri audit tidak tersedia';
  };

  const refresh = () => {
    if (state.busy) return;
    state.busy = true;
    Promise.all([
      getJSON('/api/review'),
      getJSON('/api/brief'),
      getJSON('/api/approvals'),
      getJSON('/api/playbooks')
    ]).then(([review, brief, approvals, playbooks]) => {
      renderReview(review.body || {}, review.ok);
      renderReasons(review.body || {}, review.ok);
      renderActions(brief.body || {}, brief.ok);
      renderApprovals(approvals.body || {}, approvals.ok);
      renderPlaybooks(playbooks.body || {}, playbooks.ok);
      renderGenerated(brief.body || {}, brief.ok);
      state.loaded = true;
    }).catch(() => {
      setStatus('Gagal memuat data audit. Mencoba ulang otomatis.', 'bad');
    }).finally(() => {
      state.busy = false;
    });
  };

  const decide = (id, action, button) => {
    if (!id) return;
    if (action === 'approve' && !(state.confirmId === id && Date.now() < state.confirmUntil)) {
      state.confirmId = id;
      state.confirmUntil = Date.now() + CONFIRM_MS;
      if (button) button.textContent = 'Konfirmasi setujui';
      setStatus('Setujui ditekan sekali. Tekan sekali lagi dalam 6 detik untuk mengirim persetujuan.', '');
      clearTimeout(state.confirmTimer);
      state.confirmTimer = setTimeout(() => {
        state.confirmId = '';
        refresh();
      }, CONFIRM_MS + 200);
      return;
    }
    state.confirmId = '';
    const buttons = Array.from(document.querySelectorAll('.approval-actions .btn'));
    buttons.forEach((btn) => { btn.disabled = true; });
    if (button) button.textContent = action === 'approve' ? 'Mengirim…' : 'Menolak…';
    setStatus(action === 'approve' ? 'Mengirim persetujuan…' : 'Mengirim penolakan…', '');
    fetch(`/api/approvals/${encodeURIComponent(id)}/${action}`, {
      method: 'POST',
      headers: { Accept: 'application/json' }
    }).then((res) => res.json().catch(() => ({}))
      .then((body) => ({ ok: res.ok, status: res.status, body: body && typeof body === 'object' ? body : {} })))
      .then(({ ok, status, body }) => {
        if (status === 403) {
          setStatus('Ditolak server: butuh token. Buka dashboard dengan ?token=<APPROVAL_API_TOKEN> atau akses dari localhost.', 'bad');
          return;
        }
        if (!ok || body.ok === false) {
          setStatus(`Gagal: ${text(body.error || body.message, `HTTP ${status}`)}`, 'bad');
          return;
        }
        const ticket = body.ticket || {};
        if (action === 'approve') {
          const execution = body.execution || {};
          const done = execution && execution.executed;
          setStatus(done
            ? `Tiket ${text(ticket.id)} disetujui dan dieksekusi.`
            : `Tiket ${text(ticket.id)} disetujui. Eksekusi otomatis hanya berjalan pada mode live.`, 'ok');
        } else {
          setStatus(`Tiket ${text(ticket.id)} ditolak.`, 'ok');
        }
      })
      .catch(() => setStatus('Koneksi gagal saat mengirim keputusan.', 'bad'))
      .finally(() => {
        buttons.forEach((btn) => { btn.disabled = false; });
        refresh();
      });
  };

  const bind = () => {
    const wrap = document.getElementById('auditApprovals');
    if (wrap) {
      wrap.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;
        decide(button.dataset.id, button.dataset.action, button);
      });
    }
    const refreshBtn = document.getElementById('auditRefresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        refreshBtn.disabled = true;
        refresh();
        setTimeout(() => { refreshBtn.disabled = false; }, 800);
      });
    }
  };

  const activate = () => {
    if (!state.loaded) refresh();
    clearInterval(state.timer);
    state.timer = setInterval(() => {
      if (!document.hidden) refresh();
    }, REFRESH_MS);
  };

  const deactivate = () => {
    clearInterval(state.timer);
    state.timer = 0;
  };

  const init = () => {
    bind();
    if (location.hash === '#audit') activate();
  };

  window.AegisAudit = { activate, deactivate, refresh };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
