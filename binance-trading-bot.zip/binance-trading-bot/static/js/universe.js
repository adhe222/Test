(function () {
  'use strict';

  const canvas = document.getElementById('universe');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  const FRAME_MS = 1000 / 30;

  let width = 0;
  let height = 0;
  let layers = [];
  let nebula = [];
  let shooting = null;
  let nextShootAt = 0;
  let lastFrame = 0;
  let rafId = 0;
  let running = false;
  let theme = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';

  const palette = () => theme === 'light'
    ? { star: '15,45,80', accent: '14,116,144', nebulaA: '14,116,144', nebulaB: '15,118,110' }
    : { star: '190,225,255', accent: '34,211,238', nebulaA: '34,211,238', nebulaB: '45,212,191' };

  const rand = (min, max) => min + Math.random() * (max - min);

  const buildStars = (count, depth) => Array.from({ length: count }, () => ({
    x: Math.random(),
    y: Math.random(),
    r: rand(0.4, depth * 1.5),
    a: rand(0.18, 0.7) * depth,
    drift: rand(0.006, 0.024) * depth,
    phase: rand(0, Math.PI * 2)
  }));

  const buildNebula = () => [
    { x: 0.16, y: 0.18, r: 0.55, color: 'A', alpha: 0.1 },
    { x: 0.86, y: 0.72, r: 0.62, color: 'B', alpha: 0.08 }
  ];

  const resize = () => {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * DPR);
    canvas.height = Math.floor(height * DPR);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    layers = [buildStars(70, 0.55), buildStars(45, 0.85), buildStars(28, 1.25)];
    nebula = buildNebula();
    if (!running) draw(0);
  };

  const drawNebula = () => {
    const c = palette();
    nebula.forEach((n) => {
      const cx = n.x * width;
      const cy = n.y * height;
      const r = n.r * Math.max(width, height) * 0.6;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, `rgba(${n.color === 'A' ? c.nebulaA : c.nebulaB},${n.alpha})`);
      g.addColorStop(0.45, `rgba(${n.color === 'A' ? c.nebulaA : c.nebulaB},${n.alpha * 0.35})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, width, height);
    });
  };

  const drawStars = (t) => {
    const c = palette();
    layers.forEach((stars, index) => {
      const drift = t * 0.000004 * (index + 1);
      stars.forEach((s) => {
        const twinkle = 0.72 + 0.28 * Math.sin(t * 0.0011 + s.phase);
        const x = ((s.x + drift) % 1) * width;
        const y = s.y * height;
        ctx.beginPath();
        ctx.arc(x, y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${c.star},${(s.a * twinkle).toFixed(3)})`;
        ctx.fill();
        if (index === 2 && s.r > 1.1) {
          ctx.beginPath();
          ctx.arc(x, y, s.r * 3.4, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${c.accent},${(0.05 * twinkle).toFixed(3)})`;
          ctx.fill();
        }
      });
    });
  };

  const drawShooting = (t) => {
    if (reduceMotion) return;
    const c = palette();
    if (!shooting && t > nextShootAt) {
      shooting = {
        x: rand(0.1, 0.75) * width,
        y: rand(0.05, 0.35) * height,
        vx: rand(3.4, 5.6),
        vy: rand(1.5, 2.6),
        life: 0,
        max: rand(38, 62)
      };
      nextShootAt = t + rand(9000, 14000);
    }
    if (!shooting) return;
    shooting.life += 1;
    shooting.x += shooting.vx;
    shooting.y += shooting.vy;
    const fade = 1 - shooting.life / shooting.max;
    if (fade <= 0) {
      shooting = null;
      return;
    }
    const tail = 90;
    const g = ctx.createLinearGradient(shooting.x, shooting.y, shooting.x - tail, shooting.y - tail * 0.55);
    g.addColorStop(0, `rgba(${c.accent},${(0.55 * fade).toFixed(3)})`);
    g.addColorStop(1, `rgba(${c.accent},0)`);
    ctx.strokeStyle = g;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(shooting.x, shooting.y);
    ctx.lineTo(shooting.x - tail, shooting.y - tail * 0.55);
    ctx.stroke();
  };

  const draw = (t) => {
    ctx.clearRect(0, 0, width, height);
    drawNebula();
    drawStars(t);
    drawShooting(t);
  };

  const loop = (now) => {
    if (!running) return;
    rafId = requestAnimationFrame(loop);
    if (now - lastFrame < FRAME_MS) return;
    lastFrame = now;
    draw(now);
  };

  const start = () => {
    if (running) return;
    running = true;
    lastFrame = 0;
    nextShootAt = performance.now() + rand(4000, 8000);
    rafId = requestAnimationFrame(loop);
  };

  const stop = () => {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
  };

  const onVisibility = () => {
    if (document.hidden) stop();
    else if (!reduceMotion) start();
  };

  const setTheme = (next) => {
    theme = next === 'light' ? 'light' : 'dark';
    canvas.dataset.theme = theme;
    draw(performance.now());
  };

  let resizeTimer = 0;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      resize();
      draw(performance.now());
    }, 160);
  }, { passive: true });
  document.addEventListener('visibilitychange', onVisibility);

  resize();
  canvas.dataset.theme = theme;
  if (reduceMotion) {
    draw(performance.now());
  } else {
    start();
  }

  window.AegisUniverse = { setTheme, stop, start };
})();
