(function () {
  'use strict';

  const U = window.AegisUtil;
  const state = {
    candles: [],
    symbol: '',
    market: 'SPOT',
    interval: '15m',
    meta: {},
    hover: -1,
    dirty: true
  };

  const cssVar = (name, fallback) => {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  };

  const theme = () => ({
    up: cssVar('--teal', '#2dd4bf'),
    down: cssVar('--rose', '#fb7185'),
    cyan: cssVar('--cyan', '#22d3ee'),
    amber: cssVar('--amber', '#f5b544'),
    grid: cssVar('--hairline', 'rgba(120,180,235,.14)'),
    ink: cssVar('--ink', '#e8f0fb'),
    muted: cssVar('--muted', '#7e90a8'),
    inset: cssVar('--inset', '#060a13')
  });

  const setupCanvas = (canvas) => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, Math.floor(rect.width));
    const h = Math.max(1, Math.floor(rect.height));
    if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, w, h };
  };

  const ema = (values, period) => {
    const k = 2 / (period + 1);
    const out = [];
    let prev = values[0];
    values.forEach((v, i) => {
      if (i === 0) {
        out.push(v);
        return;
      }
      prev = v * k + prev * (1 - k);
      out.push(prev);
    });
    return out;
  };

  const fmtTime = (ts, interval) => {
    const d = new Date(ts);
    if (isNaN(d.getTime())) return '';
    const intraday = !/d$/.test(interval || '15m') || interval === '1d';
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  };

  const drawMarket = () => {
    const canvas = document.getElementById('marketChart');
    if (!canvas) return;
    const note = document.getElementById('chartNote');
    const { ctx, w, h } = setupCanvas(canvas);
    const C = theme();
    ctx.clearRect(0, 0, w, h);

    const candles = state.candles;
    if (!candles.length) {
      if (note) {
        note.classList.add('show');
        note.textContent = state.meta.error || 'Menunggu feed pasar. Pilih simbol untuk memuat candle.';
      }
      return;
    }
    if (note) note.classList.remove('show');

    const padTop = 16;
    const padBottom = 22;
    const padRight = 62;
    const padLeft = 8;
    const volH = Math.round((h - padTop - padBottom) * 0.2);
    const priceH = h - padTop - padBottom - volH - 10;

    const highs = candles.map((c) => c.h);
    const lows = candles.map((c) => c.l);
    let max = Math.max(...highs);
    let min = Math.min(...lows);
    const span = max - min || max * 0.01 || 1;
    max += span * 0.06;
    min -= span * 0.06;

    const plotW = w - padLeft - padRight;
    const step = plotW / candles.length;
    const bodyW = Math.max(2, Math.min(11, step * 0.62));
    const yOf = (price) => padTop + priceH - ((price - min) / (max - min)) * priceH;
    const xOf = (i) => padLeft + step * i + step / 2;

    ctx.strokeStyle = C.grid;
    ctx.lineWidth = 1;
    for (let g = 0; g <= 4; g += 1) {
      const y = Math.round(padTop + (priceH / 4) * g) + 0.5;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(w - padRight, y);
      ctx.stroke();
      const value = max - ((max - min) / 4) * g;
      ctx.fillStyle = C.muted;
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(U.price(value), w - padRight + 8, y + 3);
    }

    const volMax = Math.max(...candles.map((c) => c.v), 1);
    const volTop = padTop + priceH + 10;
    candles.forEach((c, i) => {
      const up = c.c >= c.o;
      const color = up ? C.up : C.down;
      const x = xOf(i);
      const vh = (c.v / volMax) * volH;
      ctx.globalAlpha = 0.32;
      ctx.fillStyle = color;
      ctx.fillRect(x - bodyW / 2, volTop + volH - vh, bodyW, vh);
      ctx.globalAlpha = 1;
    });

    const closes = candles.map((c) => c.c);
    const drawLine = (series, color, alpha, width) => {
      ctx.beginPath();
      series.forEach((v, i) => {
        const x = xOf(i);
        const y = yOf(v);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.strokeStyle = color;
      ctx.globalAlpha = alpha;
      ctx.lineWidth = width;
      ctx.stroke();
      ctx.globalAlpha = 1;
    };

    candles.forEach((c, i) => {
      const up = c.c >= c.o;
      const color = up ? C.up : C.down;
      const x = xOf(i);
      const yHigh = yOf(c.h);
      const yLow = yOf(c.l);
      const yOpen = yOf(c.o);
      const yClose = yOf(c.c);
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, yHigh);
      ctx.lineTo(Math.round(x) + 0.5, yLow);
      ctx.stroke();
      const top = Math.min(yOpen, yClose);
      const bh = Math.max(1.5, Math.abs(yClose - yOpen));
      ctx.shadowColor = color;
      ctx.shadowBlur = 6;
      ctx.globalAlpha = 0.92;
      ctx.fillStyle = color;
      ctx.fillRect(x - bodyW / 2, top, bodyW, bh);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
    });

    if (closes.length > 21) drawLine(ema(closes, 21), C.cyan, 0.75, 1.4);
    if (closes.length > 50) drawLine(ema(closes, 50), C.amber, 0.55, 1.4);

    const last = candles[candles.length - 1];
    const yLast = yOf(last.c);
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = last.c >= last.o ? C.up : C.down;
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.moveTo(padLeft, yLast);
    ctx.lineTo(w - padRight, yLast);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;

    const tagText = U.price(last.c);
    ctx.font = '600 10.5px "JetBrains Mono", monospace';
    const tagW = ctx.measureText(tagText).width + 12;
    const tagH = 17;
    const tagY = Math.min(Math.max(yLast - tagH / 2, padTop), padTop + priceH - tagH);
    ctx.fillStyle = last.c >= last.o ? C.up : C.down;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(w - padRight + 2, tagY, tagW, tagH, 4) : ctx.rect(w - padRight + 2, tagY, tagW, tagH);
    ctx.fill();
    ctx.fillStyle = '#04121f';
    ctx.textAlign = 'left';
    ctx.fillText(tagText, w - padRight + 8, tagY + 12);

    if (state.hover >= 0 && state.hover < candles.length) {
      const c = candles[state.hover];
      const x = xOf(state.hover);
      ctx.setLineDash([3, 3]);
      ctx.strokeStyle = C.cyan;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(x, padTop);
      ctx.lineTo(x, h - padBottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
      const readout = document.getElementById('chartOverlay');
      if (readout) {
        readout.innerHTML = `<span>O <b>${U.price(c.o)}</b></span><span>H <b>${U.price(c.h)}</b></span>`
          + `<span>L <b>${U.price(c.l)}</b></span><span>C <b>${U.price(c.c)}</b></span>`
          + `<span>V <b>${U.compact(c.v)}</b></span><span>${U.stamp(c.t)}</span>`;
      }
    } else {
      const readout = document.getElementById('chartOverlay');
      if (readout) {
        readout.innerHTML = `<span>O <b>${U.price(last.o)}</b></span><span>H <b>${U.price(last.h)}</b></span>`
          + `<span>L <b>${U.price(last.l)}</b></span><span>C <b>${U.price(last.c)}</b></span>`
          + `<span>V <b>${U.compact(last.v)}</b></span>`;
      }
    }

    ctx.fillStyle = C.muted;
    ctx.font = '10px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    const ticks = Math.min(6, candles.length);
    for (let i = 0; i < ticks; i += 1) {
      const idx = Math.round((candles.length - 1) * (i / Math.max(1, ticks - 1)));
      ctx.fillText(fmtTime(candles[idx].t, state.interval), xOf(idx), h - 6);
    }
  };

  const summary = () => {
    const el = document.getElementById('chartSummary');
    if (!el) return;
    const c = state.candles;
    if (!c.length) {
      el.textContent = 'Belum ada data candle untuk simbol ini.';
      return;
    }
    const first = c[0].o;
    const last = c[c.length - 1].c;
    const change = first > 0 ? ((last - first) / first) * 100 : 0;
    el.textContent = `Chart ${state.symbol} ${state.market} interval ${state.interval}: `
      + `${c.length} candle, harga terakhir ${U.price(last)}, perubahan ${U.signedPct(change, 2)} pada rentang tampil.`;
  };

  const bindHover = () => {
    const canvas = document.getElementById('marketChart');
    if (!canvas || canvas.dataset.bound === '1') return;
    canvas.dataset.bound = '1';
    const pick = (clientX) => {
      const rect = canvas.getBoundingClientRect();
      const padRight = 62;
      const plotW = rect.width - 8 - padRight;
      const ratio = (clientX - rect.left - 8) / plotW;
      const idx = Math.floor(ratio * state.candles.length);
      return Math.min(state.candles.length - 1, Math.max(0, idx));
    };
    canvas.addEventListener('mousemove', (e) => {
      if (!state.candles.length) return;
      const idx = pick(e.clientX);
      if (idx !== state.hover) {
        state.hover = idx;
        drawMarket();
      }
    });
    canvas.addEventListener('mouseleave', () => {
      state.hover = -1;
      drawMarket();
    });
    canvas.addEventListener('touchstart', (e) => {
      if (!state.candles.length || !e.touches[0]) return;
      state.hover = pick(e.touches[0].clientX);
      drawMarket();
    }, { passive: true });
    canvas.addEventListener('touchmove', (e) => {
      if (!state.candles.length || !e.touches[0]) return;
      state.hover = pick(e.touches[0].clientX);
      drawMarket();
    }, { passive: true });
    canvas.addEventListener('touchend', () => {
      state.hover = -1;
      drawMarket();
    }, { passive: true });
  };

  const market = (payload, options) => {
    const data = payload || {};
    const opts = options || {};
    const rows = Array.isArray(data.candles) ? data.candles : [];
    state.candles = rows.filter((c) => c && Number.isFinite(Number(c.c)));
    state.symbol = data.symbol || opts.symbol || '';
    state.market = data.market || opts.market || 'SPOT';
    state.interval = data.interval || opts.interval || '15m';
    state.meta = data;
    state.hover = -1;

    const label = document.getElementById('chartSymbolLabel');
    if (label) label.textContent = state.symbol ? `${state.symbol} · ${state.market}` : '—';
    const delta = document.getElementById('chartDelta');
    if (delta) {
      const change = Number(data.change_pct);
      delta.textContent = Number.isFinite(change) ? U.signedPct(change, 2) : '—';
      delta.className = U.cls(change);
    }
    const foot = document.getElementById('chartFoot');
    if (foot) {
      const ex = data.exchange ? `${data.exchange}` : '—';
      const route = data.dns_route ? ` · DNS ${data.dns_route}` : '';
      foot.textContent = `${state.interval} · ${state.candles.length} candle · ${ex}${route} · ${U.stamp(data.generated_at)}`;
    }
    bindHover();
    drawMarket();
    summary();
  };

  const render = (d) => {
    const canvas = document.getElementById('equityChart');
    const fallback = document.getElementById('chartFallback');
    const data = d || {};
    const series = Array.isArray(data.equity_curve) ? data.equity_curve
      : Array.isArray(data.equity_history) ? data.equity_history : [];
    const points = series.map((p) => (typeof p === 'number' ? p : U.safe(p && (p.equity !== undefined ? p.equity : p.value))))
      .filter((v) => Number.isFinite(v));
    if (!canvas) return;
    const { ctx, w, h } = setupCanvas(canvas);
    const C = theme();
    ctx.clearRect(0, 0, w, h);
    if (points.length < 2) {
      if (fallback) fallback.style.display = 'flex';
      return;
    }
    if (fallback) fallback.style.display = 'none';
    const max = Math.max(...points);
    const min = Math.min(...points);
    const span = max - min || Math.abs(max) * 0.01 || 1;
    const pad = 12;
    const yOf = (v) => h - pad - ((v - min) / span) * (h - pad * 2);
    const xOf = (i) => (w / (points.length - 1)) * i;
    const rising = points[points.length - 1] >= points[0];
    const color = rising ? C.up : C.down;

    ctx.strokeStyle = C.grid;
    ctx.lineWidth = 1;
    for (let g = 0; g <= 3; g += 1) {
      const y = Math.round(pad + ((h - pad * 2) / 3) * g) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, rising ? 'rgba(45,212,191,.26)' : 'rgba(251,113,133,.26)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    points.forEach((v, i) => {
      const x = xOf(i);
      const y = yOf(v);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.beginPath();
    points.forEach((v, i) => {
      const x = xOf(i);
      const y = yOf(v);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.8;
    ctx.shadowColor = color;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;

    const lx = xOf(points.length - 1);
    const ly = yOf(points[points.length - 1]);
    ctx.beginPath();
    ctx.arc(lx - 1, ly, 3, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
  };

  const redraw = () => {
    drawMarket();
    const canvas = document.getElementById('equityChart');
    if (canvas) {
      const payload = window.__aegisLastStatus || null;
      if (payload) render(payload);
    }
  };

  window.AegisChart = { market, render, redraw, state };
})();
