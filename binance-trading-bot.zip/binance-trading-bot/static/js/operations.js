(function () {
  'use strict';

  const U = window.AegisUtil;

  const rows = (payload) => {
    if (payload === null || payload === undefined) return [];
    const items = Array.isArray(payload) ? payload : payload.items;
    if (!Array.isArray(items)) return [];
    return items.filter((row) => row !== null && typeof row === 'object' && !Array.isArray(row));
  };

  const stamp = (value) => {
    if (!value) return 'Waktu belum valid';
    const d = value instanceof Date ? value : new Date(value);
    if (isNaN(d.getTime())) return 'Waktu belum valid';
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const STATUS_TEXT = {
    WAITING_SETUP: 'Menunggu setup',
    MACRO_PAUSED: 'Entry ditahan makro',
    ENTRY_READY: 'Siap entry',
    READY: 'Siap entry',
    BLOCKED: 'Diblokir gate',
    COOLDOWN: 'Cooldown',
    DISABLED: 'Nonaktif',
    RUNNING: 'Berjalan',
    SCANNING: 'Memindai'
  };

  const ACTIVITY_TEXT = {
    SCANNING: 'Memindai pasar',
    ANALYZING: 'Menganalisa kandidat',
    WAITING: 'Menunggu setup',
    COOLDOWN: 'Cooldown setelah siklus',
    IDLE: 'Siaga',
    PAUSED: 'Jeda operator',
    HALTED: 'Dihentikan'
  };

  const stateClass = (route) => {
    if (!route || route.entry_eligible === false) return 'blocked';
    if (String(route.status || '').toUpperCase() === 'WAITING_SETUP') return 'paper';
    if (String(route.execution || '').toUpperCase() === 'LIVE') return 'live';
    if (String(route.execution || '').toUpperCase() === 'SIMULATION') return 'paper';
    return 'off';
  };

  const routeLabel = (route) => {
    const market = String(route.market || '—').toUpperCase();
    const direction = String(route.direction || '').toUpperCase();
    return `${market}${direction ? ` ${direction}` : ''}`;
  };

  const renderRoutes = (routes) => {
    const list = Array.isArray(routes) ? routes : [];
    if (!list.length) {
      return '<div class="route-bubble"><div><div class="route-name">Rute belum tersedia</div>'
        + '<div class="route-detail">Telemetri pasar belum dikirim engine</div></div>'
        + '<div class="route-state"><span class="state-pill off">waiting</span></div></div>';
    }
    return list.map((route) => {
      const status = String(route.status || '').toUpperCase();
      const label = STATUS_TEXT[status] || route.reason || status || 'Aktif';
      const exec = String(route.execution || '').toUpperCase();
      const execText = exec === 'LIVE' ? 'live order' : exec === 'SIMULATION' ? 'simulasi' : exec.toLowerCase() || 'n/a';
      return `<div class="route-bubble"><div>`
        + `<div class="route-name">${U.esc(routeLabel(route))}</div>`
        + `<div class="route-detail">${U.esc(label)} · ${U.esc(execText)}</div></div>`
        + `<div class="route-state"><span class="state-pill ${stateClass(route)}">${U.esc(route.entry_eligible === false ? 'ditahan' : 'aktif')}</span>`
        + `<span class="route-note">${U.esc(route.reason || '—')}</span></div></div>`;
    }).join('');
  };

  const auditBubble = (candidate) => {
    const blockers = Array.isArray(candidate.blockers) ? candidate.blockers
      : Array.isArray(candidate.reasons) ? candidate.reasons : [];
    const score = candidate.score !== undefined ? Number(candidate.score) : null;
    const scoreText = score !== null && Number.isFinite(score) ? score.toFixed(2) : '—';
    const items = blockers.slice(0, 4).map((b) => `<li>${U.esc(b)}</li>`).join('');
    return `<div class="audit-row"><div class="audit-head">`
      + `<span class="audit-symbol">${U.esc(candidate.symbol || '—')}</span>`
      + `<span class="audit-score">${U.esc(String(candidate.market || 'SPOT'))} · ${U.esc(scoreText)}</span></div>`
      + (items ? `<ul class="audit-reasons">${items}</ul>` : '<div class="route-note" style="margin-top:6px">Tidak ada blocker tercatat</div>')
      + '</div>';
  };

  const renderCandidates = (candidates) => {
    const list = Array.isArray(candidates) ? candidates.filter((c) => c && typeof c === 'object') : [];
    if (!list.length) {
      return '<div class="route-note">Tidak ada kandidat yang ditolak pada siklus ini.</div>';
    }
    const visible = list.slice(0, 3);
    const rest = list.slice(3);
    const prev = U.$('#remainingCandidates');
    const wasOpen = Boolean(prev && prev.open);
    let html = visible.map(auditBubble).join('');
    if (rest.length) {
      html += `<details id="remainingCandidates"${wasOpen ? ' open' : ''}>`
        + `<summary class="route-note" style="cursor:pointer;margin-top:8px">Lihat ${rest.length} kandidat lainnya</summary>`
        + `<div class="audit-stream" style="margin-top:8px">${rest.map(auditBubble).join('')}</div></details>`;
    }
    return html;
  };

  const render = (data) => {
    const ops = data && typeof data === 'object' ? data.market_operations : null;
    const freshness = U.$('#operationsFreshness');

    if (!ops || typeof ops !== 'object') {
      U.setText('executionMode', 'MENUNGGU API BARU');
      U.setText('botActivity', 'Menunggu telemetri mesin');
      U.setHTML('marketRoutes', renderRoutes([]));
      U.setHTML('candidateAudit', '<div class="route-note">Belum ada data kandidat.</div>');
      U.setText('remainingCandidates', '');
      if (freshness) freshness.hidden = false;
      return;
    }

    const mode = String(ops.mode || 'PAPER').toUpperCase();
    const modeText = mode === 'PAPER' ? 'PAPER · SIMULASI' : mode === 'LIVE' ? 'LIVE · ORDER NYATA' : mode;
    U.setText('executionMode', modeText);

    const activity = String(ops.activity || 'IDLE').toUpperCase();
    U.setText('botActivity', ACTIVITY_TEXT[activity] || U.esc(activity));

    U.setHTML('marketRoutes', renderRoutes(ops.routes));
    U.setHTML('candidateAudit', renderCandidates(ops.candidates));

    const evaluated = Number(ops.evaluated_count);
    const executed = Number(ops.executed_count);

    const facts = [
      ['Data market', String(ops.data_market || '—')],
      ['Host data', String(ops.data_host || '—')],
      ['Timeframe', Array.isArray(ops.timeframes) ? ops.timeframes.join(' / ') : '—'],
      ['Leverage', ops.configured_leverage !== undefined ? `${Number(ops.configured_leverage)}x` : '—'],
      ['Evaluasi', Number.isFinite(evaluated) ? `${evaluated} kandidat` : '—'],
      ['Eksekusi', Number.isFinite(executed) ? `${executed} order` : '—'],
      ['Snapshot', stamp(ops.snapshot_at)]
    ];
    U.setHTML('opsFacts', facts.map(([k, v]) => `<div class="fact"><span>${U.esc(k)}</span><b>${U.esc(v)}</b></div>`).join(''));

    const noticeEl = U.$('#opsNotice');
    if (noticeEl) {
      const notice = ops.execution_notice || ops.futures_notice || '';
      noticeEl.textContent = notice;
      noticeEl.hidden = !notice;
    }

    if (freshness) {
      freshness.hidden = true;
      freshness.className = 'freshness';
    }
  };

  const stale = (flag) => {
    const el = U.$('#operationsFreshness');
    if (!el) return;
    if (flag) {
      el.hidden = false;
      el.textContent = 'Koneksi terputus · data terakhir ditahan';
      el.className = 'freshness stale';
    } else {
      el.hidden = true;
      el.className = 'freshness';
    }
  };

  window.AegisOperations = { render, stale, rows, stamp };
})();
