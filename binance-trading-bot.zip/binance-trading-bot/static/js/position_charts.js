/* Live position charts for the Ringkasan view.
 * Consumes /ws/positions (1 Hz tape + 30 s candle refresh) and falls back to
 * /api/positions/charts polling when the socket is unavailable. */
(function () {
  'use strict';

  const U = window.AegisUtil || {};
  const state = {
    interval: '1m',
    positions: new Map(),
    socket: null,
    connected: false,
    retries: 0,
    reconnectTimer: 0,
    pollTimer: 0,
    lastChartsAt: 0,
    lastTickAt: 0
  };

  const $ = (id) => document.getElementById(id);
  const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const price = (v) => (U.price ? U.price(v) : (num(v) === null ? '—' : Number(v).toFixed(6)));
  const money = (v) => (U.money ? U.money(v) : `$${(num(v) || 0).toFixed(2)}`);
  const signed = (v, digits) => {
    const n = num(v) || 0;
    const sign = n > 0 ? '+' : '';
    return `${sign}${n.toFixed(digits === undefined ? 2 : digits)}`;
  };
  const stamp = (v) => {
    if (U.stamp) return U.stamp(v);
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? '—' : d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  const esc = (v) => (U.esc ? U.esc(v) : String(v === undefined || v === null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  const symbolLabel = (symbol) => {
    if (!symbol) return '—';
    const quotes = ['USDT', 'USDC', 'FDUSD', 'USD'];
    for (let i = 0; i < quotes.length; i += 1) {
      if (symbol.endsWith(quotes[i])) return `${symbol.slice(0, -quotes[i].length)}/${quotes[i]}`;
    }
    return symbol;
  };

  const cssVar = (name, fallback) => {
    const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return value || fallback;
  };

  const theme = () => ({
    up: cssVar('--teal', '#2dd4bf'),
    down: cssVar('--rose', '#fb7185'),
    cyan: cssVar('--cyan', '#22d3ee'),
    amber: cssVar('--amber', '#f5b544'),
    ink: cssVar('--ink', '#e8f0fb'),
    muted: cssVar('--muted', '#7e90a8'),
    grid: cssVar('--hairline', 'rgba(120,180,235,.14)')
  });

  const tvBadge = (row) => {
    const tv = row.tv || {};
    const direction = row.direction === 'SHORT' ? 'SHORT' : 'LONG';
    const bias = tv.bias || 'UNKNOWN';
    const score = num(tv.score);
    const aligned = tv.aligned || {};
    if (!tv.fetched_at && !tv.fetched_ts) return { text: 'TV MEMUAT', tone: 'warn' };
    if (bias === direction && (aligned[direction] || 0) >= 2) {
      return { text: `TV SEPAKAT ${score === null ? '' : score.toFixed(2)}`, tone: 'ok' };
    }
    if (bias !== 'NEUTRAL' && bias !== direction) {
      return { text: `TV KONFLIK ${score === null ? '' : score.toFixed(2)}`, tone: 'bad' };
    }
    return { text: `TV NETRAL ${score === null ? '' : score.toFixed(2)}`, tone: 'warn' };
  };

  const makeCard = (row) => {
    const article = document.createElement('article');
    article.className = 'position-chart-card';
    article.dataset.symbol = row.symbol;
    article.innerHTML = `
      <div class="pc-head">
        <div class="pc-symbol">
          <b>${esc(symbolLabel(row.symbol))}</b>
          <span class="pc-badge ${row.direction === 'SHORT' ? 'short' : 'long'}">${esc(row.direction)}</span>
          <span class="pc-tv" data-role="tv">TV —</span>
          <span class="pc-tv" data-role="local">LOKAL —</span>
        </div>
        <div class="pc-pnl" data-role="pnl">$0.00<small>0.00%</small></div>
      </div>
      <div class="pc-canvas-wrap">
        <canvas aria-label="Live chart ${esc(row.symbol)}"></canvas>
        <div class="pc-canvas-note" data-role="note">Memuat candle…</div>
      </div>
      <div class="pc-levels">
        <span class="entry">ENTRY <b data-role="entry">—</b></span>
        <span class="tp">TP1 <b data-role="tp1">—</b></span>
        <span class="sl">SL <b data-role="sl">—</b></span>
        <span>ROI <b data-role="roi">—</b></span>
      </div>
      <div class="pc-foot">
        <span class="pc-trail" data-role="trail">verifikasi menunggu…</span>
        <span class="pc-live"><i></i><span data-role="live">live</span></span>
      </div>`;
    const wrap = article.querySelector('.pc-canvas-wrap');
    if (window.ResizeObserver) {
      const observer = new ResizeObserver(() => {
        const record = state.positions.get(row.symbol);
        if (record) draw(record);
      });
      observer.observe(wrap);
    }
    return article;
  };

  const draw = (record) => {
    const card = record.el;
    if (!card) return;
    const canvas = card.querySelector('canvas');
    const note = card.querySelector('[data-role="note"]');
    if (!canvas) return;
    const candles = record.candles || [];
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.floor(rect.width));
    const height = Math.max(1, Math.floor(rect.height));
    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    if (!candles.length) {
      if (note) note.classList.add('show');
      return;
    }
    if (note) note.classList.remove('show');

    const C = theme();
    const padTop = 10;
    const padBottom = 18;
    const padLeft = 4;
    const padRight = 52;
    const plotW = Math.max(10, width - padLeft - padRight);
    const plotH = Math.max(10, height - padTop - padBottom);
    const entry = num(record.entry_price) || 0;
    const stop = num(record.stop_loss_price) || 0;
    const tp1 = num(record.take_profit_1) || 0;
    const tp2 = num(record.take_profit_2) || 0;

    let low = Math.min(...candles.map((c) => c.l));
    let high = Math.max(...candles.map((c) => c.h));
    [entry, stop, tp1, tp2].forEach((level) => {
      if (level > 0) {
        low = Math.min(low, level);
        high = Math.max(high, level);
      }
    });
    const span = high - low || Math.max(high * 0.002, 1e-9);
    high += span * 0.06;
    low -= span * 0.06;
    const yOf = (value) => padTop + plotH - ((value - low) / (high - low)) * plotH;
    const step = plotW / candles.length;
    const bodyW = Math.max(1.5, Math.min(9, step * 0.62));
    const xOf = (index) => padLeft + step * index + step / 2;

    ctx.strokeStyle = C.grid;
    ctx.lineWidth = 1;
    for (let g = 0; g <= 3; g += 1) {
      const y = Math.round(padTop + (plotH / 3) * g) + 0.5;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
      ctx.fillStyle = C.muted;
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(price(high - ((high - low) / 3) * g), width - padRight + 5, y + 3);
    }

    candles.forEach((candle, index) => {
      const up = candle.c >= candle.o;
      const color = up ? C.up : C.down;
      const x = xOf(index);
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, yOf(candle.h));
      ctx.lineTo(Math.round(x) + 0.5, yOf(candle.l));
      ctx.stroke();
      const top = Math.min(yOf(candle.o), yOf(candle.c));
      const bodyH = Math.max(1.2, Math.abs(yOf(candle.c) - yOf(candle.o)));
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.9;
      ctx.fillRect(x - bodyW / 2, top, bodyW, bodyH);
      ctx.globalAlpha = 1;
    });

    const level = (value, color, label, dash) => {
      if (!(value > 0) || value < low || value > high) return;
      const y = Math.round(yOf(value)) + 0.5;
      ctx.setLineDash(dash || [4, 4]);
      ctx.strokeStyle = color;
      ctx.globalAlpha = 0.75;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(width - padRight, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
      ctx.fillStyle = color;
      ctx.font = '8.5px "JetBrains Mono", monospace';
      ctx.textAlign = 'right';
      ctx.fillText(label, width - padRight - 4, y - 3);
    };
    level(entry, C.cyan, 'ENTRY', [5, 4]);
    level(tp1, C.up, 'TP1', [3, 4]);
    level(tp2, C.up, 'TP2', [2, 5]);
    level(stop, C.down, 'SL', [3, 4]);

    const last = candles[candles.length - 1];
    const lastY = Math.round(yOf(last.c)) + 0.5;
    ctx.setLineDash([2, 3]);
    ctx.strokeStyle = last.c >= last.o ? C.up : C.down;
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.moveTo(padLeft, lastY);
    ctx.lineTo(width - padRight, lastY);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;

    const tag = price(last.c);
    ctx.font = '600 9.5px "JetBrains Mono", monospace';
    const tagW = ctx.measureText(tag).width + 10;
    const tagH = 15;
    const tagY = Math.min(Math.max(lastY - tagH / 2, padTop), padTop + plotH - tagH);
    ctx.fillStyle = last.c >= last.o ? C.up : C.down;
    if (ctx.roundRect) {
      ctx.beginPath();
      ctx.roundRect(width - padRight + 1, tagY, tagW, tagH, 3);
      ctx.fill();
    } else {
      ctx.fillRect(width - padRight + 1, tagY, tagW, tagH);
    }
    ctx.fillStyle = '#04121f';
    ctx.textAlign = 'left';
    ctx.fillText(tag, width - padRight + 6, tagY + 10.5);

    ctx.fillStyle = C.muted;
    ctx.font = '9px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    const ticks = Math.min(4, candles.length);
    for (let i = 0; i < ticks; i += 1) {
      const index = Math.round((candles.length - 1) * (i / Math.max(1, ticks - 1)));
      const when = new Date(candles[index].t);
      if (Number.isNaN(when.getTime())) continue;
      ctx.fillText(when.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }), xOf(index), height - 5);
    }
  };

  const paintCard = (record) => {
    const card = record.el;
    if (!card) return;
    const pnlEl = card.querySelector('[data-role="pnl"]');
    const pnl = num(record.unrealized_pnl_usdt) || 0;
    const pct = num(record.unrealized_pnl_pct) || 0;
    const tone = pnl > 0 ? 'up' : pnl < 0 ? 'down' : 'flat';
    if (pnlEl) {
      pnlEl.className = `pc-pnl ${tone}`;
      pnlEl.innerHTML = `${pnl >= 0 ? '+' : ''}${money(pnl)}<small>${signed(pct, 2)}%</small>`;
    }
    const set = (role, value) => {
      const el = card.querySelector(`[data-role="${role}"]`);
      if (el) el.textContent = value;
    };
    set('entry', price(record.entry_price));
    set('tp1', price(record.take_profit_1));
    set('sl', price(record.stop_loss_price));
    set('roi', `${signed(pct, 2)}%`);
    const badge = tvBadge(record);
    const tvEl = card.querySelector('[data-role="tv"]');
    if (tvEl) {
      tvEl.textContent = badge.text;
      tvEl.dataset.state = badge.tone;
    }
    const localEl = card.querySelector('[data-role="local"]');
    if (localEl) {
      const local = record.verification && record.verification.local ? record.verification.local : record.local;
      const localScore = local ? Number(local.score) * (record.direction === 'SHORT' ? -1 : 1) : null;
      if (localScore === null || !Number.isFinite(localScore)) {
        localEl.textContent = 'LOKAL —';
        localEl.dataset.state = '';
      } else {
        localEl.textContent = `LOKAL ${localScore >= 0.12 ? '✓' : localScore <= -0.12 ? '✗' : '~'} ${localScore.toFixed(2)}`;
        localEl.dataset.state = localScore >= 0.12 ? 'ok' : localScore <= -0.12 ? 'bad' : 'warn';
      }
    }
    const trail = record.trail && record.trail[0];
    if (trail) {
      set('trail', `${String(trail.event || '').replace(/_/g, ' ')} · ${stamp(trail.ts)}`);
    }
    const liveEl = card.querySelector('[data-role="live"]');
    if (liveEl) liveEl.textContent = state.connected ? 'live 1s' : 'polling';
  };

  const rebuild = () => {
    const grid = $('positionCharts');
    if (!grid) return;
    const symbols = Array.from(state.positions.keys());
    Array.from(grid.querySelectorAll('.position-chart-card')).forEach((el) => {
      if (!state.positions.has(el.dataset.symbol)) el.remove();
    });
    const empty = $('positionEmpty');
    if (!symbols.length) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    let index = 0;
    symbols.forEach((symbol) => {
      const record = state.positions.get(symbol);
      if (!record.el) record.el = makeCard(record);
      if (record.el.parentNode !== grid) grid.appendChild(record.el);
      paintCard(record);
      draw(record);
      index += 1;
    });
    const meta = $('positionLiveMeta');
    if (meta) meta.textContent = `${index} posisi · ${state.interval} · ${state.connected ? 'stream 1s' : 'polling'}`;
    const summary = $('positionLiveSummary');
    if (summary) {
      summary.textContent = `${index} posisi terbuka dipantau: ` + symbols.map((s) => {
        const record = state.positions.get(s);
        return `${symbolLabel(s)} ${record.direction} harga ${price(record.current_price)}`;
      }).join(', ');
    }
  };

  const applyCharts = (rows, interval) => {
    if (interval && interval !== state.interval) return;
    const next = new Map();
    (rows || []).forEach((row) => {
      if (!row || !row.symbol) return;
      const previous = state.positions.get(row.symbol) || {};
      next.set(row.symbol, {
        ...previous,
        ...row,
        candles: Array.isArray(row.candles) && row.candles.length ? row.candles : (previous.candles || []),
        el: previous.el || null
      });
    });
    state.positions = next;
    rebuild();
  };

  const applyTick = (rows) => {
    if (!Array.isArray(rows) || !rows.length) return;
    state.lastTickAt = Date.now();
    rows.forEach((row) => {
      if (!row || !row.symbol) return;
      const record = state.positions.get(row.symbol);
      if (!record) {
        state.positions.set(row.symbol, { ...row, candles: [], el: null });
        return;
      }
      Object.assign(record, row);
      const candles = record.candles || [];
      const current = num(row.current_price);
      if (current !== null && candles.length) {
        const last = candles[candles.length - 1];
        const now = Date.now();
        if (now - Number(last.t) > 60000) {
          candles.push({ t: now, o: current, h: current, l: current, c: current, v: 0 });
        } else {
          last.c = current;
          last.h = Math.max(last.h, current);
          last.l = Math.min(last.l, current);
        }
      }
      paintCard(record);
      draw(record);
    });
    const meta = $('positionLiveMeta');
    if (meta) meta.textContent = `${state.positions.size} posisi · ${state.interval} · ${state.connected ? 'stream 1s' : 'polling'}`;
  };

  const setTvPill = (health) => {
    const pill = $('tvStatusPill');
    if (!pill || !health) return;
    const status = String(health.status || 'UNKNOWN').toUpperCase();
    pill.textContent = `TV ${status}${health.avg_latency_ms ? ` · ${Math.round(health.avg_latency_ms)}ms` : ''}`;
    pill.dataset.state = status === 'LIVE' ? 'ok' : status === 'DEGRADED' ? 'warn' : status === 'DISABLED' ? 'down' : 'warn';
  };

  const pollCharts = () => {
    clearInterval(state.pollTimer);
    state.pollTimer = setInterval(() => {
      if (state.connected || document.hidden) return;
      const controller = new AbortController();
      fetch(`/api/positions/charts?interval=${encodeURIComponent(state.interval)}&limit=90`, {
        headers: { Accept: 'application/json' },
        signal: controller.signal
      })
        .then((res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.json();
        })
        .then((data) => {
          applyCharts(data.positions || [], data.interval || state.interval);
          setTvPill(data.tv_health);
        })
        .catch(() => {})
        .finally(() => { clearTimeout(controller.__timeout); });
    }, 5000);
  };

  const connect = () => {
    if (state.socket || document.hidden) return;
    const protocol = window.location.protocol === 'https:' ? 'wss://' : 'ws://';
    let socket;
    try {
      socket = new WebSocket(`${protocol}${window.location.host}/ws/positions`);
    } catch (err) {
      scheduleReconnect();
      return;
    }
    state.socket = socket;
    socket.onopen = () => {
      state.connected = true;
      state.retries = 0;
    };
    socket.onmessage = (event) => {
      let payload;
      try {
        payload = JSON.parse(event.data);
      } catch (err) {
        return;
      }
      if (!payload || !payload.type) return;
      state.lastChartsAt = Date.now();
      if (payload.type === 'charts') {
        setTvPill(payload.tv_health);
        applyCharts(payload.positions || [], payload.interval || state.interval);
      } else if (payload.type === 'tick') {
        applyTick(payload.positions || []);
      } else if (payload.type === 'empty') {
        state.positions = new Map();
        rebuild();
      }
    };
    socket.onclose = () => {
      state.connected = false;
      state.socket = null;
      rebuild();
      scheduleReconnect();
    };
    socket.onerror = () => {
      try { socket.close(); } catch (err) { /* noop */ }
    };
  };

  const scheduleReconnect = () => {
    clearTimeout(state.reconnectTimer);
    state.retries += 1;
    const delay = Math.min(5000, 600 + state.retries * 700);
    state.reconnectTimer = setTimeout(connect, delay);
  };

  const disconnect = () => {
    clearTimeout(state.reconnectTimer);
    if (state.socket) {
      const socket = state.socket;
      state.socket = null;
      state.connected = false;
      try { socket.close(); } catch (err) { /* noop */ }
    }
  };

  const loadInterval = (interval) => {
    state.interval = interval;
    document.querySelectorAll('#positionIntervals .chip').forEach((chip) => {
      chip.setAttribute('aria-pressed', chip.dataset.interval === interval ? 'true' : 'false');
    });
    fetch(`/api/positions/charts?interval=${encodeURIComponent(interval)}&limit=90`, {
      headers: { Accept: 'application/json' }
    })
      .then((res) => res.json())
      .then((data) => {
        applyCharts(data.positions || [], interval);
        setTvPill(data.tv_health);
      })
      .catch(() => {});
  };

  const init = () => {
    if (!$('positionCharts')) return;
    const group = $('positionIntervals');
    if (group) {
      group.addEventListener('click', (event) => {
        const chip = event.target.closest('.chip');
        if (chip && chip.dataset.interval) loadInterval(chip.dataset.interval);
      });
    }
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) disconnect();
      else connect();
    });
    connect();
    pollCharts();
    loadInterval('1m');
  };

  window.AegisPositions = { init, state };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
