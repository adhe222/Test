import json
import os
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DATA_DIR = Path(os.getenv("BOT_DATA_DIR", "data"))
HISTORY_PATH = DATA_DIR / "trade_history.json"
PORTFOLIO_PATH = DATA_DIR / "portfolio.json"
JOURNAL_PATH = DATA_DIR / "review_journal.json"

JOURNAL_LIMIT = 200
SAMPLE_FLOOR = 20
DIRECTIONS = ("LONG", "SHORT")


def _load_json(path: Path, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def _parse_time(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


class TradeReviewer:
    def __init__(
        self,
        history_path: Optional[Path] = None,
        portfolio_path: Optional[Path] = None,
        journal_path: Optional[Path] = None,
    ):
        self.history_path = Path(history_path or HISTORY_PATH)
        self.portfolio_path = Path(portfolio_path or PORTFOLIO_PATH)
        self.journal_path = Path(journal_path or JOURNAL_PATH)

    def _scoped(self, events: List[Dict[str, Any]], since: Optional[datetime]) -> List[Dict[str, Any]]:
        if since is None:
            return list(events)
        kept = []
        for event in events:
            stamp = _parse_time(event.get("exit_time") or event.get("entry_time"))
            if stamp is None or stamp >= since:
                kept.append(event)
        return kept

    def _grade(self, event: Dict[str, Any]) -> Dict[str, Any]:
        pnl = _number(event.get("pnl_usdt"))
        gross = _number(event.get("gross_pnl_usdt"))
        fee = _number(event.get("fee_paid_usdt"))
        pct = _number(event.get("pnl_pct"))
        reason = str(event.get("reason") or "")
        direction = str(event.get("direction") or "")
        entry_time = _parse_time(event.get("entry_time"))
        exit_time = _parse_time(event.get("exit_time"))
        hold_minutes = None
        if entry_time and exit_time:
            hold_minutes = round((exit_time - entry_time).total_seconds() / 60.0, 2)

        flags = set()
        if not reason:
            flags.add("MISSING_EXIT_REASON")
        if hold_minutes is None:
            flags.add("MISSING_TIMESTAMPS")
        elif hold_minutes < 1.0:
            flags.add("SUB_MINUTE_HOLD")
        if direction not in DIRECTIONS:
            flags.add("MISSING_DIRECTION")
        if reason.startswith("TAKE_PROFIT") and gross <= 0:
            flags.add("DEGENERATE_TARGET")
        if gross == 0 and pnl < 0:
            flags.add("FEE_ONLY_LOSS")
        if pnl < 0 and fee > 0 and abs(pnl) <= fee * 1.05:
            flags.add("FEE_DOMINATED")
        if reason.startswith("TAKE_PROFIT") and abs(pct) < 0.25:
            flags.add("FEE_DOMINATED")

        if pnl > 0:
            outcome = "WIN"
        elif pnl < 0:
            outcome = "LOSS"
        else:
            outcome = "SCRATCH"

        return {
            "symbol": event.get("symbol"),
            "direction": direction or None,
            "reason": reason or None,
            "outcome": outcome,
            "pnl_usdt": round(pnl, 4),
            "gross_pnl_usdt": round(gross, 4),
            "fee_paid_usdt": round(fee, 4),
            "pnl_pct": round(pct, 4),
            "hold_minutes": hold_minutes,
            "process": "CLEAN" if not flags else "DEFECT",
            "flags": sorted(flags),
            "entry_time": event.get("entry_time"),
            "exit_time": event.get("exit_time"),
        }

    @staticmethod
    def _aggregate(trades: List[Dict[str, Any]], key: str) -> List[Dict[str, Any]]:
        buckets: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for trade in trades:
            buckets[str(trade.get(key) or "UNKNOWN")].append(trade)
        rows = []
        for name, group in buckets.items():
            wins = [t["pnl_usdt"] for t in group if t["pnl_usdt"] > 0]
            losses = [t["pnl_usdt"] for t in group if t["pnl_usdt"] < 0]
            net = sum(t["pnl_usdt"] for t in group)
            rows.append({
                "key": name,
                "trades": len(group),
                "net_usdt": round(net, 4),
                "avg_usdt": round(net / len(group), 4) if group else 0.0,
                "win_rate_pct": round(len(wins) / len(group) * 100.0, 2) if group else 0.0,
                "gross_win_usdt": round(sum(wins), 4),
                "gross_loss_usdt": round(sum(losses), 4),
                "fees_usdt": round(sum(t["fee_paid_usdt"] for t in group), 4),
            })
        rows.sort(key=lambda row: (row["net_usdt"], row["trades"]))
        return rows

    def review(self, persist: bool = True) -> Dict[str, Any]:
        portfolio = _load_json(self.portfolio_path, {}) or {}
        history = _load_json(self.history_path, []) or []
        events = [event for event in history if isinstance(event, dict)]
        since = _parse_time(portfolio.get("counter_since"))
        scoped = self._scoped(events, since)

        closed = [e for e in scoped if str(e.get("action", "")).upper() == "CLOSED"]
        partials = [e for e in scoped if "PARTIAL" in str(e.get("action", "")).upper()]
        trades = [self._grade(event) for event in closed]

        fees = round(sum(_number(e.get("fee_paid_usdt")) for e in scoped), 4)
        net = round(sum(t["pnl_usdt"] for t in trades), 4)
        gross = round(sum(t["gross_pnl_usdt"] for t in trades), 4)
        wins = [t["pnl_usdt"] for t in trades if t["pnl_usdt"] > 0]
        losses = [t["pnl_usdt"] for t in trades if t["pnl_usdt"] < 0]
        wins_sum = sum(wins)
        losses_sum = abs(sum(losses))
        profit_factor = round(wins_sum / losses_sum, 3) if losses_sum > 0 else (None if wins_sum == 0 else float("inf"))
        sample = len(trades)
        fee_share = round(fees / gross * 100.0, 2) if gross > 0 else None

        defect_counts: Dict[str, int] = defaultdict(int)
        for trade in trades:
            for flag in trade["flags"]:
                defect_counts[flag] += 1

        by_reason = self._aggregate(trades, "reason")
        by_direction = self._aggregate(trades, "direction")
        by_symbol = self._aggregate(trades, "symbol")[:5]

        if sample < SAMPLE_FLOOR:
            verdict = "SAMPLE_TOO_SMALL"
        elif profit_factor is None or profit_factor < 1.0:
            verdict = "NEGATIVE_EDGE"
        elif profit_factor < 1.3:
            verdict = "FEE_BREAK_EVEN"
        else:
            verdict = "POSITIVE_EDGE"

        worst_reason = by_reason[0] if by_reason else None
        worst_direction = by_direction[0] if by_direction else None
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "scope_since": since.isoformat() if since else None,
            "sample": {
                "closed_trades": sample,
                "partial_events": len(partials),
                "events_in_scope": len(scoped),
            },
            "metrics": {
                "net_usdt": net,
                "gross_usdt": gross,
                "fees_usdt": fees,
                "fee_share_of_gross_pct": fee_share,
                "win_rate_pct": round(len(wins) / sample * 100.0, 2) if sample else 0.0,
                "wins": len(wins),
                "losses": len(losses),
                "avg_win_usdt": round(wins_sum / len(wins), 4) if wins else 0.0,
                "avg_loss_usdt": round(sum(losses) / len(losses), 4) if losses else 0.0,
                "payoff_ratio": round((wins_sum / len(wins)) / abs(sum(losses) / len(losses)), 3) if wins and losses else None,
                "profit_factor": profit_factor,
                "expectancy_usdt": round(net / sample, 4) if sample else 0.0,
            },
            "verdict": verdict,
            "defects": dict(sorted(defect_counts.items(), key=lambda kv: -kv[1])),
            "process_clean_pct": round(
                sum(1 for t in trades if t["process"] == "CLEAN") / sample * 100.0, 2
            ) if sample else 0.0,
            "worst_reason": worst_reason,
            "worst_direction": worst_direction,
            "by_reason": by_reason,
            "by_direction": by_direction,
            "by_symbol": by_symbol,
            "trades": trades,
        }

        if persist:
            self._append_journal(report)
        return report

    def _append_journal(self, report: Dict[str, Any]) -> None:
        journal = _load_json(self.journal_path, [])
        if not isinstance(journal, list):
            journal = []
        entry = {
            "reviewed_at": report["generated_at"],
            "scope_since": report["scope_since"],
            "sample": report["sample"],
            "metrics": report["metrics"],
            "verdict": report["verdict"],
            "defects": report["defects"],
            "worst_reason": (report["worst_reason"] or {}).get("key"),
            "worst_direction": (report["worst_direction"] or {}).get("key"),
        }
        journal.append(entry)
        journal = journal[-JOURNAL_LIMIT:]
        tmp = self.journal_path.with_suffix(".json.tmp")
        try:
            self.journal_path.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(journal, handle, indent=2)
            os.replace(tmp, self.journal_path)
        except OSError:
            try:
                tmp.unlink()
            except OSError:
                pass


def format_report(report: Dict[str, Any]) -> str:
    metrics = report["metrics"]
    lines = [
        f"REVIEW {report['generated_at']}  scope_since={report['scope_since']}",
        f"sample: {report['sample']['closed_trades']} closed / {report['sample']['partial_events']} partials",
        f"verdict: {report['verdict']}   process_clean: {report['process_clean_pct']}%",
        (
            f"net {metrics['net_usdt']:+.2f} USDT | gross {metrics['gross_usdt']:+.2f} | "
            f"fees {metrics['fees_usdt']:.2f} | fee_share {metrics['fee_share_of_gross_pct']}%"
        ),
        (
            f"win_rate {metrics['win_rate_pct']}% ({metrics['wins']}W/{metrics['losses']}L) | "
            f"PF {metrics['profit_factor']} | payoff {metrics['payoff_ratio']} | "
            f"expectancy {metrics['expectancy_usdt']:+.4f}/trade"
        ),
        "",
        "by exit reason:",
    ]
    for row in report["by_reason"]:
        lines.append(
            f"  {row['key']:<26} n={row['trades']:<3} net={row['net_usdt']:+8.2f} "
            f"avg={row['avg_usdt']:+6.2f} wr={row['win_rate_pct']:5.1f}%"
        )
    lines.append("")
    lines.append("by direction:")
    for row in report["by_direction"]:
        lines.append(
            f"  {row['key']:<26} n={row['trades']:<3} net={row['net_usdt']:+8.2f} "
            f"avg={row['avg_usdt']:+6.2f} wr={row['win_rate_pct']:5.1f}%"
        )
    if report["defects"]:
        lines.append("")
        lines.append("process defects:")
        for name, count in report["defects"].items():
            lines.append(f"  {name:<26} {count}")
    return "\n".join(lines)


if __name__ == "__main__":
    print(format_report(TradeReviewer().review()))
